require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function generateUUID() {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
}
exports.generateUUID = generateUUID;

},{}],3:[function(require,module,exports){
"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const SiftLib = __importStar(require("./sift"));
const stubs_1 = require("./stubs");
class FLStub {
    constructor() {
        this.thoughts = new stubs_1.ThoughtServiceStub();
        this.speech = new stubs_1.SpeechServiceStub();
        this.image = new stubs_1.ImageServiceStub();
        this.system = new stubs_1.SystemServiceStub();
        this.graph = new stubs_1.GraphServiceStub();
        this.keyValue = new stubs_1.KeyValueServiceStub();
        this.button = new stubs_1.ButtonServiceStub();
    }
}
exports.FL = (window['FL'] || new FLStub());
exports.Sift = SiftLib;

},{"./sift":5,"./stubs":13}],4:[function(require,module,exports){
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("../index");
const graphHelper = __importStar(require("@open-studio/single-page-msft-graph-helper"));
const SCOPE = 'User.Read Mail.Read Calendars.Read Group.Read.All Tasks.Read User.ReadBasic.All';
class FLGraph {
    initialize() {
        return index_1.FL.graph.updateScope(SCOPE.split(' '));
    }
    isLoggedIn() {
        return index_1.FL.graph.isLoggedIn();
    }
    logIn() {
        return index_1.FL.graph.login();
    }
    logOut() {
        return index_1.FL.graph.logout();
    }
    accessToken() {
        return __awaiter(this, void 0, void 0, function* () {
            const token = yield index_1.FL.graph.getAccessToken();
            if (token.accessToken) {
                return token.accessToken;
            }
            throw new Error('No access token');
        });
    }
}
exports.FLGraph = FLGraph;
class WebGraph {
    initialize() {
        graphHelper.initialize({
            appID: 'd539a8da-31fa-4e4a-91b8-fef148972507',
            scope: SCOPE,
        });
    }
    isLoggedIn() {
        return graphHelper.isAuthenticated();
    }
    logIn() {
        return __awaiter(this, void 0, void 0, function* () {
            console.info('calling login', graphHelper);
            yield graphHelper.login();
            return;
        });
    }
    logOut() {
        return __awaiter(this, void 0, void 0, function* () {
            return graphHelper.logout();
        });
    }
    accessToken() {
        try {
            return Promise.resolve(graphHelper.accessToken());
        }
        catch (e) {
            return Promise.reject(e);
        }
    }
}
exports.WebGraph = WebGraph;

},{"../index":3,"@open-studio/single-page-msft-graph-helper":14}],5:[function(require,module,exports){
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// determine if window.FL exists
// if it does use the graph API on it
// if it doesn't, use the hello.js lib
//
// create get for the feed
// create get for an image base 64
const query_string_1 = __importDefault(require("query-string"));
const helpers_1 = require("./helpers");
const helper = !!window['FL'] ? new helpers_1.FLGraph() : new helpers_1.WebGraph();
const BASE_URL = 'https://lookout-proto.azurewebsites.net';
// const BASE_URL = 'https://lookout.ngrok.io'
function initialize() {
    return helper.initialize();
}
exports.initialize = initialize;
function isLoggedIn() {
    return helper.isLoggedIn();
}
exports.isLoggedIn = isLoggedIn;
function logIn() {
    return helper.logIn();
}
exports.logIn = logIn;
function logOut() {
    return helper.logOut();
}
exports.logOut = logOut;
function accessToken() {
    return helper.accessToken();
}
exports.accessToken = accessToken;
function jsonAcceptHeader() {
    return { name: 'Accept', value: 'application/json' };
}
function feed(args) {
    const path = '/users/me/feed';
    let baseURL = BASE_URL;
    args = args || {};
    if (args.baseURL) {
        baseURL = args.baseURL;
        delete args.baseURL;
    }
    const timeZoneOffset = new Date().getTimezoneOffset() / -60;
    if (!args.timeZoneOffset) {
        args.timeZoneOffset = timeZoneOffset;
    }
    const url = baseURL + path;
    return makeRequest(url, { qs: args, headers: [jsonAcceptHeader()] });
}
exports.feed = feed;
function priorityContacts(args) {
    return __awaiter(this, void 0, void 0, function* () {
        const path = '/users/me/priorityContacts';
        let baseURL = BASE_URL;
        if (args && args.baseURL) {
            baseURL = args.baseURL;
            delete args.baseURL;
        }
        const url = baseURL + path;
        return makeRequest(url, { headers: [jsonAcceptHeader()] });
    });
}
exports.priorityContacts = priorityContacts;
function createPriorityContact(args) {
    return __awaiter(this, void 0, void 0, function* () {
        const path = '/users/me/priorityContacts';
        let baseURL = BASE_URL;
        args = args || {};
        if (args.baseURL) {
            baseURL = args.baseURL;
            delete args.baseURL;
        }
        const payload = { email: args.email };
        const url = baseURL + path;
        return makeRequest(url, { method: 'POST', jsonBody: payload, headers: [jsonAcceptHeader()] });
    });
}
exports.createPriorityContact = createPriorityContact;
function deletePriorityContact(args) {
    return __awaiter(this, void 0, void 0, function* () {
        let baseURL = BASE_URL;
        args = args || {};
        if (!args.email) {
            throw new Error('email is required');
        }
        const path = `/users/me/priorityContacts/${args.email}`;
        if (args.baseURL) {
            baseURL = args.baseURL;
            delete args.baseURL;
        }
        const url = baseURL + path;
        return makeRequest(url, { method: 'DELETE', headers: [jsonAcceptHeader()] });
    });
}
exports.deletePriorityContact = deletePriorityContact;
function fetchGraphImage(url) {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield makeRequest(url, { responseType: 'blob' });
        // console.info('Got result', result)
        const wURL = window.URL;
        const blobUrl = wURL.createObjectURL(result);
        return blobUrl;
    });
}
exports.fetchGraphImage = fetchGraphImage;
function makeRequest(url, options) {
    return __awaiter(this, void 0, void 0, function* () {
        console.info('Requesting', url);
        const { responseType = 'json', method = 'GET', jsonBody = null, qs = {}, headers = [] } = options || {};
        const token = yield accessToken();
        return new Promise((resolve, reject) => {
            try {
                if (qs) {
                    const value = query_string_1.default.stringify(qs);
                    if (value.length > 0)
                        url = url + '?' + value;
                }
                const request = new XMLHttpRequest();
                request.open(method, url, true);
                request.responseType = responseType;
                request.setRequestHeader('Authorization', `Bearer ${token}`);
                if (jsonBody) {
                    request.setRequestHeader('Content-Type', 'application/json');
                }
                headers.forEach((header) => {
                    request.setRequestHeader(header.name, header.value);
                });
                request.onreadystatechange = () => {
                    // console.info('Something happened', url, request.response)
                    if (request.status >= 400) {
                        reject(`Error ${request.status}`);
                        return;
                    }
                    if (request.readyState == XMLHttpRequest.DONE && request.status == 200) {
                        resolve(request.response);
                    }
                };
                let body = null;
                if (jsonBody) {
                    body = JSON.stringify(jsonBody);
                }
                request.send(body);
            }
            catch (e) {
                reject(e);
            }
        });
    });
}
exports.makeRequest = makeRequest;

},{"./helpers":4,"query-string":17}],6:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ButtonServiceStub {
    add(args) {
        return Promise.resolve();
    }
    load(args) {
        return Promise.resolve();
    }
    move(args) {
        return Promise.resolve();
    }
    remove(args) {
        return Promise.resolve();
    }
}
exports.default = ButtonServiceStub;

},{}],7:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class GraphServiceStub {
    constructor() {
        this.loggedIn = false;
    }
    isLoggedIn() {
        return Promise.resolve(this.loggedIn);
    }
    updateScope(scope) { }
    login() {
        this.loggedIn = true;
        return Promise.resolve();
    }
    logout() {
        this.loggedIn = false;
        return Promise.resolve();
    }
    get(url) {
        return Promise.resolve({
            "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#users/$entity",
            "businessPhones": [
                "+1 412 555 0109"
            ],
            "displayName": "Megan Bowen",
            "givenName": "Megan",
            "jobTitle": "Auditor",
            "mail": "MeganB@M365x214355.onmicrosoft.com",
            "mobilePhone": null,
            "officeLocation": "12/1110",
            "preferredLanguage": "en-US",
            "surname": "Bowen",
            "userPrincipalName": "MeganB@M365x214355.onmicrosoft.com",
            "id": "48d31887-5fad-4d73-a9f5-3c356e68a038"
        });
    }
    getAccessToken() {
        return Promise.resolve({ accessToken: 'this is fake' });
    }
}
exports.default = GraphServiceStub;

},{}],8:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ImageServiceStub {
    capture(args) {
        return imageToDataURL('https://picsum.photos/200/300/?random');
    }
}
exports.default = ImageServiceStub;
// https://stackoverflow.com/a/20285053/3965
function imageToDataURL(url) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.onload = () => {
            const reader = new FileReader();
            reader.onloadend = () => {
                resolve(reader.result);
            };
            reader.readAsDataURL(xhr.response);
        };
        xhr.onerror = (ev) => {
            reject(`There was an error getting the blob ${ev}`);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    });
}

},{}],9:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const helpers_1 = require("../helpers");
class KeyValueServiceStub {
    constructor() {
        this._isConnected = false;
        this.messageCallbacks = new Map();
        this.isConnectedCallbacks = new Map();
        this.deferredPromises = new Map();
    }
    isConnected() {
        return this._isConnected;
    }
    setOnMessageCallback(callback) {
        this.setupSocket();
        const uuid = helpers_1.generateUUID();
        this.messageCallbacks.set(uuid, callback);
        console.info('Added KeyValue callback. Token:', uuid);
        return uuid;
    }
    removeOnMessageCallback(token) {
        console.info('Removed On Message Callback.  Token:', token);
        this.messageCallbacks.delete(token);
    }
    setIsConnectedChangedCallback(callback) {
        const uuid = helpers_1.generateUUID();
        this.isConnectedCallbacks.set(uuid, callback);
        console.info('Added isConnected callback. Token:', uuid);
        return uuid;
    }
    removeIsConnectedChangedCallback(token) {
        console.info('Removed isConnected callback. Token:', token);
        this.isConnectedCallbacks.delete(token);
    }
    setKey(key, value) {
        console.info('set key', key, value);
        const msg = { "type": "setKey", value: { key, value } };
        const str = JSON.stringify(msg);
        if (this.socket) {
            this.socket.send(str);
        }
    }
    deleteKey(key) {
        const msg = { "type": "deleteKey", value: key };
        const str = JSON.stringify(msg);
        if (this.socket) {
            this.socket.send(str);
        }
    }
    requestKey(key) {
        this.setupSocket();
        /*
        "type": "requestKey",
                "value": key,
                "requestID": requestID
                */
        const uuid = helpers_1.generateUUID();
        const msg = {
            "type": "requestKey",
            "value": key,
            "requestID": uuid
        };
        const str = JSON.stringify(msg);
        const deferred = new Deferred();
        this.deferredPromises.set(uuid, deferred);
        if (this.socket) {
            this.socket.send(str);
            return deferred.promise;
        }
        else {
            return Promise.reject('Socket not set up');
        }
    }
    onMessage(ev) {
        // console.info('Event coming in -', typeof ev.data)
        const str = ev.data;
        if (str) {
            try {
                const msg = JSON.parse(ev.data);
                this.handleJSMessage(msg);
            }
            catch (e) {
                console.error("Could not parse server message", ev.data, e);
            }
        }
        else {
            console.warn('data returned from message is not a string', typeof ev.data, ev.data);
        }
    }
    handleJSMessage(msg) {
        if (msg.requestID) {
            const deferred = this.deferredPromises.get(msg.requestID);
            this.deferredPromises.delete(msg.requestID);
            if (deferred && deferred.resolve && msg.value) {
                deferred.resolve(msg.value);
                return;
            }
        }
        this.messageCallbacks.forEach(callback => {
            callback(msg);
        });
    }
    updateIsConnected(connected) {
        this._isConnected = connected;
        this.isConnectedCallbacks.forEach(callback => {
            callback(this._isConnected);
        });
    }
    setupSocket() {
        if (this.socket) {
            return;
        }
        console.info('connecting to socket');
        // const URL = "wss://lookout.ngrok.io/socket/sift"
        const URL = "wss://lookout-proto.azurewebsites.net/socket/sift";
        this.socket = new WebSocket(URL);
        this.socket.onmessage = (e) => {
            this.onMessage(e);
        };
        this.socket.onopen = (e) => {
            console.info('connection opened to', URL, e);
            this.updateIsConnected(true);
        };
        this.socket.onclose = (e) => {
            console.info('connection closed', e);
            this.updateIsConnected(false);
        };
        this.socket.onerror = (e) => {
            console.error('connection error', e);
        };
    }
}
exports.default = KeyValueServiceStub;
class Deferred {
    constructor(callback) {
        this.promise = new Promise((resolve, reject) => {
            this.resolve = resolve;
            this.reject = reject;
            if (callback) {
                callback();
            }
        });
    }
}

},{"../helpers":2}],10:[function(require,module,exports){
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const helpers_1 = require("../helpers");
class SpeechServiceStub {
    constructor() {
        this.inputLevelCallbacks = new Map();
        this.speechRunning = false;
    }
    isRunning() {
        return this.speechRunning;
    }
    toggleRunning(callback) {
        this.speechCallback = callback;
        this.speechRunning = !this.speechRunning;
        if (this.speechIsRunningCallback) {
            this.speechIsRunningCallback(this.speechRunning);
        }
        if (this.speechRunning) {
            this.fetchText();
            this.startTimer();
        }
        else {
            this.stopTimer();
        }
        return Promise.resolve();
    }
    setIsRunningCallback(callback) {
        this.speechIsRunningCallback = callback;
    }
    setOnResultsCallback(callback) {
        console.info('setOnResultsCallback is currently stubbed');
        return helpers_1.generateUUID();
    }
    removeOnResultsCallback(token) {
        console.info('removeOnResultsCallback is currently stubbed');
    }
    fetchText() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.speechRunning)
                return;
            try {
                const response = yield fetch('https://www.randomtext.me/api/gibberish/p-1/3-17');
                const json = yield response.json();
                const textWithP = json.text_out;
                // console.info('Text Response:', json, textWithP)
                if (this.speechCallback && textWithP) {
                    const cleanText = textWithP
                        .trim()
                        .replace('<p>', '')
                        .replace('</p>', '');
                    this.speechCallback(cleanText, null);
                }
            }
            catch (error) {
                if (this.speechCallback) {
                    this.speechCallback(null, error);
                }
            }
        });
    }
    setInputLevelCallback(callback) {
        const uuid = helpers_1.generateUUID();
        this.inputLevelCallbacks.set(uuid, callback);
        console.info('Added inputLevel callback. Token:', uuid);
        return uuid;
    }
    removeInputLevelCalback(token) {
        console.info('Removed inputLevel callback. Token:', token);
        this.inputLevelCallbacks.delete(token);
    }
    startTimer() {
        if (this.intervalToken) {
            return;
        }
        this.intervalToken = setInterval(() => {
            let percent = Math.random();
            this.inputLevelCallbacks.forEach((callback) => {
                callback(percent);
            });
        }, 100);
    }
    stopTimer() {
        if (!this.intervalToken) {
            return;
        }
        clearInterval(this.intervalToken);
        this.intervalToken = undefined;
    }
}
exports.default = SpeechServiceStub;

},{"../helpers":2}],11:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class SystemServiceStub {
    performHaptic(type) {
        console.info('Perform haptic:', type);
    }
    takeSnapshot() {
        return Promise.resolve();
    }
    onShowSystemMenu(callback) {
        console.info('Set onShowSystemMenu callback');
    }
    performNavigation(args) { }
    setWindowSettings(args) {
        return Promise.resolve();
    }
    getWindowSettings(args) {
        return Promise.resolve({});
    }
    setTitle(args) {
        if (args.title) {
            document.title = args.title;
        }
        return Promise.resolve();
    }
    getLocation(args) {
        if (!navigator.geolocation) {
            return Promise.reject('Browser does not support location');
        }
        return new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition((location) => {
                if (!location) {
                    reject('Could not get location');
                }
                else {
                    resolve({
                        coordinate: { latitude: location.coords.latitude, longitude: location.coords.longitude },
                        timestamp: location.timestamp,
                        horizontalAccuracy: location.coords.accuracy,
                        speed: location.coords.speed,
                        course: location.coords.heading,
                        altitude: location.coords.altitude,
                        verticalAccuracy: location.coords.altitudeAccuracy,
                    });
                }
            });
        });
    }
}
exports.default = SystemServiceStub;

},{}],12:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ThoughtServiceStub {
    constructor() {
        this.thoughts = [{ _id: '-1', subject: 'Buy some milk' }, { _id: '-2', subject: 'Create slide deck' }];
    }
    setBucket(bucket) { }
    create(thought) {
        this.thoughts.push({ _id: `${new Date()}`, subject: thought.subject });
        if (this.thoughtsUpdatedCallback) {
            this.thoughtsUpdatedCallback(this.thoughts, null);
        }
    }
    setUpdatedCallback(callback) {
        this.thoughtsUpdatedCallback = callback;
        this.thoughtsUpdatedCallback(this.thoughts, null);
    }
    delete(id) {
        const index = this.thoughts.findIndex((thought) => {
            return thought._id == id;
        });
        if (index > -1) {
            this.thoughts.splice(index, 1);
        }
    }
}
exports.default = ThoughtServiceStub;

},{}],13:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ThoughtServiceStub_1 = require("./ThoughtServiceStub");
exports.ThoughtServiceStub = ThoughtServiceStub_1.default;
var SpeechServiceStub_1 = require("./SpeechServiceStub");
exports.SpeechServiceStub = SpeechServiceStub_1.default;
var ImageServiceStub_1 = require("./ImageServiceStub");
exports.ImageServiceStub = ImageServiceStub_1.default;
var SystemServicesStub_1 = require("./SystemServicesStub");
exports.SystemServiceStub = SystemServicesStub_1.default;
var GraphServiceStub_1 = require("./GraphServiceStub");
exports.GraphServiceStub = GraphServiceStub_1.default;
var KeyValueServiceStub_1 = require("./KeyValueServiceStub");
exports.KeyValueServiceStub = KeyValueServiceStub_1.default;
var ButtonServiceStub_1 = require("./ButtonServiceStub");
exports.ButtonServiceStub = ButtonServiceStub_1.default;

},{"./ButtonServiceStub":6,"./GraphServiceStub":7,"./ImageServiceStub":8,"./KeyValueServiceStub":9,"./SpeechServiceStub":10,"./SystemServicesStub":11,"./ThoughtServiceStub":12}],14:[function(require,module,exports){
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const hellojs_1 = __importDefault(require("hellojs"));
let config = {
    scope: 'user.read group.read.all',
    msft: {
        id: 'your-app-id',
        oauth: {
            version: 2,
            auth: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize'
        },
        scope_delim: ' ',
        form: false
    }
};
let helloObj = null;
function setHello(hello) {
    helloObj = hello;
    helloObj.init({
        // @ts-ignore
        msft: config.msft
    }, {
        redirect_uri: window.location.href
    });
}
function initialize(params) {
    config.scope = params.scope || 'user.read';
    if (!params.appID) {
        throw new Error('appID must be passed into initialize');
    }
    config.msft.id = params.appID;
    setHello(hellojs_1.default);
}
exports.initialize = initialize;
function logout() {
    if (helloObj) {
        return helloObj('msft').logout({ force: true });
    }
    else {
        throw new Error('`initialize` was never called');
    }
}
exports.logout = logout;
function login() {
    if (helloObj) {
        return helloObj('msft').login({ scope: config.scope });
    }
    else {
        throw new Error('`initialize` was never called');
    }
}
exports.login = login;
function accessToken() {
    if (!helloObj) {
        throw new Error('Has initialized been called? Hello is null.');
    }
    const msft = helloObj('msft');
    if (!msft) {
        throw new Error('Could not find msft object in hello.  Has hello been initialized?');
    }
    const authResponse = msft.getAuthResponse();
    if (!authResponse) {
        throw new Error('No auth response found.  Has user been authenticated?');
    }
    const token = authResponse.access_token;
    if (!token) {
        throw new Error('Access token not found for msft.  Has user been authenticated?');
    }
    return token;
}
exports.accessToken = accessToken;
function makeRequest(url, options) {
    return __awaiter(this, void 0, void 0, function* () {
        console.info('Requesting', url);
        const { responseType = 'json', method = 'GET', jsonBody = null } = options || {};
        return new Promise((resolve, reject) => {
            try {
                const token = accessToken();
                const request = new XMLHttpRequest();
                request.open(method, url, true);
                request.responseType = responseType;
                request.setRequestHeader('Authorization', `Bearer ${token}`);
                if (jsonBody) {
                    request.setRequestHeader('Content-Type', 'application/json');
                }
                request.onreadystatechange = () => {
                    if (request.status >= 400) {
                        reject(`Error ${request.status}`);
                        return;
                    }
                    if (request.readyState == XMLHttpRequest.DONE && request.status == 200) {
                        resolve(request.response);
                    }
                };
                let body = null;
                if (jsonBody) {
                    body = JSON.stringify(jsonBody);
                }
                request.send(body);
            }
            catch (e) {
                reject(e);
            }
        });
    });
}
exports.makeRequest = makeRequest;
function isAuthenticated() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!helloObj) {
            console.warn('helpers has not be initialized');
            return false;
        }
        const msft = helloObj('msft');
        if (!msft) {
            console.info('Could not find msft object in hello.  Has hello been initialized?');
            return false;
        }
        const authResponse = msft.getAuthResponse();
        if (!authResponse) {
            return false;
        }
        const token = authResponse.access_token;
        if (!token) {
            return false;
        }
        try {
            const profile = yield makeRequest('https://graph.microsoft.com/v1.0/me/');
            return !!profile['displayName'];
        }
        catch (e) {
            // console.error('Error checking profile to see if logged in.', e)
            return false;
        }
    });
}
exports.isAuthenticated = isAuthenticated;

},{"hellojs":16}],15:[function(require,module,exports){
'use strict';
var token = '%[a-f0-9]{2}';
var singleMatcher = new RegExp(token, 'gi');
var multiMatcher = new RegExp('(' + token + ')+', 'gi');

function decodeComponents(components, split) {
	try {
		// Try to decode the entire string first
		return decodeURIComponent(components.join(''));
	} catch (err) {
		// Do nothing
	}

	if (components.length === 1) {
		return components;
	}

	split = split || 1;

	// Split the array in 2 parts
	var left = components.slice(0, split);
	var right = components.slice(split);

	return Array.prototype.concat.call([], decodeComponents(left), decodeComponents(right));
}

function decode(input) {
	try {
		return decodeURIComponent(input);
	} catch (err) {
		var tokens = input.match(singleMatcher);

		for (var i = 1; i < tokens.length; i++) {
			input = decodeComponents(tokens, i).join('');

			tokens = input.match(singleMatcher);
		}

		return input;
	}
}

function customDecodeURIComponent(input) {
	// Keep track of all the replacements and prefill the map with the `BOM`
	var replaceMap = {
		'%FE%FF': '\uFFFD\uFFFD',
		'%FF%FE': '\uFFFD\uFFFD'
	};

	var match = multiMatcher.exec(input);
	while (match) {
		try {
			// Decode as big chunks as possible
			replaceMap[match[0]] = decodeURIComponent(match[0]);
		} catch (err) {
			var result = decode(match[0]);

			if (result !== match[0]) {
				replaceMap[match[0]] = result;
			}
		}

		match = multiMatcher.exec(input);
	}

	// Add `%C2` at the end of the map to make sure it does not replace the combinator before everything else
	replaceMap['%C2'] = '\uFFFD';

	var entries = Object.keys(replaceMap);

	for (var i = 0; i < entries.length; i++) {
		// Replace all decoded components
		var key = entries[i];
		input = input.replace(new RegExp(key, 'g'), replaceMap[key]);
	}

	return input;
}

module.exports = function (encodedURI) {
	if (typeof encodedURI !== 'string') {
		throw new TypeError('Expected `encodedURI` to be of type `string`, got `' + typeof encodedURI + '`');
	}

	try {
		encodedURI = encodedURI.replace(/\+/g, ' ');

		// Try the built in decoder first
		return decodeURIComponent(encodedURI);
	} catch (err) {
		// Fallback to a more advanced decoder
		return customDecodeURIComponent(encodedURI);
	}
};

},{}],16:[function(require,module,exports){
(function (process){
/*! hellojs v1.18.0 | (c) 2012-2019 Andrew Dodson | MIT https://adodson.com/hello.js/LICENSE */
// ES5 Object.create
if (!Object.create) {

	// Shim, Object create
	// A shim for Object.create(), it adds a prototype to a new object
	Object.create = (function() {

		function F() {}

		return function(o) {

			if (arguments.length != 1) {
				throw new Error('Object.create implementation only accepts one parameter.');
			}

			F.prototype = o;
			return new F();
		};

	})();

}

// ES5 Object.keys
if (!Object.keys) {
	Object.keys = function(o, k, r) {
		r = [];
		for (k in o) {
			if (r.hasOwnProperty.call(o, k))
				r.push(k);
		}

		return r;
	};
}

// ES5 [].indexOf
if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function(s) {

		for (var j = 0; j < this.length; j++) {
			if (this[j] === s) {
				return j;
			}
		}

		return -1;
	};
}

// ES5 [].forEach
if (!Array.prototype.forEach) {
	Array.prototype.forEach = function(fun/*, thisArg*/) {

		if (this === void 0 || this === null) {
			throw new TypeError();
		}

		var t = Object(this);
		var len = t.length >>> 0;
		if (typeof fun !== 'function') {
			throw new TypeError();
		}

		var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
		for (var i = 0; i < len; i++) {
			if (i in t) {
				fun.call(thisArg, t[i], i, t);
			}
		}

		return this;
	};
}

// ES5 [].filter
if (!Array.prototype.filter) {
	Array.prototype.filter = function(fun, thisArg) {

		var a = [];
		this.forEach(function(val, i, t) {
			if (fun.call(thisArg || void 0, val, i, t)) {
				a.push(val);
			}
		});

		return a;
	};
}

// Production steps of ECMA-262, Edition 5, 15.4.4.19
// Reference: http://es5.github.io/#x15.4.4.19
if (!Array.prototype.map) {

	Array.prototype.map = function(fun, thisArg) {

		var a = [];
		this.forEach(function(val, i, t) {
			a.push(fun.call(thisArg || void 0, val, i, t));
		});

		return a;
	};
}

// ES5 isArray
if (!Array.isArray) {

	// Function Array.isArray
	Array.isArray = function(o) {
		return Object.prototype.toString.call(o) === '[object Array]';
	};

}

// Test for location.assign
if (typeof window === 'object' && typeof window.location === 'object' && !window.location.assign) {

	window.location.assign = function(url) {
		window.location = url;
	};

}

// Test for Function.bind
if (!Function.prototype.bind) {

	// MDN
	// Polyfill IE8, does not support native Function.bind
	Function.prototype.bind = function(b) {

		if (typeof this !== 'function') {
			throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');
		}

		function C() {}

		var a = [].slice;
		var f = a.call(arguments, 1);
		var _this = this;
		var D = function() {
			return _this.apply(this instanceof C ? this : b || window, f.concat(a.call(arguments)));
		};

		C.prototype = this.prototype;
		D.prototype = new C();

		return D;
	};

}

/**
 * @hello.js
 *
 * HelloJS is a client side Javascript SDK for making OAuth2 logins and subsequent REST calls.
 *
 * @author Andrew Dodson
 * @website https://adodson.com/hello.js/
 *
 * @copyright Andrew Dodson, 2012 - 2015
 * @license MIT: You are free to use and modify this code for any use, on the condition that this copyright notice remains.
 */

var hello = function(name) {
	return hello.use(name);
};

hello.utils = {

	// Extend the first object with the properties and methods of the second
	extend: function(r /*, a[, b[, ...]] */) {

		// Get the arguments as an array but ommit the initial item
		Array.prototype.slice.call(arguments, 1).forEach(function(a) {
			if (Array.isArray(r) && Array.isArray(a)) {
				Array.prototype.push.apply(r, a);
			}
			else if (r && (r instanceof Object || typeof r === 'object') && a && (a instanceof Object || typeof a === 'object') && r !== a) {
				for (var x in a) {
					r[x] = hello.utils.extend(r[x], a[x]);
				}
			}
			else {

				if (Array.isArray(a)) {
					// Clone it
					a = a.slice(0);
				}

				r = a;
			}
		});

		return r;
	}
};

// Core library
hello.utils.extend(hello, {

	settings: {

		// OAuth2 authentication defaults
		redirect_uri: window.location.href.split('#')[0],
		response_type: 'token',
		display: 'popup',
		state: '',

		// OAuth1 shim
		// The path to the OAuth1 server for signing user requests
		// Want to recreate your own? Checkout https://github.com/MrSwitch/node-oauth-shim
		oauth_proxy: 'https://auth-server.herokuapp.com/proxy',

		// API timeout in milliseconds
		timeout: 20000,

		// Popup Options
		popup: {
			resizable: 1,
			scrollbars: 1,
			width: 500,
			height: 550
		},

		// Default scope
		// Many services require atleast a profile scope,
		// HelloJS automatially includes the value of provider.scope_map.basic
		// If that's not required it can be removed via hello.settings.scope.length = 0;
		scope: ['basic'],

		// Scope Maps
		// This is the default module scope, these are the defaults which each service is mapped too.
		// By including them here it prevents the scope from being applied accidentally
		scope_map: {
			basic: ''
		},

		// Default service / network
		default_service: null,

		// Force authentication
		// When hello.login is fired.
		// (null): ignore current session expiry and continue with login
		// (true): ignore current session expiry and continue with login, ask for user to reauthenticate
		// (false): if the current session looks good for the request scopes return the current session.
		force: null,

		// Page URL
		// When 'display=page' this property defines where the users page should end up after redirect_uri
		// Ths could be problematic if the redirect_uri is indeed the final place,
		// Typically this circumvents the problem of the redirect_url being a dumb relay page.
		page_uri: window.location.href
	},

	// Service configuration objects
	services: {},

	// Use
	// Define a new instance of the HelloJS library with a default service
	use: function(service) {

		// Create self, which inherits from its parent
		var self = Object.create(this);

		// Inherit the prototype from its parent
		self.settings = Object.create(this.settings);

		// Define the default service
		if (service) {
			self.settings.default_service = service;
		}

		// Create an instance of Events
		self.utils.Event.call(self);

		return self;
	},

	// Initialize
	// Define the client_ids for the endpoint services
	// @param object o, contains a key value pair, service => clientId
	// @param object opts, contains a key value pair of options used for defining the authentication defaults
	// @param number timeout, timeout in seconds
	init: function(services, options) {

		var utils = this.utils;

		if (!services) {
			return this.services;
		}

		// Define provider credentials
		// Reformat the ID field
		for (var x in services) {if (services.hasOwnProperty(x)) {
			if (typeof (services[x]) !== 'object') {
				services[x] = {id: services[x]};
			}
		}}

		// Merge services if there already exists some
		utils.extend(this.services, services);

		// Update the default settings with this one.
		if (options) {
			utils.extend(this.settings, options);

			// Do this immediatly incase the browser changes the current path.
			if ('redirect_uri' in options) {
				this.settings.redirect_uri = utils.url(options.redirect_uri).href;
			}
		}

		return this;
	},

	// Login
	// Using the endpoint
	// @param network stringify       name to connect to
	// @param options object    (optional)  {display mode, is either none|popup(default)|page, scope: email,birthday,publish, .. }
	// @param callback  function  (optional)  fired on signin
	login: function() {

		// Create an object which inherits its parent as the prototype and constructs a new event chain.
		var _this = this;
		var utils = _this.utils;
		var error = utils.error;
		var promise = utils.Promise();

		// Get parameters
		var p = utils.args({network: 's', options: 'o', callback: 'f'}, arguments);

		// Local vars
		var url;

		// Get all the custom options and store to be appended to the querystring
		var qs = utils.diffKey(p.options, _this.settings);

		// Merge/override options with app defaults
		var opts = p.options = utils.merge(_this.settings, p.options || {});

		// Merge/override options with app defaults
		opts.popup = utils.merge(_this.settings.popup, p.options.popup || {});

		// Network
		p.network = p.network || _this.settings.default_service;

		// Bind callback to both reject and fulfill states
		promise.proxy.then(p.callback, p.callback);

		// Trigger an event on the global listener
		function emit(s, value) {
			hello.emit(s, value);
		}

		promise.proxy.then(emit.bind(this, 'auth.login auth'), emit.bind(this, 'auth.failed auth'));

		// Is our service valid?
		if (typeof (p.network) !== 'string' || !(p.network in _this.services)) {
			// Trigger the default login.
			// Ahh we dont have one.
			return promise.reject(error('invalid_network', 'The provided network was not recognized'));
		}

		var provider = _this.services[p.network];

		// Create a global listener to capture events triggered out of scope
		var callbackId = utils.globalEvent(function(obj) {

			// The responseHandler returns a string, lets save this locally
			if (obj) {
				if (typeof (obj) == 'string') {
					obj = JSON.parse(obj);
				}
			}
			else {
				obj = error('cancelled', 'The authentication was not completed');
			}

			// Handle these response using the local
			// Trigger on the parent
			if (!obj.error) {

				// Save on the parent window the new credentials
				// This fixes an IE10 bug i think... atleast it does for me.
				utils.store(obj.network, obj);

				// Fulfill a successful login
				promise.fulfill({
					network: obj.network,
					authResponse: obj
				});
			}
			else {
				// Reject a successful login
				promise.reject(obj);
			}
		});

		var redirectUri = utils.url(opts.redirect_uri).href;

		// May be a space-delimited list of multiple, complementary types
		var responseType = provider.oauth.response_type || opts.response_type;

		// Fallback to token if the module hasn't defined a grant url
		if (/\bcode\b/.test(responseType) && !provider.oauth.grant) {
			responseType = responseType.replace(/\bcode\b/, 'token');
		}

		// Query string parameters, we may pass our own arguments to form the querystring
		p.qs = utils.merge(qs, {
			client_id: encodeURIComponent(provider.id),
			response_type: encodeURIComponent(responseType),
			redirect_uri: encodeURIComponent(redirectUri),
			state: {
				client_id: provider.id,
				network: p.network,
				display: opts.display,
				callback: callbackId,
				state: opts.state,
				redirect_uri: redirectUri
			}
		});

		// Get current session for merging scopes, and for quick auth response
		var session = utils.store(p.network);

		// Scopes (authentication permisions)
		// Ensure this is a string - IE has a problem moving Arrays between windows
		// Append the setup scope
		var SCOPE_SPLIT = /[,\s]+/;

		// Include default scope settings (cloned).
		var scope = _this.settings.scope ? [_this.settings.scope.toString()] : [];

		// Extend the providers scope list with the default
		var scopeMap = utils.merge(_this.settings.scope_map, provider.scope || {});

		// Add user defined scopes...
		if (opts.scope) {
			scope.push(opts.scope.toString());
		}

		// Append scopes from a previous session.
		// This helps keep app credentials constant,
		// Avoiding having to keep tabs on what scopes are authorized
		if (session && 'scope' in session && session.scope instanceof String) {
			scope.push(session.scope);
		}

		// Join and Split again
		scope = scope.join(',').split(SCOPE_SPLIT);

		// Format remove duplicates and empty values
		scope = utils.unique(scope).filter(filterEmpty);

		// Save the the scopes to the state with the names that they were requested with.
		p.qs.state.scope = scope.join(',');

		// Map scopes to the providers naming convention
		scope = scope.map(function(item) {
			// Does this have a mapping?
			return (item in scopeMap) ? scopeMap[item] : item;
		});

		// Stringify and Arrayify so that double mapped scopes are given the chance to be formatted
		scope = scope.join(',').split(SCOPE_SPLIT);

		// Again...
		// Format remove duplicates and empty values
		scope = utils.unique(scope).filter(filterEmpty);

		// Join with the expected scope delimiter into a string
		p.qs.scope = scope.join(provider.scope_delim || ',');

		// Is the user already signed in with the appropriate scopes, valid access_token?
		if (opts.force === false) {

			if (session && 'access_token' in session && session.access_token && 'expires' in session && session.expires > ((new Date()).getTime() / 1e3)) {
				// What is different about the scopes in the session vs the scopes in the new login?
				var diff = utils.diff((session.scope || '').split(SCOPE_SPLIT), (p.qs.state.scope || '').split(SCOPE_SPLIT));
				if (diff.length === 0) {

					// OK trigger the callback
					promise.fulfill({
						unchanged: true,
						network: p.network,
						authResponse: session
					});

					// Nothing has changed
					return promise;
				}
			}
		}

		// Page URL
		if (opts.display === 'page' && opts.page_uri) {
			// Add a page location, place to endup after session has authenticated
			p.qs.state.page_uri = utils.url(opts.page_uri).href;
		}

		// Bespoke
		// Override login querystrings from auth_options
		if ('login' in provider && typeof (provider.login) === 'function') {
			// Format the paramaters according to the providers formatting function
			provider.login(p);
		}

		// Add OAuth to state
		// Where the service is going to take advantage of the oauth_proxy
		if (!/\btoken\b/.test(responseType) ||
		parseInt(provider.oauth.version, 10) < 2 ||
		(opts.display === 'none' && provider.oauth.grant && session && session.refresh_token)) {

			// Add the oauth endpoints
			p.qs.state.oauth = provider.oauth;

			// Add the proxy url
			p.qs.state.oauth_proxy = opts.oauth_proxy;

		}

		// Convert state to a string
		p.qs.state = encodeURIComponent(JSON.stringify(p.qs.state));

		// URL
		if (parseInt(provider.oauth.version, 10) === 1) {

			// Turn the request to the OAuth Proxy for 3-legged auth
			url = utils.qs(opts.oauth_proxy, p.qs, encodeFunction);
		}

		// Refresh token
		else if (opts.display === 'none' && provider.oauth.grant && session && session.refresh_token) {

			// Add the refresh_token to the request
			p.qs.refresh_token = session.refresh_token;

			// Define the request path
			url = utils.qs(opts.oauth_proxy, p.qs, encodeFunction);
		}
		else {
			url = utils.qs(provider.oauth.auth, p.qs, encodeFunction);
		}

		// Broadcast this event as an auth:init
		emit('auth.init', p);

		// Execute
		// Trigger how we want self displayed
		if (opts.display === 'none') {
			// Sign-in in the background, iframe
			utils.iframe(url, redirectUri);
		}

		// Triggering popup?
		else if (opts.display === 'popup') {

			var popup = utils.popup(url, redirectUri, opts.popup);

			var timer = setInterval(function() {
				if (!popup || popup.closed) {
					clearInterval(timer);
					if (!promise.state) {

						var response = error('cancelled', 'Login has been cancelled');

						if (!popup) {
							response = error('blocked', 'Popup was blocked');
						}

						response.network = p.network;

						promise.reject(response);
					}
				}
			}, 100);
		}

		else {
			window.location = url;
		}

		return promise.proxy;

		function encodeFunction(s) {return s;}

		function filterEmpty(s) {return !!s;}
	},

	// Remove any data associated with a given service
	// @param string name of the service
	// @param function callback
	logout: function() {

		var _this = this;
		var utils = _this.utils;
		var error = utils.error;

		// Create a new promise
		var promise = utils.Promise();

		var p = utils.args({name:'s', options: 'o', callback: 'f'}, arguments);

		p.options = p.options || {};

		// Add callback to events
		promise.proxy.then(p.callback, p.callback);

		// Trigger an event on the global listener
		function emit(s, value) {
			hello.emit(s, value);
		}

		promise.proxy.then(emit.bind(this, 'auth.logout auth'), emit.bind(this, 'error'));

		// Network
		p.name = p.name || this.settings.default_service;
		p.authResponse = utils.store(p.name);

		if (p.name && !(p.name in _this.services)) {

			promise.reject(error('invalid_network', 'The network was unrecognized'));

		}
		else if (p.name && p.authResponse) {

			// Define the callback
			var callback = function(opts) {

				// Remove from the store
				utils.store(p.name, null);

				// Emit events by default
				promise.fulfill(hello.utils.merge({network:p.name}, opts || {}));
			};

			// Run an async operation to remove the users session
			var _opts = {};
			if (p.options.force) {
				var logout = _this.services[p.name].logout;
				if (logout) {
					// Convert logout to URL string,
					// If no string is returned, then this function will handle the logout async style
					if (typeof (logout) === 'function') {
						logout = logout(callback, p);
					}

					// If logout is a string then assume URL and open in iframe.
					if (typeof (logout) === 'string') {
						utils.iframe(logout);
						_opts.force = null;
						_opts.message = 'Logout success on providers site was indeterminate';
					}
					else if (logout === undefined) {
						// The callback function will handle the response.
						return promise.proxy;
					}
				}
			}

			// Remove local credentials
			callback(_opts);
		}
		else {
			promise.reject(error('invalid_session', 'There was no session to remove'));
		}

		return promise.proxy;
	},

	// Returns all the sessions that are subscribed too
	// @param string optional, name of the service to get information about.
	getAuthResponse: function(service) {

		// If the service doesn't exist
		service = service || this.settings.default_service;

		if (!service || !(service in this.services)) {
			return null;
		}

		return this.utils.store(service) || null;
	},

	// Events: placeholder for the events
	events: {}
});

// Core utilities
hello.utils.extend(hello.utils, {

	// Error
	error: function(code, message) {
		return {
			error: {
				code: code,
				message: message
			}
		};
	},

	// Append the querystring to a url
	// @param string url
	// @param object parameters
	qs: function(url, params, formatFunction) {

		if (params) {

			// Set default formatting function
			formatFunction = formatFunction || encodeURIComponent;

			// Override the items in the URL which already exist
			for (var x in params) {
				var str = '([\\?\\&])' + x + '=[^\\&]*';
				var reg = new RegExp(str);
				if (url.match(reg)) {
					url = url.replace(reg, '$1' + x + '=' + formatFunction(params[x]));
					delete params[x];
				}
			}
		}

		if (!this.isEmpty(params)) {
			return url + (url.indexOf('?') > -1 ? '&' : '?') + this.param(params, formatFunction);
		}

		return url;
	},

	// Param
	// Explode/encode the parameters of an URL string/object
	// @param string s, string to decode
	param: function(s, formatFunction) {
		var b;
		var a = {};
		var m;

		if (typeof (s) === 'string') {

			formatFunction = formatFunction || decodeURIComponent;

			m = s.replace(/^[\#\?]/, '').match(/([^=\/\&]+)=([^\&]+)/g);
			if (m) {
				for (var i = 0; i < m.length; i++) {
					b = m[i].match(/([^=]+)=(.*)/);
					a[b[1]] = formatFunction(b[2]);
				}
			}

			return a;
		}
		else {

			formatFunction = formatFunction || encodeURIComponent;

			var o = s;

			a = [];

			for (var x in o) {if (o.hasOwnProperty(x)) {
				if (o.hasOwnProperty(x)) {
					a.push([x, o[x] === '?' ? '?' : formatFunction(o[x])].join('='));
				}
			}}

			return a.join('&');
		}
	},

	// Local storage facade
	store: (function() {

		var a = ['localStorage', 'sessionStorage'];
		var i = -1;
		var prefix = 'test';

		// Set LocalStorage
		var localStorage;

		while (a[++i]) {
			try {
				// In Chrome with cookies blocked, calling localStorage throws an error
				localStorage = window[a[i]];
				localStorage.setItem(prefix + i, i);
				localStorage.removeItem(prefix + i);
				break;
			}
			catch (e) {
				localStorage = null;
			}
		}

		if (!localStorage) {

			var cache = null;

			localStorage = {
				getItem: function(prop) {
					prop = prop + '=';
					var m = document.cookie.split(';');
					for (var i = 0; i < m.length; i++) {
						var _m = m[i].replace(/(^\s+|\s+$)/, '');
						if (_m && _m.indexOf(prop) === 0) {
							return _m.substr(prop.length);
						}
					}

					return cache;
				},

				setItem: function(prop, value) {
					cache = value;
					document.cookie = prop + '=' + value;
				}
			};

			// Fill the cache up
			cache = localStorage.getItem('hello');
		}

		function get() {
			var json = {};
			try {
				json = JSON.parse(localStorage.getItem('hello')) || {};
			}
			catch (e) {}

			return json;
		}

		function set(json) {
			localStorage.setItem('hello', JSON.stringify(json));
		}

		// Check if the browser support local storage
		return function(name, value, days) {

			// Local storage
			var json = get();

			if (name && value === undefined) {
				return json[name] || null;
			}
			else if (name && value === null) {
				try {
					delete json[name];
				}
				catch (e) {
					json[name] = null;
				}
			}
			else if (name) {
				json[name] = value;
			}
			else {
				return json;
			}

			set(json);

			return json || null;
		};

	})(),

	// Create and Append new DOM elements
	// @param node string
	// @param attr object literal
	// @param dom/string
	append: function(node, attr, target) {

		var n = typeof (node) === 'string' ? document.createElement(node) : node;

		if (typeof (attr) === 'object') {
			if ('tagName' in attr) {
				target = attr;
			}
			else {
				for (var x in attr) {if (attr.hasOwnProperty(x)) {
					if (typeof (attr[x]) === 'object') {
						for (var y in attr[x]) {if (attr[x].hasOwnProperty(y)) {
							n[x][y] = attr[x][y];
						}}
					}
					else if (x === 'html') {
						n.innerHTML = attr[x];
					}

					// IE doesn't like us setting methods with setAttribute
					else if (!/^on/.test(x)) {
						n.setAttribute(x, attr[x]);
					}
					else {
						n[x] = attr[x];
					}
				}}
			}
		}

		if (target === 'body') {
			(function self() {
				if (document.body) {
					document.body.appendChild(n);
				}
				else {
					setTimeout(self, 16);
				}
			})();
		}
		else if (typeof (target) === 'object') {
			target.appendChild(n);
		}
		else if (typeof (target) === 'string') {
			document.getElementsByTagName(target)[0].appendChild(n);
		}

		return n;
	},

	// An easy way to create a hidden iframe
	// @param string src
	iframe: function(src) {
		this.append('iframe', {src: src, style: {position:'absolute', left: '-1000px', bottom: 0, height: '1px', width: '1px'}}, 'body');
	},

	// Recursive merge two objects into one, second parameter overides the first
	// @param a array
	merge: function(/* Args: a, b, c, .. n */) {
		var args = Array.prototype.slice.call(arguments);
		args.unshift({});
		return this.extend.apply(null, args);
	},

	// Makes it easier to assign parameters, where some are optional
	// @param o object
	// @param a arguments
	args: function(o, args) {

		var p = {};
		var i = 0;
		var t = null;
		var x = null;

		// 'x' is the first key in the list of object parameters
		for (x in o) {if (o.hasOwnProperty(x)) {
			break;
		}}

		// Passing in hash object of arguments?
		// Where the first argument can't be an object
		if ((args.length === 1) && (typeof (args[0]) === 'object') && o[x] != 'o!') {

			// Could this object still belong to a property?
			// Check the object keys if they match any of the property keys
			for (x in args[0]) {if (o.hasOwnProperty(x)) {
				// Does this key exist in the property list?
				if (x in o) {
					// Yes this key does exist so its most likely this function has been invoked with an object parameter
					// Return first argument as the hash of all arguments
					return args[0];
				}
			}}
		}

		// Else loop through and account for the missing ones.
		for (x in o) {if (o.hasOwnProperty(x)) {

			t = typeof (args[i]);

			if ((typeof (o[x]) === 'function' && o[x].test(args[i])) || (typeof (o[x]) === 'string' && (
			(o[x].indexOf('s') > -1 && t === 'string') ||
			(o[x].indexOf('o') > -1 && t === 'object') ||
			(o[x].indexOf('i') > -1 && t === 'number') ||
			(o[x].indexOf('a') > -1 && t === 'object') ||
			(o[x].indexOf('f') > -1 && t === 'function')
			))
			) {
				p[x] = args[i++];
			}

			else if (typeof (o[x]) === 'string' && o[x].indexOf('!') > -1) {
				return false;
			}
		}}

		return p;
	},

	// Returns a URL instance
	url: function(path) {

		// If the path is empty
		if (!path) {
			return window.location;
		}

		// Chrome and FireFox support new URL() to extract URL objects
		else if (window.URL && URL instanceof Function && URL.length !== 0) {
			return new URL(path, window.location);
		}

		// Ugly shim, it works!
		else {
			var a = document.createElement('a');
			a.href = path;
			return a.cloneNode(false);
		}
	},

	diff: function(a, b) {
		return b.filter(function(item) {
			return a.indexOf(item) === -1;
		});
	},

	// Get the different hash of properties unique to `a`, and not in `b`
	diffKey: function(a, b) {
		if (a || !b) {
			var r = {};
			for (var x in a) {
				// Does the property not exist?
				if (!(x in b)) {
					r[x] = a[x];
				}
			}

			return r;
		}

		return a;
	},

	// Unique
	// Remove duplicate and null values from an array
	// @param a array
	unique: function(a) {
		if (!Array.isArray(a)) { return []; }

		return a.filter(function(item, index) {
			// Is this the first location of item
			return a.indexOf(item) === index;
		});
	},

	isEmpty: function(obj) {

		// Scalar
		if (!obj)
			return true;

		// Array
		if (Array.isArray(obj)) {
			return !obj.length;
		}
		else if (typeof (obj) === 'object') {
			// Object
			for (var key in obj) {
				if (obj.hasOwnProperty(key)) {
					return false;
				}
			}
		}

		return true;
	},

	//jscs:disable

	/*!
	 **  Thenable -- Embeddable Minimum Strictly-Compliant Promises/A+ 1.1.1 Thenable
	 **  Copyright (c) 2013-2014 Ralf S. Engelschall <http://engelschall.com>
	 **  Licensed under The MIT License <http://opensource.org/licenses/MIT>
	 **  Source-Code distributed on <http://github.com/rse/thenable>
	 */
	Promise: (function(){
		/*  promise states [Promises/A+ 2.1]  */
		var STATE_PENDING   = 0;                                         /*  [Promises/A+ 2.1.1]  */
		var STATE_FULFILLED = 1;                                         /*  [Promises/A+ 2.1.2]  */
		var STATE_REJECTED  = 2;                                         /*  [Promises/A+ 2.1.3]  */

		/*  promise object constructor  */
		var api = function (executor) {
			/*  optionally support non-constructor/plain-function call  */
			if (!(this instanceof api))
				return new api(executor);

			/*  initialize object  */
			this.id           = "Thenable/1.0.6";
			this.state        = STATE_PENDING; /*  initial state  */
			this.fulfillValue = undefined;     /*  initial value  */     /*  [Promises/A+ 1.3, 2.1.2.2]  */
			this.rejectReason = undefined;     /*  initial reason */     /*  [Promises/A+ 1.5, 2.1.3.2]  */
			this.onFulfilled  = [];            /*  initial handlers  */
			this.onRejected   = [];            /*  initial handlers  */

			/*  provide optional information-hiding proxy  */
			this.proxy = {
				then: this.then.bind(this)
			};

			/*  support optional executor function  */
			if (typeof executor === "function")
				executor.call(this, this.fulfill.bind(this), this.reject.bind(this));
		};

		/*  promise API methods  */
		api.prototype = {
			/*  promise resolving methods  */
			fulfill: function (value) { return deliver(this, STATE_FULFILLED, "fulfillValue", value); },
			reject:  function (value) { return deliver(this, STATE_REJECTED,  "rejectReason", value); },

			/*  "The then Method" [Promises/A+ 1.1, 1.2, 2.2]  */
			then: function (onFulfilled, onRejected) {
				var curr = this;
				var next = new api();                                    /*  [Promises/A+ 2.2.7]  */
				curr.onFulfilled.push(
					resolver(onFulfilled, next, "fulfill"));             /*  [Promises/A+ 2.2.2/2.2.6]  */
				curr.onRejected.push(
					resolver(onRejected,  next, "reject" ));             /*  [Promises/A+ 2.2.3/2.2.6]  */
				execute(curr);
				return next.proxy;                                       /*  [Promises/A+ 2.2.7, 3.3]  */
			}
		};

		/*  deliver an action  */
		var deliver = function (curr, state, name, value) {
			if (curr.state === STATE_PENDING) {
				curr.state = state;                                      /*  [Promises/A+ 2.1.2.1, 2.1.3.1]  */
				curr[name] = value;                                      /*  [Promises/A+ 2.1.2.2, 2.1.3.2]  */
				execute(curr);
			}
			return curr;
		};

		/*  execute all handlers  */
		var execute = function (curr) {
			if (curr.state === STATE_FULFILLED)
				execute_handlers(curr, "onFulfilled", curr.fulfillValue);
			else if (curr.state === STATE_REJECTED)
				execute_handlers(curr, "onRejected",  curr.rejectReason);
		};

		/*  execute particular set of handlers  */
		var execute_handlers = function (curr, name, value) {
			/* global process: true */
			/* global setImmediate: true */
			/* global setTimeout: true */

			/*  short-circuit processing  */
			if (curr[name].length === 0)
				return;

			/*  iterate over all handlers, exactly once  */
			var handlers = curr[name];
			curr[name] = [];                                             /*  [Promises/A+ 2.2.2.3, 2.2.3.3]  */
			var func = function () {
				for (var i = 0; i < handlers.length; i++)
					handlers[i](value);                                  /*  [Promises/A+ 2.2.5]  */
			};

			/*  execute procedure asynchronously  */                     /*  [Promises/A+ 2.2.4, 3.1]  */
			if (typeof process === "object" && typeof process.nextTick === "function")
				process.nextTick(func);
			else if (typeof setImmediate === "function")
				setImmediate(func);
			else
				setTimeout(func, 0);
		};

		/*  generate a resolver function  */
		var resolver = function (cb, next, method) {
			return function (value) {
				if (typeof cb !== "function")                            /*  [Promises/A+ 2.2.1, 2.2.7.3, 2.2.7.4]  */
					next[method].call(next, value);                      /*  [Promises/A+ 2.2.7.3, 2.2.7.4]  */
				else {
					var result;
					try { result = cb(value); }                          /*  [Promises/A+ 2.2.2.1, 2.2.3.1, 2.2.5, 3.2]  */
					catch (e) {
						next.reject(e);                                  /*  [Promises/A+ 2.2.7.2]  */
						return;
					}
					resolve(next, result);                               /*  [Promises/A+ 2.2.7.1]  */
				}
			};
		};

		/*  "Promise Resolution Procedure"  */                           /*  [Promises/A+ 2.3]  */
		var resolve = function (promise, x) {
			/*  sanity check arguments  */                               /*  [Promises/A+ 2.3.1]  */
			if (promise === x || promise.proxy === x) {
				promise.reject(new TypeError("cannot resolve promise with itself"));
				return;
			}

			/*  surgically check for a "then" method
				(mainly to just call the "getter" of "then" only once)  */
			var then;
			if ((typeof x === "object" && x !== null) || typeof x === "function") {
				try { then = x.then; }                                   /*  [Promises/A+ 2.3.3.1, 3.5]  */
				catch (e) {
					promise.reject(e);                                   /*  [Promises/A+ 2.3.3.2]  */
					return;
				}
			}

			/*  handle own Thenables    [Promises/A+ 2.3.2]
				and similar "thenables" [Promises/A+ 2.3.3]  */
			if (typeof then === "function") {
				var resolved = false;
				try {
					/*  call retrieved "then" method */                  /*  [Promises/A+ 2.3.3.3]  */
					then.call(x,
						/*  resolvePromise  */                           /*  [Promises/A+ 2.3.3.3.1]  */
						function (y) {
							if (resolved) return; resolved = true;       /*  [Promises/A+ 2.3.3.3.3]  */
							if (y === x)                                 /*  [Promises/A+ 3.6]  */
								promise.reject(new TypeError("circular thenable chain"));
							else
								resolve(promise, y);
						},

						/*  rejectPromise  */                            /*  [Promises/A+ 2.3.3.3.2]  */
						function (r) {
							if (resolved) return; resolved = true;       /*  [Promises/A+ 2.3.3.3.3]  */
							promise.reject(r);
						}
					);
				}
				catch (e) {
					if (!resolved)                                       /*  [Promises/A+ 2.3.3.3.3]  */
						promise.reject(e);                               /*  [Promises/A+ 2.3.3.3.4]  */
				}
				return;
			}

			/*  handle other values  */
			promise.fulfill(x);                                          /*  [Promises/A+ 2.3.4, 2.3.3.4]  */
		};

		/*  export API  */
		return api;
	})(),

	//jscs:enable

	// Event
	// A contructor superclass for adding event menthods, on, off, emit.
	Event: function() {

		var separator = /[\s\,]+/;

		// If this doesn't support getPrototype then we can't get prototype.events of the parent
		// So lets get the current instance events, and add those to a parent property
		this.parent = {
			events: this.events,
			findEvents: this.findEvents,
			parent: this.parent,
			utils: this.utils
		};

		this.events = {};

		// On, subscribe to events
		// @param evt   string
		// @param callback  function
		this.on = function(evt, callback) {

			if (callback && typeof (callback) === 'function') {
				var a = evt.split(separator);
				for (var i = 0; i < a.length; i++) {

					// Has this event already been fired on this instance?
					this.events[a[i]] = [callback].concat(this.events[a[i]] || []);
				}
			}

			return this;
		};

		// Off, unsubscribe to events
		// @param evt   string
		// @param callback  function
		this.off = function(evt, callback) {

			this.findEvents(evt, function(name, index) {
				if (!callback || this.events[name][index] === callback) {
					this.events[name][index] = null;
				}
			});

			return this;
		};

		// Emit
		// Triggers any subscribed events
		this.emit = function(evt /*, data, ... */) {

			// Get arguments as an Array, knock off the first one
			var args = Array.prototype.slice.call(arguments, 1);
			args.push(evt);

			// Handler
			var handler = function(name, index) {

				// Replace the last property with the event name
				args[args.length - 1] = (name === '*' ? evt : name);

				// Trigger
				this.events[name][index].apply(this, args);
			};

			// Find the callbacks which match the condition and call
			var _this = this;
			while (_this && _this.findEvents) {

				// Find events which match
				_this.findEvents(evt + ',*', handler);
				_this = _this.parent;
			}

			return this;
		};

		//
		// Easy functions
		this.emitAfter = function() {
			var _this = this;
			var args = arguments;
			setTimeout(function() {
				_this.emit.apply(_this, args);
			}, 0);

			return this;
		};

		this.findEvents = function(evt, callback) {

			var a = evt.split(separator);

			for (var name in this.events) {if (this.events.hasOwnProperty(name)) {

				if (a.indexOf(name) > -1) {

					for (var i = 0; i < this.events[name].length; i++) {

						// Does the event handler exist?
						if (this.events[name][i]) {
							// Emit on the local instance of this
							callback.call(this, name, i);
						}
					}
				}
			}}
		};

		return this;
	},

	// Global Events
	// Attach the callback to the window object
	// Return its unique reference
	globalEvent: function(callback, guid) {
		// If the guid has not been supplied then create a new one.
		guid = guid || '_hellojs_' + parseInt(Math.random() * 1e12, 10).toString(36);

		// Define the callback function
		window[guid] = function() {
			// Trigger the callback
			try {
				if (callback.apply(this, arguments)) {
					delete window[guid];
				}
			}
			catch (e) {
				console.error(e);
			}
		};

		return guid;
	},

	// Trigger a clientside popup
	// This has been augmented to support PhoneGap
	popup: function(url, redirectUri, options) {

		var documentElement = document.documentElement;

		// Multi Screen Popup Positioning (http://stackoverflow.com/a/16861050)
		// Credit: http://www.xtf.dk/2011/08/center-new-popup-window-even-on.html
		// Fixes dual-screen position                         Most browsers      Firefox

		if (options.height && options.top === undefined) {
			var dualScreenTop = window.screenTop !== undefined ? window.screenTop : screen.top;
			var height = screen.height || window.innerHeight || documentElement.clientHeight;
			options.top = parseInt((height - options.height) / 2, 10) + dualScreenTop;
		}

		if (options.width && options.left === undefined) {
			var dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : screen.left;
			var width = screen.width || window.innerWidth || documentElement.clientWidth;
			options.left = parseInt((width - options.width) / 2, 10) + dualScreenLeft;
		}

		// Convert options into an array
		var optionsArray = [];
		Object.keys(options).forEach(function(name) {
			var value = options[name];
			optionsArray.push(name + (value !== null ? '=' + value : ''));
		});

		// Call the open() function with the initial path
		//
		// OAuth redirect, fixes URI fragments from being lost in Safari
		// (URI Fragments within 302 Location URI are lost over HTTPS)
		// Loading the redirect.html before triggering the OAuth Flow seems to fix it.
		//
		// Firefox  decodes URL fragments when calling location.hash.
		//  - This is bad if the value contains break points which are escaped
		//  - Hence the url must be encoded twice as it contains breakpoints.
		if (navigator.userAgent.indexOf('Safari') !== -1 && navigator.userAgent.indexOf('Chrome') === -1) {
			url = redirectUri + '#oauth_redirect=' + encodeURIComponent(encodeURIComponent(url));
		}

		var popup = window.open(
			url,
			'_blank',
			optionsArray.join(',')
		);

		if (popup && popup.focus) {
			popup.focus();
		}

		return popup;
	},

	// OAuth and API response handler
	responseHandler: function(window, parent) {

		var _this = this;
		var p;
		var location = window.location;

		// Is this an auth relay message which needs to call the proxy?
		p = _this.param(location.search);

		// OAuth2 or OAuth1 server response?
		if (p && p.state && (p.code || p.oauth_token)) {

			var state = JSON.parse(p.state);

			// Add this path as the redirect_uri
			p.redirect_uri = state.redirect_uri || location.href.replace(/[\?\#].*$/, '');

			// Redirect to the host
			var path = _this.qs(state.oauth_proxy, p);

			location.assign(path);

			return;
		}

		// Save session, from redirected authentication
		// #access_token has come in?
		//
		// FACEBOOK is returning auth errors within as a query_string... thats a stickler for consistency.
		// SoundCloud is the state in the querystring and the token in the hashtag, so we'll mix the two together

		p = _this.merge(_this.param(location.search || ''), _this.param(location.hash || ''));

		// If p.state
		if (p && 'state' in p) {

			// Remove any addition information
			// E.g. p.state = 'facebook.page';
			try {
				var a = JSON.parse(p.state);
				_this.extend(p, a);
			}
			catch (e) {
				var stateDecoded = decodeURIComponent(p.state);
				try {
					var b = JSON.parse(stateDecoded);
					_this.extend(p, b);
				}
				catch (e) {
					console.error('Could not decode state parameter');
				}
			}

			// Access_token?
			if (('access_token' in p && p.access_token) && p.network) {

				if (!p.expires_in || parseInt(p.expires_in, 10) === 0) {
					// If p.expires_in is unset, set to 0
					p.expires_in = 0;
				}

				p.expires_in = parseInt(p.expires_in, 10);
				p.expires = ((new Date()).getTime() / 1e3) + (p.expires_in || (60 * 60 * 24 * 365));

				// Lets use the "state" to assign it to one of our networks
				authCallback(p, window, parent);
			}

			// Error=?
			// &error_description=?
			// &state=?
			else if (('error' in p && p.error) && p.network) {

				p.error = {
					code: p.error,
					message: p.error_message || p.error_description
				};

				// Let the state handler handle it
				authCallback(p, window, parent);
			}

			// API call, or a cancelled login
			// Result is serialized JSON string
			else if (p.callback && p.callback in parent) {

				// Trigger a function in the parent
				var res = 'result' in p && p.result ? JSON.parse(p.result) : false;

				// Trigger the callback on the parent
				callback(parent, p.callback)(res);
				closeWindow();
			}

			// If this page is still open
			if (p.page_uri) {
				location.assign(p.page_uri);
			}
		}

		// OAuth redirect, fixes URI fragments from being lost in Safari
		// (URI Fragments within 302 Location URI are lost over HTTPS)
		// Loading the redirect.html before triggering the OAuth Flow seems to fix it.
		else if ('oauth_redirect' in p) {

			location.assign(decodeURIComponent(p.oauth_redirect));
			return;
		}

		// Trigger a callback to authenticate
		function authCallback(obj, window, parent) {

			var cb = obj.callback;
			var network = obj.network;

			// Trigger the callback on the parent
			_this.store(network, obj);

			// If this is a page request it has no parent or opener window to handle callbacks
			if (('display' in obj) && obj.display === 'page') {
				return;
			}

			// Remove from session object
			if (parent && cb && cb in parent) {

				try {
					delete obj.callback;
				}
				catch (e) {}

				// Update store
				_this.store(network, obj);

				// Call the globalEvent function on the parent
				// It's safer to pass back a string to the parent,
				// Rather than an object/array (better for IE8)
				var str = JSON.stringify(obj);

				try {
					callback(parent, cb)(str);
				}
				catch (e) {
					// Error thrown whilst executing parent callback
				}
			}

			closeWindow();
		}

		function callback(parent, callbackID) {
			if (callbackID.indexOf('_hellojs_') !== 0) {
				return function() {
					throw 'Could not execute callback ' + callbackID;
				};
			}

			return parent[callbackID];
		}

		function closeWindow() {

			if (window.frameElement) {
				// Inside an iframe, remove from parent
				parent.document.body.removeChild(window.frameElement);
			}
			else {
				// Close this current window
				try {
					window.close();
				}
				catch (e) {}

				// IOS bug wont let us close a popup if still loading
				if (window.addEventListener) {
					window.addEventListener('load', function() {
						window.close();
					});
				}
			}

		}
	}
});

// Events
// Extend the hello object with its own event instance
hello.utils.Event.call(hello);

///////////////////////////////////
// Monitoring session state
// Check for session changes
///////////////////////////////////

(function(hello) {

	// Monitor for a change in state and fire
	var oldSessions = {};

	// Hash of expired tokens
	var expired = {};

	// Listen to other triggers to Auth events, use these to update this
	hello.on('auth.login, auth.logout', function(auth) {
		if (auth && typeof (auth) === 'object' && auth.network) {
			oldSessions[auth.network] = hello.utils.store(auth.network) || {};
		}
	});

	(function self() {

		var CURRENT_TIME = ((new Date()).getTime() / 1e3);
		var emit = function(eventName) {
			hello.emit('auth.' + eventName, {
				network: name,
				authResponse: session
			});
		};

		// Loop through the services
		for (var name in hello.services) {if (hello.services.hasOwnProperty(name)) {

			if (!hello.services[name].id) {
				// We haven't attached an ID so dont listen.
				continue;
			}

			// Get session
			var session = hello.utils.store(name) || {};
			var provider = hello.services[name];
			var oldSess = oldSessions[name] || {};

			// Listen for globalEvents that did not get triggered from the child
			if (session && 'callback' in session) {

				// To do remove from session object...
				var cb = session.callback;
				try {
					delete session.callback;
				}
				catch (e) {}

				// Update store
				// Removing the callback
				hello.utils.store(name, session);

				// Emit global events
				try {
					window[cb](session);
				}
				catch (e) {}
			}

			// Refresh token
			if (session && ('expires' in session) && session.expires < CURRENT_TIME) {

				// If auto refresh is possible
				// Either the browser supports
				var refresh = provider.refresh || session.refresh_token;

				// Has the refresh been run recently?
				if (refresh && (!(name in expired) || expired[name] < CURRENT_TIME)) {
					// Try to resignin
					hello.emit('notice', name + ' has expired trying to resignin');
					hello.login(name, {display: 'none', force: false});

					// Update expired, every 10 minutes
					expired[name] = CURRENT_TIME + 600;
				}

				// Does this provider not support refresh
				else if (!refresh && !(name in expired)) {
					// Label the event
					emit('expired');
					expired[name] = true;
				}

				// If session has expired then we dont want to store its value until it can be established that its been updated
				continue;
			}

			// Has session changed?
			else if (oldSess.access_token === session.access_token &&
			oldSess.expires === session.expires) {
				continue;
			}

			// Access_token has been removed
			else if (!session.access_token && oldSess.access_token) {
				emit('logout');
			}

			// Access_token has been created
			else if (session.access_token && !oldSess.access_token) {
				emit('login');
			}

			// Access_token has been updated
			else if (session.expires !== oldSess.expires) {
				emit('update');
			}

			// Updated stored session
			oldSessions[name] = session;

			// Remove the expired flags
			if (name in expired) {
				delete expired[name];
			}
		}}

		// Check error events
		setTimeout(self, 1000);
	})();

})(hello);

// EOF CORE lib
//////////////////////////////////

/////////////////////////////////////////
// API
// @param path    string
// @param query   object (optional)
// @param method  string (optional)
// @param data    object (optional)
// @param timeout integer (optional)
// @param callback  function (optional)

hello.api = function() {

	// Shorthand
	var _this = this;
	var utils = _this.utils;
	var error = utils.error;

	// Construct a new Promise object
	var promise = utils.Promise();

	// Arguments
	var p = utils.args({path: 's!', query: 'o', method: 's', data: 'o', timeout: 'i', callback: 'f'}, arguments);

	// Method
	p.method = (p.method || 'get').toLowerCase();

	// Headers
	p.headers = p.headers || {};

	// Query
	p.query = p.query || {};

	// If get, put all parameters into query
	if (p.method === 'get' || p.method === 'delete') {
		utils.extend(p.query, p.data);
		p.data = {};
	}

	var data = p.data = p.data || {};

	// Completed event callback
	promise.then(p.callback, p.callback);

	// Remove the network from path, e.g. facebook:/me/friends
	// Results in { network : facebook, path : me/friends }
	if (!p.path) {
		return promise.reject(error('invalid_path', 'Missing the path parameter from the request'));
	}

	p.path = p.path.replace(/^\/+/, '');
	var a = (p.path.split(/[\/\:]/, 2) || [])[0].toLowerCase();

	if (a in _this.services) {
		p.network = a;
		var reg = new RegExp('^' + a + ':?\/?');
		p.path = p.path.replace(reg, '');
	}

	// Network & Provider
	// Define the network that this request is made for
	p.network = _this.settings.default_service = p.network || _this.settings.default_service;
	var o = _this.services[p.network];

	// INVALID
	// Is there no service by the given network name?
	if (!o) {
		return promise.reject(error('invalid_network', 'Could not match the service requested: ' + p.network));
	}

	// PATH
	// As long as the path isn't flagged as unavaiable, e.g. path == false

	if (!(!(p.method in o) || !(p.path in o[p.method]) || o[p.method][p.path] !== false)) {
		return promise.reject(error('invalid_path', 'The provided path is not available on the selected network'));
	}

	// PROXY
	// OAuth1 calls always need a proxy

	if (!p.oauth_proxy) {
		p.oauth_proxy = _this.settings.oauth_proxy;
	}

	if (!('proxy' in p)) {
		p.proxy = p.oauth_proxy && o.oauth && parseInt(o.oauth.version, 10) === 1;
	}

	// TIMEOUT
	// Adopt timeout from global settings by default

	if (!('timeout' in p)) {
		p.timeout = _this.settings.timeout;
	}

	// Format response
	// Whether to run the raw response through post processing.
	if (!('formatResponse' in p)) {
		p.formatResponse = true;
	}

	// Get the current session
	// Append the access_token to the query
	p.authResponse = _this.getAuthResponse(p.network);
	if (p.authResponse && p.authResponse.access_token) {
		p.query.access_token = p.authResponse.access_token;
	}

	var url = p.path;
	var m;

	// Store the query as options
	// This is used to populate the request object before the data is augmented by the prewrap handlers.
	p.options = utils.clone(p.query);

	// Clone the data object
	// Prevent this script overwriting the data of the incoming object.
	// Ensure that everytime we run an iteration the callbacks haven't removed some data
	p.data = utils.clone(data);

	// URL Mapping
	// Is there a map for the given URL?
	var actions = o[{'delete': 'del'}[p.method] || p.method] || {};

	// Extrapolate the QueryString
	// Provide a clean path
	// Move the querystring into the data
	if (p.method === 'get') {

		var query = url.split(/[\?#]/)[1];
		if (query) {
			utils.extend(p.query, utils.param(query));

			// Remove the query part from the URL
			url = url.replace(/\?.*?(#|$)/, '$1');
		}
	}

	// Is the hash fragment defined
	if ((m = url.match(/#(.+)/, ''))) {
		url = url.split('#')[0];
		p.path = m[1];
	}
	else if (url in actions) {
		p.path = url;
		url = actions[url];
	}
	else if ('default' in actions) {
		url = actions['default'];
	}

	// Redirect Handler
	// This defines for the Form+Iframe+Hash hack where to return the results too.
	p.redirect_uri = _this.settings.redirect_uri;

	// Define FormatHandler
	// The request can be procesed in a multitude of ways
	// Here's the options - depending on the browser and endpoint
	p.xhr = o.xhr;
	p.jsonp = o.jsonp;
	p.form = o.form;

	// Make request
	if (typeof (url) === 'function') {
		// Does self have its own callback?
		url(p, getPath);
	}
	else {
		// Else the URL is a string
		getPath(url);
	}

	return promise.proxy;

	// If url needs a base
	// Wrap everything in
	function getPath(url) {

		// Format the string if it needs it
		url = url.replace(/\@\{([a-z\_\-]+)(\|.*?)?\}/gi, function(m, key, defaults) {
			var val = defaults ? defaults.replace(/^\|/, '') : '';
			if (key in p.query) {
				val = p.query[key];
				delete p.query[key];
			}
			else if (p.data && key in p.data) {
				val = p.data[key];
				delete p.data[key];
			}
			else if (!defaults) {
				promise.reject(error('missing_attribute', 'The attribute ' + key + ' is missing from the request'));
			}

			return val;
		});

		// Add base
		if (!url.match(/^https?:\/\//)) {
			url = o.base + url;
		}

		// Define the request URL
		p.url = url;

		// Make the HTTP request with the curated request object
		// CALLBACK HANDLER
		// @ response object
		// @ statusCode integer if available
		utils.request(p, function(r, headers) {

			// Is this a raw response?
			if (!p.formatResponse) {
				// Bad request? error statusCode or otherwise contains an error response vis JSONP?
				if (typeof headers === 'object' ? (headers.statusCode >= 400) : (typeof r === 'object' && 'error' in r)) {
					promise.reject(r);
				}
				else {
					promise.fulfill(r);
				}

				return;
			}

			// Should this be an object
			if (r === true) {
				r = {success:true};
			}
			else if (!r) {
				r = {};
			}

			// The delete callback needs a better response
			if (p.method === 'delete') {
				r = (!r || utils.isEmpty(r)) ? {success:true} : r;
			}

			// FORMAT RESPONSE?
			// Does self request have a corresponding formatter
			if (o.wrap && ((p.path in o.wrap) || ('default' in o.wrap))) {
				var wrap = (p.path in o.wrap ? p.path : 'default');
				var time = (new Date()).getTime();

				// FORMAT RESPONSE
				var b = o.wrap[wrap](r, headers, p);

				// Has the response been utterly overwritten?
				// Typically self augments the existing object.. but for those rare occassions
				if (b) {
					r = b;
				}
			}

			// Is there a next_page defined in the response?
			if (r && 'paging' in r && r.paging.next) {

				// Add the relative path if it is missing from the paging/next path
				if (r.paging.next[0] === '?') {
					r.paging.next = p.path + r.paging.next;
				}

				// The relative path has been defined, lets markup the handler in the HashFragment
				else {
					r.paging.next += '#' + p.path;
				}
			}

			// Dispatch to listeners
			// Emit events which pertain to the formatted response
			if (!r || 'error' in r) {
				promise.reject(r);
			}
			else {
				promise.fulfill(r);
			}
		});
	}
};

// API utilities
hello.utils.extend(hello.utils, {

	// Make an HTTP request
	request: function(p, callback) {

		var _this = this;
		var error = _this.error;

		// This has to go through a POST request
		if (!_this.isEmpty(p.data) && !('FileList' in window) && _this.hasBinary(p.data)) {

			// Disable XHR and JSONP
			p.xhr = false;
			p.jsonp = false;
		}

		// Check if the browser and service support CORS
		var cors = this.request_cors(function() {
			// If it does then run this...
			return ((p.xhr === undefined) || (p.xhr && (typeof (p.xhr) !== 'function' || p.xhr(p, p.query))));
		});

		if (cors) {

			formatUrl(p, function(url) {

				var x = _this.xhr(p.method, url, p.headers, p.data, callback);
				x.onprogress = p.onprogress || null;

				// Windows Phone does not support xhr.upload, see #74
				// Feature detect
				if (x.upload && p.onuploadprogress) {
					x.upload.onprogress = p.onuploadprogress;
				}

			});

			return;
		}

		// Clone the query object
		// Each request modifies the query object and needs to be tared after each one.
		var _query = p.query;

		p.query = _this.clone(p.query);

		// Assign a new callbackID
		p.callbackID = _this.globalEvent();

		// JSONP
		if (p.jsonp !== false) {

			// Clone the query object
			p.query.callback = p.callbackID;

			// If the JSONP is a function then run it
			if (typeof (p.jsonp) === 'function') {
				p.jsonp(p, p.query);
			}

			// Lets use JSONP if the method is 'get'
			if (p.method === 'get') {

				formatUrl(p, function(url) {
					_this.jsonp(url, callback, p.callbackID, p.timeout);
				});

				return;
			}
			else {
				// It's not compatible reset query
				p.query = _query;
			}

		}

		// Otherwise we're on to the old school, iframe hacks and JSONP
		if (p.form !== false) {

			// Add some additional query parameters to the URL
			// We're pretty stuffed if the endpoint doesn't like these
			p.query.redirect_uri = p.redirect_uri;
			p.query.state = JSON.stringify({callback:p.callbackID});

			var opts;

			if (typeof (p.form) === 'function') {

				// Format the request
				opts = p.form(p, p.query);
			}

			if (p.method === 'post' && opts !== false) {

				formatUrl(p, function(url) {
					_this.post(url, p.data, opts, callback, p.callbackID, p.timeout);
				});

				return;
			}
		}

		// None of the methods were successful throw an error
		callback(error('invalid_request', 'There was no mechanism for handling this request'));

		return;

		// Format URL
		// Constructs the request URL, optionally wraps the URL through a call to a proxy server
		// Returns the formatted URL
		function formatUrl(p, callback) {

			// Are we signing the request?
			var sign;

			// OAuth1
			// Remove the token from the query before signing
			if (p.authResponse && p.authResponse.oauth && parseInt(p.authResponse.oauth.version, 10) === 1) {

				// OAUTH SIGNING PROXY
				sign = p.query.access_token;

				// Remove the access_token
				delete p.query.access_token;

				// Enfore use of Proxy
				p.proxy = true;
			}

			// POST body to querystring
			if (p.data && (p.method === 'get' || p.method === 'delete')) {
				// Attach the p.data to the querystring.
				_this.extend(p.query, p.data);
				p.data = null;
			}

			// Construct the path
			var path = _this.qs(p.url, p.query);

			// Proxy the request through a server
			// Used for signing OAuth1
			// And circumventing services without Access-Control Headers
			if (p.proxy) {
				// Use the proxy as a path
				path = _this.qs(p.oauth_proxy, {
					path: path,
					access_token: sign || '',

					// This will prompt the request to be signed as though it is OAuth1
					then: p.proxy_response_type || (p.method.toLowerCase() === 'get' ? 'redirect' : 'proxy'),
					method: p.method.toLowerCase(),
					suppress_response_codes: true
				});
			}

			callback(path);
		}
	},

	// Test whether the browser supports the CORS response
	request_cors: function(callback) {
		return 'withCredentials' in new XMLHttpRequest() && callback();
	},

	// Return the type of DOM object
	domInstance: function(type, data) {
		var test = 'HTML' + (type || '').replace(
			/^[a-z]/,
			function(m) {
				return m.toUpperCase();
			}

		) + 'Element';

		if (!data) {
			return false;
		}

		if (window[test]) {
			return data instanceof window[test];
		}
		else if (window.Element) {
			return data instanceof window.Element && (!type || (data.tagName && data.tagName.toLowerCase() === type));
		}
		else {
			return (!(data instanceof Object || data instanceof Array || data instanceof String || data instanceof Number) && data.tagName && data.tagName.toLowerCase() === type);
		}
	},

	// Create a clone of an object
	clone: function(obj) {
		// Does not clone DOM elements, nor Binary data, e.g. Blobs, Filelists
		if (obj === null || typeof (obj) !== 'object' || obj instanceof Date || 'nodeName' in obj || this.isBinary(obj) || (typeof FormData === 'function' && obj instanceof FormData)) {
			return obj;
		}

		if (Array.isArray(obj)) {
			// Clone each item in the array
			return obj.map(this.clone.bind(this));
		}

		// But does clone everything else.
		var clone = {};
		for (var x in obj) {
			clone[x] = this.clone(obj[x]);
		}

		return clone;
	},

	// XHR: uses CORS to make requests
	xhr: function(method, url, headers, data, callback) {

		var r = new XMLHttpRequest();
		var error = this.error;

		// Binary?
		var binary = false;
		if (method === 'blob') {
			binary = method;
			method = 'GET';
		}

		method = method.toUpperCase();

		// Xhr.responseType 'json' is not supported in any of the vendors yet.
		r.onload = function(e) {
			var json = r.response;
			try {
				json = JSON.parse(r.responseText);
			}
			catch (_e) {
				if (r.status === 401) {
					json = error('access_denied', r.statusText);
				}
			}

			var headers = headersToJSON(r.getAllResponseHeaders());
			headers.statusCode = r.status;

			callback(json || (method === 'GET' ? error('empty_response', 'Could not get resource') : {}), headers);
		};

		r.onerror = function(e) {
			var json = r.responseText;
			try {
				json = JSON.parse(r.responseText);
			}
			catch (_e) {}

			callback(json || error('access_denied', 'Could not get resource'));
		};

		var x;

		// Should we add the query to the URL?
		if (method === 'GET' || method === 'DELETE') {
			data = null;
		}
		else if (data && typeof (data) !== 'string' && !(data instanceof FormData) && !(data instanceof File) && !(data instanceof Blob)) {
			// Loop through and add formData
			var f = new FormData();
			for (x in data) if (data.hasOwnProperty(x)) {
				if (data[x] instanceof HTMLInputElement) {
					if ('files' in data[x] && data[x].files.length > 0) {
						f.append(x, data[x].files[0]);
					}
				}
				else if (data[x] instanceof Blob) {
					f.append(x, data[x], data.name);
				}
				else {
					f.append(x, data[x]);
				}
			}

			data = f;
		}

		// Open the path, async
		r.open(method, url, true);

		if (binary) {
			if ('responseType' in r) {
				r.responseType = binary;
			}
			else {
				r.overrideMimeType('text/plain; charset=x-user-defined');
			}
		}

		// Set any bespoke headers
		if (headers) {
			for (x in headers) {
				r.setRequestHeader(x, headers[x]);
			}
		}

		r.send(data);

		return r;

		// Headers are returned as a string
		function headersToJSON(s) {
			var r = {};
			var reg = /([a-z\-]+):\s?(.*);?/gi;
			var m;
			while ((m = reg.exec(s))) {
				r[m[1]] = m[2];
			}

			return r;
		}
	},

	// JSONP
	// Injects a script tag into the DOM to be executed and appends a callback function to the window object
	// @param string/function pathFunc either a string of the URL or a callback function pathFunc(querystringhash, continueFunc);
	// @param function callback a function to call on completion;
	jsonp: function(url, callback, callbackID, timeout) {

		var _this = this;
		var error = _this.error;

		// Change the name of the callback
		var bool = 0;
		var head = document.getElementsByTagName('head')[0];
		var operaFix;
		var result = error('server_error', 'server_error');
		var cb = function() {
			if (!(bool++)) {
				window.setTimeout(function() {
					callback(result);
					head.removeChild(script);
				}, 0);
			}

		};

		// Add callback to the window object
		callbackID = _this.globalEvent(function(json) {
			result = json;
			return true;

			// Mark callback as done
		}, callbackID);

		// The URL is a function for some cases and as such
		// Determine its value with a callback containing the new parameters of this function.
		url = url.replace(new RegExp('=\\?(&|$)'), '=' + callbackID + '$1');

		// Build script tag
		var script = _this.append('script', {
			id: callbackID,
			name: callbackID,
			src: url,
			async: true,
			onload: cb,
			onerror: cb,
			onreadystatechange: function() {
				if (/loaded|complete/i.test(this.readyState)) {
					cb();
				}
			}
		});

		// Opera fix error
		// Problem: If an error occurs with script loading Opera fails to trigger the script.onerror handler we specified
		//
		// Fix:
		// By setting the request to synchronous we can trigger the error handler when all else fails.
		// This action will be ignored if we've already called the callback handler "cb" with a successful onload event
		if (window.navigator.userAgent.toLowerCase().indexOf('opera') > -1) {
			operaFix = _this.append('script', {
				text: 'document.getElementById(\'' + callbackID + '\').onerror();'
			});
			script.async = false;
		}

		// Add timeout
		if (timeout) {
			window.setTimeout(function() {
				result = error('timeout', 'timeout');
				cb();
			}, timeout);
		}

		// TODO: add fix for IE,
		// However: unable recreate the bug of firing off the onreadystatechange before the script content has been executed and the value of "result" has been defined.
		// Inject script tag into the head element
		head.appendChild(script);

		// Append Opera Fix to run after our script
		if (operaFix) {
			head.appendChild(operaFix);
		}
	},

	// Post
	// Send information to a remote location using the post mechanism
	// @param string uri path
	// @param object data, key value data to send
	// @param function callback, function to execute in response
	post: function(url, data, options, callback, callbackID, timeout) {

		var _this = this;
		var error = _this.error;
		var doc = document;

		// This hack needs a form
		var form = null;
		var reenableAfterSubmit = [];
		var newform;
		var i = 0;
		var x = null;
		var bool = 0;
		var cb = function(r) {
			if (!(bool++)) {
				callback(r);
			}
		};

		// What is the name of the callback to contain
		// We'll also use this to name the iframe
		_this.globalEvent(cb, callbackID);

		// Build the iframe window
		var win;
		try {
			// IE7 hack, only lets us define the name here, not later.
			win = doc.createElement('<iframe name="' + callbackID + '">');
		}
		catch (e) {
			win = doc.createElement('iframe');
		}

		win.name = callbackID;
		win.id = callbackID;
		win.style.display = 'none';

		// Override callback mechanism. Triggger a response onload/onerror
		if (options && options.callbackonload) {
			// Onload is being fired twice
			win.onload = function() {
				cb({
					response: 'posted',
					message: 'Content was posted'
				});
			};
		}

		if (timeout) {
			setTimeout(function() {
				cb(error('timeout', 'The post operation timed out'));
			}, timeout);
		}

		doc.body.appendChild(win);

		// If we are just posting a single item
		if (_this.domInstance('form', data)) {
			// Get the parent form
			form = data.form;

			// Loop through and disable all of its siblings
			for (i = 0; i < form.elements.length; i++) {
				if (form.elements[i] !== data) {
					form.elements[i].setAttribute('disabled', true);
				}
			}

			// Move the focus to the form
			data = form;
		}

		// Posting a form
		if (_this.domInstance('form', data)) {
			// This is a form element
			form = data;

			// Does this form need to be a multipart form?
			for (i = 0; i < form.elements.length; i++) {
				if (!form.elements[i].disabled && form.elements[i].type === 'file') {
					form.encoding = form.enctype = 'multipart/form-data';
					form.elements[i].setAttribute('name', 'file');
				}
			}
		}
		else {
			// Its not a form element,
			// Therefore it must be a JSON object of Key=>Value or Key=>Element
			// If anyone of those values are a input type=file we shall shall insert its siblings into the form for which it belongs.
			for (x in data) if (data.hasOwnProperty(x)) {
				// Is this an input Element?
				if (_this.domInstance('input', data[x]) && data[x].type === 'file') {
					form = data[x].form;
					form.encoding = form.enctype = 'multipart/form-data';
				}
			}

			// Do If there is no defined form element, lets create one.
			if (!form) {
				// Build form
				form = doc.createElement('form');
				doc.body.appendChild(form);
				newform = form;
			}

			var input;

			// Add elements to the form if they dont exist
			for (x in data) if (data.hasOwnProperty(x)) {

				// Is this an element?
				var el = (_this.domInstance('input', data[x]) || _this.domInstance('textArea', data[x]) || _this.domInstance('select', data[x]));

				// Is this not an input element, or one that exists outside the form.
				if (!el || data[x].form !== form) {

					// Does an element have the same name?
					var inputs = form.elements[x];
					if (input) {
						// Remove it.
						if (!(inputs instanceof NodeList)) {
							inputs = [inputs];
						}

						for (i = 0; i < inputs.length; i++) {
							inputs[i].parentNode.removeChild(inputs[i]);
						}

					}

					// Create an input element
					input = doc.createElement('input');
					input.setAttribute('type', 'hidden');
					input.setAttribute('name', x);

					// Does it have a value attribute?
					if (el) {
						input.value = data[x].value;
					}
					else if (_this.domInstance(null, data[x])) {
						input.value = data[x].innerHTML || data[x].innerText;
					}
					else {
						input.value = data[x];
					}

					form.appendChild(input);
				}

				// It is an element, which exists within the form, but the name is wrong
				else if (el && data[x].name !== x) {
					data[x].setAttribute('name', x);
					data[x].name = x;
				}
			}

			// Disable elements from within the form if they weren't specified
			for (i = 0; i < form.elements.length; i++) {

				input = form.elements[i];

				// Does the same name and value exist in the parent
				if (!(input.name in data) && input.getAttribute('disabled') !== true) {
					// Disable
					input.setAttribute('disabled', true);

					// Add re-enable to callback
					reenableAfterSubmit.push(input);
				}
			}
		}

		// Set the target of the form
		form.setAttribute('method', 'POST');
		form.setAttribute('target', callbackID);
		form.target = callbackID;

		// Update the form URL
		form.setAttribute('action', url);

		// Submit the form
		// Some reason this needs to be offset from the current window execution
		setTimeout(function() {
			form.submit();

			setTimeout(function() {
				try {
					// Remove the iframe from the page.
					//win.parentNode.removeChild(win);
					// Remove the form
					if (newform) {
						newform.parentNode.removeChild(newform);
					}
				}
				catch (e) {
					try {
						console.error('HelloJS: could not remove iframe');
					}
					catch (ee) {}
				}

				// Reenable the disabled form
				for (var i = 0; i < reenableAfterSubmit.length; i++) {
					if (reenableAfterSubmit[i]) {
						reenableAfterSubmit[i].setAttribute('disabled', false);
						reenableAfterSubmit[i].disabled = false;
					}
				}
			}, 0);
		}, 100);
	},

	// Some of the providers require that only multipart is used with non-binary forms.
	// This function checks whether the form contains binary data
	hasBinary: function(data) {
		for (var x in data) if (data.hasOwnProperty(x)) {
			if (this.isBinary(data[x])) {
				return true;
			}
		}

		return false;
	},

	// Determines if a variable Either Is or like a FormInput has the value of a Blob

	isBinary: function(data) {

		return data instanceof Object && (
		(this.domInstance('input', data) && data.type === 'file') ||
		('FileList' in window && data instanceof window.FileList) ||
		('File' in window && data instanceof window.File) ||
		('Blob' in window && data instanceof window.Blob));

	},

	// Convert Data-URI to Blob string
	toBlob: function(dataURI) {
		var reg = /^data\:([^;,]+(\;charset=[^;,]+)?)(\;base64)?,/i;
		var m = dataURI.match(reg);
		if (!m) {
			return dataURI;
		}

		var binary = atob(dataURI.replace(reg, ''));
		var array = [];
		for (var i = 0; i < binary.length; i++) {
			array.push(binary.charCodeAt(i));
		}

		return new Blob([new Uint8Array(array)], {type: m[1]});
	}

});

// EXTRA: Convert FormElement to JSON for POSTing
// Wrappers to add additional functionality to existing functions
(function(hello) {

	// Copy original function
	var api = hello.api;
	var utils = hello.utils;

	utils.extend(utils, {

		// DataToJSON
		// This takes a FormElement|NodeList|InputElement|MixedObjects and convers the data object to JSON.
		dataToJSON: function(p) {

			var _this = this;
			var w = window;
			var data = p.data;

			// Is data a form object
			if (_this.domInstance('form', data)) {
				data = _this.nodeListToJSON(data.elements);
			}
			else if ('NodeList' in w && data instanceof NodeList) {
				data = _this.nodeListToJSON(data);
			}
			else if (_this.domInstance('input', data)) {
				data = _this.nodeListToJSON([data]);
			}

			// Is data a blob, File, FileList?
			if (('File' in w && data instanceof w.File) ||
				('Blob' in w && data instanceof w.Blob) ||
				('FileList' in w && data instanceof w.FileList)) {
				data = {file: data};
			}

			// Loop through data if it's not form data it must now be a JSON object
			if (!('FormData' in w && data instanceof w.FormData)) {

				for (var x in data) if (data.hasOwnProperty(x)) {

					if ('FileList' in w && data[x] instanceof w.FileList) {
						if (data[x].length === 1) {
							data[x] = data[x][0];
						}
					}
					else if (_this.domInstance('input', data[x]) && data[x].type === 'file') {
						continue;
					}
					else if (_this.domInstance('input', data[x]) ||
						_this.domInstance('select', data[x]) ||
						_this.domInstance('textArea', data[x])) {
						data[x] = data[x].value;
					}
					else if (_this.domInstance(null, data[x])) {
						data[x] = data[x].innerHTML || data[x].innerText;
					}
				}
			}

			p.data = data;
			return data;
		},

		// NodeListToJSON
		// Given a list of elements extrapolate their values and return as a json object
		nodeListToJSON: function(nodelist) {

			var json = {};

			// Create a data string
			for (var i = 0; i < nodelist.length; i++) {

				var input = nodelist[i];

				// If the name of the input is empty or diabled, dont add it.
				if (input.disabled || !input.name) {
					continue;
				}

				// Is this a file, does the browser not support 'files' and 'FormData'?
				if (input.type === 'file') {
					json[input.name] = input;
				}
				else {
					json[input.name] = input.value || input.innerHTML;
				}
			}

			return json;
		}
	});

	// Replace it
	hello.api = function() {

		// Get arguments
		var p = utils.args({path: 's!', method: 's', data:'o', timeout: 'i', callback: 'f'}, arguments);

		// Change for into a data object
		if (p.data) {
			utils.dataToJSON(p);
		}

		return api.call(this, p);
	};

})(hello);

/////////////////////////////////////
//
// Save any access token that is in the current page URL
// Handle any response solicited through iframe hash tag following an API request
//
/////////////////////////////////////

hello.utils.responseHandler(window, window.opener || window.parent);

// Script to support ChromeApps
// This overides the hello.utils.popup method to support chrome.identity.launchWebAuthFlow
// See https://developer.chrome.com/apps/app_identity#non

// Is this a chrome app?

if (typeof chrome === 'object' && typeof chrome.identity === 'object' && chrome.identity.launchWebAuthFlow) {

	(function() {

		// Swap the popup method
		hello.utils.popup = function(url) {

			return _open(url, true);

		};

		// Swap the hidden iframe method
		hello.utils.iframe = function(url) {

			_open(url, false);

		};

		// Swap the request_cors method
		hello.utils.request_cors = function(callback) {

			callback();

			// Always run as CORS

			return true;
		};

		// Swap the storage method
		var _cache = {};
		chrome.storage.local.get('hello', function(r) {
			// Update the cache
			_cache = r.hello || {};
		});

		hello.utils.store = function(name, value) {

			// Get all
			if (arguments.length === 0) {
				return _cache;
			}

			// Get
			if (arguments.length === 1) {
				return _cache[name] || null;
			}

			// Set
			if (value) {
				_cache[name] = value;
				chrome.storage.local.set({hello: _cache});
				return value;
			}

			// Delete
			if (value === null) {
				delete _cache[name];
				chrome.storage.local.set({hello: _cache});
				return null;
			}
		};

		// Open function
		function _open(url, interactive) {

			// Launch
			var ref = {
				closed: false
			};

			// Launch the webAuthFlow
			chrome.identity.launchWebAuthFlow({
				url: url,
				interactive: interactive
			}, function(responseUrl) {

				// Did the user cancel this prematurely
				if (responseUrl === undefined) {
					ref.closed = true;
					return;
				}

				// Split appart the URL
				var a = hello.utils.url(responseUrl);

				// The location can be augmented in to a location object like so...
				// We dont have window operations on the popup so lets create some
				var _popup = {
					location: {

						// Change the location of the popup
						assign: function(url) {

							// If there is a secondary reassign
							// In the case of OAuth1
							// Trigger this in non-interactive mode.
							_open(url, false);
						},

						search: a.search,
						hash: a.hash,
						href: a.href
					},
					close: function() {}
				};

				// Then this URL contains information which HelloJS must process
				// URL string
				// Window - any action such as window relocation goes here
				// Opener - the parent window which opened this, aka this script

				hello.utils.responseHandler(_popup, window);
			});

			// Return the reference
			return ref;
		}

	})();
}

// Phonegap override for hello.phonegap.js
(function() {

	// Is this a phonegap implementation?
	if (!(/^file:\/{3}[^\/]/.test(window.location.href) && window.cordova)) {
		// Cordova is not included.
		return;
	}

	// Augment the hidden iframe method
	hello.utils.iframe = function(url, redirectUri) {
		hello.utils.popup(url, redirectUri, {hidden: 'yes'});
	};

	// Augment the popup
	var utilPopup = hello.utils.popup;

	// Replace popup
	hello.utils.popup = function(url, redirectUri, options) {

		// Run the standard
		var popup = utilPopup.call(this, url, redirectUri, options);

		// Create a function for reopening the popup, and assigning events to the new popup object
		// PhoneGap support
		// Add an event listener to listen to the change in the popup windows URL
		// This must appear before popup.focus();
		try {
			if (popup && popup.addEventListener) {

				// Get the origin of the redirect URI

				var a = hello.utils.url(redirectUri);
				var redirectUriOrigin = a.origin || (a.protocol + '//' + a.hostname);

				// Listen to changes in the InAppBrowser window

				popup.addEventListener('loadstart', function(e) {

					var url = e.url;

					// Is this the path, as given by the redirectUri?
					// Check the new URL agains the redirectUriOrigin.
					// According to #63 a user could click 'cancel' in some dialog boxes ....
					// The popup redirects to another page with the same origin, yet we still wish it to close.

					if (url.indexOf(redirectUriOrigin) !== 0) {
						return;
					}

					// Split appart the URL
					var a = hello.utils.url(url);

					// We dont have window operations on the popup so lets create some
					// The location can be augmented in to a location object like so...

					var _popup = {
						location: {
							// Change the location of the popup
							assign: function(location) {

								// Unfourtunatly an app is may not change the location of a InAppBrowser window.
								// So to shim this, just open a new one.
								popup.executeScript({code: 'window.location.href = "' + location + ';"'});
							},

							search: a.search,
							hash: a.hash,
							href: a.href
						},
						close: function() {
							if (popup.close) {
								popup.close();
								try {
									popup.closed = true;
								}
								catch (_e) {}
							}
						}
					};

					// Then this URL contains information which HelloJS must process
					// URL string
					// Window - any action such as window relocation goes here
					// Opener - the parent window which opened this, aka this script

					hello.utils.responseHandler(_popup, window);

				});
			}
		}
		catch (e) {}

		return popup;
	};

})();

(function(hello) {

	// OAuth1
	var OAuth1Settings = {
		version: '1.0',
		auth: 'https://www.dropbox.com/1/oauth/authorize',
		request: 'https://api.dropbox.com/1/oauth/request_token',
		token: 'https://api.dropbox.com/1/oauth/access_token'
	};

	// OAuth2 Settings
	var OAuth2Settings = {
		version: 2,
		auth: 'https://www.dropbox.com/1/oauth2/authorize',
		grant: 'https://api.dropbox.com/1/oauth2/token'
	};

	// Initiate the Dropbox module
	hello.init({

		dropbox: {

			name: 'Dropbox',

			oauth: OAuth2Settings,

			login: function(p) {
				// OAuth2 non-standard adjustments
				p.qs.scope = '';

				// Should this be run as OAuth1?
				// If the redirect_uri is is HTTP (non-secure) then its required to revert to the OAuth1 endpoints
				var redirect = decodeURIComponent(p.qs.redirect_uri);
				if (redirect.indexOf('http:') === 0 && redirect.indexOf('http://localhost/') !== 0) {

					// Override the dropbox OAuth settings.
					hello.services.dropbox.oauth = OAuth1Settings;
				}
				else {
					// Override the dropbox OAuth settings.
					hello.services.dropbox.oauth = OAuth2Settings;
				}

				// The dropbox login window is a different size
				p.options.popup.width = 1000;
				p.options.popup.height = 1000;
			},

			/*
				Dropbox does not allow insecure HTTP URI's in the redirect_uri field
				...otherwise I'd love to use OAuth2

				Follow request https://forums.dropbox.com/topic.php?id=106505

				p.qs.response_type = 'code';
				oauth: {
					version: 2,
					auth: 'https://www.dropbox.com/1/oauth2/authorize',
					grant: 'https://api.dropbox.com/1/oauth2/token'
				}
			*/

			// API Base URL
			base: 'https://api.dropbox.com/1/',

			// Bespoke setting: this is states whether to use the custom environment of Dropbox or to use their own environment
			// Because it's notoriously difficult for Dropbox too provide access from other webservices, this defaults to Sandbox
			root: 'sandbox',

			// Map GET requests
			get: {
				me: 'account/info',

				// Https://www.dropbox.com/developers/core/docs#metadata
				'me/files': req('metadata/auto/@{parent|}'),
				'me/folder': req('metadata/auto/@{id}'),
				'me/folders': req('metadata/auto/'),

				'default': function(p, callback) {
					if (p.path.match('https://api-content.dropbox.com/1/files/')) {
						// This is a file, return binary data
						p.method = 'blob';
					}

					callback(p.path);
				}
			},

			post: {
				'me/files': function(p, callback) {

					var path = p.data.parent;
					var fileName = p.data.name;

					p.data = {
						file: p.data.file
					};

					// Does this have a data-uri to upload as a file?
					if (typeof (p.data.file) === 'string') {
						p.data.file = hello.utils.toBlob(p.data.file);
					}

					callback('https://api-content.dropbox.com/1/files_put/auto/' + path + '/' + fileName);
				},

				'me/folders': function(p, callback) {

					var name = p.data.name;
					p.data = {};

					callback('fileops/create_folder?root=@{root|sandbox}&' + hello.utils.param({
						path: name
					}));
				}
			},

			// Map DELETE requests
			del: {
				'me/files': 'fileops/delete?root=@{root|sandbox}&path=@{id}',
				'me/folder': 'fileops/delete?root=@{root|sandbox}&path=@{id}'
			},

			wrap: {
				me: function(o) {
					formatError(o);
					if (!o.uid) {
						return o;
					}

					o.name = o.display_name;
					var m = o.name.split(' ');
					o.first_name = m.shift();
					o.last_name = m.join(' ');
					o.id = o.uid;
					delete o.uid;
					delete o.display_name;
					return o;
				},

				'default': function(o, headers, req) {
					formatError(o);
					if (o.is_dir && o.contents) {
						o.data = o.contents;
						delete o.contents;

						o.data.forEach(function(item) {
							item.root = o.root;
							formatFile(item, headers, req);
						});
					}

					formatFile(o, headers, req);

					if (o.is_deleted) {
						o.success = true;
					}

					return o;
				}
			},

			// Doesn't return the CORS headers
			xhr: function(p) {

				// The proxy supports allow-cross-origin-resource
				// Alas that's the only thing we're using.
				if (p.data && p.data.file) {
					var file = p.data.file;
					if (file) {
						if (file.files) {
							p.data = file.files[0];
						}
						else {
							p.data = file;
						}
					}
				}

				if (p.method === 'delete') {
					p.method = 'post';
				}

				return true;
			},

			form: function(p, qs) {
				delete qs.state;
				delete qs.redirect_uri;
			}
		}
	});

	function formatError(o) {
		if (o && 'error' in o) {
			o.error = {
				code: 'server_error',
				message: o.error.message || o.error
			};
		}
	}

	function formatFile(o, headers, req) {

		if (typeof o !== 'object' ||
			(typeof Blob !== 'undefined' && o instanceof Blob) ||
			(typeof ArrayBuffer !== 'undefined' && o instanceof ArrayBuffer)) {
			// This is a file, let it through unformatted
			return;
		}

		if ('error' in o) {
			return;
		}

		var path = (o.root !== 'app_folder' ? o.root : '') + o.path.replace(/\&/g, '%26');
		path = path.replace(/^\//, '');
		if (o.thumb_exists) {
			o.thumbnail = req.oauth_proxy + '?path=' +
			encodeURIComponent('https://api-content.dropbox.com/1/thumbnails/auto/' + path + '?format=jpeg&size=m') + '&access_token=' + req.options.access_token;
		}

		o.type = (o.is_dir ? 'folder' : o.mime_type);
		o.name = o.path.replace(/.*\//g, '');
		if (o.is_dir) {
			o.files = path.replace(/^\//, '');
		}
		else {
			o.downloadLink = hello.settings.oauth_proxy + '?path=' +
			encodeURIComponent('https://api-content.dropbox.com/1/files/auto/' + path) + '&access_token=' + req.options.access_token;
			o.file = 'https://api-content.dropbox.com/1/files/auto/' + path;
		}

		if (!o.id) {
			o.id = o.path.replace(/^\//, '');
		}

		// O.media = 'https://api-content.dropbox.com/1/files/' + path;
	}

	function req(str) {
		return function(p, cb) {
			delete p.query.limit;
			cb(str);
		};
	}

})(hello);

(function(hello) {
	// For APIs, once a version is no longer usable, any calls made to it will be defaulted to the next oldest usable version.
	// So we explicitly state it.
	var version = 'v2.9';

	hello.init({

		facebook: {

			name: 'Facebook',

			// SEE https://developers.facebook.com/docs/facebook-login/manually-build-a-login-flow
			oauth: {
				version: 2,
				auth: 'https://www.facebook.com/' + version + '/dialog/oauth/',
				grant: 'https://graph.facebook.com/oauth/access_token'
			},

			// Authorization scopes
			scope: {
				basic: 'public_profile',
				email: 'email',
				share: 'user_posts',
				birthday: 'user_birthday',
				events: 'user_events',
				photos: 'user_photos',
				videos: 'user_videos',
				friends: 'user_friends',
				files: 'user_photos,user_videos',
				publish_files: 'user_photos,user_videos,publish_actions',
				publish: 'publish_actions',

				// Deprecated in v2.0
				// Create_event	: 'create_event',

				offline_access: ''
			},

			// Refresh the access_token
			refresh: false,

			login: function(p) {

				// Reauthenticate
				// https://developers.facebook.com/docs/facebook-login/reauthentication
				if (p.options.force) {
					p.qs.auth_type = 'reauthenticate';
				}

				// Set the display value
				p.qs.display = p.options.display || 'popup';
			},

			logout: function(callback, options) {
				// Assign callback to a global handler
				var callbackID = hello.utils.globalEvent(callback);
				var redirect = encodeURIComponent(hello.settings.redirect_uri + '?' + hello.utils.param({callback:callbackID, result: JSON.stringify({force:true}), state: '{}'}));
				var token = (options.authResponse || {}).access_token;
				hello.utils.iframe('https://www.facebook.com/logout.php?next=' + redirect + '&access_token=' + token);

				// Possible responses:
				// String URL	- hello.logout should handle the logout
				// Undefined	- this function will handle the callback
				// True - throw a success, this callback isn't handling the callback
				// False - throw a error
				if (!token) {
					// If there isn't a token, the above wont return a response, so lets trigger a response
					return false;
				}
			},

			// API Base URL
			base: 'https://graph.facebook.com/' + version + '/',

			// Map GET requests
			get: {
				me: 'me?fields=email,first_name,last_name,name,timezone,verified',
				'me/friends': 'me/friends',
				'me/following': 'me/friends',
				'me/followers': 'me/friends',
				'me/share': 'me/feed',
				'me/like': 'me/likes',
				'me/files': 'me/albums',
				'me/albums': 'me/albums?fields=cover_photo,name',
				'me/album': '@{id}/photos?fields=picture',
				'me/photos': 'me/photos',
				'me/photo': '@{id}',
				'friend/albums': '@{id}/albums',
				'friend/photos': '@{id}/photos'

				// Pagination
				// Https://developers.facebook.com/docs/reference/api/pagination/
			},

			// Map POST requests
			post: {
				'me/share': 'me/feed',
				'me/photo': '@{id}'

				// Https://developers.facebook.com/docs/graph-api/reference/v2.2/object/likes/
			},

			wrap: {
				me: formatUser,
				'me/friends': formatFriends,
				'me/following': formatFriends,
				'me/followers': formatFriends,
				'me/albums': format,
				'me/photos': format,
				'me/files': format,
				'default': format
			},

			// Special requirements for handling XHR
			xhr: function(p, qs) {
				if (p.method === 'get' || p.method === 'post') {
					qs.suppress_response_codes = true;
				}

				// Is this a post with a data-uri?
				if (p.method === 'post' && p.data && typeof (p.data.file) === 'string') {
					// Convert the Data-URI to a Blob
					p.data.file = hello.utils.toBlob(p.data.file);
				}

				return true;
			},

			// Special requirements for handling JSONP fallback
			jsonp: function(p, qs) {
				var m = p.method;
				if (m !== 'get' && !hello.utils.hasBinary(p.data)) {
					p.data.method = m;
					p.method = 'get';
				}
				else if (p.method === 'delete') {
					qs.method = 'delete';
					p.method = 'post';
				}
			},

			// Special requirements for iframe form hack
			form: function(p) {
				return {
					// Fire the callback onload
					callbackonload: true
				};
			}
		}
	});

	var base = 'https://graph.facebook.com/';

	function formatUser(o) {
		if (o.id) {
			o.thumbnail = o.picture = 'https://graph.facebook.com/' + o.id + '/picture';
		}

		return o;
	}

	function formatFriends(o) {
		if ('data' in o) {
			o.data.forEach(formatUser);
		}

		return o;
	}

	function format(o, headers, req) {
		if (typeof o === 'boolean') {
			o = {success: o};
		}

		if (o && 'data' in o) {
			var token = req.query.access_token;

			if (!(o.data instanceof Array)) {
				var data = o.data;
				delete o.data;
				o.data = [data];
			}

			o.data.forEach(function(d) {

				if (d.picture) {
					d.thumbnail = d.picture;
				}

				d.pictures = (d.images || [])
					.sort(function(a, b) {
						return a.width - b.width;
					});

				if (d.cover_photo && d.cover_photo.id) {
					d.thumbnail = base + d.cover_photo.id + '/picture?access_token=' + token;
				}

				if (d.type === 'album') {
					d.files = d.photos = base + d.id + '/photos';
				}

				if (d.can_upload) {
					d.upload_location = base + d.id + '/photos';
				}
			});
		}

		return o;
	}

})(hello);

(function(hello) {

	hello.init({

		flickr: {

			name: 'Flickr',

			// Ensure that you define an oauth_proxy
			oauth: {
				version: '1.0a',
				auth: 'https://www.flickr.com/services/oauth/authorize?perms=read',
				request: 'https://www.flickr.com/services/oauth/request_token',
				token: 'https://www.flickr.com/services/oauth/access_token'
			},

			// API base URL
			base: 'https://api.flickr.com/services/rest',

			// Map GET resquests
			get: {
				me: sign('flickr.people.getInfo'),
				'me/friends': sign('flickr.contacts.getList', {per_page:'@{limit|50}'}),
				'me/following': sign('flickr.contacts.getList', {per_page:'@{limit|50}'}),
				'me/followers': sign('flickr.contacts.getList', {per_page:'@{limit|50}'}),
				'me/albums': sign('flickr.photosets.getList', {per_page:'@{limit|50}'}),
				'me/album': sign('flickr.photosets.getPhotos', {photoset_id: '@{id}'}),
				'me/photos': sign('flickr.people.getPhotos', {per_page:'@{limit|50}'})
			},

			wrap: {
				me: function(o) {
					formatError(o);
					o = checkResponse(o, 'person');
					if (o.id) {
						if (o.realname) {
							o.name = o.realname._content;
							var m = o.name.split(' ');
							o.first_name = m.shift();
							o.last_name = m.join(' ');
						}

						o.thumbnail = getBuddyIcon(o, 'l');
						o.picture = getBuddyIcon(o, 'l');
					}

					return o;
				},

				'me/friends': formatFriends,
				'me/followers': formatFriends,
				'me/following': formatFriends,
				'me/albums': function(o) {
					formatError(o);
					o = checkResponse(o, 'photosets');
					paging(o);
					if (o.photoset) {
						o.data = o.photoset;
						o.data.forEach(function(item) {
							item.name = item.title._content;
							item.photos = 'https://api.flickr.com/services/rest' + getApiUrl('flickr.photosets.getPhotos', {photoset_id: item.id}, true);
						});

						delete o.photoset;
					}

					return o;
				},

				'me/photos': function(o) {
					formatError(o);
					return formatPhotos(o);
				},

				'default': function(o) {
					formatError(o);
					return formatPhotos(o);
				}
			},

			xhr: false,

			jsonp: function(p, qs) {
				if (p.method == 'get') {
					delete qs.callback;
					qs.jsoncallback = p.callbackID;
				}
			}
		}
	});

	function getApiUrl(method, extraParams, skipNetwork) {
		var url = ((skipNetwork) ? '' : 'flickr:') +
			'?method=' + method +
			'&api_key=' + hello.services.flickr.id +
			'&format=json';
		for (var param in extraParams) {
			if (extraParams.hasOwnProperty(param)) {
				url += '&' + param + '=' + extraParams[param];
			}
		}

		return url;
	}

	// This is not exactly neat but avoid to call
	// The method 'flickr.test.login' for each api call

	function withUser(cb) {
		var auth = hello.getAuthResponse('flickr');
		cb(auth && auth.user_nsid ? auth.user_nsid : null);
	}

	function sign(url, params) {
		if (!params) {
			params = {};
		}

		return function(p, callback) {
			withUser(function(userId) {
				params.user_id = userId;
				callback(getApiUrl(url, params, true));
			});
		};
	}

	function getBuddyIcon(profile, size) {
		var url = 'https://www.flickr.com/images/buddyicon.gif';
		if (profile.nsid && profile.iconserver && profile.iconfarm) {
			url = 'https://farm' + profile.iconfarm + '.staticflickr.com/' +
				profile.iconserver + '/' +
				'buddyicons/' + profile.nsid +
				((size) ? '_' + size : '') + '.jpg';
		}

		return url;
	}

	// See: https://www.flickr.com/services/api/misc.urls.html
	function createPhotoUrl(id, farm, server, secret, size) {
		size = (size) ? '_' + size : '';
		return 'https://farm' + farm + '.staticflickr.com/' + server + '/' + id + '_' + secret + size + '.jpg';
	}

	function formatUser(o) {
	}

	function formatError(o) {
		if (o && o.stat && o.stat.toLowerCase() != 'ok') {
			o.error = {
				code: 'invalid_request',
				message: o.message
			};
		}
	}

	function formatPhotos(o) {
		if (o.photoset || o.photos) {
			var set = ('photoset' in o) ? 'photoset' : 'photos';
			o = checkResponse(o, set);
			paging(o);
			o.data = o.photo;
			delete o.photo;
			for (var i = 0; i < o.data.length; i++) {
				var photo = o.data[i];
				photo.name = photo.title;
				photo.picture = createPhotoUrl(photo.id, photo.farm, photo.server, photo.secret, '');
				photo.pictures = createPictures(photo.id, photo.farm, photo.server, photo.secret);
				photo.source = createPhotoUrl(photo.id, photo.farm, photo.server, photo.secret, 'b');
				photo.thumbnail = createPhotoUrl(photo.id, photo.farm, photo.server, photo.secret, 'm');
			}
		}

		return o;
	}

	// See: https://www.flickr.com/services/api/misc.urls.html
	function createPictures(id, farm, server, secret) {

		var NO_LIMIT = 2048;
		var sizes = [
			{id: 't', max: 100},
			{id: 'm', max: 240},
			{id: 'n', max: 320},
			{id: '', max: 500},
			{id: 'z', max: 640},
			{id: 'c', max: 800},
			{id: 'b', max: 1024},
			{id: 'h', max: 1600},
			{id: 'k', max: 2048},
			{id: 'o', max: NO_LIMIT}
		];

		return sizes.map(function(size) {
			return {
				source: createPhotoUrl(id, farm, server, secret, size.id),

				// Note: this is a guess that's almost certain to be wrong (unless square source)
				width: size.max,
				height: size.max
			};
		});
	}

	function checkResponse(o, key) {

		if (key in o) {
			o = o[key];
		}
		else if (!('error' in o)) {
			o.error = {
				code: 'invalid_request',
				message: o.message || 'Failed to get data from Flickr'
			};
		}

		return o;
	}

	function formatFriends(o) {
		formatError(o);
		if (o.contacts) {
			o = checkResponse(o, 'contacts');
			paging(o);
			o.data = o.contact;
			delete o.contact;
			for (var i = 0; i < o.data.length; i++) {
				var item = o.data[i];
				item.id = item.nsid;
				item.name = item.realname || item.username;
				item.thumbnail = getBuddyIcon(item, 'm');
			}
		}

		return o;
	}

	function paging(res) {
		if (res.page && res.pages && res.page !== res.pages) {
			res.paging = {
				next: '?page=' + (++res.page)
			};
		}
	}

})(hello);

(function(hello) {

	hello.init({

		foursquare: {

			name: 'Foursquare',

			oauth: {
				// See: https://developer.foursquare.com/overview/auth
				version: 2,
				auth: 'https://foursquare.com/oauth2/authenticate',
				grant: 'https://foursquare.com/oauth2/access_token'
			},

			// Refresh the access_token once expired
			refresh: true,

			base: 'https://api.foursquare.com/v2/',

			get: {
				me: 'users/self',
				'me/friends': 'users/self/friends',
				'me/followers': 'users/self/friends',
				'me/following': 'users/self/friends'
			},

			wrap: {
				me: function(o) {
					formatError(o);
					if (o && o.response) {
						o = o.response.user;
						formatUser(o);
					}

					return o;
				},

				'default': function(o) {
					formatError(o);

					// Format friends
					if (o && 'response' in o && 'friends' in o.response && 'items' in o.response.friends) {
						o.data = o.response.friends.items;
						o.data.forEach(formatUser);
						delete o.response;
					}

					return o;
				}
			},

			xhr: formatRequest,
			jsonp: formatRequest
		}
	});

	function formatError(o) {
		if (o.meta && (o.meta.code === 400 || o.meta.code === 401)) {
			o.error = {
				code: 'access_denied',
				message: o.meta.errorDetail
			};
		}
	}

	function formatUser(o) {
		if (o && o.id) {
			o.thumbnail = o.photo.prefix + '100x100' + o.photo.suffix;
			o.name = o.firstName + ' ' + o.lastName;
			o.first_name = o.firstName;
			o.last_name = o.lastName;
			if (o.contact) {
				if (o.contact.email) {
					o.email = o.contact.email;
				}
			}
		}
	}

	function formatRequest(p, qs) {
		var token = qs.access_token;
		delete qs.access_token;
		qs.oauth_token = token;
		qs.v = 20121125;
		return true;
	}

})(hello);

(function(hello) {

	hello.init({

		github: {

			name: 'GitHub',

			oauth: {
				version: 2,
				auth: 'https://github.com/login/oauth/authorize',
				grant: 'https://github.com/login/oauth/access_token',
				response_type: 'code'
			},

			scope: {
				email: 'user:email'
			},

			base: 'https://api.github.com/',

			get: {
				me: 'user',
				'me/friends': 'user/following?per_page=@{limit|100}',
				'me/following': 'user/following?per_page=@{limit|100}',
				'me/followers': 'user/followers?per_page=@{limit|100}',
				'me/like': 'user/starred?per_page=@{limit|100}'
			},

			wrap: {
				me: function(o, headers) {

					formatError(o, headers);
					formatUser(o);

					return o;
				},

				'default': function(o, headers, req) {

					formatError(o, headers);

					if (Array.isArray(o)) {
						o = {data:o};
					}

					if (o.data) {
						paging(o, headers, req);
						o.data.forEach(formatUser);
					}

					return o;
				}
			},

			xhr: function(p) {

				if (p.method !== 'get' && p.data) {

					// Serialize payload as JSON
					p.headers = p.headers || {};
					p.headers['Content-Type'] = 'application/json';
					if (typeof (p.data) === 'object') {
						p.data = JSON.stringify(p.data);
					}
				}

				return true;
			}
		}
	});

	function formatError(o, headers) {
		var code = headers ? headers.statusCode : (o && 'meta' in o && 'status' in o.meta && o.meta.status);
		if ((code === 401 || code === 403)) {
			o.error = {
				code: 'access_denied',
				message: o.message || (o.data ? o.data.message : 'Could not get response')
			};
			delete o.message;
		}
	}

	function formatUser(o) {
		if (o.id) {
			o.thumbnail = o.picture = o.avatar_url;
			o.name = o.login;
		}
	}

	function paging(res, headers, req) {
		if (res.data && res.data.length && headers && headers.Link) {
			var next = headers.Link.match(/<(.*?)>;\s*rel=\"next\"/);
			if (next) {
				res.paging = {
					next: next[1]
				};
			}
		}
	}

})(hello);

(function(hello) {

	var contactsUrl = 'https://www.google.com/m8/feeds/contacts/default/full?v=3.0&alt=json&max-results=@{limit|1000}&start-index=@{start|1}';

	hello.init({

		google: {

			name: 'Google Sign-In',

			// See: http://code.google.com/apis/accounts/docs/OAuth2UserAgent.html
			oauth: {
				version: 2,
				auth: 'https://accounts.google.com/o/oauth2/v2/auth',
				grant: 'https://www.googleapis.com/oauth2/v4/token'
			},

			// Authorization scopes
			scope: {
				basic: 'openid profile',
				email: 'email',
				birthday: '',
				events: '',
				photos: 'https://picasaweb.google.com/data/',
				videos: 'http://gdata.youtube.com',
				files: 'https://www.googleapis.com/auth/drive.readonly',
				publish: '',
				publish_files: 'https://www.googleapis.com/auth/drive',
				share: '',
				create_event: '',
				offline_access: ''
			},

			scope_delim: ' ',

			login: function(p) {

				if (p.qs.response_type === 'code') {

					// Let's set this to an offline access to return a refresh_token
					p.qs.access_type = 'offline';
				}
				else if (p.qs.response_type.indexOf('id_token') > -1) {
					p.qs.nonce = parseInt(Math.random() * 1e12, 10).toString(36);
				}

				// Reauthenticate
				// https://developers.google.com/identity/protocols/
				if (p.options.force) {
					p.qs.approval_prompt = 'force';
				}
			},

			// API base URI
			base: 'https://www.googleapis.com/',

			// Map GET requests
			get: {
				me: 'oauth2/v3/userinfo?alt=json',

				// Deprecated Sept 1, 2014
				//'me': 'oauth2/v1/userinfo?alt=json',

				// See: https://developers.google.com/+/api/latest/people/list
				'me/following': contactsUrl,
				'me/followers': contactsUrl,
				'me/contacts': contactsUrl,
				'me/albums': 'https://picasaweb.google.com/data/feed/api/user/default?alt=json&max-results=@{limit|100}&start-index=@{start|1}',
				'me/album': function(p, callback) {
					var key = p.query.id;
					delete p.query.id;
					callback(key.replace('/entry/', '/feed/'));
				},

				'me/photos': 'https://picasaweb.google.com/data/feed/api/user/default?alt=json&kind=photo&max-results=@{limit|100}&start-index=@{start|1}',

				// See: https://developers.google.com/drive/v2/reference/files/list
				'me/file': 'drive/v2/files/@{id}',
				'me/files': 'drive/v2/files?q=%22@{parent|root}%22+in+parents+and+trashed=false&maxResults=@{limit|100}',

				// See: https://developers.google.com/drive/v2/reference/files/list
				'me/folders': 'drive/v2/files?q=%22@{id|root}%22+in+parents+and+mimeType+=+%22application/vnd.google-apps.folder%22+and+trashed=false&maxResults=@{limit|100}',

				// See: https://developers.google.com/drive/v2/reference/files/list
				'me/folder': 'drive/v2/files?q=%22@{id|root}%22+in+parents+and+trashed=false&maxResults=@{limit|100}'
			},

			// Map POST requests
			post: {

				// Google Drive
				'me/files': uploadDrive,
				'me/folders': function(p, callback) {
					p.data = {
						title: p.data.name,
						parents: [{id: p.data.parent || 'root'}],
						mimeType: 'application/vnd.google-apps.folder'
					};
					callback('drive/v2/files');
				}
			},

			// Map PUT requests
			put: {
				'me/files': uploadDrive
			},

			// Map DELETE requests
			del: {
				'me/files': 'drive/v2/files/@{id}',
				'me/folder': 'drive/v2/files/@{id}'
			},

			// Map PATCH requests
			patch: {
				'me/file': 'drive/v2/files/@{id}'
			},

			wrap: {
				me: function(o) {
					if (o.sub) {
						o.id = o.sub;
					}

					if (o.id) {
						o.last_name = o.family_name || (o.name ? o.name.familyName : null);
						o.first_name = o.given_name || (o.name ? o.name.givenName : null);

						if (o.emails && o.emails.length) {
							o.email = o.emails[0].value;
						}

						formatPerson(o);
					}

					return o;
				},

				'me/friends': function(o) {
					if (o.items) {
						paging(o);
						o.data = o.items;
						o.data.forEach(formatPerson);
						delete o.items;
					}

					return o;
				},

				'me/contacts': formatFriends,
				'me/followers': formatFriends,
				'me/following': formatFriends,
				'me/share': formatFeed,
				'me/feed': formatFeed,
				'me/albums': gEntry,
				'me/photos': formatPhotos,
				'default': gEntry
			},

			xhr: function(p) {

				if (p.method === 'post' || p.method === 'put') {
					toJSON(p);
				}
				else if (p.method === 'patch') {
					hello.utils.extend(p.query, p.data);
					p.data = null;
				}

				return true;
			},

			// Don't even try submitting via form.
			// This means no POST operations in <=IE9
			form: false
		}
	});

	function toInt(s) {
		return parseInt(s, 10);
	}

	function formatFeed(o) {
		paging(o);
		o.data = o.items;
		delete o.items;
		return o;
	}

	// Format: ensure each record contains a name, id etc.
	function formatItem(o) {
		if (o.error) {
			return;
		}

		if (!o.name) {
			o.name = o.title || o.message;
		}

		if (!o.picture) {
			o.picture = o.thumbnailLink;
		}

		if (!o.thumbnail) {
			o.thumbnail = o.thumbnailLink;
		}

		if (o.mimeType === 'application/vnd.google-apps.folder') {
			o.type = 'folder';
			o.files = 'https://www.googleapis.com/drive/v2/files?q=%22' + o.id + '%22+in+parents';
		}

		return o;
	}

	function formatImage(image) {
		return {
			source: image.url,
			width: image.width,
			height: image.height
		};
	}

	function formatPhotos(o) {
		if ('feed' in o) {
			o.data = 'entry' in o.feed ? o.feed.entry.map(formatEntry) : [];
			delete o.feed;
		}

		return o;
	}

	// Google has a horrible JSON API
	function gEntry(o) {
		paging(o);

		if ('feed' in o && 'entry' in o.feed) {
			o.data = o.feed.entry.map(formatEntry);
			delete o.feed;
		}

		// Old style: Picasa, etc.
		else if ('entry' in o) {
			return formatEntry(o.entry);
		}

		// New style: Google Drive
		else if ('items' in o) {
			o.data = o.items.map(formatItem);
			delete o.items;
		}
		else {
			formatItem(o);
		}

		return o;
	}

	function formatPerson(o) {
		o.name = o.displayName || o.name;
		o.picture = o.picture || (o.image ? o.image.url : null);
		o.thumbnail = o.picture;
	}

	function formatFriends(o, headers, req) {
		paging(o);
		var r = [];
		if ('feed' in o && 'entry' in o.feed) {
			var token = req.query.access_token;
			for (var i = 0; i < o.feed.entry.length; i++) {
				var a = o.feed.entry[i];

				a.id	= a.id.$t;
				a.name	= a.title.$t;
				delete a.title;
				if (a.gd$email) {
					a.email	= (a.gd$email && a.gd$email.length > 0) ? a.gd$email[0].address : null;
					a.emails = a.gd$email;
					delete a.gd$email;
				}

				if (a.updated) {
					a.updated = a.updated.$t;
				}

				if (a.link) {

					var pic = (a.link.length > 0) ? a.link[0].href : null;
					if (pic && a.link[0].gd$etag) {
						pic += (pic.indexOf('?') > -1 ? '&' : '?') + 'access_token=' + token;
						a.picture = pic;
						a.thumbnail = pic;
					}

					delete a.link;
				}

				if (a.category) {
					delete a.category;
				}
			}

			o.data = o.feed.entry;
			delete o.feed;
		}

		return o;
	}

	function formatEntry(a) {

		var group = a.media$group;
		var photo = group.media$content.length ? group.media$content[0] : {};
		var mediaContent = group.media$content || [];
		var mediaThumbnail = group.media$thumbnail || [];

		var pictures = mediaContent
			.concat(mediaThumbnail)
			.map(formatImage)
			.sort(function(a, b) {
				return a.width - b.width;
			});

		var i = 0;
		var _a;
		var p = {
			id: a.id.$t,
			name: a.title.$t,
			description: a.summary.$t,
			updated_time: a.updated.$t,
			created_time: a.published.$t,
			picture: photo ? photo.url : null,
			pictures: pictures,
			images: [],
			thumbnail: photo ? photo.url : null,
			width: photo.width,
			height: photo.height
		};

		// Get feed/children
		if ('link' in a) {
			for (i = 0; i < a.link.length; i++) {
				var d = a.link[i];
				if (d.rel.match(/\#feed$/)) {
					p.upload_location = p.files = p.photos = d.href;
					break;
				}
			}
		}

		// Get images of different scales
		if ('category' in a && a.category.length) {
			_a = a.category;
			for (i = 0; i < _a.length; i++) {
				if (_a[i].scheme && _a[i].scheme.match(/\#kind$/)) {
					p.type = _a[i].term.replace(/^.*?\#/, '');
				}
			}
		}

		// Get images of different scales
		if ('media$thumbnail' in group && group.media$thumbnail.length) {
			_a = group.media$thumbnail;
			p.thumbnail = _a[0].url;
			p.images = _a.map(formatImage);
		}

		_a = group.media$content;

		if (_a && _a.length) {
			p.images.push(formatImage(_a[0]));
		}

		return p;
	}

	function paging(res) {

		// Contacts V2
		if ('feed' in res && res.feed.openSearch$itemsPerPage) {
			var limit = toInt(res.feed.openSearch$itemsPerPage.$t);
			var start = toInt(res.feed.openSearch$startIndex.$t);
			var total = toInt(res.feed.openSearch$totalResults.$t);

			if ((start + limit) < total) {
				res.paging = {
					next: '?start=' + (start + limit)
				};
			}
		}
		else if ('nextPageToken' in res) {
			res.paging = {
				next: '?pageToken=' + res.nextPageToken
			};
		}
	}

	// Construct a multipart message
	function Multipart() {

		// Internal body
		var body = [];
		var boundary = (Math.random() * 1e10).toString(32);
		var counter = 0;
		var lineBreak = '\r\n';
		var delim = lineBreak + '--' + boundary;
		var ready = function() {};

		var dataUri = /^data\:([^;,]+(\;charset=[^;,]+)?)(\;base64)?,/i;

		// Add file
		function addFile(item) {
			var fr = new FileReader();
			fr.onload = function(e) {
				addContent(btoa(e.target.result), item.type + lineBreak + 'Content-Transfer-Encoding: base64');
			};

			fr.readAsBinaryString(item);
		}

		// Add content
		function addContent(content, type) {
			body.push(lineBreak + 'Content-Type: ' + type + lineBreak + lineBreak + content);
			counter--;
			ready();
		}

		// Add new things to the object
		this.append = function(content, type) {

			// Does the content have an array
			if (typeof (content) === 'string' || !('length' in Object(content))) {
				// Converti to multiples
				content = [content];
			}

			for (var i = 0; i < content.length; i++) {

				counter++;

				var item = content[i];

				// Is this a file?
				// Files can be either Blobs or File types
				if (
					(typeof (File) !== 'undefined' && item instanceof File) ||
					(typeof (Blob) !== 'undefined' && item instanceof Blob)
				) {
					// Read the file in
					addFile(item);
				}

				// Data-URI?
				// Data:[<mime type>][;charset=<charset>][;base64],<encoded data>
				// /^data\:([^;,]+(\;charset=[^;,]+)?)(\;base64)?,/i
				else if (typeof (item) === 'string' && item.match(dataUri)) {
					var m = item.match(dataUri);
					addContent(item.replace(dataUri, ''), m[1] + lineBreak + 'Content-Transfer-Encoding: base64');
				}

				// Regular string
				else {
					addContent(item, type);
				}
			}
		};

		this.onready = function(fn) {
			ready = function() {
				if (counter === 0) {
					// Trigger ready
					body.unshift('');
					body.push('--');
					fn(body.join(delim), boundary);
					body = [];
				}
			};

			ready();
		};
	}

	// Upload to Drive
	// If this is PUT then only augment the file uploaded
	// PUT https://developers.google.com/drive/v2/reference/files/update
	// POST https://developers.google.com/drive/manage-uploads
	function uploadDrive(p, callback) {

		var data = {};

		// Test for DOM element
		if (p.data &&
			(typeof (HTMLInputElement) !== 'undefined' && p.data instanceof HTMLInputElement)
		) {
			p.data = {file: p.data};
		}

		if (!p.data.name && Object(Object(p.data.file).files).length && p.method === 'post') {
			p.data.name = p.data.file.files[0].name;
		}

		if (p.method === 'post') {
			p.data = {
				title: p.data.name,
				parents: [{id: p.data.parent || 'root'}],
				file: p.data.file
			};
		}
		else {

			// Make a reference
			data = p.data;
			p.data = {};

			// Add the parts to change as required
			if (data.parent) {
				p.data.parents = [{id: p.data.parent || 'root'}];
			}

			if (data.file) {
				p.data.file = data.file;
			}

			if (data.name) {
				p.data.title = data.name;
			}
		}

		// Extract the file, if it exists from the data object
		// If the File is an INPUT element lets just concern ourselves with the NodeList
		var file;
		if ('file' in p.data) {
			file = p.data.file;
			delete p.data.file;

			if (typeof (file) === 'object' && 'files' in file) {
				// Assign the NodeList
				file = file.files;
			}

			if (!file || !file.length) {
				callback({
					error: {
						code: 'request_invalid',
						message: 'There were no files attached with this request to upload'
					}
				});
				return;
			}
		}

		// Set type p.data.mimeType = Object(file[0]).type || 'application/octet-stream';

		// Construct a multipart message
		var parts = new Multipart();
		parts.append(JSON.stringify(p.data), 'application/json');

		// Read the file into a  base64 string... yep a hassle, i know
		// FormData doesn't let us assign our own Multipart headers and HTTP Content-Type
		// Alas GoogleApi need these in a particular format
		if (file) {
			parts.append(file);
		}

		parts.onready(function(body, boundary) {

			p.headers['content-type'] = 'multipart/related; boundary="' + boundary + '"';
			p.data = body;

			callback('upload/drive/v2/files' + (data.id ? '/' + data.id : '') + '?uploadType=multipart');
		});

	}

	function toJSON(p) {
		if (typeof (p.data) === 'object') {
			// Convert the POST into a javascript object
			try {
				p.data = JSON.stringify(p.data);
				p.headers['content-type'] = 'application/json';
			}
			catch (e) {}
		}
	}

})(hello);

(function(hello) {

	hello.init({

		instagram: {

			name: 'Instagram',

			oauth: {
				// See: http://instagram.com/developer/authentication/
				version: 2,
				auth: 'https://instagram.com/oauth/authorize/',
				grant: 'https://api.instagram.com/oauth/access_token'
			},

			// Refresh the access_token once expired
			refresh: true,

			scope: {
				basic: 'basic',
				photos: '',
				friends: 'relationships',
				publish: 'likes comments',
				email: '',
				share: '',
				publish_files: '',
				files: '',
				videos: '',
				offline_access: ''
			},

			scope_delim: ' ',

			base: 'https://api.instagram.com/v1/',

			get: {
				me: 'users/self',
				'me/feed': 'users/self/feed?count=@{limit|100}',
				'me/photos': 'users/self/media/recent?min_id=0&count=@{limit|100}',
				'me/friends': 'users/self/follows?count=@{limit|100}',
				'me/following': 'users/self/follows?count=@{limit|100}',
				'me/followers': 'users/self/followed-by?count=@{limit|100}',
				'friend/photos': 'users/@{id}/media/recent?min_id=0&count=@{limit|100}'
			},

			post: {
				'me/like': function(p, callback) {
					var id = p.data.id;
					p.data = {};
					callback('media/' + id + '/likes');
				}
			},

			del: {
				'me/like': 'media/@{id}/likes'
			},

			wrap: {
				me: function(o) {

					formatError(o);

					if ('data' in o) {
						o.id = o.data.id;
						o.thumbnail = o.data.profile_picture;
						o.name = o.data.full_name || o.data.username;
					}

					return o;
				},

				'me/friends': formatFriends,
				'me/following': formatFriends,
				'me/followers': formatFriends,
				'me/photos': function(o) {

					formatError(o);
					paging(o);

					if ('data' in o) {
						o.data = o.data.filter(function(d) {
							return d.type === 'image';
						});

						o.data.forEach(function(d) {
							d.name = d.caption ? d.caption.text : null;
							d.thumbnail = d.images.thumbnail.url;
							d.picture = d.images.standard_resolution.url;
							d.pictures = Object.keys(d.images)
								.map(function(key) {
									var image = d.images[key];
									return formatImage(image);
								})
								.sort(function(a, b) {
									return a.width - b.width;
								});
						});
					}

					return o;
				},

				'default': function(o) {
					o = formatError(o);
					paging(o);
					return o;
				}
			},

			// Instagram does not return any CORS Headers
			// So besides JSONP we're stuck with proxy
			xhr: function(p, qs) {

				var method = p.method;
				var proxy = method !== 'get';

				if (proxy) {

					if ((method === 'post' || method === 'put') && p.query.access_token) {
						p.data.access_token = p.query.access_token;
						delete p.query.access_token;
					}

					// No access control headers
					// Use the proxy instead
					p.proxy = proxy;
				}

				return proxy;
			},

			// No form
			form: false
		}
	});

	function formatImage(image) {
		return {
			source: image.url,
			width: image.width,
			height: image.height
		};
	}

	function formatError(o) {
		if (typeof o === 'string') {
			return {
				error: {
					code: 'invalid_request',
					message: o
				}
			};
		}

		if (o && 'meta' in o && 'error_type' in o.meta) {
			o.error = {
				code: o.meta.error_type,
				message: o.meta.error_message
			};
		}

		return o;
	}

	function formatFriends(o) {
		paging(o);
		if (o && 'data' in o) {
			o.data.forEach(formatFriend);
		}

		return o;
	}

	function formatFriend(o) {
		if (o.id) {
			o.thumbnail = o.profile_picture;
			o.name = o.full_name || o.username;
		}
	}

	// See: http://instagram.com/developer/endpoints/
	function paging(res) {
		if ('pagination' in res) {
			res.paging = {
				next: res.pagination.next_url
			};
			delete res.pagination;
		}
	}

})(hello);

(function(hello) {

	hello.init({

		joinme: {

			name: 'join.me',

			oauth: {
				version: 2,
				auth: 'https://secure.join.me/api/public/v1/auth/oauth2',
				grant: 'https://secure.join.me/api/public/v1/auth/oauth2'
			},

			refresh: false,

			scope: {
				basic: 'user_info',
				user: 'user_info',
				scheduler: 'scheduler',
				start: 'start_meeting',
				email: '',
				friends: '',
				share: '',
				publish: '',
				photos: '',
				publish_files: '',
				files: '',
				videos: '',
				offline_access: ''
			},

			scope_delim: ' ',

			login: function(p) {
				p.options.popup.width = 400;
				p.options.popup.height = 700;
			},

			base: 'https://api.join.me/v1/',

			get: {
				me: 'user',
				meetings: 'meetings',
				'meetings/info': 'meetings/@{id}'
			},

			post: {
				'meetings/start/adhoc': function(p, callback) {
					callback('meetings/start');
				},

				'meetings/start/scheduled': function(p, callback) {
					var meetingId = p.data.meetingId;
					p.data = {};
					callback('meetings/' + meetingId + '/start');
				},

				'meetings/schedule': function(p, callback) {
					callback('meetings');
				}
			},

			patch: {
				'meetings/update': function(p, callback) {
					callback('meetings/' + p.data.meetingId);
				}
			},

			del: {
				'meetings/delete': 'meetings/@{id}'
			},

			wrap: {
				me: function(o, headers) {
					formatError(o, headers);

					if (!o.email) {
						return o;
					}

					o.name = o.fullName;
					o.first_name = o.name.split(' ')[0];
					o.last_name = o.name.split(' ')[1];
					o.id = o.email;

					return o;
				},

				'default': function(o, headers) {
					formatError(o, headers);

					return o;
				}
			},

			xhr: formatRequest

		}
	});

	function formatError(o, headers) {
		var errorCode;
		var message;
		var details;

		if (o && ('Message' in o)) {
			message = o.Message;
			delete o.Message;

			if ('ErrorCode' in o) {
				errorCode = o.ErrorCode;
				delete o.ErrorCode;
			}
			else {
				errorCode = getErrorCode(headers);
			}

			o.error = {
				code: errorCode,
				message: message,
				details: o
			};
		}

		return o;
	}

	function formatRequest(p, qs) {
		// Move the access token from the request body to the request header
		var token = qs.access_token;
		delete qs.access_token;
		p.headers.Authorization = 'Bearer ' + token;

		// Format non-get requests to indicate json body
		if (p.method !== 'get' && p.data) {
			p.headers['Content-Type'] = 'application/json';
			if (typeof (p.data) === 'object') {
				p.data = JSON.stringify(p.data);
			}
		}

		if (p.method === 'put') {
			p.method = 'patch';
		}

		return true;
	}

	function getErrorCode(headers) {
		switch (headers.statusCode) {
			case 400:
				return 'invalid_request';
			case 403:
				return 'stale_token';
			case 401:
				return 'invalid_token';
			case 500:
				return 'server_error';
			default:
				return 'server_error';
		}
	}

}(hello));

(function(hello) {

	hello.init({

		linkedin: {

			oauth: {
				version: 2,
				response_type: 'code',
				auth: 'https://www.linkedin.com/uas/oauth2/authorization',
				grant: 'https://www.linkedin.com/uas/oauth2/accessToken'
			},

			// Refresh the access_token once expired
			refresh: true,

			scope: {
				basic: 'r_basicprofile',
				email: 'r_emailaddress',
				files: '',
				friends: '',
				photos: '',
				publish: 'w_share',
				publish_files: 'w_share',
				share: '',
				videos: '',
				offline_access: ''
			},
			scope_delim: ' ',

			base: 'https://api.linkedin.com/v1/',

			get: {
				me: 'people/~:(picture-url,first-name,last-name,id,formatted-name,email-address)',

				// See: http://developer.linkedin.com/documents/get-network-updates-and-statistics-api
				'me/share': 'people/~/network/updates?count=@{limit|250}'
			},

			post: {

				// See: https://developer.linkedin.com/documents/api-requests-json
				'me/share': function(p, callback) {
					var data = {
						visibility: {
							code: 'anyone'
						}
					};

					if (p.data.id) {

						data.attribution = {
							share: {
								id: p.data.id
							}
						};

					}
					else {
						data.comment = p.data.message;
						if (p.data.picture && p.data.link) {
							data.content = {
								'submitted-url': p.data.link,
								'submitted-image-url': p.data.picture
							};
						}
					}

					p.data = JSON.stringify(data);

					callback('people/~/shares?format=json');
				},

				'me/like': like
			},

			del:{
				'me/like': like
			},

			wrap: {
				me: function(o) {
					formatError(o);
					formatUser(o);
					return o;
				},

				'me/friends': formatFriends,
				'me/following': formatFriends,
				'me/followers': formatFriends,
				'me/share': function(o) {
					formatError(o);
					paging(o);
					if (o.values) {
						o.data = o.values.map(formatUser);
						o.data.forEach(function(item) {
							item.message = item.headline;
						});

						delete o.values;
					}

					return o;
				},

				'default': function(o, headers) {
					formatError(o);
					empty(o, headers);
					paging(o);
				}
			},

			jsonp: function(p, qs) {
				formatQuery(qs);
				if (p.method === 'get') {
					qs.format = 'jsonp';
					qs['error-callback'] = p.callbackID;
				}
			},

			xhr: function(p, qs) {
				if (p.method !== 'get') {
					formatQuery(qs);
					p.headers['Content-Type'] = 'application/json';

					// Note: x-li-format ensures error responses are not returned in XML
					p.headers['x-li-format'] = 'json';
					p.proxy = true;
					return true;
				}

				return false;
			}
		}
	});

	function formatError(o) {
		if (o && 'errorCode' in o) {
			o.error = {
				code: o.status,
				message: o.message
			};
		}
	}

	function formatUser(o) {
		if (o.error) {
			return;
		}

		o.first_name = o.firstName;
		o.last_name = o.lastName;
		o.name = o.formattedName || (o.first_name + ' ' + o.last_name);
		o.thumbnail = o.pictureUrl;
		o.email = o.emailAddress;
		return o;
	}

	function formatFriends(o) {
		formatError(o);
		paging(o);
		if (o.values) {
			o.data = o.values.map(formatUser);
			delete o.values;
		}

		return o;
	}

	function paging(res) {
		if ('_count' in res && '_start' in res && (res._count + res._start) < res._total) {
			res.paging = {
				next: '?start=' + (res._start + res._count) + '&count=' + res._count
			};
		}
	}

	function empty(o, headers) {
		if (JSON.stringify(o) === '{}' && headers.statusCode === 200) {
			o.success = true;
		}
	}

	function formatQuery(qs) {
		// LinkedIn signs requests with the parameter 'oauth2_access_token'
		// ... yeah another one who thinks they should be different!
		if (qs.access_token) {
			qs.oauth2_access_token = qs.access_token;
			delete qs.access_token;
		}
	}

	function like(p, callback) {
		p.headers['x-li-format'] = 'json';
		var id = p.data.id;
		p.data = (p.method !== 'delete').toString();
		p.method = 'put';
		callback('people/~/network/updates/key=' + id + '/is-liked');
	}

})(hello);

// See: https://developers.soundcloud.com/docs/api/reference
(function(hello) {

	hello.init({

		soundcloud: {
			name: 'SoundCloud',

			oauth: {
				version: 2,
				auth: 'https://soundcloud.com/connect',
				grant: 'https://soundcloud.com/oauth2/token'
			},

			// Request path translated
			base: 'https://api.soundcloud.com/',
			get: {
				me: 'me.json',

				// Http://developers.soundcloud.com/docs/api/reference#me
				'me/friends': 'me/followings.json',
				'me/followers': 'me/followers.json',
				'me/following': 'me/followings.json',

				// See: http://developers.soundcloud.com/docs/api/reference#activities
				'default': function(p, callback) {

					// Include '.json at the end of each request'
					callback(p.path + '.json');
				}
			},

			// Response handlers
			wrap: {
				me: function(o) {
					formatUser(o);
					return o;
				},

				'default': function(o) {
					if (Array.isArray(o)) {
						o = {
							data: o.map(formatUser)
						};
					}

					paging(o);
					return o;
				}
			},

			xhr: formatRequest,
			jsonp: formatRequest
		}
	});

	function formatRequest(p, qs) {
		// Alter the querystring
		var token = qs.access_token;
		delete qs.access_token;
		qs.oauth_token = token;
		qs['_status_code_map[302]'] = 200;
		return true;
	}

	function formatUser(o) {
		if (o.id) {
			o.picture = o.avatar_url;
			o.thumbnail = o.avatar_url;
			o.name = o.username || o.full_name;
		}

		return o;
	}

	// See: http://developers.soundcloud.com/docs/api/reference#activities
	function paging(res) {
		if ('next_href' in res) {
			res.paging = {
				next: res.next_href
			};
		}
	}

})(hello);

// See: https://developer.spotify.com/web-api/
(function(hello) {

	hello.init({

		spotify: {
			name: 'Spotify',

			oauth: {
				version: 2,
				auth: 'https://accounts.spotify.com/authorize',
				grant: 'https://accounts.spotify.com/api/token'
			},

			// See: https://developer.spotify.com/web-api/using-scopes/
			scope_delim: ' ',
			scope: {
				basic: '',
				photos: '',
				friends: 'user-follow-read',
				publish: 'user-library-read',
				email: 'user-read-email',
				share: '',
				publish_files: '',
				files: '',
				videos: '',
				offline_access: ''
			},

			// Request path translated
			base: 'https://api.spotify.com',

			// See: https://developer.spotify.com/web-api/endpoint-reference/
			get: {
				me: '/v1/me',
				'me/following': '/v1/me/following?type=artist', // Only 'artist' is supported

				// Because tracks, albums and playlist exist on spotify, the tracks are considered
				// the resource for the 'me/likes' endpoint
				'me/like': '/v1/me/tracks'
			},

			// Response handlers
			wrap: {
				me: formatUser,
				'me/following': formatFollowees,
				'me/like': formatTracks
			},

			xhr: formatRequest,
			jsonp: false
		}
	});

	// Move the access token from the request body to the request header
	function formatRequest(p, qs) {
		var token = qs.access_token;
		delete qs.access_token;
		p.headers.Authorization = 'Bearer ' + token;

		return true;
	}

	function formatUser(o) {
		if (o.id) {
			o.name = o.display_name;
			o.thumbnail = o.images.length ? o.images[0].url : null;
			o.picture = o.thumbnail;
		}

		return o;
	}

	function formatFollowees(o) {
		paging(o);
		if (o && 'artists' in o) {
			o.data = o.artists.items.forEach(formatUser);
		}

		return o;
	}

	function formatTracks(o) {
		paging(o);
		o.data = o.items;

		return o;
	}

	function paging(res) {
		if (res && 'next' in res) {
			res.paging = {
				next: res.next
			};
			delete res.next;
		}
	}

})(hello);

(function(hello) {

	var base = 'https://api.twitter.com/';

	hello.init({

		twitter: {

			// Ensure that you define an oauth_proxy
			oauth: {
				version: '1.0a',
				auth: base + 'oauth/authenticate',
				request: base + 'oauth/request_token',
				token: base + 'oauth/access_token'
			},

			login: function(p) {
				// Reauthenticate
				// https://dev.twitter.com/oauth/reference/get/oauth/authenticate
				var prefix = '?force_login=true';
				this.oauth.auth = this.oauth.auth.replace(prefix, '') + (p.options.force ? prefix : '');
			},

			base: base + '1.1/',

			get: {
				me: 'account/verify_credentials.json',
				'me/friends': 'friends/list.json?count=@{limit|200}',
				'me/following': 'friends/list.json?count=@{limit|200}',
				'me/followers': 'followers/list.json?count=@{limit|200}',

				// Https://dev.twitter.com/docs/api/1.1/get/statuses/user_timeline
				'me/share': 'statuses/user_timeline.json?count=@{limit|200}',

				// Https://dev.twitter.com/rest/reference/get/favorites/list
				'me/like': 'favorites/list.json?count=@{limit|200}'
			},

			post: {
				'me/share': function(p, callback) {

					var data = p.data;
					p.data = null;

					var status = [];

					// Change message to status
					if (data.message) {
						status.push(data.message);
						delete data.message;
					}

					// If link is given
					if (data.link) {
						status.push(data.link);
						delete data.link;
					}

					if (data.picture) {
						status.push(data.picture);
						delete data.picture;
					}

					// Compound all the components
					if (status.length) {
						data.status = status.join(' ');
					}

					// Tweet media
					if (data.file) {
						data['media[]'] = data.file;
						delete data.file;
						p.data = data;
						callback('statuses/update_with_media.json');
					}

					// Retweet?
					else if ('id' in data) {
						callback('statuses/retweet/' + data.id + '.json');
					}

					// Tweet
					else {
						// Assign the post body to the query parameters
						hello.utils.extend(p.query, data);
						callback('statuses/update.json?include_entities=1');
					}
				},

				// See: https://dev.twitter.com/rest/reference/post/favorites/create
				'me/like': function(p, callback) {
					var id = p.data.id;
					p.data = null;
					callback('favorites/create.json?id=' + id);
				}
			},

			del: {

				// See: https://dev.twitter.com/rest/reference/post/favorites/destroy
				'me/like': function() {
					p.method = 'post';
					var id = p.data.id;
					p.data = null;
					callback('favorites/destroy.json?id=' + id);
				}
			},

			wrap: {
				me: function(res) {
					formatError(res);
					formatUser(res);
					return res;
				},

				'me/friends': formatFriends,
				'me/followers': formatFriends,
				'me/following': formatFriends,

				'me/share': function(res) {
					formatError(res);
					paging(res);
					if (!res.error && 'length' in res) {
						return {data: res};
					}

					return res;
				},

				'default': function(res) {
					res = arrayToDataResponse(res);
					paging(res);
					return res;
				}
			},
			xhr: function(p) {

				// Rely on the proxy for non-GET requests.
				return (p.method !== 'get');
			}
		}
	});

	function formatUser(o) {
		if (o.id) {
			if (o.name) {
				var m = o.name.split(' ');
				o.first_name = m.shift();
				o.last_name = m.join(' ');
			}

			// See: https://dev.twitter.com/overview/general/user-profile-images-and-banners
			o.thumbnail = o.profile_image_url_https || o.profile_image_url;
		}

		return o;
	}

	function formatFriends(o) {
		formatError(o);
		paging(o);
		if (o.users) {
			o.data = o.users.map(formatUser);
			delete o.users;
		}

		return o;
	}

	function formatError(o) {
		if (o.errors) {
			var e = o.errors[0];
			o.error = {
				code: 'request_failed',
				message: e.message
			};
		}
	}

	// Take a cursor and add it to the path
	function paging(res) {
		// Does the response include a 'next_cursor_string'
		if ('next_cursor_str' in res) {
			// See: https://dev.twitter.com/docs/misc/cursoring
			res.paging = {
				next: '?cursor=' + res.next_cursor_str
			};
		}
	}

	function arrayToDataResponse(res) {
		return Array.isArray(res) ? {data: res} : res;
	}

	/**
	// The documentation says to define user in the request
	// Although its not actually required.

	var user_id;

	function withUserId(callback){
		if(user_id){
			callback(user_id);
		}
		else{
			hello.api('twitter:/me', function(o){
				user_id = o.id;
				callback(o.id);
			});
		}
	}

	function sign(url){
		return function(p, callback){
			withUserId(function(user_id){
				callback(url+'?user_id='+user_id);
			});
		};
	}
	*/

})(hello);

// Vkontakte (vk.com)
(function(hello) {

	hello.init({

		vk: {
			name: 'Vk',

			// See https://vk.com/dev/oauth_dialog
			oauth: {
				version: 2,
				auth: 'https://oauth.vk.com/authorize',
				grant: 'https://oauth.vk.com/access_token'
			},

			// Authorization scopes
			// See https://vk.com/dev/permissions
			scope: {
				email: 'email',
				friends: 'friends',
				photos: 'photos',
				videos: 'video',
				share: 'share',
				offline_access: 'offline'
			},

			// Refresh the access_token
			refresh: true,

			login: function(p) {
				p.qs.display = window.navigator &&
					window.navigator.userAgent &&
					/ipad|phone|phone|android/.test(window.navigator.userAgent.toLowerCase()) ? 'mobile' : 'popup';
			},

			// API Base URL
			base: 'https://api.vk.com/method/',

			// Map GET requests
			get: {
				me: function(p, callback) {
					p.query.fields = 'id,first_name,last_name,photo_max';
					callback('users.get');
				}
			},

			wrap: {
				me: function(res, headers, req) {
					formatError(res);
					return formatUser(res, req);
				}
			},

			// No XHR
			xhr: false,

			// All requests should be JSONP as of missing CORS headers in https://api.vk.com/method/*
			jsonp: true,

			// No form
			form: false
		}
	});

	function formatUser(o, req) {

		if (o !== null && 'response' in o && o.response !== null && o.response.length) {
			o = o.response[0];
			o.id = o.uid;
			o.thumbnail = o.picture = o.photo_max;
			o.name = o.first_name + ' ' + o.last_name;

			if (req.authResponse && req.authResponse.email !== null)
				o.email = req.authResponse.email;
		}

		return o;
	}

	function formatError(o) {

		if (o.error) {
			var e = o.error;
			o.error = {
				code: e.error_code,
				message: e.error_msg
			};
		}
	}

})(hello);

(function(hello) {

	hello.init({
		windows: {
			name: 'Windows live',

			// REF: http://msdn.microsoft.com/en-us/library/hh243641.aspx
			oauth: {
				version: 2,
				auth: 'https://login.live.com/oauth20_authorize.srf',
				grant: 'https://login.live.com/oauth20_token.srf'
			},

			// Refresh the access_token once expired
			refresh: true,

			logout: function() {
				return 'http://login.live.com/oauth20_logout.srf?ts=' + (new Date()).getTime();
			},

			// Authorization scopes
			scope: {
				basic: 'wl.signin,wl.basic',
				email: 'wl.emails',
				birthday: 'wl.birthday',
				events: 'wl.calendars',
				photos: 'wl.photos',
				videos: 'wl.photos',
				friends: 'wl.contacts_emails',
				files: 'wl.skydrive',
				publish: 'wl.share',
				publish_files: 'wl.skydrive_update',
				share: 'wl.share',
				create_event: 'wl.calendars_update,wl.events_create',
				offline_access: 'wl.offline_access'
			},

			// API base URL
			base: 'https://apis.live.net/v5.0/',

			// Map GET requests
			get: {

				// Friends
				me: 'me',
				'me/friends': 'me/friends',
				'me/following': 'me/contacts',
				'me/followers': 'me/friends',
				'me/contacts': 'me/contacts',

				'me/albums': 'me/albums',

				// Include the data[id] in the path
				'me/album': '@{id}/files',
				'me/photo': '@{id}',

				// Files
				'me/files': '@{parent|me/skydrive}/files',
				'me/folders': '@{id|me/skydrive}/files',
				'me/folder': '@{id|me/skydrive}/files'
			},

			// Map POST requests
			post: {
				'me/albums': 'me/albums',
				'me/album': '@{id}/files/',

				'me/folders': '@{id|me/skydrive/}',
				'me/files': '@{parent|me/skydrive}/files'
			},

			// Map DELETE requests
			del: {
				// Include the data[id] in the path
				'me/album': '@{id}',
				'me/photo': '@{id}',
				'me/folder': '@{id}',
				'me/files': '@{id}'
			},

			wrap: {
				me: formatUser,

				'me/friends': formatFriends,
				'me/contacts': formatFriends,
				'me/followers': formatFriends,
				'me/following': formatFriends,
				'me/albums': formatAlbums,
				'me/photos': formatDefault,
				'default': formatDefault
			},

			xhr: function(p) {
				if (p.method !== 'get' && p.method !== 'delete' && !hello.utils.hasBinary(p.data)) {

					// Does this have a data-uri to upload as a file?
					if (typeof (p.data.file) === 'string') {
						p.data.file = hello.utils.toBlob(p.data.file);
					}
					else {
						p.data = JSON.stringify(p.data);
						p.headers = {
							'Content-Type': 'application/json'
						};
					}
				}

				return true;
			},

			jsonp: function(p) {
				if (p.method !== 'get' && !hello.utils.hasBinary(p.data)) {
					p.data.method = p.method;
					p.method = 'get';
				}
			}
		}
	});

	function formatDefault(o) {
		if ('data' in o) {
			o.data.forEach(function(d) {
				if (d.picture) {
					d.thumbnail = d.picture;
				}

				if (d.images) {
					d.pictures = d.images
						.map(formatImage)
						.sort(function(a, b) {
							return a.width - b.width;
						});
				}
			});
		}

		return o;
	}

	function formatImage(image) {
		return {
			width: image.width,
			height: image.height,
			source: image.source
		};
	}

	function formatAlbums(o) {
		if ('data' in o) {
			o.data.forEach(function(d) {
				d.photos = d.files = 'https://apis.live.net/v5.0/' + d.id + '/photos';
			});
		}

		return o;
	}

	function formatUser(o, headers, req) {
		if (o.id) {
			var token = req.query.access_token;
			if (o.emails) {
				o.email = o.emails.preferred;
			}

			// If this is not an non-network friend
			if (o.is_friend !== false) {
				// Use the id of the user_id if available
				var id = (o.user_id || o.id);
				o.thumbnail = o.picture = 'https://apis.live.net/v5.0/' + id + '/picture?access_token=' + token;
			}
		}

		return o;
	}

	function formatFriends(o, headers, req) {
		if ('data' in o) {
			o.data.forEach(function(d) {
				formatUser(d, headers, req);
			});
		}

		return o;
	}

})(hello);

(function(hello) {

	hello.init({

		yahoo: {

			// Ensure that you define an oauth_proxy
			oauth: {
				version: '1.0a',
				auth: 'https://api.login.yahoo.com/oauth/v2/request_auth',
				request: 'https://api.login.yahoo.com/oauth/v2/get_request_token',
				token: 'https://api.login.yahoo.com/oauth/v2/get_token'
			},

			// Login handler
			login: function(p) {
				// Change the default popup window to be at least 560
				// Yahoo does dynamically change it on the fly for the signin screen (only, what if your already signed in)
				p.options.popup.width = 560;

				// Yahoo throws an parameter error if for whatever reason the state.scope contains a comma, so lets remove scope
				try {delete p.qs.state.scope;}
				catch (e) {}
			},

			base: 'https://social.yahooapis.com/v1/',

			get: {
				me: yql('select * from social.profile(0) where guid=me'),
				'me/friends': yql('select * from social.contacts(0) where guid=me'),
				'me/following': yql('select * from social.contacts(0) where guid=me')
			},
			wrap: {
				me: formatUser,

				// Can't get IDs
				// It might be better to loop through the social.relationship table with has unique IDs of users.
				'me/friends': formatFriends,
				'me/following': formatFriends,
				'default': paging
			}
		}
	});

	/*
		// Auto-refresh fix: bug in Yahoo can't get this to work with node-oauth-shim
		login : function(o){
			// Is the user already logged in
			var auth = hello('yahoo').getAuthResponse();

			// Is this a refresh token?
			if(o.options.display==='none'&&auth&&auth.access_token&&auth.refresh_token){
				// Add the old token and the refresh token, including path to the query
				// See http://developer.yahoo.com/oauth/guide/oauth-refreshaccesstoken.html
				o.qs.access_token = auth.access_token;
				o.qs.refresh_token = auth.refresh_token;
				o.qs.token_url = 'https://api.login.yahoo.com/oauth/v2/get_token';
			}
		},
	*/

	function formatError(o) {
		if (o && 'meta' in o && 'error_type' in o.meta) {
			o.error = {
				code: o.meta.error_type,
				message: o.meta.error_message
			};
		}
	}

	function formatUser(o) {

		formatError(o);
		if (o.query && o.query.results && o.query.results.profile) {
			o = o.query.results.profile;
			o.id = o.guid;
			o.last_name = o.familyName;
			o.first_name = o.givenName || o.nickname;
			var a = [];
			if (o.first_name) {
				a.push(o.first_name);
			}

			if (o.last_name) {
				a.push(o.last_name);
			}

			o.name = a.join(' ');
			o.email = (o.emails && o.emails[0]) ? o.emails[0].handle : null;
			o.thumbnail = o.image ? o.image.imageUrl : null;
		}

		return o;
	}

	function formatFriends(o, headers, request) {
		formatError(o);
		paging(o, headers, request);
		var contact;
		var field;
		if (o.query && o.query.results && o.query.results.contact) {
			o.data = o.query.results.contact;
			delete o.query;

			if (!Array.isArray(o.data)) {
				o.data = [o.data];
			}

			o.data.forEach(formatFriend);
		}

		return o;
	}

	function formatFriend(contact) {
		contact.id = null;

		// #362: Reports of responses returning a single item, rather than an Array of items.
		// Format the contact.fields to be an array.
		if (contact.fields && !(contact.fields instanceof Array)) {
			contact.fields = [contact.fields];
		}

		(contact.fields || []).forEach(function(field) {
			if (field.type === 'email') {
				contact.email = field.value;
			}

			if (field.type === 'name') {
				contact.first_name = field.value.givenName;
				contact.last_name = field.value.familyName;
				contact.name = field.value.givenName + ' ' + field.value.familyName;
			}

			if (field.type === 'yahooid') {
				contact.id = field.value;
			}
		});
	}

	function paging(res, headers, request) {

		// See: http://developer.yahoo.com/yql/guide/paging.html#local_limits
		if (res.query && res.query.count && request.options) {
			res.paging = {
				next: '?start=' + (res.query.count + (+request.options.start || 1))
			};
		}

		return res;
	}

	function yql(q) {
		return 'https://query.yahooapis.com/v1/yql?q=' + (q + ' limit @{limit|100} offset @{start|0}').replace(/\s/g, '%20') + '&format=json';
	}

})(hello);

// Register as anonymous AMD module
if (typeof define === 'function' && define.amd) {
	define(function() {
		return hello;
	});
}

// CommonJS module for browserify
if (typeof module === 'object' && module.exports) {
	module.exports = hello;
}

}).call(this,require('_process'))

},{"_process":1}],17:[function(require,module,exports){
'use strict';
const strictUriEncode = require('strict-uri-encode');
const decodeComponent = require('decode-uri-component');
const splitOnFirst = require('split-on-first');

function encoderForArrayFormat(options) {
	switch (options.arrayFormat) {
		case 'index':
			return key => (result, value) => {
				const index = result.length;
				if (value === undefined) {
					return result;
				}

				if (value === null) {
					return [...result, [encode(key, options), '[', index, ']'].join('')];
				}

				return [
					...result,
					[encode(key, options), '[', encode(index, options), ']=', encode(value, options)].join('')
				];
			};

		case 'bracket':
			return key => (result, value) => {
				if (value === undefined) {
					return result;
				}

				if (value === null) {
					return [...result, [encode(key, options), '[]'].join('')];
				}

				return [...result, [encode(key, options), '[]=', encode(value, options)].join('')];
			};

		case 'comma':
			return key => (result, value, index) => {
				if (value === null || value === undefined || value.length === 0) {
					return result;
				}

				if (index === 0) {
					return [[encode(key, options), '=', encode(value, options)].join('')];
				}

				return [[result, encode(value, options)].join(',')];
			};

		default:
			return key => (result, value) => {
				if (value === undefined) {
					return result;
				}

				if (value === null) {
					return [...result, encode(key, options)];
				}

				return [...result, [encode(key, options), '=', encode(value, options)].join('')];
			};
	}
}

function parserForArrayFormat(options) {
	let result;

	switch (options.arrayFormat) {
		case 'index':
			return (key, value, accumulator) => {
				result = /\[(\d*)\]$/.exec(key);

				key = key.replace(/\[\d*\]$/, '');

				if (!result) {
					accumulator[key] = value;
					return;
				}

				if (accumulator[key] === undefined) {
					accumulator[key] = {};
				}

				accumulator[key][result[1]] = value;
			};

		case 'bracket':
			return (key, value, accumulator) => {
				result = /(\[\])$/.exec(key);
				key = key.replace(/\[\]$/, '');

				if (!result) {
					accumulator[key] = value;
					return;
				}

				if (accumulator[key] === undefined) {
					accumulator[key] = [value];
					return;
				}

				accumulator[key] = [].concat(accumulator[key], value);
			};

		case 'comma':
			return (key, value, accumulator) => {
				const isArray = typeof value === 'string' && value.split('').indexOf(',') > -1;
				const newValue = isArray ? value.split(',') : value;
				accumulator[key] = newValue;
			};

		default:
			return (key, value, accumulator) => {
				if (accumulator[key] === undefined) {
					accumulator[key] = value;
					return;
				}

				accumulator[key] = [].concat(accumulator[key], value);
			};
	}
}

function encode(value, options) {
	if (options.encode) {
		return options.strict ? strictUriEncode(value) : encodeURIComponent(value);
	}

	return value;
}

function decode(value, options) {
	if (options.decode) {
		return decodeComponent(value);
	}

	return value;
}

function keysSorter(input) {
	if (Array.isArray(input)) {
		return input.sort();
	}

	if (typeof input === 'object') {
		return keysSorter(Object.keys(input))
			.sort((a, b) => Number(a) - Number(b))
			.map(key => input[key]);
	}

	return input;
}

function removeHash(input) {
	const hashStart = input.indexOf('#');
	if (hashStart !== -1) {
		input = input.slice(0, hashStart);
	}

	return input;
}

function extract(input) {
	input = removeHash(input);
	const queryStart = input.indexOf('?');
	if (queryStart === -1) {
		return '';
	}

	return input.slice(queryStart + 1);
}

function parse(input, options) {
	options = Object.assign({
		decode: true,
		sort: true,
		arrayFormat: 'none',
		parseNumbers: false,
		parseBooleans: false
	}, options);

	const formatter = parserForArrayFormat(options);

	// Create an object with no prototype
	const ret = Object.create(null);

	if (typeof input !== 'string') {
		return ret;
	}

	input = input.trim().replace(/^[?#&]/, '');

	if (!input) {
		return ret;
	}

	for (const param of input.split('&')) {
		let [key, value] = splitOnFirst(param.replace(/\+/g, ' '), '=');

		// Missing `=` should be `null`:
		// http://w3.org/TR/2012/WD-url-20120524/#collect-url-parameters
		value = value === undefined ? null : decode(value, options);

		if (options.parseNumbers && !Number.isNaN(Number(value))) {
			value = Number(value);
		} else if (options.parseBooleans && value !== null && (value.toLowerCase() === 'true' || value.toLowerCase() === 'false')) {
			value = value.toLowerCase() === 'true';
		}

		formatter(decode(key, options), value, ret);
	}

	if (options.sort === false) {
		return ret;
	}

	return (options.sort === true ? Object.keys(ret).sort() : Object.keys(ret).sort(options.sort)).reduce((result, key) => {
		const value = ret[key];
		if (Boolean(value) && typeof value === 'object' && !Array.isArray(value)) {
			// Sort object keys, not values
			result[key] = keysSorter(value);
		} else {
			result[key] = value;
		}

		return result;
	}, Object.create(null));
}

exports.extract = extract;
exports.parse = parse;

exports.stringify = (object, options) => {
	if (!object) {
		return '';
	}

	options = Object.assign({
		encode: true,
		strict: true,
		arrayFormat: 'none'
	}, options);

	const formatter = encoderForArrayFormat(options);
	const keys = Object.keys(object);

	if (options.sort !== false) {
		keys.sort(options.sort);
	}

	return keys.map(key => {
		const value = object[key];

		if (value === undefined) {
			return '';
		}

		if (value === null) {
			return encode(key, options);
		}

		if (Array.isArray(value)) {
			return value
				.reduce(formatter(key), [])
				.join('&');
		}

		return encode(key, options) + '=' + encode(value, options);
	}).filter(x => x.length > 0).join('&');
};

exports.parseUrl = (input, options) => {
	return {
		url: removeHash(input).split('?')[0] || '',
		query: parse(extract(input), options)
	};
};

},{"decode-uri-component":15,"split-on-first":18,"strict-uri-encode":19}],18:[function(require,module,exports){
'use strict';

module.exports = (string, separator) => {
	if (!(typeof string === 'string' && typeof separator === 'string')) {
		throw new TypeError('Expected the arguments to be of type `string`');
	}

	if (separator === '') {
		return [string];
	}

	const separatorIndex = string.indexOf(separator);

	if (separatorIndex === -1) {
		return [string];
	}

	return [
		string.slice(0, separatorIndex),
		string.slice(separatorIndex + separator.length)
	];
};

},{}],19:[function(require,module,exports){
'use strict';
module.exports = str => encodeURIComponent(str).replace(/[!'()*]/g, x => `%${x.charCodeAt(0).toString(16).toUpperCase()}`);

},{}],"KeyValue":[function(require,module,exports){
var FL,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

FL = require('npm').FL;

exports.KeyValue = (function(superClass) {
  extend(KeyValue, superClass);

  KeyValue.KeyDidChange = "keyDidChanged";

  KeyValue.DidConnect = "didConnect";

  KeyValue.DidDisconnect = "didDisconnect";

  function KeyValue(options) {
    if (options == null) {
      options = {};
    }
    this.setKey = bind(this.setKey, this);
    this.requestKey = bind(this.requestKey, this);
    this.requestKeys = bind(this.requestKeys, this);
    this.notifyWithKey = bind(this.notifyWithKey, this);
    this.onKVConnectedChange = bind(this.onKVConnectedChange, this);
    this.onKVMessage = bind(this.onKVMessage, this);
    options.visible = false;
    KeyValue.__super__.constructor.call(this, options);
    FL.keyValue.setOnMessageCallback(this.onKVMessage);
    FL.keyValue.setIsConnectedChangedCallback(this.onKVConnectedChange);
  }

  KeyValue.prototype.onKVMessage = function(msg) {
    if (msg.type === "keySet") {
      return this.notifyWithKey(msg.value.key, msg.value.value);
    }
  };

  KeyValue.prototype.onKVConnectedChange = function(connected) {
    KeyValue.isConnected = connected;
    if (connected) {
      return this.emit(KeyValue.DidConnect);
    } else {
      return this.emit(KeyValue.DidDisconnect);
    }
  };

  KeyValue.prototype.notifyWithKey = function(key, value) {
    this.emit("keyChanged:" + key, value);
    return this.emit("keyChanged: " + key, value);
  };

  KeyValue.prototype.requestKeys = function(keys) {
    var i, k, len, results;
    results = [];
    for (i = 0, len = keys.length; i < len; i++) {
      k = keys[i];
      results.push(requestKey(k));
    }
    return results;
  };

  KeyValue.prototype.requestKey = function(key) {
    if (KeyValue.isConnected !== false) {
      return FL.keyValue.requestKey(key).then((function(_this) {
        return function(result) {
          return _this.notifyWithKey(key, result.value);
        };
      })(this))["catch"]((function(_this) {
        return function(error) {
          return print(error);
        };
      })(this));
    }
  };

  KeyValue.prototype.setKey = function(key, value) {
    return FL.keyValue.setKey(key, value);
  };

  KeyValue.define("isConnected", {
    get: function() {
      return KeyValue.isConnected;
    }
  });

  return KeyValue;

})(Layer);


},{"npm":"npm"}],"npm":[function(require,module,exports){
var FL, Sift, ref;

ref = require("@open-studio/sift-framerless"), FL = ref.FL, Sift = ref.Sift;

exports.Sift = Sift;

exports.FL = FL;


},{"@open-studio/sift-framerless":3}]},{},[])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnJhbWVyLm1vZHVsZXMuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL21vZHVsZXMvbnBtLmNvZmZlZSIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL21vZHVsZXMvS2V5VmFsdWUuY29mZmVlIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL3N0cmljdC11cmktZW5jb2RlL2luZGV4LmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL3NwbGl0LW9uLWZpcnN0L2luZGV4LmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL3F1ZXJ5LXN0cmluZy9pbmRleC5qcyIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL25vZGVfbW9kdWxlcy9oZWxsb2pzL2Rpc3QvaGVsbG8uYWxsLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL2RlY29kZS11cmktY29tcG9uZW50L2luZGV4LmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaW5nbGUtcGFnZS1tc2Z0LWdyYXBoLWhlbHBlci9kaXN0L2luZGV4LmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9zdHVicy9pbmRleC5qcyIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL25vZGVfbW9kdWxlcy9Ab3Blbi1zdHVkaW8vc2lmdC1mcmFtZXJsZXNzL2Rpc3Qvc3R1YnMvVGhvdWdodFNlcnZpY2VTdHViLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9zdHVicy9TeXN0ZW1TZXJ2aWNlc1N0dWIuanMiLCIuLi8uLi8uLi8uLi8uLi9Vc2Vycy9oYWdlbnQvRGVza3RvcC9WQVVMVC9ERVNJR04vUFJPVE8vX0FTU0VUUy9LZXlWYWx1ZUV4YW1wbGUtTW9kdWxlLmZyYW1lci9ub2RlX21vZHVsZXMvQG9wZW4tc3R1ZGlvL3NpZnQtZnJhbWVybGVzcy9kaXN0L3N0dWJzL1NwZWVjaFNlcnZpY2VTdHViLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9zdHVicy9LZXlWYWx1ZVNlcnZpY2VTdHViLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9zdHVicy9JbWFnZVNlcnZpY2VTdHViLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9zdHVicy9HcmFwaFNlcnZpY2VTdHViLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9zdHVicy9CdXR0b25TZXJ2aWNlU3R1Yi5qcyIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL25vZGVfbW9kdWxlcy9Ab3Blbi1zdHVkaW8vc2lmdC1mcmFtZXJsZXNzL2Rpc3Qvc2lmdC9pbmRleC5qcyIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL25vZGVfbW9kdWxlcy9Ab3Blbi1zdHVkaW8vc2lmdC1mcmFtZXJsZXNzL2Rpc3Qvc2lmdC9oZWxwZXJzLmpzIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvS2V5VmFsdWVFeGFtcGxlLU1vZHVsZS5mcmFtZXIvbm9kZV9tb2R1bGVzL0BvcGVuLXN0dWRpby9zaWZ0LWZyYW1lcmxlc3MvZGlzdC9pbmRleC5qcyIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL0tleVZhbHVlRXhhbXBsZS1Nb2R1bGUuZnJhbWVyL25vZGVfbW9kdWxlcy9Ab3Blbi1zdHVkaW8vc2lmdC1mcmFtZXJsZXNzL2Rpc3QvaGVscGVycy5qcyIsIm5vZGVfbW9kdWxlcy9wcm9jZXNzL2Jyb3dzZXIuanMiLCJub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbInsgRkwsIFNpZnQgfSA9IHJlcXVpcmUgXCJAb3Blbi1zdHVkaW8vc2lmdC1mcmFtZXJsZXNzXCJcbmV4cG9ydHMuU2lmdCA9IFNpZnRcbmV4cG9ydHMuRkwgPSBGTFxuIiwiRkwgPSByZXF1aXJlKCducG0nKS5GTFxuXG5jbGFzcyBleHBvcnRzLktleVZhbHVlIGV4dGVuZHMgTGF5ZXJcblx0QEtleURpZENoYW5nZSA9IFwia2V5RGlkQ2hhbmdlZFwiXG5cdEBEaWRDb25uZWN0ID0gXCJkaWRDb25uZWN0XCJcblx0QERpZERpc2Nvbm5lY3QgPSBcImRpZERpc2Nvbm5lY3RcIlxuXG5cdGNvbnN0cnVjdG9yOiAob3B0aW9ucyA9IHt9KSAtPlxuXHRcdG9wdGlvbnMudmlzaWJsZSA9IGZhbHNlXG5cdFx0c3VwZXIob3B0aW9ucylcblx0XHRGTC5rZXlWYWx1ZS5zZXRPbk1lc3NhZ2VDYWxsYmFjayBAb25LVk1lc3NhZ2Vcblx0XHRGTC5rZXlWYWx1ZS5zZXRJc0Nvbm5lY3RlZENoYW5nZWRDYWxsYmFjayBAb25LVkNvbm5lY3RlZENoYW5nZVxuXG5cdG9uS1ZNZXNzYWdlOiAobXNnKSA9PlxuXHRcdGlmIG1zZy50eXBlIGlzIFwia2V5U2V0XCJcblx0XHRcdEBub3RpZnlXaXRoS2V5KG1zZy52YWx1ZS5rZXksIG1zZy52YWx1ZS52YWx1ZSlcblxuXHRvbktWQ29ubmVjdGVkQ2hhbmdlOiAoY29ubmVjdGVkKSA9PlxuXHRcdEtleVZhbHVlLmlzQ29ubmVjdGVkID0gY29ubmVjdGVkXG5cdFx0aWYgY29ubmVjdGVkXG5cdFx0XHRAZW1pdCBLZXlWYWx1ZS5EaWRDb25uZWN0XG5cdFx0ZWxzZSBcblx0XHRcdEBlbWl0IEtleVZhbHVlLkRpZERpc2Nvbm5lY3RcblxuXHRub3RpZnlXaXRoS2V5OiAoa2V5LCB2YWx1ZSkgPT5cblx0XHQjZW1pdCB3aXRoIGFuZCB3aXRob3V0IGEgc3BhY2UganVzdCBpbiBjYXNlXG5cdFx0QGVtaXQgXCJrZXlDaGFuZ2VkOlwiICsga2V5LCB2YWx1ZVxuXHRcdEBlbWl0IFwia2V5Q2hhbmdlZDogXCIgKyBrZXksIHZhbHVlXG5cblx0cmVxdWVzdEtleXM6IChrZXlzKSA9PlxuXHRcdGZvciBrIGluIGtleXNcblx0XHRcdHJlcXVlc3RLZXkoaylcblxuXHRyZXF1ZXN0S2V5OiAoa2V5KSA9PlxuXHRcdHVubGVzcyBLZXlWYWx1ZS5pc0Nvbm5lY3RlZCBpcyBmYWxzZVxuXHRcdFx0Rkwua2V5VmFsdWUucmVxdWVzdEtleShrZXkpXG5cdFx0XHQudGhlbiAocmVzdWx0KSA9PlxuXHRcdFx0XHRAbm90aWZ5V2l0aEtleSBrZXksIHJlc3VsdC52YWx1ZVxuXHRcdFx0LmNhdGNoIChlcnJvcikgPT5cblx0XHRcdFx0cHJpbnQgZXJyb3JcblxuXHRzZXRLZXk6IChrZXksIHZhbHVlKSA9PlxuXHRcdEZMLmtleVZhbHVlLnNldEtleShrZXksIHZhbHVlKVxuXG5cdEBkZWZpbmUgXCJpc0Nvbm5lY3RlZFwiLFxuXHRcdGdldDogLT4gS2V5VmFsdWUuaXNDb25uZWN0ZWRcblxuIiwiJ3VzZSBzdHJpY3QnO1xubW9kdWxlLmV4cG9ydHMgPSBzdHIgPT4gZW5jb2RlVVJJQ29tcG9uZW50KHN0cikucmVwbGFjZSgvWyEnKCkqXS9nLCB4ID0+IGAlJHt4LmNoYXJDb2RlQXQoMCkudG9TdHJpbmcoMTYpLnRvVXBwZXJDYXNlKCl9YCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gKHN0cmluZywgc2VwYXJhdG9yKSA9PiB7XG5cdGlmICghKHR5cGVvZiBzdHJpbmcgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBzZXBhcmF0b3IgPT09ICdzdHJpbmcnKSkge1xuXHRcdHRocm93IG5ldyBUeXBlRXJyb3IoJ0V4cGVjdGVkIHRoZSBhcmd1bWVudHMgdG8gYmUgb2YgdHlwZSBgc3RyaW5nYCcpO1xuXHR9XG5cblx0aWYgKHNlcGFyYXRvciA9PT0gJycpIHtcblx0XHRyZXR1cm4gW3N0cmluZ107XG5cdH1cblxuXHRjb25zdCBzZXBhcmF0b3JJbmRleCA9IHN0cmluZy5pbmRleE9mKHNlcGFyYXRvcik7XG5cblx0aWYgKHNlcGFyYXRvckluZGV4ID09PSAtMSkge1xuXHRcdHJldHVybiBbc3RyaW5nXTtcblx0fVxuXG5cdHJldHVybiBbXG5cdFx0c3RyaW5nLnNsaWNlKDAsIHNlcGFyYXRvckluZGV4KSxcblx0XHRzdHJpbmcuc2xpY2Uoc2VwYXJhdG9ySW5kZXggKyBzZXBhcmF0b3IubGVuZ3RoKVxuXHRdO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcbmNvbnN0IHN0cmljdFVyaUVuY29kZSA9IHJlcXVpcmUoJ3N0cmljdC11cmktZW5jb2RlJyk7XG5jb25zdCBkZWNvZGVDb21wb25lbnQgPSByZXF1aXJlKCdkZWNvZGUtdXJpLWNvbXBvbmVudCcpO1xuY29uc3Qgc3BsaXRPbkZpcnN0ID0gcmVxdWlyZSgnc3BsaXQtb24tZmlyc3QnKTtcblxuZnVuY3Rpb24gZW5jb2RlckZvckFycmF5Rm9ybWF0KG9wdGlvbnMpIHtcblx0c3dpdGNoIChvcHRpb25zLmFycmF5Rm9ybWF0KSB7XG5cdFx0Y2FzZSAnaW5kZXgnOlxuXHRcdFx0cmV0dXJuIGtleSA9PiAocmVzdWx0LCB2YWx1ZSkgPT4ge1xuXHRcdFx0XHRjb25zdCBpbmRleCA9IHJlc3VsdC5sZW5ndGg7XG5cdFx0XHRcdGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuXHRcdFx0XHRcdHJldHVybiBbLi4ucmVzdWx0LCBbZW5jb2RlKGtleSwgb3B0aW9ucyksICdbJywgaW5kZXgsICddJ10uam9pbignJyldO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0XHQuLi5yZXN1bHQsXG5cdFx0XHRcdFx0W2VuY29kZShrZXksIG9wdGlvbnMpLCAnWycsIGVuY29kZShpbmRleCwgb3B0aW9ucyksICddPScsIGVuY29kZSh2YWx1ZSwgb3B0aW9ucyldLmpvaW4oJycpXG5cdFx0XHRcdF07XG5cdFx0XHR9O1xuXG5cdFx0Y2FzZSAnYnJhY2tldCc6XG5cdFx0XHRyZXR1cm4ga2V5ID0+IChyZXN1bHQsIHZhbHVlKSA9PiB7XG5cdFx0XHRcdGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuXHRcdFx0XHRcdHJldHVybiBbLi4ucmVzdWx0LCBbZW5jb2RlKGtleSwgb3B0aW9ucyksICdbXSddLmpvaW4oJycpXTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHJldHVybiBbLi4ucmVzdWx0LCBbZW5jb2RlKGtleSwgb3B0aW9ucyksICdbXT0nLCBlbmNvZGUodmFsdWUsIG9wdGlvbnMpXS5qb2luKCcnKV07XG5cdFx0XHR9O1xuXG5cdFx0Y2FzZSAnY29tbWEnOlxuXHRcdFx0cmV0dXJuIGtleSA9PiAocmVzdWx0LCB2YWx1ZSwgaW5kZXgpID0+IHtcblx0XHRcdFx0aWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChpbmRleCA9PT0gMCkge1xuXHRcdFx0XHRcdHJldHVybiBbW2VuY29kZShrZXksIG9wdGlvbnMpLCAnPScsIGVuY29kZSh2YWx1ZSwgb3B0aW9ucyldLmpvaW4oJycpXTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHJldHVybiBbW3Jlc3VsdCwgZW5jb2RlKHZhbHVlLCBvcHRpb25zKV0uam9pbignLCcpXTtcblx0XHRcdH07XG5cblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGtleSA9PiAocmVzdWx0LCB2YWx1ZSkgPT4ge1xuXHRcdFx0XHRpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAodmFsdWUgPT09IG51bGwpIHtcblx0XHRcdFx0XHRyZXR1cm4gWy4uLnJlc3VsdCwgZW5jb2RlKGtleSwgb3B0aW9ucyldO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuIFsuLi5yZXN1bHQsIFtlbmNvZGUoa2V5LCBvcHRpb25zKSwgJz0nLCBlbmNvZGUodmFsdWUsIG9wdGlvbnMpXS5qb2luKCcnKV07XG5cdFx0XHR9O1xuXHR9XG59XG5cbmZ1bmN0aW9uIHBhcnNlckZvckFycmF5Rm9ybWF0KG9wdGlvbnMpIHtcblx0bGV0IHJlc3VsdDtcblxuXHRzd2l0Y2ggKG9wdGlvbnMuYXJyYXlGb3JtYXQpIHtcblx0XHRjYXNlICdpbmRleCc6XG5cdFx0XHRyZXR1cm4gKGtleSwgdmFsdWUsIGFjY3VtdWxhdG9yKSA9PiB7XG5cdFx0XHRcdHJlc3VsdCA9IC9cXFsoXFxkKilcXF0kLy5leGVjKGtleSk7XG5cblx0XHRcdFx0a2V5ID0ga2V5LnJlcGxhY2UoL1xcW1xcZCpcXF0kLywgJycpO1xuXG5cdFx0XHRcdGlmICghcmVzdWx0KSB7XG5cdFx0XHRcdFx0YWNjdW11bGF0b3Jba2V5XSA9IHZhbHVlO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChhY2N1bXVsYXRvcltrZXldID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRhY2N1bXVsYXRvcltrZXldID0ge307XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRhY2N1bXVsYXRvcltrZXldW3Jlc3VsdFsxXV0gPSB2YWx1ZTtcblx0XHRcdH07XG5cblx0XHRjYXNlICdicmFja2V0Jzpcblx0XHRcdHJldHVybiAoa2V5LCB2YWx1ZSwgYWNjdW11bGF0b3IpID0+IHtcblx0XHRcdFx0cmVzdWx0ID0gLyhcXFtcXF0pJC8uZXhlYyhrZXkpO1xuXHRcdFx0XHRrZXkgPSBrZXkucmVwbGFjZSgvXFxbXFxdJC8sICcnKTtcblxuXHRcdFx0XHRpZiAoIXJlc3VsdCkge1xuXHRcdFx0XHRcdGFjY3VtdWxhdG9yW2tleV0gPSB2YWx1ZTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoYWNjdW11bGF0b3Jba2V5XSA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0YWNjdW11bGF0b3Jba2V5XSA9IFt2YWx1ZV07XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0YWNjdW11bGF0b3Jba2V5XSA9IFtdLmNvbmNhdChhY2N1bXVsYXRvcltrZXldLCB2YWx1ZSk7XG5cdFx0XHR9O1xuXG5cdFx0Y2FzZSAnY29tbWEnOlxuXHRcdFx0cmV0dXJuIChrZXksIHZhbHVlLCBhY2N1bXVsYXRvcikgPT4ge1xuXHRcdFx0XHRjb25zdCBpc0FycmF5ID0gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiB2YWx1ZS5zcGxpdCgnJykuaW5kZXhPZignLCcpID4gLTE7XG5cdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID0gaXNBcnJheSA/IHZhbHVlLnNwbGl0KCcsJykgOiB2YWx1ZTtcblx0XHRcdFx0YWNjdW11bGF0b3Jba2V5XSA9IG5ld1ZhbHVlO1xuXHRcdFx0fTtcblxuXHRcdGRlZmF1bHQ6XG5cdFx0XHRyZXR1cm4gKGtleSwgdmFsdWUsIGFjY3VtdWxhdG9yKSA9PiB7XG5cdFx0XHRcdGlmIChhY2N1bXVsYXRvcltrZXldID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRhY2N1bXVsYXRvcltrZXldID0gdmFsdWU7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0YWNjdW11bGF0b3Jba2V5XSA9IFtdLmNvbmNhdChhY2N1bXVsYXRvcltrZXldLCB2YWx1ZSk7XG5cdFx0XHR9O1xuXHR9XG59XG5cbmZ1bmN0aW9uIGVuY29kZSh2YWx1ZSwgb3B0aW9ucykge1xuXHRpZiAob3B0aW9ucy5lbmNvZGUpIHtcblx0XHRyZXR1cm4gb3B0aW9ucy5zdHJpY3QgPyBzdHJpY3RVcmlFbmNvZGUodmFsdWUpIDogZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcblx0fVxuXG5cdHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gZGVjb2RlKHZhbHVlLCBvcHRpb25zKSB7XG5cdGlmIChvcHRpb25zLmRlY29kZSkge1xuXHRcdHJldHVybiBkZWNvZGVDb21wb25lbnQodmFsdWUpO1xuXHR9XG5cblx0cmV0dXJuIHZhbHVlO1xufVxuXG5mdW5jdGlvbiBrZXlzU29ydGVyKGlucHV0KSB7XG5cdGlmIChBcnJheS5pc0FycmF5KGlucHV0KSkge1xuXHRcdHJldHVybiBpbnB1dC5zb3J0KCk7XG5cdH1cblxuXHRpZiAodHlwZW9mIGlucHV0ID09PSAnb2JqZWN0Jykge1xuXHRcdHJldHVybiBrZXlzU29ydGVyKE9iamVjdC5rZXlzKGlucHV0KSlcblx0XHRcdC5zb3J0KChhLCBiKSA9PiBOdW1iZXIoYSkgLSBOdW1iZXIoYikpXG5cdFx0XHQubWFwKGtleSA9PiBpbnB1dFtrZXldKTtcblx0fVxuXG5cdHJldHVybiBpbnB1dDtcbn1cblxuZnVuY3Rpb24gcmVtb3ZlSGFzaChpbnB1dCkge1xuXHRjb25zdCBoYXNoU3RhcnQgPSBpbnB1dC5pbmRleE9mKCcjJyk7XG5cdGlmIChoYXNoU3RhcnQgIT09IC0xKSB7XG5cdFx0aW5wdXQgPSBpbnB1dC5zbGljZSgwLCBoYXNoU3RhcnQpO1xuXHR9XG5cblx0cmV0dXJuIGlucHV0O1xufVxuXG5mdW5jdGlvbiBleHRyYWN0KGlucHV0KSB7XG5cdGlucHV0ID0gcmVtb3ZlSGFzaChpbnB1dCk7XG5cdGNvbnN0IHF1ZXJ5U3RhcnQgPSBpbnB1dC5pbmRleE9mKCc/Jyk7XG5cdGlmIChxdWVyeVN0YXJ0ID09PSAtMSkge1xuXHRcdHJldHVybiAnJztcblx0fVxuXG5cdHJldHVybiBpbnB1dC5zbGljZShxdWVyeVN0YXJ0ICsgMSk7XG59XG5cbmZ1bmN0aW9uIHBhcnNlKGlucHV0LCBvcHRpb25zKSB7XG5cdG9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHtcblx0XHRkZWNvZGU6IHRydWUsXG5cdFx0c29ydDogdHJ1ZSxcblx0XHRhcnJheUZvcm1hdDogJ25vbmUnLFxuXHRcdHBhcnNlTnVtYmVyczogZmFsc2UsXG5cdFx0cGFyc2VCb29sZWFuczogZmFsc2Vcblx0fSwgb3B0aW9ucyk7XG5cblx0Y29uc3QgZm9ybWF0dGVyID0gcGFyc2VyRm9yQXJyYXlGb3JtYXQob3B0aW9ucyk7XG5cblx0Ly8gQ3JlYXRlIGFuIG9iamVjdCB3aXRoIG5vIHByb3RvdHlwZVxuXHRjb25zdCByZXQgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG5cdGlmICh0eXBlb2YgaW5wdXQgIT09ICdzdHJpbmcnKSB7XG5cdFx0cmV0dXJuIHJldDtcblx0fVxuXG5cdGlucHV0ID0gaW5wdXQudHJpbSgpLnJlcGxhY2UoL15bPyMmXS8sICcnKTtcblxuXHRpZiAoIWlucHV0KSB7XG5cdFx0cmV0dXJuIHJldDtcblx0fVxuXG5cdGZvciAoY29uc3QgcGFyYW0gb2YgaW5wdXQuc3BsaXQoJyYnKSkge1xuXHRcdGxldCBba2V5LCB2YWx1ZV0gPSBzcGxpdE9uRmlyc3QocGFyYW0ucmVwbGFjZSgvXFwrL2csICcgJyksICc9Jyk7XG5cblx0XHQvLyBNaXNzaW5nIGA9YCBzaG91bGQgYmUgYG51bGxgOlxuXHRcdC8vIGh0dHA6Ly93My5vcmcvVFIvMjAxMi9XRC11cmwtMjAxMjA1MjQvI2NvbGxlY3QtdXJsLXBhcmFtZXRlcnNcblx0XHR2YWx1ZSA9IHZhbHVlID09PSB1bmRlZmluZWQgPyBudWxsIDogZGVjb2RlKHZhbHVlLCBvcHRpb25zKTtcblxuXHRcdGlmIChvcHRpb25zLnBhcnNlTnVtYmVycyAmJiAhTnVtYmVyLmlzTmFOKE51bWJlcih2YWx1ZSkpKSB7XG5cdFx0XHR2YWx1ZSA9IE51bWJlcih2YWx1ZSk7XG5cdFx0fSBlbHNlIGlmIChvcHRpb25zLnBhcnNlQm9vbGVhbnMgJiYgdmFsdWUgIT09IG51bGwgJiYgKHZhbHVlLnRvTG93ZXJDYXNlKCkgPT09ICd0cnVlJyB8fCB2YWx1ZS50b0xvd2VyQ2FzZSgpID09PSAnZmFsc2UnKSkge1xuXHRcdFx0dmFsdWUgPSB2YWx1ZS50b0xvd2VyQ2FzZSgpID09PSAndHJ1ZSc7XG5cdFx0fVxuXG5cdFx0Zm9ybWF0dGVyKGRlY29kZShrZXksIG9wdGlvbnMpLCB2YWx1ZSwgcmV0KTtcblx0fVxuXG5cdGlmIChvcHRpb25zLnNvcnQgPT09IGZhbHNlKSB7XG5cdFx0cmV0dXJuIHJldDtcblx0fVxuXG5cdHJldHVybiAob3B0aW9ucy5zb3J0ID09PSB0cnVlID8gT2JqZWN0LmtleXMocmV0KS5zb3J0KCkgOiBPYmplY3Qua2V5cyhyZXQpLnNvcnQob3B0aW9ucy5zb3J0KSkucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuXHRcdGNvbnN0IHZhbHVlID0gcmV0W2tleV07XG5cdFx0aWYgKEJvb2xlYW4odmFsdWUpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG5cdFx0XHQvLyBTb3J0IG9iamVjdCBrZXlzLCBub3QgdmFsdWVzXG5cdFx0XHRyZXN1bHRba2V5XSA9IGtleXNTb3J0ZXIodmFsdWUpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRyZXN1bHRba2V5XSA9IHZhbHVlO1xuXHRcdH1cblxuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0sIE9iamVjdC5jcmVhdGUobnVsbCkpO1xufVxuXG5leHBvcnRzLmV4dHJhY3QgPSBleHRyYWN0O1xuZXhwb3J0cy5wYXJzZSA9IHBhcnNlO1xuXG5leHBvcnRzLnN0cmluZ2lmeSA9IChvYmplY3QsIG9wdGlvbnMpID0+IHtcblx0aWYgKCFvYmplY3QpIHtcblx0XHRyZXR1cm4gJyc7XG5cdH1cblxuXHRvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7XG5cdFx0ZW5jb2RlOiB0cnVlLFxuXHRcdHN0cmljdDogdHJ1ZSxcblx0XHRhcnJheUZvcm1hdDogJ25vbmUnXG5cdH0sIG9wdGlvbnMpO1xuXG5cdGNvbnN0IGZvcm1hdHRlciA9IGVuY29kZXJGb3JBcnJheUZvcm1hdChvcHRpb25zKTtcblx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9iamVjdCk7XG5cblx0aWYgKG9wdGlvbnMuc29ydCAhPT0gZmFsc2UpIHtcblx0XHRrZXlzLnNvcnQob3B0aW9ucy5zb3J0KTtcblx0fVxuXG5cdHJldHVybiBrZXlzLm1hcChrZXkgPT4ge1xuXHRcdGNvbnN0IHZhbHVlID0gb2JqZWN0W2tleV07XG5cblx0XHRpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0cmV0dXJuICcnO1xuXHRcdH1cblxuXHRcdGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuXHRcdFx0cmV0dXJuIGVuY29kZShrZXksIG9wdGlvbnMpO1xuXHRcdH1cblxuXHRcdGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuXHRcdFx0cmV0dXJuIHZhbHVlXG5cdFx0XHRcdC5yZWR1Y2UoZm9ybWF0dGVyKGtleSksIFtdKVxuXHRcdFx0XHQuam9pbignJicpO1xuXHRcdH1cblxuXHRcdHJldHVybiBlbmNvZGUoa2V5LCBvcHRpb25zKSArICc9JyArIGVuY29kZSh2YWx1ZSwgb3B0aW9ucyk7XG5cdH0pLmZpbHRlcih4ID0+IHgubGVuZ3RoID4gMCkuam9pbignJicpO1xufTtcblxuZXhwb3J0cy5wYXJzZVVybCA9IChpbnB1dCwgb3B0aW9ucykgPT4ge1xuXHRyZXR1cm4ge1xuXHRcdHVybDogcmVtb3ZlSGFzaChpbnB1dCkuc3BsaXQoJz8nKVswXSB8fCAnJyxcblx0XHRxdWVyeTogcGFyc2UoZXh0cmFjdChpbnB1dCksIG9wdGlvbnMpXG5cdH07XG59O1xuIiwiLyohIGhlbGxvanMgdjEuMTguMCB8IChjKSAyMDEyLTIwMTkgQW5kcmV3IERvZHNvbiB8IE1JVCBodHRwczovL2Fkb2Rzb24uY29tL2hlbGxvLmpzL0xJQ0VOU0UgKi9cbi8vIEVTNSBPYmplY3QuY3JlYXRlXG5pZiAoIU9iamVjdC5jcmVhdGUpIHtcblxuXHQvLyBTaGltLCBPYmplY3QgY3JlYXRlXG5cdC8vIEEgc2hpbSBmb3IgT2JqZWN0LmNyZWF0ZSgpLCBpdCBhZGRzIGEgcHJvdG90eXBlIHRvIGEgbmV3IG9iamVjdFxuXHRPYmplY3QuY3JlYXRlID0gKGZ1bmN0aW9uKCkge1xuXG5cdFx0ZnVuY3Rpb24gRigpIHt9XG5cblx0XHRyZXR1cm4gZnVuY3Rpb24obykge1xuXG5cdFx0XHRpZiAoYXJndW1lbnRzLmxlbmd0aCAhPSAxKSB7XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcignT2JqZWN0LmNyZWF0ZSBpbXBsZW1lbnRhdGlvbiBvbmx5IGFjY2VwdHMgb25lIHBhcmFtZXRlci4nKTtcblx0XHRcdH1cblxuXHRcdFx0Ri5wcm90b3R5cGUgPSBvO1xuXHRcdFx0cmV0dXJuIG5ldyBGKCk7XG5cdFx0fTtcblxuXHR9KSgpO1xuXG59XG5cbi8vIEVTNSBPYmplY3Qua2V5c1xuaWYgKCFPYmplY3Qua2V5cykge1xuXHRPYmplY3Qua2V5cyA9IGZ1bmN0aW9uKG8sIGssIHIpIHtcblx0XHRyID0gW107XG5cdFx0Zm9yIChrIGluIG8pIHtcblx0XHRcdGlmIChyLmhhc093blByb3BlcnR5LmNhbGwobywgaykpXG5cdFx0XHRcdHIucHVzaChrKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gcjtcblx0fTtcbn1cblxuLy8gRVM1IFtdLmluZGV4T2ZcbmlmICghQXJyYXkucHJvdG90eXBlLmluZGV4T2YpIHtcblx0QXJyYXkucHJvdG90eXBlLmluZGV4T2YgPSBmdW5jdGlvbihzKSB7XG5cblx0XHRmb3IgKHZhciBqID0gMDsgaiA8IHRoaXMubGVuZ3RoOyBqKyspIHtcblx0XHRcdGlmICh0aGlzW2pdID09PSBzKSB7XG5cdFx0XHRcdHJldHVybiBqO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiAtMTtcblx0fTtcbn1cblxuLy8gRVM1IFtdLmZvckVhY2hcbmlmICghQXJyYXkucHJvdG90eXBlLmZvckVhY2gpIHtcblx0QXJyYXkucHJvdG90eXBlLmZvckVhY2ggPSBmdW5jdGlvbihmdW4vKiwgdGhpc0FyZyovKSB7XG5cblx0XHRpZiAodGhpcyA9PT0gdm9pZCAwIHx8IHRoaXMgPT09IG51bGwpIHtcblx0XHRcdHRocm93IG5ldyBUeXBlRXJyb3IoKTtcblx0XHR9XG5cblx0XHR2YXIgdCA9IE9iamVjdCh0aGlzKTtcblx0XHR2YXIgbGVuID0gdC5sZW5ndGggPj4+IDA7XG5cdFx0aWYgKHR5cGVvZiBmdW4gIT09ICdmdW5jdGlvbicpIHtcblx0XHRcdHRocm93IG5ldyBUeXBlRXJyb3IoKTtcblx0XHR9XG5cblx0XHR2YXIgdGhpc0FyZyA9IGFyZ3VtZW50cy5sZW5ndGggPj0gMiA/IGFyZ3VtZW50c1sxXSA6IHZvaWQgMDtcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0XHRpZiAoaSBpbiB0KSB7XG5cdFx0XHRcdGZ1bi5jYWxsKHRoaXNBcmcsIHRbaV0sIGksIHQpO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiB0aGlzO1xuXHR9O1xufVxuXG4vLyBFUzUgW10uZmlsdGVyXG5pZiAoIUFycmF5LnByb3RvdHlwZS5maWx0ZXIpIHtcblx0QXJyYXkucHJvdG90eXBlLmZpbHRlciA9IGZ1bmN0aW9uKGZ1biwgdGhpc0FyZykge1xuXG5cdFx0dmFyIGEgPSBbXTtcblx0XHR0aGlzLmZvckVhY2goZnVuY3Rpb24odmFsLCBpLCB0KSB7XG5cdFx0XHRpZiAoZnVuLmNhbGwodGhpc0FyZyB8fCB2b2lkIDAsIHZhbCwgaSwgdCkpIHtcblx0XHRcdFx0YS5wdXNoKHZhbCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cblx0XHRyZXR1cm4gYTtcblx0fTtcbn1cblxuLy8gUHJvZHVjdGlvbiBzdGVwcyBvZiBFQ01BLTI2MiwgRWRpdGlvbiA1LCAxNS40LjQuMTlcbi8vIFJlZmVyZW5jZTogaHR0cDovL2VzNS5naXRodWIuaW8vI3gxNS40LjQuMTlcbmlmICghQXJyYXkucHJvdG90eXBlLm1hcCkge1xuXG5cdEFycmF5LnByb3RvdHlwZS5tYXAgPSBmdW5jdGlvbihmdW4sIHRoaXNBcmcpIHtcblxuXHRcdHZhciBhID0gW107XG5cdFx0dGhpcy5mb3JFYWNoKGZ1bmN0aW9uKHZhbCwgaSwgdCkge1xuXHRcdFx0YS5wdXNoKGZ1bi5jYWxsKHRoaXNBcmcgfHwgdm9pZCAwLCB2YWwsIGksIHQpKTtcblx0XHR9KTtcblxuXHRcdHJldHVybiBhO1xuXHR9O1xufVxuXG4vLyBFUzUgaXNBcnJheVxuaWYgKCFBcnJheS5pc0FycmF5KSB7XG5cblx0Ly8gRnVuY3Rpb24gQXJyYXkuaXNBcnJheVxuXHRBcnJheS5pc0FycmF5ID0gZnVuY3Rpb24obykge1xuXHRcdHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobykgPT09ICdbb2JqZWN0IEFycmF5XSc7XG5cdH07XG5cbn1cblxuLy8gVGVzdCBmb3IgbG9jYXRpb24uYXNzaWduXG5pZiAodHlwZW9mIHdpbmRvdyA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHdpbmRvdy5sb2NhdGlvbiA9PT0gJ29iamVjdCcgJiYgIXdpbmRvdy5sb2NhdGlvbi5hc3NpZ24pIHtcblxuXHR3aW5kb3cubG9jYXRpb24uYXNzaWduID0gZnVuY3Rpb24odXJsKSB7XG5cdFx0d2luZG93LmxvY2F0aW9uID0gdXJsO1xuXHR9O1xuXG59XG5cbi8vIFRlc3QgZm9yIEZ1bmN0aW9uLmJpbmRcbmlmICghRnVuY3Rpb24ucHJvdG90eXBlLmJpbmQpIHtcblxuXHQvLyBNRE5cblx0Ly8gUG9seWZpbGwgSUU4LCBkb2VzIG5vdCBzdXBwb3J0IG5hdGl2ZSBGdW5jdGlvbi5iaW5kXG5cdEZ1bmN0aW9uLnByb3RvdHlwZS5iaW5kID0gZnVuY3Rpb24oYikge1xuXG5cdFx0aWYgKHR5cGVvZiB0aGlzICE9PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHR0aHJvdyBuZXcgVHlwZUVycm9yKCdGdW5jdGlvbi5wcm90b3R5cGUuYmluZCAtIHdoYXQgaXMgdHJ5aW5nIHRvIGJlIGJvdW5kIGlzIG5vdCBjYWxsYWJsZScpO1xuXHRcdH1cblxuXHRcdGZ1bmN0aW9uIEMoKSB7fVxuXG5cdFx0dmFyIGEgPSBbXS5zbGljZTtcblx0XHR2YXIgZiA9IGEuY2FsbChhcmd1bWVudHMsIDEpO1xuXHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0dmFyIEQgPSBmdW5jdGlvbigpIHtcblx0XHRcdHJldHVybiBfdGhpcy5hcHBseSh0aGlzIGluc3RhbmNlb2YgQyA/IHRoaXMgOiBiIHx8IHdpbmRvdywgZi5jb25jYXQoYS5jYWxsKGFyZ3VtZW50cykpKTtcblx0XHR9O1xuXG5cdFx0Qy5wcm90b3R5cGUgPSB0aGlzLnByb3RvdHlwZTtcblx0XHRELnByb3RvdHlwZSA9IG5ldyBDKCk7XG5cblx0XHRyZXR1cm4gRDtcblx0fTtcblxufVxuXG4vKipcbiAqIEBoZWxsby5qc1xuICpcbiAqIEhlbGxvSlMgaXMgYSBjbGllbnQgc2lkZSBKYXZhc2NyaXB0IFNESyBmb3IgbWFraW5nIE9BdXRoMiBsb2dpbnMgYW5kIHN1YnNlcXVlbnQgUkVTVCBjYWxscy5cbiAqXG4gKiBAYXV0aG9yIEFuZHJldyBEb2Rzb25cbiAqIEB3ZWJzaXRlIGh0dHBzOi8vYWRvZHNvbi5jb20vaGVsbG8uanMvXG4gKlxuICogQGNvcHlyaWdodCBBbmRyZXcgRG9kc29uLCAyMDEyIC0gMjAxNVxuICogQGxpY2Vuc2UgTUlUOiBZb3UgYXJlIGZyZWUgdG8gdXNlIGFuZCBtb2RpZnkgdGhpcyBjb2RlIGZvciBhbnkgdXNlLCBvbiB0aGUgY29uZGl0aW9uIHRoYXQgdGhpcyBjb3B5cmlnaHQgbm90aWNlIHJlbWFpbnMuXG4gKi9cblxudmFyIGhlbGxvID0gZnVuY3Rpb24obmFtZSkge1xuXHRyZXR1cm4gaGVsbG8udXNlKG5hbWUpO1xufTtcblxuaGVsbG8udXRpbHMgPSB7XG5cblx0Ly8gRXh0ZW5kIHRoZSBmaXJzdCBvYmplY3Qgd2l0aCB0aGUgcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvZiB0aGUgc2Vjb25kXG5cdGV4dGVuZDogZnVuY3Rpb24ociAvKiwgYVssIGJbLCAuLi5dXSAqLykge1xuXG5cdFx0Ly8gR2V0IHRoZSBhcmd1bWVudHMgYXMgYW4gYXJyYXkgYnV0IG9tbWl0IHRoZSBpbml0aWFsIGl0ZW1cblx0XHRBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpLmZvckVhY2goZnVuY3Rpb24oYSkge1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkocikgJiYgQXJyYXkuaXNBcnJheShhKSkge1xuXHRcdFx0XHRBcnJheS5wcm90b3R5cGUucHVzaC5hcHBseShyLCBhKTtcblx0XHRcdH1cblx0XHRcdGVsc2UgaWYgKHIgJiYgKHIgaW5zdGFuY2VvZiBPYmplY3QgfHwgdHlwZW9mIHIgPT09ICdvYmplY3QnKSAmJiBhICYmIChhIGluc3RhbmNlb2YgT2JqZWN0IHx8IHR5cGVvZiBhID09PSAnb2JqZWN0JykgJiYgciAhPT0gYSkge1xuXHRcdFx0XHRmb3IgKHZhciB4IGluIGEpIHtcblx0XHRcdFx0XHRyW3hdID0gaGVsbG8udXRpbHMuZXh0ZW5kKHJbeF0sIGFbeF0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRlbHNlIHtcblxuXHRcdFx0XHRpZiAoQXJyYXkuaXNBcnJheShhKSkge1xuXHRcdFx0XHRcdC8vIENsb25lIGl0XG5cdFx0XHRcdFx0YSA9IGEuc2xpY2UoMCk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyID0gYTtcblx0XHRcdH1cblx0XHR9KTtcblxuXHRcdHJldHVybiByO1xuXHR9XG59O1xuXG4vLyBDb3JlIGxpYnJhcnlcbmhlbGxvLnV0aWxzLmV4dGVuZChoZWxsbywge1xuXG5cdHNldHRpbmdzOiB7XG5cblx0XHQvLyBPQXV0aDIgYXV0aGVudGljYXRpb24gZGVmYXVsdHNcblx0XHRyZWRpcmVjdF91cmk6IHdpbmRvdy5sb2NhdGlvbi5ocmVmLnNwbGl0KCcjJylbMF0sXG5cdFx0cmVzcG9uc2VfdHlwZTogJ3Rva2VuJyxcblx0XHRkaXNwbGF5OiAncG9wdXAnLFxuXHRcdHN0YXRlOiAnJyxcblxuXHRcdC8vIE9BdXRoMSBzaGltXG5cdFx0Ly8gVGhlIHBhdGggdG8gdGhlIE9BdXRoMSBzZXJ2ZXIgZm9yIHNpZ25pbmcgdXNlciByZXF1ZXN0c1xuXHRcdC8vIFdhbnQgdG8gcmVjcmVhdGUgeW91ciBvd24/IENoZWNrb3V0IGh0dHBzOi8vZ2l0aHViLmNvbS9NclN3aXRjaC9ub2RlLW9hdXRoLXNoaW1cblx0XHRvYXV0aF9wcm94eTogJ2h0dHBzOi8vYXV0aC1zZXJ2ZXIuaGVyb2t1YXBwLmNvbS9wcm94eScsXG5cblx0XHQvLyBBUEkgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcblx0XHR0aW1lb3V0OiAyMDAwMCxcblxuXHRcdC8vIFBvcHVwIE9wdGlvbnNcblx0XHRwb3B1cDoge1xuXHRcdFx0cmVzaXphYmxlOiAxLFxuXHRcdFx0c2Nyb2xsYmFyczogMSxcblx0XHRcdHdpZHRoOiA1MDAsXG5cdFx0XHRoZWlnaHQ6IDU1MFxuXHRcdH0sXG5cblx0XHQvLyBEZWZhdWx0IHNjb3BlXG5cdFx0Ly8gTWFueSBzZXJ2aWNlcyByZXF1aXJlIGF0bGVhc3QgYSBwcm9maWxlIHNjb3BlLFxuXHRcdC8vIEhlbGxvSlMgYXV0b21hdGlhbGx5IGluY2x1ZGVzIHRoZSB2YWx1ZSBvZiBwcm92aWRlci5zY29wZV9tYXAuYmFzaWNcblx0XHQvLyBJZiB0aGF0J3Mgbm90IHJlcXVpcmVkIGl0IGNhbiBiZSByZW1vdmVkIHZpYSBoZWxsby5zZXR0aW5ncy5zY29wZS5sZW5ndGggPSAwO1xuXHRcdHNjb3BlOiBbJ2Jhc2ljJ10sXG5cblx0XHQvLyBTY29wZSBNYXBzXG5cdFx0Ly8gVGhpcyBpcyB0aGUgZGVmYXVsdCBtb2R1bGUgc2NvcGUsIHRoZXNlIGFyZSB0aGUgZGVmYXVsdHMgd2hpY2ggZWFjaCBzZXJ2aWNlIGlzIG1hcHBlZCB0b28uXG5cdFx0Ly8gQnkgaW5jbHVkaW5nIHRoZW0gaGVyZSBpdCBwcmV2ZW50cyB0aGUgc2NvcGUgZnJvbSBiZWluZyBhcHBsaWVkIGFjY2lkZW50YWxseVxuXHRcdHNjb3BlX21hcDoge1xuXHRcdFx0YmFzaWM6ICcnXG5cdFx0fSxcblxuXHRcdC8vIERlZmF1bHQgc2VydmljZSAvIG5ldHdvcmtcblx0XHRkZWZhdWx0X3NlcnZpY2U6IG51bGwsXG5cblx0XHQvLyBGb3JjZSBhdXRoZW50aWNhdGlvblxuXHRcdC8vIFdoZW4gaGVsbG8ubG9naW4gaXMgZmlyZWQuXG5cdFx0Ly8gKG51bGwpOiBpZ25vcmUgY3VycmVudCBzZXNzaW9uIGV4cGlyeSBhbmQgY29udGludWUgd2l0aCBsb2dpblxuXHRcdC8vICh0cnVlKTogaWdub3JlIGN1cnJlbnQgc2Vzc2lvbiBleHBpcnkgYW5kIGNvbnRpbnVlIHdpdGggbG9naW4sIGFzayBmb3IgdXNlciB0byByZWF1dGhlbnRpY2F0ZVxuXHRcdC8vIChmYWxzZSk6IGlmIHRoZSBjdXJyZW50IHNlc3Npb24gbG9va3MgZ29vZCBmb3IgdGhlIHJlcXVlc3Qgc2NvcGVzIHJldHVybiB0aGUgY3VycmVudCBzZXNzaW9uLlxuXHRcdGZvcmNlOiBudWxsLFxuXG5cdFx0Ly8gUGFnZSBVUkxcblx0XHQvLyBXaGVuICdkaXNwbGF5PXBhZ2UnIHRoaXMgcHJvcGVydHkgZGVmaW5lcyB3aGVyZSB0aGUgdXNlcnMgcGFnZSBzaG91bGQgZW5kIHVwIGFmdGVyIHJlZGlyZWN0X3VyaVxuXHRcdC8vIFRocyBjb3VsZCBiZSBwcm9ibGVtYXRpYyBpZiB0aGUgcmVkaXJlY3RfdXJpIGlzIGluZGVlZCB0aGUgZmluYWwgcGxhY2UsXG5cdFx0Ly8gVHlwaWNhbGx5IHRoaXMgY2lyY3VtdmVudHMgdGhlIHByb2JsZW0gb2YgdGhlIHJlZGlyZWN0X3VybCBiZWluZyBhIGR1bWIgcmVsYXkgcGFnZS5cblx0XHRwYWdlX3VyaTogd2luZG93LmxvY2F0aW9uLmhyZWZcblx0fSxcblxuXHQvLyBTZXJ2aWNlIGNvbmZpZ3VyYXRpb24gb2JqZWN0c1xuXHRzZXJ2aWNlczoge30sXG5cblx0Ly8gVXNlXG5cdC8vIERlZmluZSBhIG5ldyBpbnN0YW5jZSBvZiB0aGUgSGVsbG9KUyBsaWJyYXJ5IHdpdGggYSBkZWZhdWx0IHNlcnZpY2Vcblx0dXNlOiBmdW5jdGlvbihzZXJ2aWNlKSB7XG5cblx0XHQvLyBDcmVhdGUgc2VsZiwgd2hpY2ggaW5oZXJpdHMgZnJvbSBpdHMgcGFyZW50XG5cdFx0dmFyIHNlbGYgPSBPYmplY3QuY3JlYXRlKHRoaXMpO1xuXG5cdFx0Ly8gSW5oZXJpdCB0aGUgcHJvdG90eXBlIGZyb20gaXRzIHBhcmVudFxuXHRcdHNlbGYuc2V0dGluZ3MgPSBPYmplY3QuY3JlYXRlKHRoaXMuc2V0dGluZ3MpO1xuXG5cdFx0Ly8gRGVmaW5lIHRoZSBkZWZhdWx0IHNlcnZpY2Vcblx0XHRpZiAoc2VydmljZSkge1xuXHRcdFx0c2VsZi5zZXR0aW5ncy5kZWZhdWx0X3NlcnZpY2UgPSBzZXJ2aWNlO1xuXHRcdH1cblxuXHRcdC8vIENyZWF0ZSBhbiBpbnN0YW5jZSBvZiBFdmVudHNcblx0XHRzZWxmLnV0aWxzLkV2ZW50LmNhbGwoc2VsZik7XG5cblx0XHRyZXR1cm4gc2VsZjtcblx0fSxcblxuXHQvLyBJbml0aWFsaXplXG5cdC8vIERlZmluZSB0aGUgY2xpZW50X2lkcyBmb3IgdGhlIGVuZHBvaW50IHNlcnZpY2VzXG5cdC8vIEBwYXJhbSBvYmplY3QgbywgY29udGFpbnMgYSBrZXkgdmFsdWUgcGFpciwgc2VydmljZSA9PiBjbGllbnRJZFxuXHQvLyBAcGFyYW0gb2JqZWN0IG9wdHMsIGNvbnRhaW5zIGEga2V5IHZhbHVlIHBhaXIgb2Ygb3B0aW9ucyB1c2VkIGZvciBkZWZpbmluZyB0aGUgYXV0aGVudGljYXRpb24gZGVmYXVsdHNcblx0Ly8gQHBhcmFtIG51bWJlciB0aW1lb3V0LCB0aW1lb3V0IGluIHNlY29uZHNcblx0aW5pdDogZnVuY3Rpb24oc2VydmljZXMsIG9wdGlvbnMpIHtcblxuXHRcdHZhciB1dGlscyA9IHRoaXMudXRpbHM7XG5cblx0XHRpZiAoIXNlcnZpY2VzKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5zZXJ2aWNlcztcblx0XHR9XG5cblx0XHQvLyBEZWZpbmUgcHJvdmlkZXIgY3JlZGVudGlhbHNcblx0XHQvLyBSZWZvcm1hdCB0aGUgSUQgZmllbGRcblx0XHRmb3IgKHZhciB4IGluIHNlcnZpY2VzKSB7aWYgKHNlcnZpY2VzLmhhc093blByb3BlcnR5KHgpKSB7XG5cdFx0XHRpZiAodHlwZW9mIChzZXJ2aWNlc1t4XSkgIT09ICdvYmplY3QnKSB7XG5cdFx0XHRcdHNlcnZpY2VzW3hdID0ge2lkOiBzZXJ2aWNlc1t4XX07XG5cdFx0XHR9XG5cdFx0fX1cblxuXHRcdC8vIE1lcmdlIHNlcnZpY2VzIGlmIHRoZXJlIGFscmVhZHkgZXhpc3RzIHNvbWVcblx0XHR1dGlscy5leHRlbmQodGhpcy5zZXJ2aWNlcywgc2VydmljZXMpO1xuXG5cdFx0Ly8gVXBkYXRlIHRoZSBkZWZhdWx0IHNldHRpbmdzIHdpdGggdGhpcyBvbmUuXG5cdFx0aWYgKG9wdGlvbnMpIHtcblx0XHRcdHV0aWxzLmV4dGVuZCh0aGlzLnNldHRpbmdzLCBvcHRpb25zKTtcblxuXHRcdFx0Ly8gRG8gdGhpcyBpbW1lZGlhdGx5IGluY2FzZSB0aGUgYnJvd3NlciBjaGFuZ2VzIHRoZSBjdXJyZW50IHBhdGguXG5cdFx0XHRpZiAoJ3JlZGlyZWN0X3VyaScgaW4gb3B0aW9ucykge1xuXHRcdFx0XHR0aGlzLnNldHRpbmdzLnJlZGlyZWN0X3VyaSA9IHV0aWxzLnVybChvcHRpb25zLnJlZGlyZWN0X3VyaSkuaHJlZjtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRyZXR1cm4gdGhpcztcblx0fSxcblxuXHQvLyBMb2dpblxuXHQvLyBVc2luZyB0aGUgZW5kcG9pbnRcblx0Ly8gQHBhcmFtIG5ldHdvcmsgc3RyaW5naWZ5ICAgICAgIG5hbWUgdG8gY29ubmVjdCB0b1xuXHQvLyBAcGFyYW0gb3B0aW9ucyBvYmplY3QgICAgKG9wdGlvbmFsKSAge2Rpc3BsYXkgbW9kZSwgaXMgZWl0aGVyIG5vbmV8cG9wdXAoZGVmYXVsdCl8cGFnZSwgc2NvcGU6IGVtYWlsLGJpcnRoZGF5LHB1Ymxpc2gsIC4uIH1cblx0Ly8gQHBhcmFtIGNhbGxiYWNrICBmdW5jdGlvbiAgKG9wdGlvbmFsKSAgZmlyZWQgb24gc2lnbmluXG5cdGxvZ2luOiBmdW5jdGlvbigpIHtcblxuXHRcdC8vIENyZWF0ZSBhbiBvYmplY3Qgd2hpY2ggaW5oZXJpdHMgaXRzIHBhcmVudCBhcyB0aGUgcHJvdG90eXBlIGFuZCBjb25zdHJ1Y3RzIGEgbmV3IGV2ZW50IGNoYWluLlxuXHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0dmFyIHV0aWxzID0gX3RoaXMudXRpbHM7XG5cdFx0dmFyIGVycm9yID0gdXRpbHMuZXJyb3I7XG5cdFx0dmFyIHByb21pc2UgPSB1dGlscy5Qcm9taXNlKCk7XG5cblx0XHQvLyBHZXQgcGFyYW1ldGVyc1xuXHRcdHZhciBwID0gdXRpbHMuYXJncyh7bmV0d29yazogJ3MnLCBvcHRpb25zOiAnbycsIGNhbGxiYWNrOiAnZid9LCBhcmd1bWVudHMpO1xuXG5cdFx0Ly8gTG9jYWwgdmFyc1xuXHRcdHZhciB1cmw7XG5cblx0XHQvLyBHZXQgYWxsIHRoZSBjdXN0b20gb3B0aW9ucyBhbmQgc3RvcmUgdG8gYmUgYXBwZW5kZWQgdG8gdGhlIHF1ZXJ5c3RyaW5nXG5cdFx0dmFyIHFzID0gdXRpbHMuZGlmZktleShwLm9wdGlvbnMsIF90aGlzLnNldHRpbmdzKTtcblxuXHRcdC8vIE1lcmdlL292ZXJyaWRlIG9wdGlvbnMgd2l0aCBhcHAgZGVmYXVsdHNcblx0XHR2YXIgb3B0cyA9IHAub3B0aW9ucyA9IHV0aWxzLm1lcmdlKF90aGlzLnNldHRpbmdzLCBwLm9wdGlvbnMgfHwge30pO1xuXG5cdFx0Ly8gTWVyZ2Uvb3ZlcnJpZGUgb3B0aW9ucyB3aXRoIGFwcCBkZWZhdWx0c1xuXHRcdG9wdHMucG9wdXAgPSB1dGlscy5tZXJnZShfdGhpcy5zZXR0aW5ncy5wb3B1cCwgcC5vcHRpb25zLnBvcHVwIHx8IHt9KTtcblxuXHRcdC8vIE5ldHdvcmtcblx0XHRwLm5ldHdvcmsgPSBwLm5ldHdvcmsgfHwgX3RoaXMuc2V0dGluZ3MuZGVmYXVsdF9zZXJ2aWNlO1xuXG5cdFx0Ly8gQmluZCBjYWxsYmFjayB0byBib3RoIHJlamVjdCBhbmQgZnVsZmlsbCBzdGF0ZXNcblx0XHRwcm9taXNlLnByb3h5LnRoZW4ocC5jYWxsYmFjaywgcC5jYWxsYmFjayk7XG5cblx0XHQvLyBUcmlnZ2VyIGFuIGV2ZW50IG9uIHRoZSBnbG9iYWwgbGlzdGVuZXJcblx0XHRmdW5jdGlvbiBlbWl0KHMsIHZhbHVlKSB7XG5cdFx0XHRoZWxsby5lbWl0KHMsIHZhbHVlKTtcblx0XHR9XG5cblx0XHRwcm9taXNlLnByb3h5LnRoZW4oZW1pdC5iaW5kKHRoaXMsICdhdXRoLmxvZ2luIGF1dGgnKSwgZW1pdC5iaW5kKHRoaXMsICdhdXRoLmZhaWxlZCBhdXRoJykpO1xuXG5cdFx0Ly8gSXMgb3VyIHNlcnZpY2UgdmFsaWQ/XG5cdFx0aWYgKHR5cGVvZiAocC5uZXR3b3JrKSAhPT0gJ3N0cmluZycgfHwgIShwLm5ldHdvcmsgaW4gX3RoaXMuc2VydmljZXMpKSB7XG5cdFx0XHQvLyBUcmlnZ2VyIHRoZSBkZWZhdWx0IGxvZ2luLlxuXHRcdFx0Ly8gQWhoIHdlIGRvbnQgaGF2ZSBvbmUuXG5cdFx0XHRyZXR1cm4gcHJvbWlzZS5yZWplY3QoZXJyb3IoJ2ludmFsaWRfbmV0d29yaycsICdUaGUgcHJvdmlkZWQgbmV0d29yayB3YXMgbm90IHJlY29nbml6ZWQnKSk7XG5cdFx0fVxuXG5cdFx0dmFyIHByb3ZpZGVyID0gX3RoaXMuc2VydmljZXNbcC5uZXR3b3JrXTtcblxuXHRcdC8vIENyZWF0ZSBhIGdsb2JhbCBsaXN0ZW5lciB0byBjYXB0dXJlIGV2ZW50cyB0cmlnZ2VyZWQgb3V0IG9mIHNjb3BlXG5cdFx0dmFyIGNhbGxiYWNrSWQgPSB1dGlscy5nbG9iYWxFdmVudChmdW5jdGlvbihvYmopIHtcblxuXHRcdFx0Ly8gVGhlIHJlc3BvbnNlSGFuZGxlciByZXR1cm5zIGEgc3RyaW5nLCBsZXRzIHNhdmUgdGhpcyBsb2NhbGx5XG5cdFx0XHRpZiAob2JqKSB7XG5cdFx0XHRcdGlmICh0eXBlb2YgKG9iaikgPT0gJ3N0cmluZycpIHtcblx0XHRcdFx0XHRvYmogPSBKU09OLnBhcnNlKG9iaik7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRvYmogPSBlcnJvcignY2FuY2VsbGVkJywgJ1RoZSBhdXRoZW50aWNhdGlvbiB3YXMgbm90IGNvbXBsZXRlZCcpO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBIYW5kbGUgdGhlc2UgcmVzcG9uc2UgdXNpbmcgdGhlIGxvY2FsXG5cdFx0XHQvLyBUcmlnZ2VyIG9uIHRoZSBwYXJlbnRcblx0XHRcdGlmICghb2JqLmVycm9yKSB7XG5cblx0XHRcdFx0Ly8gU2F2ZSBvbiB0aGUgcGFyZW50IHdpbmRvdyB0aGUgbmV3IGNyZWRlbnRpYWxzXG5cdFx0XHRcdC8vIFRoaXMgZml4ZXMgYW4gSUUxMCBidWcgaSB0aGluay4uLiBhdGxlYXN0IGl0IGRvZXMgZm9yIG1lLlxuXHRcdFx0XHR1dGlscy5zdG9yZShvYmoubmV0d29yaywgb2JqKTtcblxuXHRcdFx0XHQvLyBGdWxmaWxsIGEgc3VjY2Vzc2Z1bCBsb2dpblxuXHRcdFx0XHRwcm9taXNlLmZ1bGZpbGwoe1xuXHRcdFx0XHRcdG5ldHdvcms6IG9iai5uZXR3b3JrLFxuXHRcdFx0XHRcdGF1dGhSZXNwb25zZTogb2JqXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdC8vIFJlamVjdCBhIHN1Y2Nlc3NmdWwgbG9naW5cblx0XHRcdFx0cHJvbWlzZS5yZWplY3Qob2JqKTtcblx0XHRcdH1cblx0XHR9KTtcblxuXHRcdHZhciByZWRpcmVjdFVyaSA9IHV0aWxzLnVybChvcHRzLnJlZGlyZWN0X3VyaSkuaHJlZjtcblxuXHRcdC8vIE1heSBiZSBhIHNwYWNlLWRlbGltaXRlZCBsaXN0IG9mIG11bHRpcGxlLCBjb21wbGVtZW50YXJ5IHR5cGVzXG5cdFx0dmFyIHJlc3BvbnNlVHlwZSA9IHByb3ZpZGVyLm9hdXRoLnJlc3BvbnNlX3R5cGUgfHwgb3B0cy5yZXNwb25zZV90eXBlO1xuXG5cdFx0Ly8gRmFsbGJhY2sgdG8gdG9rZW4gaWYgdGhlIG1vZHVsZSBoYXNuJ3QgZGVmaW5lZCBhIGdyYW50IHVybFxuXHRcdGlmICgvXFxiY29kZVxcYi8udGVzdChyZXNwb25zZVR5cGUpICYmICFwcm92aWRlci5vYXV0aC5ncmFudCkge1xuXHRcdFx0cmVzcG9uc2VUeXBlID0gcmVzcG9uc2VUeXBlLnJlcGxhY2UoL1xcYmNvZGVcXGIvLCAndG9rZW4nKTtcblx0XHR9XG5cblx0XHQvLyBRdWVyeSBzdHJpbmcgcGFyYW1ldGVycywgd2UgbWF5IHBhc3Mgb3VyIG93biBhcmd1bWVudHMgdG8gZm9ybSB0aGUgcXVlcnlzdHJpbmdcblx0XHRwLnFzID0gdXRpbHMubWVyZ2UocXMsIHtcblx0XHRcdGNsaWVudF9pZDogZW5jb2RlVVJJQ29tcG9uZW50KHByb3ZpZGVyLmlkKSxcblx0XHRcdHJlc3BvbnNlX3R5cGU6IGVuY29kZVVSSUNvbXBvbmVudChyZXNwb25zZVR5cGUpLFxuXHRcdFx0cmVkaXJlY3RfdXJpOiBlbmNvZGVVUklDb21wb25lbnQocmVkaXJlY3RVcmkpLFxuXHRcdFx0c3RhdGU6IHtcblx0XHRcdFx0Y2xpZW50X2lkOiBwcm92aWRlci5pZCxcblx0XHRcdFx0bmV0d29yazogcC5uZXR3b3JrLFxuXHRcdFx0XHRkaXNwbGF5OiBvcHRzLmRpc3BsYXksXG5cdFx0XHRcdGNhbGxiYWNrOiBjYWxsYmFja0lkLFxuXHRcdFx0XHRzdGF0ZTogb3B0cy5zdGF0ZSxcblx0XHRcdFx0cmVkaXJlY3RfdXJpOiByZWRpcmVjdFVyaVxuXHRcdFx0fVxuXHRcdH0pO1xuXG5cdFx0Ly8gR2V0IGN1cnJlbnQgc2Vzc2lvbiBmb3IgbWVyZ2luZyBzY29wZXMsIGFuZCBmb3IgcXVpY2sgYXV0aCByZXNwb25zZVxuXHRcdHZhciBzZXNzaW9uID0gdXRpbHMuc3RvcmUocC5uZXR3b3JrKTtcblxuXHRcdC8vIFNjb3BlcyAoYXV0aGVudGljYXRpb24gcGVybWlzaW9ucylcblx0XHQvLyBFbnN1cmUgdGhpcyBpcyBhIHN0cmluZyAtIElFIGhhcyBhIHByb2JsZW0gbW92aW5nIEFycmF5cyBiZXR3ZWVuIHdpbmRvd3Ncblx0XHQvLyBBcHBlbmQgdGhlIHNldHVwIHNjb3BlXG5cdFx0dmFyIFNDT1BFX1NQTElUID0gL1ssXFxzXSsvO1xuXG5cdFx0Ly8gSW5jbHVkZSBkZWZhdWx0IHNjb3BlIHNldHRpbmdzIChjbG9uZWQpLlxuXHRcdHZhciBzY29wZSA9IF90aGlzLnNldHRpbmdzLnNjb3BlID8gW190aGlzLnNldHRpbmdzLnNjb3BlLnRvU3RyaW5nKCldIDogW107XG5cblx0XHQvLyBFeHRlbmQgdGhlIHByb3ZpZGVycyBzY29wZSBsaXN0IHdpdGggdGhlIGRlZmF1bHRcblx0XHR2YXIgc2NvcGVNYXAgPSB1dGlscy5tZXJnZShfdGhpcy5zZXR0aW5ncy5zY29wZV9tYXAsIHByb3ZpZGVyLnNjb3BlIHx8IHt9KTtcblxuXHRcdC8vIEFkZCB1c2VyIGRlZmluZWQgc2NvcGVzLi4uXG5cdFx0aWYgKG9wdHMuc2NvcGUpIHtcblx0XHRcdHNjb3BlLnB1c2gob3B0cy5zY29wZS50b1N0cmluZygpKTtcblx0XHR9XG5cblx0XHQvLyBBcHBlbmQgc2NvcGVzIGZyb20gYSBwcmV2aW91cyBzZXNzaW9uLlxuXHRcdC8vIFRoaXMgaGVscHMga2VlcCBhcHAgY3JlZGVudGlhbHMgY29uc3RhbnQsXG5cdFx0Ly8gQXZvaWRpbmcgaGF2aW5nIHRvIGtlZXAgdGFicyBvbiB3aGF0IHNjb3BlcyBhcmUgYXV0aG9yaXplZFxuXHRcdGlmIChzZXNzaW9uICYmICdzY29wZScgaW4gc2Vzc2lvbiAmJiBzZXNzaW9uLnNjb3BlIGluc3RhbmNlb2YgU3RyaW5nKSB7XG5cdFx0XHRzY29wZS5wdXNoKHNlc3Npb24uc2NvcGUpO1xuXHRcdH1cblxuXHRcdC8vIEpvaW4gYW5kIFNwbGl0IGFnYWluXG5cdFx0c2NvcGUgPSBzY29wZS5qb2luKCcsJykuc3BsaXQoU0NPUEVfU1BMSVQpO1xuXG5cdFx0Ly8gRm9ybWF0IHJlbW92ZSBkdXBsaWNhdGVzIGFuZCBlbXB0eSB2YWx1ZXNcblx0XHRzY29wZSA9IHV0aWxzLnVuaXF1ZShzY29wZSkuZmlsdGVyKGZpbHRlckVtcHR5KTtcblxuXHRcdC8vIFNhdmUgdGhlIHRoZSBzY29wZXMgdG8gdGhlIHN0YXRlIHdpdGggdGhlIG5hbWVzIHRoYXQgdGhleSB3ZXJlIHJlcXVlc3RlZCB3aXRoLlxuXHRcdHAucXMuc3RhdGUuc2NvcGUgPSBzY29wZS5qb2luKCcsJyk7XG5cblx0XHQvLyBNYXAgc2NvcGVzIHRvIHRoZSBwcm92aWRlcnMgbmFtaW5nIGNvbnZlbnRpb25cblx0XHRzY29wZSA9IHNjb3BlLm1hcChmdW5jdGlvbihpdGVtKSB7XG5cdFx0XHQvLyBEb2VzIHRoaXMgaGF2ZSBhIG1hcHBpbmc/XG5cdFx0XHRyZXR1cm4gKGl0ZW0gaW4gc2NvcGVNYXApID8gc2NvcGVNYXBbaXRlbV0gOiBpdGVtO1xuXHRcdH0pO1xuXG5cdFx0Ly8gU3RyaW5naWZ5IGFuZCBBcnJheWlmeSBzbyB0aGF0IGRvdWJsZSBtYXBwZWQgc2NvcGVzIGFyZSBnaXZlbiB0aGUgY2hhbmNlIHRvIGJlIGZvcm1hdHRlZFxuXHRcdHNjb3BlID0gc2NvcGUuam9pbignLCcpLnNwbGl0KFNDT1BFX1NQTElUKTtcblxuXHRcdC8vIEFnYWluLi4uXG5cdFx0Ly8gRm9ybWF0IHJlbW92ZSBkdXBsaWNhdGVzIGFuZCBlbXB0eSB2YWx1ZXNcblx0XHRzY29wZSA9IHV0aWxzLnVuaXF1ZShzY29wZSkuZmlsdGVyKGZpbHRlckVtcHR5KTtcblxuXHRcdC8vIEpvaW4gd2l0aCB0aGUgZXhwZWN0ZWQgc2NvcGUgZGVsaW1pdGVyIGludG8gYSBzdHJpbmdcblx0XHRwLnFzLnNjb3BlID0gc2NvcGUuam9pbihwcm92aWRlci5zY29wZV9kZWxpbSB8fCAnLCcpO1xuXG5cdFx0Ly8gSXMgdGhlIHVzZXIgYWxyZWFkeSBzaWduZWQgaW4gd2l0aCB0aGUgYXBwcm9wcmlhdGUgc2NvcGVzLCB2YWxpZCBhY2Nlc3NfdG9rZW4/XG5cdFx0aWYgKG9wdHMuZm9yY2UgPT09IGZhbHNlKSB7XG5cblx0XHRcdGlmIChzZXNzaW9uICYmICdhY2Nlc3NfdG9rZW4nIGluIHNlc3Npb24gJiYgc2Vzc2lvbi5hY2Nlc3NfdG9rZW4gJiYgJ2V4cGlyZXMnIGluIHNlc3Npb24gJiYgc2Vzc2lvbi5leHBpcmVzID4gKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCkgLyAxZTMpKSB7XG5cdFx0XHRcdC8vIFdoYXQgaXMgZGlmZmVyZW50IGFib3V0IHRoZSBzY29wZXMgaW4gdGhlIHNlc3Npb24gdnMgdGhlIHNjb3BlcyBpbiB0aGUgbmV3IGxvZ2luP1xuXHRcdFx0XHR2YXIgZGlmZiA9IHV0aWxzLmRpZmYoKHNlc3Npb24uc2NvcGUgfHwgJycpLnNwbGl0KFNDT1BFX1NQTElUKSwgKHAucXMuc3RhdGUuc2NvcGUgfHwgJycpLnNwbGl0KFNDT1BFX1NQTElUKSk7XG5cdFx0XHRcdGlmIChkaWZmLmxlbmd0aCA9PT0gMCkge1xuXG5cdFx0XHRcdFx0Ly8gT0sgdHJpZ2dlciB0aGUgY2FsbGJhY2tcblx0XHRcdFx0XHRwcm9taXNlLmZ1bGZpbGwoe1xuXHRcdFx0XHRcdFx0dW5jaGFuZ2VkOiB0cnVlLFxuXHRcdFx0XHRcdFx0bmV0d29yazogcC5uZXR3b3JrLFxuXHRcdFx0XHRcdFx0YXV0aFJlc3BvbnNlOiBzZXNzaW9uXG5cdFx0XHRcdFx0fSk7XG5cblx0XHRcdFx0XHQvLyBOb3RoaW5nIGhhcyBjaGFuZ2VkXG5cdFx0XHRcdFx0cmV0dXJuIHByb21pc2U7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBQYWdlIFVSTFxuXHRcdGlmIChvcHRzLmRpc3BsYXkgPT09ICdwYWdlJyAmJiBvcHRzLnBhZ2VfdXJpKSB7XG5cdFx0XHQvLyBBZGQgYSBwYWdlIGxvY2F0aW9uLCBwbGFjZSB0byBlbmR1cCBhZnRlciBzZXNzaW9uIGhhcyBhdXRoZW50aWNhdGVkXG5cdFx0XHRwLnFzLnN0YXRlLnBhZ2VfdXJpID0gdXRpbHMudXJsKG9wdHMucGFnZV91cmkpLmhyZWY7XG5cdFx0fVxuXG5cdFx0Ly8gQmVzcG9rZVxuXHRcdC8vIE92ZXJyaWRlIGxvZ2luIHF1ZXJ5c3RyaW5ncyBmcm9tIGF1dGhfb3B0aW9uc1xuXHRcdGlmICgnbG9naW4nIGluIHByb3ZpZGVyICYmIHR5cGVvZiAocHJvdmlkZXIubG9naW4pID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHQvLyBGb3JtYXQgdGhlIHBhcmFtYXRlcnMgYWNjb3JkaW5nIHRvIHRoZSBwcm92aWRlcnMgZm9ybWF0dGluZyBmdW5jdGlvblxuXHRcdFx0cHJvdmlkZXIubG9naW4ocCk7XG5cdFx0fVxuXG5cdFx0Ly8gQWRkIE9BdXRoIHRvIHN0YXRlXG5cdFx0Ly8gV2hlcmUgdGhlIHNlcnZpY2UgaXMgZ29pbmcgdG8gdGFrZSBhZHZhbnRhZ2Ugb2YgdGhlIG9hdXRoX3Byb3h5XG5cdFx0aWYgKCEvXFxidG9rZW5cXGIvLnRlc3QocmVzcG9uc2VUeXBlKSB8fFxuXHRcdHBhcnNlSW50KHByb3ZpZGVyLm9hdXRoLnZlcnNpb24sIDEwKSA8IDIgfHxcblx0XHQob3B0cy5kaXNwbGF5ID09PSAnbm9uZScgJiYgcHJvdmlkZXIub2F1dGguZ3JhbnQgJiYgc2Vzc2lvbiAmJiBzZXNzaW9uLnJlZnJlc2hfdG9rZW4pKSB7XG5cblx0XHRcdC8vIEFkZCB0aGUgb2F1dGggZW5kcG9pbnRzXG5cdFx0XHRwLnFzLnN0YXRlLm9hdXRoID0gcHJvdmlkZXIub2F1dGg7XG5cblx0XHRcdC8vIEFkZCB0aGUgcHJveHkgdXJsXG5cdFx0XHRwLnFzLnN0YXRlLm9hdXRoX3Byb3h5ID0gb3B0cy5vYXV0aF9wcm94eTtcblxuXHRcdH1cblxuXHRcdC8vIENvbnZlcnQgc3RhdGUgdG8gYSBzdHJpbmdcblx0XHRwLnFzLnN0YXRlID0gZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHAucXMuc3RhdGUpKTtcblxuXHRcdC8vIFVSTFxuXHRcdGlmIChwYXJzZUludChwcm92aWRlci5vYXV0aC52ZXJzaW9uLCAxMCkgPT09IDEpIHtcblxuXHRcdFx0Ly8gVHVybiB0aGUgcmVxdWVzdCB0byB0aGUgT0F1dGggUHJveHkgZm9yIDMtbGVnZ2VkIGF1dGhcblx0XHRcdHVybCA9IHV0aWxzLnFzKG9wdHMub2F1dGhfcHJveHksIHAucXMsIGVuY29kZUZ1bmN0aW9uKTtcblx0XHR9XG5cblx0XHQvLyBSZWZyZXNoIHRva2VuXG5cdFx0ZWxzZSBpZiAob3B0cy5kaXNwbGF5ID09PSAnbm9uZScgJiYgcHJvdmlkZXIub2F1dGguZ3JhbnQgJiYgc2Vzc2lvbiAmJiBzZXNzaW9uLnJlZnJlc2hfdG9rZW4pIHtcblxuXHRcdFx0Ly8gQWRkIHRoZSByZWZyZXNoX3Rva2VuIHRvIHRoZSByZXF1ZXN0XG5cdFx0XHRwLnFzLnJlZnJlc2hfdG9rZW4gPSBzZXNzaW9uLnJlZnJlc2hfdG9rZW47XG5cblx0XHRcdC8vIERlZmluZSB0aGUgcmVxdWVzdCBwYXRoXG5cdFx0XHR1cmwgPSB1dGlscy5xcyhvcHRzLm9hdXRoX3Byb3h5LCBwLnFzLCBlbmNvZGVGdW5jdGlvbik7XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0dXJsID0gdXRpbHMucXMocHJvdmlkZXIub2F1dGguYXV0aCwgcC5xcywgZW5jb2RlRnVuY3Rpb24pO1xuXHRcdH1cblxuXHRcdC8vIEJyb2FkY2FzdCB0aGlzIGV2ZW50IGFzIGFuIGF1dGg6aW5pdFxuXHRcdGVtaXQoJ2F1dGguaW5pdCcsIHApO1xuXG5cdFx0Ly8gRXhlY3V0ZVxuXHRcdC8vIFRyaWdnZXIgaG93IHdlIHdhbnQgc2VsZiBkaXNwbGF5ZWRcblx0XHRpZiAob3B0cy5kaXNwbGF5ID09PSAnbm9uZScpIHtcblx0XHRcdC8vIFNpZ24taW4gaW4gdGhlIGJhY2tncm91bmQsIGlmcmFtZVxuXHRcdFx0dXRpbHMuaWZyYW1lKHVybCwgcmVkaXJlY3RVcmkpO1xuXHRcdH1cblxuXHRcdC8vIFRyaWdnZXJpbmcgcG9wdXA/XG5cdFx0ZWxzZSBpZiAob3B0cy5kaXNwbGF5ID09PSAncG9wdXAnKSB7XG5cblx0XHRcdHZhciBwb3B1cCA9IHV0aWxzLnBvcHVwKHVybCwgcmVkaXJlY3RVcmksIG9wdHMucG9wdXApO1xuXG5cdFx0XHR2YXIgdGltZXIgPSBzZXRJbnRlcnZhbChmdW5jdGlvbigpIHtcblx0XHRcdFx0aWYgKCFwb3B1cCB8fCBwb3B1cC5jbG9zZWQpIHtcblx0XHRcdFx0XHRjbGVhckludGVydmFsKHRpbWVyKTtcblx0XHRcdFx0XHRpZiAoIXByb21pc2Uuc3RhdGUpIHtcblxuXHRcdFx0XHRcdFx0dmFyIHJlc3BvbnNlID0gZXJyb3IoJ2NhbmNlbGxlZCcsICdMb2dpbiBoYXMgYmVlbiBjYW5jZWxsZWQnKTtcblxuXHRcdFx0XHRcdFx0aWYgKCFwb3B1cCkge1xuXHRcdFx0XHRcdFx0XHRyZXNwb25zZSA9IGVycm9yKCdibG9ja2VkJywgJ1BvcHVwIHdhcyBibG9ja2VkJyk7XG5cdFx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRcdHJlc3BvbnNlLm5ldHdvcmsgPSBwLm5ldHdvcms7XG5cblx0XHRcdFx0XHRcdHByb21pc2UucmVqZWN0KHJlc3BvbnNlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH0sIDEwMCk7XG5cdFx0fVxuXG5cdFx0ZWxzZSB7XG5cdFx0XHR3aW5kb3cubG9jYXRpb24gPSB1cmw7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHByb21pc2UucHJveHk7XG5cblx0XHRmdW5jdGlvbiBlbmNvZGVGdW5jdGlvbihzKSB7cmV0dXJuIHM7fVxuXG5cdFx0ZnVuY3Rpb24gZmlsdGVyRW1wdHkocykge3JldHVybiAhIXM7fVxuXHR9LFxuXG5cdC8vIFJlbW92ZSBhbnkgZGF0YSBhc3NvY2lhdGVkIHdpdGggYSBnaXZlbiBzZXJ2aWNlXG5cdC8vIEBwYXJhbSBzdHJpbmcgbmFtZSBvZiB0aGUgc2VydmljZVxuXHQvLyBAcGFyYW0gZnVuY3Rpb24gY2FsbGJhY2tcblx0bG9nb3V0OiBmdW5jdGlvbigpIHtcblxuXHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0dmFyIHV0aWxzID0gX3RoaXMudXRpbHM7XG5cdFx0dmFyIGVycm9yID0gdXRpbHMuZXJyb3I7XG5cblx0XHQvLyBDcmVhdGUgYSBuZXcgcHJvbWlzZVxuXHRcdHZhciBwcm9taXNlID0gdXRpbHMuUHJvbWlzZSgpO1xuXG5cdFx0dmFyIHAgPSB1dGlscy5hcmdzKHtuYW1lOidzJywgb3B0aW9uczogJ28nLCBjYWxsYmFjazogJ2YnfSwgYXJndW1lbnRzKTtcblxuXHRcdHAub3B0aW9ucyA9IHAub3B0aW9ucyB8fCB7fTtcblxuXHRcdC8vIEFkZCBjYWxsYmFjayB0byBldmVudHNcblx0XHRwcm9taXNlLnByb3h5LnRoZW4ocC5jYWxsYmFjaywgcC5jYWxsYmFjayk7XG5cblx0XHQvLyBUcmlnZ2VyIGFuIGV2ZW50IG9uIHRoZSBnbG9iYWwgbGlzdGVuZXJcblx0XHRmdW5jdGlvbiBlbWl0KHMsIHZhbHVlKSB7XG5cdFx0XHRoZWxsby5lbWl0KHMsIHZhbHVlKTtcblx0XHR9XG5cblx0XHRwcm9taXNlLnByb3h5LnRoZW4oZW1pdC5iaW5kKHRoaXMsICdhdXRoLmxvZ291dCBhdXRoJyksIGVtaXQuYmluZCh0aGlzLCAnZXJyb3InKSk7XG5cblx0XHQvLyBOZXR3b3JrXG5cdFx0cC5uYW1lID0gcC5uYW1lIHx8IHRoaXMuc2V0dGluZ3MuZGVmYXVsdF9zZXJ2aWNlO1xuXHRcdHAuYXV0aFJlc3BvbnNlID0gdXRpbHMuc3RvcmUocC5uYW1lKTtcblxuXHRcdGlmIChwLm5hbWUgJiYgIShwLm5hbWUgaW4gX3RoaXMuc2VydmljZXMpKSB7XG5cblx0XHRcdHByb21pc2UucmVqZWN0KGVycm9yKCdpbnZhbGlkX25ldHdvcmsnLCAnVGhlIG5ldHdvcmsgd2FzIHVucmVjb2duaXplZCcpKTtcblxuXHRcdH1cblx0XHRlbHNlIGlmIChwLm5hbWUgJiYgcC5hdXRoUmVzcG9uc2UpIHtcblxuXHRcdFx0Ly8gRGVmaW5lIHRoZSBjYWxsYmFja1xuXHRcdFx0dmFyIGNhbGxiYWNrID0gZnVuY3Rpb24ob3B0cykge1xuXG5cdFx0XHRcdC8vIFJlbW92ZSBmcm9tIHRoZSBzdG9yZVxuXHRcdFx0XHR1dGlscy5zdG9yZShwLm5hbWUsIG51bGwpO1xuXG5cdFx0XHRcdC8vIEVtaXQgZXZlbnRzIGJ5IGRlZmF1bHRcblx0XHRcdFx0cHJvbWlzZS5mdWxmaWxsKGhlbGxvLnV0aWxzLm1lcmdlKHtuZXR3b3JrOnAubmFtZX0sIG9wdHMgfHwge30pKTtcblx0XHRcdH07XG5cblx0XHRcdC8vIFJ1biBhbiBhc3luYyBvcGVyYXRpb24gdG8gcmVtb3ZlIHRoZSB1c2VycyBzZXNzaW9uXG5cdFx0XHR2YXIgX29wdHMgPSB7fTtcblx0XHRcdGlmIChwLm9wdGlvbnMuZm9yY2UpIHtcblx0XHRcdFx0dmFyIGxvZ291dCA9IF90aGlzLnNlcnZpY2VzW3AubmFtZV0ubG9nb3V0O1xuXHRcdFx0XHRpZiAobG9nb3V0KSB7XG5cdFx0XHRcdFx0Ly8gQ29udmVydCBsb2dvdXQgdG8gVVJMIHN0cmluZyxcblx0XHRcdFx0XHQvLyBJZiBubyBzdHJpbmcgaXMgcmV0dXJuZWQsIHRoZW4gdGhpcyBmdW5jdGlvbiB3aWxsIGhhbmRsZSB0aGUgbG9nb3V0IGFzeW5jIHN0eWxlXG5cdFx0XHRcdFx0aWYgKHR5cGVvZiAobG9nb3V0KSA9PT0gJ2Z1bmN0aW9uJykge1xuXHRcdFx0XHRcdFx0bG9nb3V0ID0gbG9nb3V0KGNhbGxiYWNrLCBwKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBJZiBsb2dvdXQgaXMgYSBzdHJpbmcgdGhlbiBhc3N1bWUgVVJMIGFuZCBvcGVuIGluIGlmcmFtZS5cblx0XHRcdFx0XHRpZiAodHlwZW9mIChsb2dvdXQpID09PSAnc3RyaW5nJykge1xuXHRcdFx0XHRcdFx0dXRpbHMuaWZyYW1lKGxvZ291dCk7XG5cdFx0XHRcdFx0XHRfb3B0cy5mb3JjZSA9IG51bGw7XG5cdFx0XHRcdFx0XHRfb3B0cy5tZXNzYWdlID0gJ0xvZ291dCBzdWNjZXNzIG9uIHByb3ZpZGVycyBzaXRlIHdhcyBpbmRldGVybWluYXRlJztcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZWxzZSBpZiAobG9nb3V0ID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdC8vIFRoZSBjYWxsYmFjayBmdW5jdGlvbiB3aWxsIGhhbmRsZSB0aGUgcmVzcG9uc2UuXG5cdFx0XHRcdFx0XHRyZXR1cm4gcHJvbWlzZS5wcm94eTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVtb3ZlIGxvY2FsIGNyZWRlbnRpYWxzXG5cdFx0XHRjYWxsYmFjayhfb3B0cyk7XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0cHJvbWlzZS5yZWplY3QoZXJyb3IoJ2ludmFsaWRfc2Vzc2lvbicsICdUaGVyZSB3YXMgbm8gc2Vzc2lvbiB0byByZW1vdmUnKSk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHByb21pc2UucHJveHk7XG5cdH0sXG5cblx0Ly8gUmV0dXJucyBhbGwgdGhlIHNlc3Npb25zIHRoYXQgYXJlIHN1YnNjcmliZWQgdG9vXG5cdC8vIEBwYXJhbSBzdHJpbmcgb3B0aW9uYWwsIG5hbWUgb2YgdGhlIHNlcnZpY2UgdG8gZ2V0IGluZm9ybWF0aW9uIGFib3V0LlxuXHRnZXRBdXRoUmVzcG9uc2U6IGZ1bmN0aW9uKHNlcnZpY2UpIHtcblxuXHRcdC8vIElmIHRoZSBzZXJ2aWNlIGRvZXNuJ3QgZXhpc3Rcblx0XHRzZXJ2aWNlID0gc2VydmljZSB8fCB0aGlzLnNldHRpbmdzLmRlZmF1bHRfc2VydmljZTtcblxuXHRcdGlmICghc2VydmljZSB8fCAhKHNlcnZpY2UgaW4gdGhpcy5zZXJ2aWNlcykpIHtcblx0XHRcdHJldHVybiBudWxsO1xuXHRcdH1cblxuXHRcdHJldHVybiB0aGlzLnV0aWxzLnN0b3JlKHNlcnZpY2UpIHx8IG51bGw7XG5cdH0sXG5cblx0Ly8gRXZlbnRzOiBwbGFjZWhvbGRlciBmb3IgdGhlIGV2ZW50c1xuXHRldmVudHM6IHt9XG59KTtcblxuLy8gQ29yZSB1dGlsaXRpZXNcbmhlbGxvLnV0aWxzLmV4dGVuZChoZWxsby51dGlscywge1xuXG5cdC8vIEVycm9yXG5cdGVycm9yOiBmdW5jdGlvbihjb2RlLCBtZXNzYWdlKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGVycm9yOiB7XG5cdFx0XHRcdGNvZGU6IGNvZGUsXG5cdFx0XHRcdG1lc3NhZ2U6IG1lc3NhZ2Vcblx0XHRcdH1cblx0XHR9O1xuXHR9LFxuXG5cdC8vIEFwcGVuZCB0aGUgcXVlcnlzdHJpbmcgdG8gYSB1cmxcblx0Ly8gQHBhcmFtIHN0cmluZyB1cmxcblx0Ly8gQHBhcmFtIG9iamVjdCBwYXJhbWV0ZXJzXG5cdHFzOiBmdW5jdGlvbih1cmwsIHBhcmFtcywgZm9ybWF0RnVuY3Rpb24pIHtcblxuXHRcdGlmIChwYXJhbXMpIHtcblxuXHRcdFx0Ly8gU2V0IGRlZmF1bHQgZm9ybWF0dGluZyBmdW5jdGlvblxuXHRcdFx0Zm9ybWF0RnVuY3Rpb24gPSBmb3JtYXRGdW5jdGlvbiB8fCBlbmNvZGVVUklDb21wb25lbnQ7XG5cblx0XHRcdC8vIE92ZXJyaWRlIHRoZSBpdGVtcyBpbiB0aGUgVVJMIHdoaWNoIGFscmVhZHkgZXhpc3Rcblx0XHRcdGZvciAodmFyIHggaW4gcGFyYW1zKSB7XG5cdFx0XHRcdHZhciBzdHIgPSAnKFtcXFxcP1xcXFwmXSknICsgeCArICc9W15cXFxcJl0qJztcblx0XHRcdFx0dmFyIHJlZyA9IG5ldyBSZWdFeHAoc3RyKTtcblx0XHRcdFx0aWYgKHVybC5tYXRjaChyZWcpKSB7XG5cdFx0XHRcdFx0dXJsID0gdXJsLnJlcGxhY2UocmVnLCAnJDEnICsgeCArICc9JyArIGZvcm1hdEZ1bmN0aW9uKHBhcmFtc1t4XSkpO1xuXHRcdFx0XHRcdGRlbGV0ZSBwYXJhbXNbeF07XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZiAoIXRoaXMuaXNFbXB0eShwYXJhbXMpKSB7XG5cdFx0XHRyZXR1cm4gdXJsICsgKHVybC5pbmRleE9mKCc/JykgPiAtMSA/ICcmJyA6ICc/JykgKyB0aGlzLnBhcmFtKHBhcmFtcywgZm9ybWF0RnVuY3Rpb24pO1xuXHRcdH1cblxuXHRcdHJldHVybiB1cmw7XG5cdH0sXG5cblx0Ly8gUGFyYW1cblx0Ly8gRXhwbG9kZS9lbmNvZGUgdGhlIHBhcmFtZXRlcnMgb2YgYW4gVVJMIHN0cmluZy9vYmplY3Rcblx0Ly8gQHBhcmFtIHN0cmluZyBzLCBzdHJpbmcgdG8gZGVjb2RlXG5cdHBhcmFtOiBmdW5jdGlvbihzLCBmb3JtYXRGdW5jdGlvbikge1xuXHRcdHZhciBiO1xuXHRcdHZhciBhID0ge307XG5cdFx0dmFyIG07XG5cblx0XHRpZiAodHlwZW9mIChzKSA9PT0gJ3N0cmluZycpIHtcblxuXHRcdFx0Zm9ybWF0RnVuY3Rpb24gPSBmb3JtYXRGdW5jdGlvbiB8fCBkZWNvZGVVUklDb21wb25lbnQ7XG5cblx0XHRcdG0gPSBzLnJlcGxhY2UoL15bXFwjXFw/XS8sICcnKS5tYXRjaCgvKFtePVxcL1xcJl0rKT0oW15cXCZdKykvZyk7XG5cdFx0XHRpZiAobSkge1xuXHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IG0ubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0XHRiID0gbVtpXS5tYXRjaCgvKFtePV0rKT0oLiopLyk7XG5cdFx0XHRcdFx0YVtiWzFdXSA9IGZvcm1hdEZ1bmN0aW9uKGJbMl0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiBhO1xuXHRcdH1cblx0XHRlbHNlIHtcblxuXHRcdFx0Zm9ybWF0RnVuY3Rpb24gPSBmb3JtYXRGdW5jdGlvbiB8fCBlbmNvZGVVUklDb21wb25lbnQ7XG5cblx0XHRcdHZhciBvID0gcztcblxuXHRcdFx0YSA9IFtdO1xuXG5cdFx0XHRmb3IgKHZhciB4IGluIG8pIHtpZiAoby5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0XHRpZiAoby5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0XHRcdGEucHVzaChbeCwgb1t4XSA9PT0gJz8nID8gJz8nIDogZm9ybWF0RnVuY3Rpb24ob1t4XSldLmpvaW4oJz0nKSk7XG5cdFx0XHRcdH1cblx0XHRcdH19XG5cblx0XHRcdHJldHVybiBhLmpvaW4oJyYnKTtcblx0XHR9XG5cdH0sXG5cblx0Ly8gTG9jYWwgc3RvcmFnZSBmYWNhZGVcblx0c3RvcmU6IChmdW5jdGlvbigpIHtcblxuXHRcdHZhciBhID0gWydsb2NhbFN0b3JhZ2UnLCAnc2Vzc2lvblN0b3JhZ2UnXTtcblx0XHR2YXIgaSA9IC0xO1xuXHRcdHZhciBwcmVmaXggPSAndGVzdCc7XG5cblx0XHQvLyBTZXQgTG9jYWxTdG9yYWdlXG5cdFx0dmFyIGxvY2FsU3RvcmFnZTtcblxuXHRcdHdoaWxlIChhWysraV0pIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdC8vIEluIENocm9tZSB3aXRoIGNvb2tpZXMgYmxvY2tlZCwgY2FsbGluZyBsb2NhbFN0b3JhZ2UgdGhyb3dzIGFuIGVycm9yXG5cdFx0XHRcdGxvY2FsU3RvcmFnZSA9IHdpbmRvd1thW2ldXTtcblx0XHRcdFx0bG9jYWxTdG9yYWdlLnNldEl0ZW0ocHJlZml4ICsgaSwgaSk7XG5cdFx0XHRcdGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKHByZWZpeCArIGkpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdGNhdGNoIChlKSB7XG5cdFx0XHRcdGxvY2FsU3RvcmFnZSA9IG51bGw7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKCFsb2NhbFN0b3JhZ2UpIHtcblxuXHRcdFx0dmFyIGNhY2hlID0gbnVsbDtcblxuXHRcdFx0bG9jYWxTdG9yYWdlID0ge1xuXHRcdFx0XHRnZXRJdGVtOiBmdW5jdGlvbihwcm9wKSB7XG5cdFx0XHRcdFx0cHJvcCA9IHByb3AgKyAnPSc7XG5cdFx0XHRcdFx0dmFyIG0gPSBkb2N1bWVudC5jb29raWUuc3BsaXQoJzsnKTtcblx0XHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IG0ubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0XHRcdHZhciBfbSA9IG1baV0ucmVwbGFjZSgvKF5cXHMrfFxccyskKS8sICcnKTtcblx0XHRcdFx0XHRcdGlmIChfbSAmJiBfbS5pbmRleE9mKHByb3ApID09PSAwKSB7XG5cdFx0XHRcdFx0XHRcdHJldHVybiBfbS5zdWJzdHIocHJvcC5sZW5ndGgpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiBjYWNoZTtcblx0XHRcdFx0fSxcblxuXHRcdFx0XHRzZXRJdGVtOiBmdW5jdGlvbihwcm9wLCB2YWx1ZSkge1xuXHRcdFx0XHRcdGNhY2hlID0gdmFsdWU7XG5cdFx0XHRcdFx0ZG9jdW1lbnQuY29va2llID0gcHJvcCArICc9JyArIHZhbHVlO1xuXHRcdFx0XHR9XG5cdFx0XHR9O1xuXG5cdFx0XHQvLyBGaWxsIHRoZSBjYWNoZSB1cFxuXHRcdFx0Y2FjaGUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaGVsbG8nKTtcblx0XHR9XG5cblx0XHRmdW5jdGlvbiBnZXQoKSB7XG5cdFx0XHR2YXIganNvbiA9IHt9O1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0anNvbiA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2hlbGxvJykpIHx8IHt9O1xuXHRcdFx0fVxuXHRcdFx0Y2F0Y2ggKGUpIHt9XG5cblx0XHRcdHJldHVybiBqc29uO1xuXHRcdH1cblxuXHRcdGZ1bmN0aW9uIHNldChqc29uKSB7XG5cdFx0XHRsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaGVsbG8nLCBKU09OLnN0cmluZ2lmeShqc29uKSk7XG5cdFx0fVxuXG5cdFx0Ly8gQ2hlY2sgaWYgdGhlIGJyb3dzZXIgc3VwcG9ydCBsb2NhbCBzdG9yYWdlXG5cdFx0cmV0dXJuIGZ1bmN0aW9uKG5hbWUsIHZhbHVlLCBkYXlzKSB7XG5cblx0XHRcdC8vIExvY2FsIHN0b3JhZ2Vcblx0XHRcdHZhciBqc29uID0gZ2V0KCk7XG5cblx0XHRcdGlmIChuYW1lICYmIHZhbHVlID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0cmV0dXJuIGpzb25bbmFtZV0gfHwgbnVsbDtcblx0XHRcdH1cblx0XHRcdGVsc2UgaWYgKG5hbWUgJiYgdmFsdWUgPT09IG51bGwpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRkZWxldGUganNvbltuYW1lXTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjYXRjaCAoZSkge1xuXHRcdFx0XHRcdGpzb25bbmFtZV0gPSBudWxsO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRlbHNlIGlmIChuYW1lKSB7XG5cdFx0XHRcdGpzb25bbmFtZV0gPSB2YWx1ZTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4ganNvbjtcblx0XHRcdH1cblxuXHRcdFx0c2V0KGpzb24pO1xuXG5cdFx0XHRyZXR1cm4ganNvbiB8fCBudWxsO1xuXHRcdH07XG5cblx0fSkoKSxcblxuXHQvLyBDcmVhdGUgYW5kIEFwcGVuZCBuZXcgRE9NIGVsZW1lbnRzXG5cdC8vIEBwYXJhbSBub2RlIHN0cmluZ1xuXHQvLyBAcGFyYW0gYXR0ciBvYmplY3QgbGl0ZXJhbFxuXHQvLyBAcGFyYW0gZG9tL3N0cmluZ1xuXHRhcHBlbmQ6IGZ1bmN0aW9uKG5vZGUsIGF0dHIsIHRhcmdldCkge1xuXG5cdFx0dmFyIG4gPSB0eXBlb2YgKG5vZGUpID09PSAnc3RyaW5nJyA/IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQobm9kZSkgOiBub2RlO1xuXG5cdFx0aWYgKHR5cGVvZiAoYXR0cikgPT09ICdvYmplY3QnKSB7XG5cdFx0XHRpZiAoJ3RhZ05hbWUnIGluIGF0dHIpIHtcblx0XHRcdFx0dGFyZ2V0ID0gYXR0cjtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRmb3IgKHZhciB4IGluIGF0dHIpIHtpZiAoYXR0ci5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0XHRcdGlmICh0eXBlb2YgKGF0dHJbeF0pID09PSAnb2JqZWN0Jykge1xuXHRcdFx0XHRcdFx0Zm9yICh2YXIgeSBpbiBhdHRyW3hdKSB7aWYgKGF0dHJbeF0uaGFzT3duUHJvcGVydHkoeSkpIHtcblx0XHRcdFx0XHRcdFx0blt4XVt5XSA9IGF0dHJbeF1beV07XG5cdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRlbHNlIGlmICh4ID09PSAnaHRtbCcpIHtcblx0XHRcdFx0XHRcdG4uaW5uZXJIVE1MID0gYXR0clt4XTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBJRSBkb2Vzbid0IGxpa2UgdXMgc2V0dGluZyBtZXRob2RzIHdpdGggc2V0QXR0cmlidXRlXG5cdFx0XHRcdFx0ZWxzZSBpZiAoIS9eb24vLnRlc3QoeCkpIHtcblx0XHRcdFx0XHRcdG4uc2V0QXR0cmlidXRlKHgsIGF0dHJbeF0pO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRcdG5beF0gPSBhdHRyW3hdO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fX1cblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZiAodGFyZ2V0ID09PSAnYm9keScpIHtcblx0XHRcdChmdW5jdGlvbiBzZWxmKCkge1xuXHRcdFx0XHRpZiAoZG9jdW1lbnQuYm9keSkge1xuXHRcdFx0XHRcdGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobik7XG5cdFx0XHRcdH1cblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0c2V0VGltZW91dChzZWxmLCAxNik7XG5cdFx0XHRcdH1cblx0XHRcdH0pKCk7XG5cdFx0fVxuXHRcdGVsc2UgaWYgKHR5cGVvZiAodGFyZ2V0KSA9PT0gJ29iamVjdCcpIHtcblx0XHRcdHRhcmdldC5hcHBlbmRDaGlsZChuKTtcblx0XHR9XG5cdFx0ZWxzZSBpZiAodHlwZW9mICh0YXJnZXQpID09PSAnc3RyaW5nJykge1xuXHRcdFx0ZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUodGFyZ2V0KVswXS5hcHBlbmRDaGlsZChuKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbjtcblx0fSxcblxuXHQvLyBBbiBlYXN5IHdheSB0byBjcmVhdGUgYSBoaWRkZW4gaWZyYW1lXG5cdC8vIEBwYXJhbSBzdHJpbmcgc3JjXG5cdGlmcmFtZTogZnVuY3Rpb24oc3JjKSB7XG5cdFx0dGhpcy5hcHBlbmQoJ2lmcmFtZScsIHtzcmM6IHNyYywgc3R5bGU6IHtwb3NpdGlvbjonYWJzb2x1dGUnLCBsZWZ0OiAnLTEwMDBweCcsIGJvdHRvbTogMCwgaGVpZ2h0OiAnMXB4Jywgd2lkdGg6ICcxcHgnfX0sICdib2R5Jyk7XG5cdH0sXG5cblx0Ly8gUmVjdXJzaXZlIG1lcmdlIHR3byBvYmplY3RzIGludG8gb25lLCBzZWNvbmQgcGFyYW1ldGVyIG92ZXJpZGVzIHRoZSBmaXJzdFxuXHQvLyBAcGFyYW0gYSBhcnJheVxuXHRtZXJnZTogZnVuY3Rpb24oLyogQXJnczogYSwgYiwgYywgLi4gbiAqLykge1xuXHRcdHZhciBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKTtcblx0XHRhcmdzLnVuc2hpZnQoe30pO1xuXHRcdHJldHVybiB0aGlzLmV4dGVuZC5hcHBseShudWxsLCBhcmdzKTtcblx0fSxcblxuXHQvLyBNYWtlcyBpdCBlYXNpZXIgdG8gYXNzaWduIHBhcmFtZXRlcnMsIHdoZXJlIHNvbWUgYXJlIG9wdGlvbmFsXG5cdC8vIEBwYXJhbSBvIG9iamVjdFxuXHQvLyBAcGFyYW0gYSBhcmd1bWVudHNcblx0YXJnczogZnVuY3Rpb24obywgYXJncykge1xuXG5cdFx0dmFyIHAgPSB7fTtcblx0XHR2YXIgaSA9IDA7XG5cdFx0dmFyIHQgPSBudWxsO1xuXHRcdHZhciB4ID0gbnVsbDtcblxuXHRcdC8vICd4JyBpcyB0aGUgZmlyc3Qga2V5IGluIHRoZSBsaXN0IG9mIG9iamVjdCBwYXJhbWV0ZXJzXG5cdFx0Zm9yICh4IGluIG8pIHtpZiAoby5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0YnJlYWs7XG5cdFx0fX1cblxuXHRcdC8vIFBhc3NpbmcgaW4gaGFzaCBvYmplY3Qgb2YgYXJndW1lbnRzP1xuXHRcdC8vIFdoZXJlIHRoZSBmaXJzdCBhcmd1bWVudCBjYW4ndCBiZSBhbiBvYmplY3Rcblx0XHRpZiAoKGFyZ3MubGVuZ3RoID09PSAxKSAmJiAodHlwZW9mIChhcmdzWzBdKSA9PT0gJ29iamVjdCcpICYmIG9beF0gIT0gJ28hJykge1xuXG5cdFx0XHQvLyBDb3VsZCB0aGlzIG9iamVjdCBzdGlsbCBiZWxvbmcgdG8gYSBwcm9wZXJ0eT9cblx0XHRcdC8vIENoZWNrIHRoZSBvYmplY3Qga2V5cyBpZiB0aGV5IG1hdGNoIGFueSBvZiB0aGUgcHJvcGVydHkga2V5c1xuXHRcdFx0Zm9yICh4IGluIGFyZ3NbMF0pIHtpZiAoby5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0XHQvLyBEb2VzIHRoaXMga2V5IGV4aXN0IGluIHRoZSBwcm9wZXJ0eSBsaXN0P1xuXHRcdFx0XHRpZiAoeCBpbiBvKSB7XG5cdFx0XHRcdFx0Ly8gWWVzIHRoaXMga2V5IGRvZXMgZXhpc3Qgc28gaXRzIG1vc3QgbGlrZWx5IHRoaXMgZnVuY3Rpb24gaGFzIGJlZW4gaW52b2tlZCB3aXRoIGFuIG9iamVjdCBwYXJhbWV0ZXJcblx0XHRcdFx0XHQvLyBSZXR1cm4gZmlyc3QgYXJndW1lbnQgYXMgdGhlIGhhc2ggb2YgYWxsIGFyZ3VtZW50c1xuXHRcdFx0XHRcdHJldHVybiBhcmdzWzBdO1xuXHRcdFx0XHR9XG5cdFx0XHR9fVxuXHRcdH1cblxuXHRcdC8vIEVsc2UgbG9vcCB0aHJvdWdoIGFuZCBhY2NvdW50IGZvciB0aGUgbWlzc2luZyBvbmVzLlxuXHRcdGZvciAoeCBpbiBvKSB7aWYgKG8uaGFzT3duUHJvcGVydHkoeCkpIHtcblxuXHRcdFx0dCA9IHR5cGVvZiAoYXJnc1tpXSk7XG5cblx0XHRcdGlmICgodHlwZW9mIChvW3hdKSA9PT0gJ2Z1bmN0aW9uJyAmJiBvW3hdLnRlc3QoYXJnc1tpXSkpIHx8ICh0eXBlb2YgKG9beF0pID09PSAnc3RyaW5nJyAmJiAoXG5cdFx0XHQob1t4XS5pbmRleE9mKCdzJykgPiAtMSAmJiB0ID09PSAnc3RyaW5nJykgfHxcblx0XHRcdChvW3hdLmluZGV4T2YoJ28nKSA+IC0xICYmIHQgPT09ICdvYmplY3QnKSB8fFxuXHRcdFx0KG9beF0uaW5kZXhPZignaScpID4gLTEgJiYgdCA9PT0gJ251bWJlcicpIHx8XG5cdFx0XHQob1t4XS5pbmRleE9mKCdhJykgPiAtMSAmJiB0ID09PSAnb2JqZWN0JykgfHxcblx0XHRcdChvW3hdLmluZGV4T2YoJ2YnKSA+IC0xICYmIHQgPT09ICdmdW5jdGlvbicpXG5cdFx0XHQpKVxuXHRcdFx0KSB7XG5cdFx0XHRcdHBbeF0gPSBhcmdzW2krK107XG5cdFx0XHR9XG5cblx0XHRcdGVsc2UgaWYgKHR5cGVvZiAob1t4XSkgPT09ICdzdHJpbmcnICYmIG9beF0uaW5kZXhPZignIScpID4gLTEpIHtcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdH19XG5cblx0XHRyZXR1cm4gcDtcblx0fSxcblxuXHQvLyBSZXR1cm5zIGEgVVJMIGluc3RhbmNlXG5cdHVybDogZnVuY3Rpb24ocGF0aCkge1xuXG5cdFx0Ly8gSWYgdGhlIHBhdGggaXMgZW1wdHlcblx0XHRpZiAoIXBhdGgpIHtcblx0XHRcdHJldHVybiB3aW5kb3cubG9jYXRpb247XG5cdFx0fVxuXG5cdFx0Ly8gQ2hyb21lIGFuZCBGaXJlRm94IHN1cHBvcnQgbmV3IFVSTCgpIHRvIGV4dHJhY3QgVVJMIG9iamVjdHNcblx0XHRlbHNlIGlmICh3aW5kb3cuVVJMICYmIFVSTCBpbnN0YW5jZW9mIEZ1bmN0aW9uICYmIFVSTC5sZW5ndGggIT09IDApIHtcblx0XHRcdHJldHVybiBuZXcgVVJMKHBhdGgsIHdpbmRvdy5sb2NhdGlvbik7XG5cdFx0fVxuXG5cdFx0Ly8gVWdseSBzaGltLCBpdCB3b3JrcyFcblx0XHRlbHNlIHtcblx0XHRcdHZhciBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuXHRcdFx0YS5ocmVmID0gcGF0aDtcblx0XHRcdHJldHVybiBhLmNsb25lTm9kZShmYWxzZSk7XG5cdFx0fVxuXHR9LFxuXG5cdGRpZmY6IGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRyZXR1cm4gYi5maWx0ZXIoZnVuY3Rpb24oaXRlbSkge1xuXHRcdFx0cmV0dXJuIGEuaW5kZXhPZihpdGVtKSA9PT0gLTE7XG5cdFx0fSk7XG5cdH0sXG5cblx0Ly8gR2V0IHRoZSBkaWZmZXJlbnQgaGFzaCBvZiBwcm9wZXJ0aWVzIHVuaXF1ZSB0byBgYWAsIGFuZCBub3QgaW4gYGJgXG5cdGRpZmZLZXk6IGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRpZiAoYSB8fCAhYikge1xuXHRcdFx0dmFyIHIgPSB7fTtcblx0XHRcdGZvciAodmFyIHggaW4gYSkge1xuXHRcdFx0XHQvLyBEb2VzIHRoZSBwcm9wZXJ0eSBub3QgZXhpc3Q/XG5cdFx0XHRcdGlmICghKHggaW4gYikpIHtcblx0XHRcdFx0XHRyW3hdID0gYVt4XTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gcjtcblx0XHR9XG5cblx0XHRyZXR1cm4gYTtcblx0fSxcblxuXHQvLyBVbmlxdWVcblx0Ly8gUmVtb3ZlIGR1cGxpY2F0ZSBhbmQgbnVsbCB2YWx1ZXMgZnJvbSBhbiBhcnJheVxuXHQvLyBAcGFyYW0gYSBhcnJheVxuXHR1bmlxdWU6IGZ1bmN0aW9uKGEpIHtcblx0XHRpZiAoIUFycmF5LmlzQXJyYXkoYSkpIHsgcmV0dXJuIFtdOyB9XG5cblx0XHRyZXR1cm4gYS5maWx0ZXIoZnVuY3Rpb24oaXRlbSwgaW5kZXgpIHtcblx0XHRcdC8vIElzIHRoaXMgdGhlIGZpcnN0IGxvY2F0aW9uIG9mIGl0ZW1cblx0XHRcdHJldHVybiBhLmluZGV4T2YoaXRlbSkgPT09IGluZGV4O1xuXHRcdH0pO1xuXHR9LFxuXG5cdGlzRW1wdHk6IGZ1bmN0aW9uKG9iaikge1xuXG5cdFx0Ly8gU2NhbGFyXG5cdFx0aWYgKCFvYmopXG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblxuXHRcdC8vIEFycmF5XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkob2JqKSkge1xuXHRcdFx0cmV0dXJuICFvYmoubGVuZ3RoO1xuXHRcdH1cblx0XHRlbHNlIGlmICh0eXBlb2YgKG9iaikgPT09ICdvYmplY3QnKSB7XG5cdFx0XHQvLyBPYmplY3Rcblx0XHRcdGZvciAodmFyIGtleSBpbiBvYmopIHtcblx0XHRcdFx0aWYgKG9iai5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHRydWU7XG5cdH0sXG5cblx0Ly9qc2NzOmRpc2FibGVcblxuXHQvKiFcblx0ICoqICBUaGVuYWJsZSAtLSBFbWJlZGRhYmxlIE1pbmltdW0gU3RyaWN0bHktQ29tcGxpYW50IFByb21pc2VzL0ErIDEuMS4xIFRoZW5hYmxlXG5cdCAqKiAgQ29weXJpZ2h0IChjKSAyMDEzLTIwMTQgUmFsZiBTLiBFbmdlbHNjaGFsbCA8aHR0cDovL2VuZ2Vsc2NoYWxsLmNvbT5cblx0ICoqICBMaWNlbnNlZCB1bmRlciBUaGUgTUlUIExpY2Vuc2UgPGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQ+XG5cdCAqKiAgU291cmNlLUNvZGUgZGlzdHJpYnV0ZWQgb24gPGh0dHA6Ly9naXRodWIuY29tL3JzZS90aGVuYWJsZT5cblx0ICovXG5cdFByb21pc2U6IChmdW5jdGlvbigpe1xuXHRcdC8qICBwcm9taXNlIHN0YXRlcyBbUHJvbWlzZXMvQSsgMi4xXSAgKi9cblx0XHR2YXIgU1RBVEVfUEVORElORyAgID0gMDsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8qICBbUHJvbWlzZXMvQSsgMi4xLjFdICAqL1xuXHRcdHZhciBTVEFURV9GVUxGSUxMRUQgPSAxOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjEuMl0gICovXG5cdFx0dmFyIFNUQVRFX1JFSkVDVEVEICA9IDI7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMS4zXSAgKi9cblxuXHRcdC8qICBwcm9taXNlIG9iamVjdCBjb25zdHJ1Y3RvciAgKi9cblx0XHR2YXIgYXBpID0gZnVuY3Rpb24gKGV4ZWN1dG9yKSB7XG5cdFx0XHQvKiAgb3B0aW9uYWxseSBzdXBwb3J0IG5vbi1jb25zdHJ1Y3Rvci9wbGFpbi1mdW5jdGlvbiBjYWxsICAqL1xuXHRcdFx0aWYgKCEodGhpcyBpbnN0YW5jZW9mIGFwaSkpXG5cdFx0XHRcdHJldHVybiBuZXcgYXBpKGV4ZWN1dG9yKTtcblxuXHRcdFx0LyogIGluaXRpYWxpemUgb2JqZWN0ICAqL1xuXHRcdFx0dGhpcy5pZCAgICAgICAgICAgPSBcIlRoZW5hYmxlLzEuMC42XCI7XG5cdFx0XHR0aGlzLnN0YXRlICAgICAgICA9IFNUQVRFX1BFTkRJTkc7IC8qICBpbml0aWFsIHN0YXRlICAqL1xuXHRcdFx0dGhpcy5mdWxmaWxsVmFsdWUgPSB1bmRlZmluZWQ7ICAgICAvKiAgaW5pdGlhbCB2YWx1ZSAgKi8gICAgIC8qICBbUHJvbWlzZXMvQSsgMS4zLCAyLjEuMi4yXSAgKi9cblx0XHRcdHRoaXMucmVqZWN0UmVhc29uID0gdW5kZWZpbmVkOyAgICAgLyogIGluaXRpYWwgcmVhc29uICovICAgICAvKiAgW1Byb21pc2VzL0ErIDEuNSwgMi4xLjMuMl0gICovXG5cdFx0XHR0aGlzLm9uRnVsZmlsbGVkICA9IFtdOyAgICAgICAgICAgIC8qICBpbml0aWFsIGhhbmRsZXJzICAqL1xuXHRcdFx0dGhpcy5vblJlamVjdGVkICAgPSBbXTsgICAgICAgICAgICAvKiAgaW5pdGlhbCBoYW5kbGVycyAgKi9cblxuXHRcdFx0LyogIHByb3ZpZGUgb3B0aW9uYWwgaW5mb3JtYXRpb24taGlkaW5nIHByb3h5ICAqL1xuXHRcdFx0dGhpcy5wcm94eSA9IHtcblx0XHRcdFx0dGhlbjogdGhpcy50aGVuLmJpbmQodGhpcylcblx0XHRcdH07XG5cblx0XHRcdC8qICBzdXBwb3J0IG9wdGlvbmFsIGV4ZWN1dG9yIGZ1bmN0aW9uICAqL1xuXHRcdFx0aWYgKHR5cGVvZiBleGVjdXRvciA9PT0gXCJmdW5jdGlvblwiKVxuXHRcdFx0XHRleGVjdXRvci5jYWxsKHRoaXMsIHRoaXMuZnVsZmlsbC5iaW5kKHRoaXMpLCB0aGlzLnJlamVjdC5iaW5kKHRoaXMpKTtcblx0XHR9O1xuXG5cdFx0LyogIHByb21pc2UgQVBJIG1ldGhvZHMgICovXG5cdFx0YXBpLnByb3RvdHlwZSA9IHtcblx0XHRcdC8qICBwcm9taXNlIHJlc29sdmluZyBtZXRob2RzICAqL1xuXHRcdFx0ZnVsZmlsbDogZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiBkZWxpdmVyKHRoaXMsIFNUQVRFX0ZVTEZJTExFRCwgXCJmdWxmaWxsVmFsdWVcIiwgdmFsdWUpOyB9LFxuXHRcdFx0cmVqZWN0OiAgZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiBkZWxpdmVyKHRoaXMsIFNUQVRFX1JFSkVDVEVELCAgXCJyZWplY3RSZWFzb25cIiwgdmFsdWUpOyB9LFxuXG5cdFx0XHQvKiAgXCJUaGUgdGhlbiBNZXRob2RcIiBbUHJvbWlzZXMvQSsgMS4xLCAxLjIsIDIuMl0gICovXG5cdFx0XHR0aGVuOiBmdW5jdGlvbiAob25GdWxmaWxsZWQsIG9uUmVqZWN0ZWQpIHtcblx0XHRcdFx0dmFyIGN1cnIgPSB0aGlzO1xuXHRcdFx0XHR2YXIgbmV4dCA9IG5ldyBhcGkoKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi43XSAgKi9cblx0XHRcdFx0Y3Vyci5vbkZ1bGZpbGxlZC5wdXNoKFxuXHRcdFx0XHRcdHJlc29sdmVyKG9uRnVsZmlsbGVkLCBuZXh0LCBcImZ1bGZpbGxcIikpOyAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi4yLzIuMi42XSAgKi9cblx0XHRcdFx0Y3Vyci5vblJlamVjdGVkLnB1c2goXG5cdFx0XHRcdFx0cmVzb2x2ZXIob25SZWplY3RlZCwgIG5leHQsIFwicmVqZWN0XCIgKSk7ICAgICAgICAgICAgIC8qICBbUHJvbWlzZXMvQSsgMi4yLjMvMi4yLjZdICAqL1xuXHRcdFx0XHRleGVjdXRlKGN1cnIpO1xuXHRcdFx0XHRyZXR1cm4gbmV4dC5wcm94eTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi43LCAzLjNdICAqL1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHQvKiAgZGVsaXZlciBhbiBhY3Rpb24gICovXG5cdFx0dmFyIGRlbGl2ZXIgPSBmdW5jdGlvbiAoY3Vyciwgc3RhdGUsIG5hbWUsIHZhbHVlKSB7XG5cdFx0XHRpZiAoY3Vyci5zdGF0ZSA9PT0gU1RBVEVfUEVORElORykge1xuXHRcdFx0XHRjdXJyLnN0YXRlID0gc3RhdGU7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMS4yLjEsIDIuMS4zLjFdICAqL1xuXHRcdFx0XHRjdXJyW25hbWVdID0gdmFsdWU7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMS4yLjIsIDIuMS4zLjJdICAqL1xuXHRcdFx0XHRleGVjdXRlKGN1cnIpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGN1cnI7XG5cdFx0fTtcblxuXHRcdC8qICBleGVjdXRlIGFsbCBoYW5kbGVycyAgKi9cblx0XHR2YXIgZXhlY3V0ZSA9IGZ1bmN0aW9uIChjdXJyKSB7XG5cdFx0XHRpZiAoY3Vyci5zdGF0ZSA9PT0gU1RBVEVfRlVMRklMTEVEKVxuXHRcdFx0XHRleGVjdXRlX2hhbmRsZXJzKGN1cnIsIFwib25GdWxmaWxsZWRcIiwgY3Vyci5mdWxmaWxsVmFsdWUpO1xuXHRcdFx0ZWxzZSBpZiAoY3Vyci5zdGF0ZSA9PT0gU1RBVEVfUkVKRUNURUQpXG5cdFx0XHRcdGV4ZWN1dGVfaGFuZGxlcnMoY3VyciwgXCJvblJlamVjdGVkXCIsICBjdXJyLnJlamVjdFJlYXNvbik7XG5cdFx0fTtcblxuXHRcdC8qICBleGVjdXRlIHBhcnRpY3VsYXIgc2V0IG9mIGhhbmRsZXJzICAqL1xuXHRcdHZhciBleGVjdXRlX2hhbmRsZXJzID0gZnVuY3Rpb24gKGN1cnIsIG5hbWUsIHZhbHVlKSB7XG5cdFx0XHQvKiBnbG9iYWwgcHJvY2VzczogdHJ1ZSAqL1xuXHRcdFx0LyogZ2xvYmFsIHNldEltbWVkaWF0ZTogdHJ1ZSAqL1xuXHRcdFx0LyogZ2xvYmFsIHNldFRpbWVvdXQ6IHRydWUgKi9cblxuXHRcdFx0LyogIHNob3J0LWNpcmN1aXQgcHJvY2Vzc2luZyAgKi9cblx0XHRcdGlmIChjdXJyW25hbWVdLmxlbmd0aCA9PT0gMClcblx0XHRcdFx0cmV0dXJuO1xuXG5cdFx0XHQvKiAgaXRlcmF0ZSBvdmVyIGFsbCBoYW5kbGVycywgZXhhY3RseSBvbmNlICAqL1xuXHRcdFx0dmFyIGhhbmRsZXJzID0gY3VycltuYW1lXTtcblx0XHRcdGN1cnJbbmFtZV0gPSBbXTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi4yLjMsIDIuMi4zLjNdICAqL1xuXHRcdFx0dmFyIGZ1bmMgPSBmdW5jdGlvbiAoKSB7XG5cdFx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgaGFuZGxlcnMubGVuZ3RoOyBpKyspXG5cdFx0XHRcdFx0aGFuZGxlcnNbaV0odmFsdWUpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi41XSAgKi9cblx0XHRcdH07XG5cblx0XHRcdC8qICBleGVjdXRlIHByb2NlZHVyZSBhc3luY2hyb25vdXNseSAgKi8gICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi40LCAzLjFdICAqL1xuXHRcdFx0aWYgKHR5cGVvZiBwcm9jZXNzID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBwcm9jZXNzLm5leHRUaWNrID09PSBcImZ1bmN0aW9uXCIpXG5cdFx0XHRcdHByb2Nlc3MubmV4dFRpY2soZnVuYyk7XG5cdFx0XHRlbHNlIGlmICh0eXBlb2Ygc2V0SW1tZWRpYXRlID09PSBcImZ1bmN0aW9uXCIpXG5cdFx0XHRcdHNldEltbWVkaWF0ZShmdW5jKTtcblx0XHRcdGVsc2Vcblx0XHRcdFx0c2V0VGltZW91dChmdW5jLCAwKTtcblx0XHR9O1xuXG5cdFx0LyogIGdlbmVyYXRlIGEgcmVzb2x2ZXIgZnVuY3Rpb24gICovXG5cdFx0dmFyIHJlc29sdmVyID0gZnVuY3Rpb24gKGNiLCBuZXh0LCBtZXRob2QpIHtcblx0XHRcdHJldHVybiBmdW5jdGlvbiAodmFsdWUpIHtcblx0XHRcdFx0aWYgKHR5cGVvZiBjYiAhPT0gXCJmdW5jdGlvblwiKSAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi4xLCAyLjIuNy4zLCAyLjIuNy40XSAgKi9cblx0XHRcdFx0XHRuZXh0W21ldGhvZF0uY2FsbChuZXh0LCB2YWx1ZSk7ICAgICAgICAgICAgICAgICAgICAgIC8qICBbUHJvbWlzZXMvQSsgMi4yLjcuMywgMi4yLjcuNF0gICovXG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdHZhciByZXN1bHQ7XG5cdFx0XHRcdFx0dHJ5IHsgcmVzdWx0ID0gY2IodmFsdWUpOyB9ICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi4yLjEsIDIuMi4zLjEsIDIuMi41LCAzLjJdICAqL1xuXHRcdFx0XHRcdGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRuZXh0LnJlamVjdChlKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjIuNy4yXSAgKi9cblx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0cmVzb2x2ZShuZXh0LCByZXN1bHQpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMi43LjFdICAqL1xuXHRcdFx0XHR9XG5cdFx0XHR9O1xuXHRcdH07XG5cblx0XHQvKiAgXCJQcm9taXNlIFJlc29sdXRpb24gUHJvY2VkdXJlXCIgICovICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjNdICAqL1xuXHRcdHZhciByZXNvbHZlID0gZnVuY3Rpb24gKHByb21pc2UsIHgpIHtcblx0XHRcdC8qICBzYW5pdHkgY2hlY2sgYXJndW1lbnRzICAqLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMy4xXSAgKi9cblx0XHRcdGlmIChwcm9taXNlID09PSB4IHx8IHByb21pc2UucHJveHkgPT09IHgpIHtcblx0XHRcdFx0cHJvbWlzZS5yZWplY3QobmV3IFR5cGVFcnJvcihcImNhbm5vdCByZXNvbHZlIHByb21pc2Ugd2l0aCBpdHNlbGZcIikpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdC8qICBzdXJnaWNhbGx5IGNoZWNrIGZvciBhIFwidGhlblwiIG1ldGhvZFxuXHRcdFx0XHQobWFpbmx5IHRvIGp1c3QgY2FsbCB0aGUgXCJnZXR0ZXJcIiBvZiBcInRoZW5cIiBvbmx5IG9uY2UpICAqL1xuXHRcdFx0dmFyIHRoZW47XG5cdFx0XHRpZiAoKHR5cGVvZiB4ID09PSBcIm9iamVjdFwiICYmIHggIT09IG51bGwpIHx8IHR5cGVvZiB4ID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0dHJ5IHsgdGhlbiA9IHgudGhlbjsgfSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4xLCAzLjVdICAqL1xuXHRcdFx0XHRjYXRjaCAoZSkge1xuXHRcdFx0XHRcdHByb21pc2UucmVqZWN0KGUpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4yXSAgKi9cblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0LyogIGhhbmRsZSBvd24gVGhlbmFibGVzICAgIFtQcm9taXNlcy9BKyAyLjMuMl1cblx0XHRcdFx0YW5kIHNpbWlsYXIgXCJ0aGVuYWJsZXNcIiBbUHJvbWlzZXMvQSsgMi4zLjNdICAqL1xuXHRcdFx0aWYgKHR5cGVvZiB0aGVuID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0dmFyIHJlc29sdmVkID0gZmFsc2U7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0LyogIGNhbGwgcmV0cmlldmVkIFwidGhlblwiIG1ldGhvZCAqLyAgICAgICAgICAgICAgICAgIC8qICBbUHJvbWlzZXMvQSsgMi4zLjMuM10gICovXG5cdFx0XHRcdFx0dGhlbi5jYWxsKHgsXG5cdFx0XHRcdFx0XHQvKiAgcmVzb2x2ZVByb21pc2UgICovICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4zLjFdICAqL1xuXHRcdFx0XHRcdFx0ZnVuY3Rpb24gKHkpIHtcblx0XHRcdFx0XHRcdFx0aWYgKHJlc29sdmVkKSByZXR1cm47IHJlc29sdmVkID0gdHJ1ZTsgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4zLjNdICAqL1xuXHRcdFx0XHRcdFx0XHRpZiAoeSA9PT0geCkgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDMuNl0gICovXG5cdFx0XHRcdFx0XHRcdFx0cHJvbWlzZS5yZWplY3QobmV3IFR5cGVFcnJvcihcImNpcmN1bGFyIHRoZW5hYmxlIGNoYWluXCIpKTtcblx0XHRcdFx0XHRcdFx0ZWxzZVxuXHRcdFx0XHRcdFx0XHRcdHJlc29sdmUocHJvbWlzZSwgeSk7XG5cdFx0XHRcdFx0XHR9LFxuXG5cdFx0XHRcdFx0XHQvKiAgcmVqZWN0UHJvbWlzZSAgKi8gICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4zLjJdICAqL1xuXHRcdFx0XHRcdFx0ZnVuY3Rpb24gKHIpIHtcblx0XHRcdFx0XHRcdFx0aWYgKHJlc29sdmVkKSByZXR1cm47IHJlc29sdmVkID0gdHJ1ZTsgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4zLjNdICAqL1xuXHRcdFx0XHRcdFx0XHRwcm9taXNlLnJlamVjdChyKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHQpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0aWYgKCFyZXNvbHZlZCkgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKiAgW1Byb21pc2VzL0ErIDIuMy4zLjMuM10gICovXG5cdFx0XHRcdFx0XHRwcm9taXNlLnJlamVjdChlKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuMy4zLjRdICAqL1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0LyogIGhhbmRsZSBvdGhlciB2YWx1ZXMgICovXG5cdFx0XHRwcm9taXNlLmZ1bGZpbGwoeCk7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLyogIFtQcm9taXNlcy9BKyAyLjMuNCwgMi4zLjMuNF0gICovXG5cdFx0fTtcblxuXHRcdC8qICBleHBvcnQgQVBJICAqL1xuXHRcdHJldHVybiBhcGk7XG5cdH0pKCksXG5cblx0Ly9qc2NzOmVuYWJsZVxuXG5cdC8vIEV2ZW50XG5cdC8vIEEgY29udHJ1Y3RvciBzdXBlcmNsYXNzIGZvciBhZGRpbmcgZXZlbnQgbWVudGhvZHMsIG9uLCBvZmYsIGVtaXQuXG5cdEV2ZW50OiBmdW5jdGlvbigpIHtcblxuXHRcdHZhciBzZXBhcmF0b3IgPSAvW1xcc1xcLF0rLztcblxuXHRcdC8vIElmIHRoaXMgZG9lc24ndCBzdXBwb3J0IGdldFByb3RvdHlwZSB0aGVuIHdlIGNhbid0IGdldCBwcm90b3R5cGUuZXZlbnRzIG9mIHRoZSBwYXJlbnRcblx0XHQvLyBTbyBsZXRzIGdldCB0aGUgY3VycmVudCBpbnN0YW5jZSBldmVudHMsIGFuZCBhZGQgdGhvc2UgdG8gYSBwYXJlbnQgcHJvcGVydHlcblx0XHR0aGlzLnBhcmVudCA9IHtcblx0XHRcdGV2ZW50czogdGhpcy5ldmVudHMsXG5cdFx0XHRmaW5kRXZlbnRzOiB0aGlzLmZpbmRFdmVudHMsXG5cdFx0XHRwYXJlbnQ6IHRoaXMucGFyZW50LFxuXHRcdFx0dXRpbHM6IHRoaXMudXRpbHNcblx0XHR9O1xuXG5cdFx0dGhpcy5ldmVudHMgPSB7fTtcblxuXHRcdC8vIE9uLCBzdWJzY3JpYmUgdG8gZXZlbnRzXG5cdFx0Ly8gQHBhcmFtIGV2dCAgIHN0cmluZ1xuXHRcdC8vIEBwYXJhbSBjYWxsYmFjayAgZnVuY3Rpb25cblx0XHR0aGlzLm9uID0gZnVuY3Rpb24oZXZ0LCBjYWxsYmFjaykge1xuXG5cdFx0XHRpZiAoY2FsbGJhY2sgJiYgdHlwZW9mIChjYWxsYmFjaykgPT09ICdmdW5jdGlvbicpIHtcblx0XHRcdFx0dmFyIGEgPSBldnQuc3BsaXQoc2VwYXJhdG9yKTtcblx0XHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBhLmxlbmd0aDsgaSsrKSB7XG5cblx0XHRcdFx0XHQvLyBIYXMgdGhpcyBldmVudCBhbHJlYWR5IGJlZW4gZmlyZWQgb24gdGhpcyBpbnN0YW5jZT9cblx0XHRcdFx0XHR0aGlzLmV2ZW50c1thW2ldXSA9IFtjYWxsYmFja10uY29uY2F0KHRoaXMuZXZlbnRzW2FbaV1dIHx8IFtdKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXG5cdFx0Ly8gT2ZmLCB1bnN1YnNjcmliZSB0byBldmVudHNcblx0XHQvLyBAcGFyYW0gZXZ0ICAgc3RyaW5nXG5cdFx0Ly8gQHBhcmFtIGNhbGxiYWNrICBmdW5jdGlvblxuXHRcdHRoaXMub2ZmID0gZnVuY3Rpb24oZXZ0LCBjYWxsYmFjaykge1xuXG5cdFx0XHR0aGlzLmZpbmRFdmVudHMoZXZ0LCBmdW5jdGlvbihuYW1lLCBpbmRleCkge1xuXHRcdFx0XHRpZiAoIWNhbGxiYWNrIHx8IHRoaXMuZXZlbnRzW25hbWVdW2luZGV4XSA9PT0gY2FsbGJhY2spIHtcblx0XHRcdFx0XHR0aGlzLmV2ZW50c1tuYW1lXVtpbmRleF0gPSBudWxsO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblxuXHRcdFx0cmV0dXJuIHRoaXM7XG5cdFx0fTtcblxuXHRcdC8vIEVtaXRcblx0XHQvLyBUcmlnZ2VycyBhbnkgc3Vic2NyaWJlZCBldmVudHNcblx0XHR0aGlzLmVtaXQgPSBmdW5jdGlvbihldnQgLyosIGRhdGEsIC4uLiAqLykge1xuXG5cdFx0XHQvLyBHZXQgYXJndW1lbnRzIGFzIGFuIEFycmF5LCBrbm9jayBvZmYgdGhlIGZpcnN0IG9uZVxuXHRcdFx0dmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpO1xuXHRcdFx0YXJncy5wdXNoKGV2dCk7XG5cblx0XHRcdC8vIEhhbmRsZXJcblx0XHRcdHZhciBoYW5kbGVyID0gZnVuY3Rpb24obmFtZSwgaW5kZXgpIHtcblxuXHRcdFx0XHQvLyBSZXBsYWNlIHRoZSBsYXN0IHByb3BlcnR5IHdpdGggdGhlIGV2ZW50IG5hbWVcblx0XHRcdFx0YXJnc1thcmdzLmxlbmd0aCAtIDFdID0gKG5hbWUgPT09ICcqJyA/IGV2dCA6IG5hbWUpO1xuXG5cdFx0XHRcdC8vIFRyaWdnZXJcblx0XHRcdFx0dGhpcy5ldmVudHNbbmFtZV1baW5kZXhdLmFwcGx5KHRoaXMsIGFyZ3MpO1xuXHRcdFx0fTtcblxuXHRcdFx0Ly8gRmluZCB0aGUgY2FsbGJhY2tzIHdoaWNoIG1hdGNoIHRoZSBjb25kaXRpb24gYW5kIGNhbGxcblx0XHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0XHR3aGlsZSAoX3RoaXMgJiYgX3RoaXMuZmluZEV2ZW50cykge1xuXG5cdFx0XHRcdC8vIEZpbmQgZXZlbnRzIHdoaWNoIG1hdGNoXG5cdFx0XHRcdF90aGlzLmZpbmRFdmVudHMoZXZ0ICsgJywqJywgaGFuZGxlcik7XG5cdFx0XHRcdF90aGlzID0gX3RoaXMucGFyZW50O1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXG5cdFx0Ly9cblx0XHQvLyBFYXN5IGZ1bmN0aW9uc1xuXHRcdHRoaXMuZW1pdEFmdGVyID0gZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgX3RoaXMgPSB0aGlzO1xuXHRcdFx0dmFyIGFyZ3MgPSBhcmd1bWVudHM7XG5cdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRfdGhpcy5lbWl0LmFwcGx5KF90aGlzLCBhcmdzKTtcblx0XHRcdH0sIDApO1xuXG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXG5cdFx0dGhpcy5maW5kRXZlbnRzID0gZnVuY3Rpb24oZXZ0LCBjYWxsYmFjaykge1xuXG5cdFx0XHR2YXIgYSA9IGV2dC5zcGxpdChzZXBhcmF0b3IpO1xuXG5cdFx0XHRmb3IgKHZhciBuYW1lIGluIHRoaXMuZXZlbnRzKSB7aWYgKHRoaXMuZXZlbnRzLmhhc093blByb3BlcnR5KG5hbWUpKSB7XG5cblx0XHRcdFx0aWYgKGEuaW5kZXhPZihuYW1lKSA+IC0xKSB7XG5cblx0XHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuZXZlbnRzW25hbWVdLmxlbmd0aDsgaSsrKSB7XG5cblx0XHRcdFx0XHRcdC8vIERvZXMgdGhlIGV2ZW50IGhhbmRsZXIgZXhpc3Q/XG5cdFx0XHRcdFx0XHRpZiAodGhpcy5ldmVudHNbbmFtZV1baV0pIHtcblx0XHRcdFx0XHRcdFx0Ly8gRW1pdCBvbiB0aGUgbG9jYWwgaW5zdGFuY2Ugb2YgdGhpc1xuXHRcdFx0XHRcdFx0XHRjYWxsYmFjay5jYWxsKHRoaXMsIG5hbWUsIGkpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fX1cblx0XHR9O1xuXG5cdFx0cmV0dXJuIHRoaXM7XG5cdH0sXG5cblx0Ly8gR2xvYmFsIEV2ZW50c1xuXHQvLyBBdHRhY2ggdGhlIGNhbGxiYWNrIHRvIHRoZSB3aW5kb3cgb2JqZWN0XG5cdC8vIFJldHVybiBpdHMgdW5pcXVlIHJlZmVyZW5jZVxuXHRnbG9iYWxFdmVudDogZnVuY3Rpb24oY2FsbGJhY2ssIGd1aWQpIHtcblx0XHQvLyBJZiB0aGUgZ3VpZCBoYXMgbm90IGJlZW4gc3VwcGxpZWQgdGhlbiBjcmVhdGUgYSBuZXcgb25lLlxuXHRcdGd1aWQgPSBndWlkIHx8ICdfaGVsbG9qc18nICsgcGFyc2VJbnQoTWF0aC5yYW5kb20oKSAqIDFlMTIsIDEwKS50b1N0cmluZygzNik7XG5cblx0XHQvLyBEZWZpbmUgdGhlIGNhbGxiYWNrIGZ1bmN0aW9uXG5cdFx0d2luZG93W2d1aWRdID0gZnVuY3Rpb24oKSB7XG5cdFx0XHQvLyBUcmlnZ2VyIHRoZSBjYWxsYmFja1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0aWYgKGNhbGxiYWNrLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykpIHtcblx0XHRcdFx0XHRkZWxldGUgd2luZG93W2d1aWRdO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRjYXRjaCAoZSkge1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKGUpO1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHRyZXR1cm4gZ3VpZDtcblx0fSxcblxuXHQvLyBUcmlnZ2VyIGEgY2xpZW50c2lkZSBwb3B1cFxuXHQvLyBUaGlzIGhhcyBiZWVuIGF1Z21lbnRlZCB0byBzdXBwb3J0IFBob25lR2FwXG5cdHBvcHVwOiBmdW5jdGlvbih1cmwsIHJlZGlyZWN0VXJpLCBvcHRpb25zKSB7XG5cblx0XHR2YXIgZG9jdW1lbnRFbGVtZW50ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50O1xuXG5cdFx0Ly8gTXVsdGkgU2NyZWVuIFBvcHVwIFBvc2l0aW9uaW5nIChodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8xNjg2MTA1MClcblx0XHQvLyBDcmVkaXQ6IGh0dHA6Ly93d3cueHRmLmRrLzIwMTEvMDgvY2VudGVyLW5ldy1wb3B1cC13aW5kb3ctZXZlbi1vbi5odG1sXG5cdFx0Ly8gRml4ZXMgZHVhbC1zY3JlZW4gcG9zaXRpb24gICAgICAgICAgICAgICAgICAgICAgICAgTW9zdCBicm93c2VycyAgICAgIEZpcmVmb3hcblxuXHRcdGlmIChvcHRpb25zLmhlaWdodCAmJiBvcHRpb25zLnRvcCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHR2YXIgZHVhbFNjcmVlblRvcCA9IHdpbmRvdy5zY3JlZW5Ub3AgIT09IHVuZGVmaW5lZCA/IHdpbmRvdy5zY3JlZW5Ub3AgOiBzY3JlZW4udG9wO1xuXHRcdFx0dmFyIGhlaWdodCA9IHNjcmVlbi5oZWlnaHQgfHwgd2luZG93LmlubmVySGVpZ2h0IHx8IGRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQ7XG5cdFx0XHRvcHRpb25zLnRvcCA9IHBhcnNlSW50KChoZWlnaHQgLSBvcHRpb25zLmhlaWdodCkgLyAyLCAxMCkgKyBkdWFsU2NyZWVuVG9wO1xuXHRcdH1cblxuXHRcdGlmIChvcHRpb25zLndpZHRoICYmIG9wdGlvbnMubGVmdCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHR2YXIgZHVhbFNjcmVlbkxlZnQgPSB3aW5kb3cuc2NyZWVuTGVmdCAhPT0gdW5kZWZpbmVkID8gd2luZG93LnNjcmVlbkxlZnQgOiBzY3JlZW4ubGVmdDtcblx0XHRcdHZhciB3aWR0aCA9IHNjcmVlbi53aWR0aCB8fCB3aW5kb3cuaW5uZXJXaWR0aCB8fCBkb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG5cdFx0XHRvcHRpb25zLmxlZnQgPSBwYXJzZUludCgod2lkdGggLSBvcHRpb25zLndpZHRoKSAvIDIsIDEwKSArIGR1YWxTY3JlZW5MZWZ0O1xuXHRcdH1cblxuXHRcdC8vIENvbnZlcnQgb3B0aW9ucyBpbnRvIGFuIGFycmF5XG5cdFx0dmFyIG9wdGlvbnNBcnJheSA9IFtdO1xuXHRcdE9iamVjdC5rZXlzKG9wdGlvbnMpLmZvckVhY2goZnVuY3Rpb24obmFtZSkge1xuXHRcdFx0dmFyIHZhbHVlID0gb3B0aW9uc1tuYW1lXTtcblx0XHRcdG9wdGlvbnNBcnJheS5wdXNoKG5hbWUgKyAodmFsdWUgIT09IG51bGwgPyAnPScgKyB2YWx1ZSA6ICcnKSk7XG5cdFx0fSk7XG5cblx0XHQvLyBDYWxsIHRoZSBvcGVuKCkgZnVuY3Rpb24gd2l0aCB0aGUgaW5pdGlhbCBwYXRoXG5cdFx0Ly9cblx0XHQvLyBPQXV0aCByZWRpcmVjdCwgZml4ZXMgVVJJIGZyYWdtZW50cyBmcm9tIGJlaW5nIGxvc3QgaW4gU2FmYXJpXG5cdFx0Ly8gKFVSSSBGcmFnbWVudHMgd2l0aGluIDMwMiBMb2NhdGlvbiBVUkkgYXJlIGxvc3Qgb3ZlciBIVFRQUylcblx0XHQvLyBMb2FkaW5nIHRoZSByZWRpcmVjdC5odG1sIGJlZm9yZSB0cmlnZ2VyaW5nIHRoZSBPQXV0aCBGbG93IHNlZW1zIHRvIGZpeCBpdC5cblx0XHQvL1xuXHRcdC8vIEZpcmVmb3ggIGRlY29kZXMgVVJMIGZyYWdtZW50cyB3aGVuIGNhbGxpbmcgbG9jYXRpb24uaGFzaC5cblx0XHQvLyAgLSBUaGlzIGlzIGJhZCBpZiB0aGUgdmFsdWUgY29udGFpbnMgYnJlYWsgcG9pbnRzIHdoaWNoIGFyZSBlc2NhcGVkXG5cdFx0Ly8gIC0gSGVuY2UgdGhlIHVybCBtdXN0IGJlIGVuY29kZWQgdHdpY2UgYXMgaXQgY29udGFpbnMgYnJlYWtwb2ludHMuXG5cdFx0aWYgKG5hdmlnYXRvci51c2VyQWdlbnQuaW5kZXhPZignU2FmYXJpJykgIT09IC0xICYmIG5hdmlnYXRvci51c2VyQWdlbnQuaW5kZXhPZignQ2hyb21lJykgPT09IC0xKSB7XG5cdFx0XHR1cmwgPSByZWRpcmVjdFVyaSArICcjb2F1dGhfcmVkaXJlY3Q9JyArIGVuY29kZVVSSUNvbXBvbmVudChlbmNvZGVVUklDb21wb25lbnQodXJsKSk7XG5cdFx0fVxuXG5cdFx0dmFyIHBvcHVwID0gd2luZG93Lm9wZW4oXG5cdFx0XHR1cmwsXG5cdFx0XHQnX2JsYW5rJyxcblx0XHRcdG9wdGlvbnNBcnJheS5qb2luKCcsJylcblx0XHQpO1xuXG5cdFx0aWYgKHBvcHVwICYmIHBvcHVwLmZvY3VzKSB7XG5cdFx0XHRwb3B1cC5mb2N1cygpO1xuXHRcdH1cblxuXHRcdHJldHVybiBwb3B1cDtcblx0fSxcblxuXHQvLyBPQXV0aCBhbmQgQVBJIHJlc3BvbnNlIGhhbmRsZXJcblx0cmVzcG9uc2VIYW5kbGVyOiBmdW5jdGlvbih3aW5kb3csIHBhcmVudCkge1xuXG5cdFx0dmFyIF90aGlzID0gdGhpcztcblx0XHR2YXIgcDtcblx0XHR2YXIgbG9jYXRpb24gPSB3aW5kb3cubG9jYXRpb247XG5cblx0XHQvLyBJcyB0aGlzIGFuIGF1dGggcmVsYXkgbWVzc2FnZSB3aGljaCBuZWVkcyB0byBjYWxsIHRoZSBwcm94eT9cblx0XHRwID0gX3RoaXMucGFyYW0obG9jYXRpb24uc2VhcmNoKTtcblxuXHRcdC8vIE9BdXRoMiBvciBPQXV0aDEgc2VydmVyIHJlc3BvbnNlP1xuXHRcdGlmIChwICYmIHAuc3RhdGUgJiYgKHAuY29kZSB8fCBwLm9hdXRoX3Rva2VuKSkge1xuXG5cdFx0XHR2YXIgc3RhdGUgPSBKU09OLnBhcnNlKHAuc3RhdGUpO1xuXG5cdFx0XHQvLyBBZGQgdGhpcyBwYXRoIGFzIHRoZSByZWRpcmVjdF91cmlcblx0XHRcdHAucmVkaXJlY3RfdXJpID0gc3RhdGUucmVkaXJlY3RfdXJpIHx8IGxvY2F0aW9uLmhyZWYucmVwbGFjZSgvW1xcP1xcI10uKiQvLCAnJyk7XG5cblx0XHRcdC8vIFJlZGlyZWN0IHRvIHRoZSBob3N0XG5cdFx0XHR2YXIgcGF0aCA9IF90aGlzLnFzKHN0YXRlLm9hdXRoX3Byb3h5LCBwKTtcblxuXHRcdFx0bG9jYXRpb24uYXNzaWduKHBhdGgpO1xuXG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Ly8gU2F2ZSBzZXNzaW9uLCBmcm9tIHJlZGlyZWN0ZWQgYXV0aGVudGljYXRpb25cblx0XHQvLyAjYWNjZXNzX3Rva2VuIGhhcyBjb21lIGluP1xuXHRcdC8vXG5cdFx0Ly8gRkFDRUJPT0sgaXMgcmV0dXJuaW5nIGF1dGggZXJyb3JzIHdpdGhpbiBhcyBhIHF1ZXJ5X3N0cmluZy4uLiB0aGF0cyBhIHN0aWNrbGVyIGZvciBjb25zaXN0ZW5jeS5cblx0XHQvLyBTb3VuZENsb3VkIGlzIHRoZSBzdGF0ZSBpbiB0aGUgcXVlcnlzdHJpbmcgYW5kIHRoZSB0b2tlbiBpbiB0aGUgaGFzaHRhZywgc28gd2UnbGwgbWl4IHRoZSB0d28gdG9nZXRoZXJcblxuXHRcdHAgPSBfdGhpcy5tZXJnZShfdGhpcy5wYXJhbShsb2NhdGlvbi5zZWFyY2ggfHwgJycpLCBfdGhpcy5wYXJhbShsb2NhdGlvbi5oYXNoIHx8ICcnKSk7XG5cblx0XHQvLyBJZiBwLnN0YXRlXG5cdFx0aWYgKHAgJiYgJ3N0YXRlJyBpbiBwKSB7XG5cblx0XHRcdC8vIFJlbW92ZSBhbnkgYWRkaXRpb24gaW5mb3JtYXRpb25cblx0XHRcdC8vIEUuZy4gcC5zdGF0ZSA9ICdmYWNlYm9vay5wYWdlJztcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHZhciBhID0gSlNPTi5wYXJzZShwLnN0YXRlKTtcblx0XHRcdFx0X3RoaXMuZXh0ZW5kKHAsIGEpO1xuXHRcdFx0fVxuXHRcdFx0Y2F0Y2ggKGUpIHtcblx0XHRcdFx0dmFyIHN0YXRlRGVjb2RlZCA9IGRlY29kZVVSSUNvbXBvbmVudChwLnN0YXRlKTtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR2YXIgYiA9IEpTT04ucGFyc2Uoc3RhdGVEZWNvZGVkKTtcblx0XHRcdFx0XHRfdGhpcy5leHRlbmQocCwgYik7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRjb25zb2xlLmVycm9yKCdDb3VsZCBub3QgZGVjb2RlIHN0YXRlIHBhcmFtZXRlcicpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIEFjY2Vzc190b2tlbj9cblx0XHRcdGlmICgoJ2FjY2Vzc190b2tlbicgaW4gcCAmJiBwLmFjY2Vzc190b2tlbikgJiYgcC5uZXR3b3JrKSB7XG5cblx0XHRcdFx0aWYgKCFwLmV4cGlyZXNfaW4gfHwgcGFyc2VJbnQocC5leHBpcmVzX2luLCAxMCkgPT09IDApIHtcblx0XHRcdFx0XHQvLyBJZiBwLmV4cGlyZXNfaW4gaXMgdW5zZXQsIHNldCB0byAwXG5cdFx0XHRcdFx0cC5leHBpcmVzX2luID0gMDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHAuZXhwaXJlc19pbiA9IHBhcnNlSW50KHAuZXhwaXJlc19pbiwgMTApO1xuXHRcdFx0XHRwLmV4cGlyZXMgPSAoKG5ldyBEYXRlKCkpLmdldFRpbWUoKSAvIDFlMykgKyAocC5leHBpcmVzX2luIHx8ICg2MCAqIDYwICogMjQgKiAzNjUpKTtcblxuXHRcdFx0XHQvLyBMZXRzIHVzZSB0aGUgXCJzdGF0ZVwiIHRvIGFzc2lnbiBpdCB0byBvbmUgb2Ygb3VyIG5ldHdvcmtzXG5cdFx0XHRcdGF1dGhDYWxsYmFjayhwLCB3aW5kb3csIHBhcmVudCk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIEVycm9yPT9cblx0XHRcdC8vICZlcnJvcl9kZXNjcmlwdGlvbj0/XG5cdFx0XHQvLyAmc3RhdGU9P1xuXHRcdFx0ZWxzZSBpZiAoKCdlcnJvcicgaW4gcCAmJiBwLmVycm9yKSAmJiBwLm5ldHdvcmspIHtcblxuXHRcdFx0XHRwLmVycm9yID0ge1xuXHRcdFx0XHRcdGNvZGU6IHAuZXJyb3IsXG5cdFx0XHRcdFx0bWVzc2FnZTogcC5lcnJvcl9tZXNzYWdlIHx8IHAuZXJyb3JfZGVzY3JpcHRpb25cblx0XHRcdFx0fTtcblxuXHRcdFx0XHQvLyBMZXQgdGhlIHN0YXRlIGhhbmRsZXIgaGFuZGxlIGl0XG5cdFx0XHRcdGF1dGhDYWxsYmFjayhwLCB3aW5kb3csIHBhcmVudCk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIEFQSSBjYWxsLCBvciBhIGNhbmNlbGxlZCBsb2dpblxuXHRcdFx0Ly8gUmVzdWx0IGlzIHNlcmlhbGl6ZWQgSlNPTiBzdHJpbmdcblx0XHRcdGVsc2UgaWYgKHAuY2FsbGJhY2sgJiYgcC5jYWxsYmFjayBpbiBwYXJlbnQpIHtcblxuXHRcdFx0XHQvLyBUcmlnZ2VyIGEgZnVuY3Rpb24gaW4gdGhlIHBhcmVudFxuXHRcdFx0XHR2YXIgcmVzID0gJ3Jlc3VsdCcgaW4gcCAmJiBwLnJlc3VsdCA/IEpTT04ucGFyc2UocC5yZXN1bHQpIDogZmFsc2U7XG5cblx0XHRcdFx0Ly8gVHJpZ2dlciB0aGUgY2FsbGJhY2sgb24gdGhlIHBhcmVudFxuXHRcdFx0XHRjYWxsYmFjayhwYXJlbnQsIHAuY2FsbGJhY2spKHJlcyk7XG5cdFx0XHRcdGNsb3NlV2luZG93KCk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIElmIHRoaXMgcGFnZSBpcyBzdGlsbCBvcGVuXG5cdFx0XHRpZiAocC5wYWdlX3VyaSkge1xuXHRcdFx0XHRsb2NhdGlvbi5hc3NpZ24ocC5wYWdlX3VyaSk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gT0F1dGggcmVkaXJlY3QsIGZpeGVzIFVSSSBmcmFnbWVudHMgZnJvbSBiZWluZyBsb3N0IGluIFNhZmFyaVxuXHRcdC8vIChVUkkgRnJhZ21lbnRzIHdpdGhpbiAzMDIgTG9jYXRpb24gVVJJIGFyZSBsb3N0IG92ZXIgSFRUUFMpXG5cdFx0Ly8gTG9hZGluZyB0aGUgcmVkaXJlY3QuaHRtbCBiZWZvcmUgdHJpZ2dlcmluZyB0aGUgT0F1dGggRmxvdyBzZWVtcyB0byBmaXggaXQuXG5cdFx0ZWxzZSBpZiAoJ29hdXRoX3JlZGlyZWN0JyBpbiBwKSB7XG5cblx0XHRcdGxvY2F0aW9uLmFzc2lnbihkZWNvZGVVUklDb21wb25lbnQocC5vYXV0aF9yZWRpcmVjdCkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdC8vIFRyaWdnZXIgYSBjYWxsYmFjayB0byBhdXRoZW50aWNhdGVcblx0XHRmdW5jdGlvbiBhdXRoQ2FsbGJhY2sob2JqLCB3aW5kb3csIHBhcmVudCkge1xuXG5cdFx0XHR2YXIgY2IgPSBvYmouY2FsbGJhY2s7XG5cdFx0XHR2YXIgbmV0d29yayA9IG9iai5uZXR3b3JrO1xuXG5cdFx0XHQvLyBUcmlnZ2VyIHRoZSBjYWxsYmFjayBvbiB0aGUgcGFyZW50XG5cdFx0XHRfdGhpcy5zdG9yZShuZXR3b3JrLCBvYmopO1xuXG5cdFx0XHQvLyBJZiB0aGlzIGlzIGEgcGFnZSByZXF1ZXN0IGl0IGhhcyBubyBwYXJlbnQgb3Igb3BlbmVyIHdpbmRvdyB0byBoYW5kbGUgY2FsbGJhY2tzXG5cdFx0XHRpZiAoKCdkaXNwbGF5JyBpbiBvYmopICYmIG9iai5kaXNwbGF5ID09PSAncGFnZScpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZW1vdmUgZnJvbSBzZXNzaW9uIG9iamVjdFxuXHRcdFx0aWYgKHBhcmVudCAmJiBjYiAmJiBjYiBpbiBwYXJlbnQpIHtcblxuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGRlbGV0ZSBvYmouY2FsbGJhY2s7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y2F0Y2ggKGUpIHt9XG5cblx0XHRcdFx0Ly8gVXBkYXRlIHN0b3JlXG5cdFx0XHRcdF90aGlzLnN0b3JlKG5ldHdvcmssIG9iaik7XG5cblx0XHRcdFx0Ly8gQ2FsbCB0aGUgZ2xvYmFsRXZlbnQgZnVuY3Rpb24gb24gdGhlIHBhcmVudFxuXHRcdFx0XHQvLyBJdCdzIHNhZmVyIHRvIHBhc3MgYmFjayBhIHN0cmluZyB0byB0aGUgcGFyZW50LFxuXHRcdFx0XHQvLyBSYXRoZXIgdGhhbiBhbiBvYmplY3QvYXJyYXkgKGJldHRlciBmb3IgSUU4KVxuXHRcdFx0XHR2YXIgc3RyID0gSlNPTi5zdHJpbmdpZnkob2JqKTtcblxuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNhbGxiYWNrKHBhcmVudCwgY2IpKHN0cik7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y2F0Y2ggKGUpIHtcblx0XHRcdFx0XHQvLyBFcnJvciB0aHJvd24gd2hpbHN0IGV4ZWN1dGluZyBwYXJlbnQgY2FsbGJhY2tcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRjbG9zZVdpbmRvdygpO1xuXHRcdH1cblxuXHRcdGZ1bmN0aW9uIGNhbGxiYWNrKHBhcmVudCwgY2FsbGJhY2tJRCkge1xuXHRcdFx0aWYgKGNhbGxiYWNrSUQuaW5kZXhPZignX2hlbGxvanNfJykgIT09IDApIHtcblx0XHRcdFx0cmV0dXJuIGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRcdHRocm93ICdDb3VsZCBub3QgZXhlY3V0ZSBjYWxsYmFjayAnICsgY2FsbGJhY2tJRDtcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHBhcmVudFtjYWxsYmFja0lEXTtcblx0XHR9XG5cblx0XHRmdW5jdGlvbiBjbG9zZVdpbmRvdygpIHtcblxuXHRcdFx0aWYgKHdpbmRvdy5mcmFtZUVsZW1lbnQpIHtcblx0XHRcdFx0Ly8gSW5zaWRlIGFuIGlmcmFtZSwgcmVtb3ZlIGZyb20gcGFyZW50XG5cdFx0XHRcdHBhcmVudC5kb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHdpbmRvdy5mcmFtZUVsZW1lbnQpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdC8vIENsb3NlIHRoaXMgY3VycmVudCB3aW5kb3dcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR3aW5kb3cuY2xvc2UoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjYXRjaCAoZSkge31cblxuXHRcdFx0XHQvLyBJT1MgYnVnIHdvbnQgbGV0IHVzIGNsb3NlIGEgcG9wdXAgaWYgc3RpbGwgbG9hZGluZ1xuXHRcdFx0XHRpZiAod2luZG93LmFkZEV2ZW50TGlzdGVuZXIpIHtcblx0XHRcdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsIGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRcdFx0d2luZG93LmNsb3NlKCk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdH1cblx0fVxufSk7XG5cbi8vIEV2ZW50c1xuLy8gRXh0ZW5kIHRoZSBoZWxsbyBvYmplY3Qgd2l0aCBpdHMgb3duIGV2ZW50IGluc3RhbmNlXG5oZWxsby51dGlscy5FdmVudC5jYWxsKGhlbGxvKTtcblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIE1vbml0b3Jpbmcgc2Vzc2lvbiBzdGF0ZVxuLy8gQ2hlY2sgZm9yIHNlc3Npb24gY2hhbmdlc1xuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0Ly8gTW9uaXRvciBmb3IgYSBjaGFuZ2UgaW4gc3RhdGUgYW5kIGZpcmVcblx0dmFyIG9sZFNlc3Npb25zID0ge307XG5cblx0Ly8gSGFzaCBvZiBleHBpcmVkIHRva2Vuc1xuXHR2YXIgZXhwaXJlZCA9IHt9O1xuXG5cdC8vIExpc3RlbiB0byBvdGhlciB0cmlnZ2VycyB0byBBdXRoIGV2ZW50cywgdXNlIHRoZXNlIHRvIHVwZGF0ZSB0aGlzXG5cdGhlbGxvLm9uKCdhdXRoLmxvZ2luLCBhdXRoLmxvZ291dCcsIGZ1bmN0aW9uKGF1dGgpIHtcblx0XHRpZiAoYXV0aCAmJiB0eXBlb2YgKGF1dGgpID09PSAnb2JqZWN0JyAmJiBhdXRoLm5ldHdvcmspIHtcblx0XHRcdG9sZFNlc3Npb25zW2F1dGgubmV0d29ya10gPSBoZWxsby51dGlscy5zdG9yZShhdXRoLm5ldHdvcmspIHx8IHt9O1xuXHRcdH1cblx0fSk7XG5cblx0KGZ1bmN0aW9uIHNlbGYoKSB7XG5cblx0XHR2YXIgQ1VSUkVOVF9USU1FID0gKChuZXcgRGF0ZSgpKS5nZXRUaW1lKCkgLyAxZTMpO1xuXHRcdHZhciBlbWl0ID0gZnVuY3Rpb24oZXZlbnROYW1lKSB7XG5cdFx0XHRoZWxsby5lbWl0KCdhdXRoLicgKyBldmVudE5hbWUsIHtcblx0XHRcdFx0bmV0d29yazogbmFtZSxcblx0XHRcdFx0YXV0aFJlc3BvbnNlOiBzZXNzaW9uXG5cdFx0XHR9KTtcblx0XHR9O1xuXG5cdFx0Ly8gTG9vcCB0aHJvdWdoIHRoZSBzZXJ2aWNlc1xuXHRcdGZvciAodmFyIG5hbWUgaW4gaGVsbG8uc2VydmljZXMpIHtpZiAoaGVsbG8uc2VydmljZXMuaGFzT3duUHJvcGVydHkobmFtZSkpIHtcblxuXHRcdFx0aWYgKCFoZWxsby5zZXJ2aWNlc1tuYW1lXS5pZCkge1xuXHRcdFx0XHQvLyBXZSBoYXZlbid0IGF0dGFjaGVkIGFuIElEIHNvIGRvbnQgbGlzdGVuLlxuXHRcdFx0XHRjb250aW51ZTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gR2V0IHNlc3Npb25cblx0XHRcdHZhciBzZXNzaW9uID0gaGVsbG8udXRpbHMuc3RvcmUobmFtZSkgfHwge307XG5cdFx0XHR2YXIgcHJvdmlkZXIgPSBoZWxsby5zZXJ2aWNlc1tuYW1lXTtcblx0XHRcdHZhciBvbGRTZXNzID0gb2xkU2Vzc2lvbnNbbmFtZV0gfHwge307XG5cblx0XHRcdC8vIExpc3RlbiBmb3IgZ2xvYmFsRXZlbnRzIHRoYXQgZGlkIG5vdCBnZXQgdHJpZ2dlcmVkIGZyb20gdGhlIGNoaWxkXG5cdFx0XHRpZiAoc2Vzc2lvbiAmJiAnY2FsbGJhY2snIGluIHNlc3Npb24pIHtcblxuXHRcdFx0XHQvLyBUbyBkbyByZW1vdmUgZnJvbSBzZXNzaW9uIG9iamVjdC4uLlxuXHRcdFx0XHR2YXIgY2IgPSBzZXNzaW9uLmNhbGxiYWNrO1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGRlbGV0ZSBzZXNzaW9uLmNhbGxiYWNrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhdGNoIChlKSB7fVxuXG5cdFx0XHRcdC8vIFVwZGF0ZSBzdG9yZVxuXHRcdFx0XHQvLyBSZW1vdmluZyB0aGUgY2FsbGJhY2tcblx0XHRcdFx0aGVsbG8udXRpbHMuc3RvcmUobmFtZSwgc2Vzc2lvbik7XG5cblx0XHRcdFx0Ly8gRW1pdCBnbG9iYWwgZXZlbnRzXG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0d2luZG93W2NiXShzZXNzaW9uKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjYXRjaCAoZSkge31cblx0XHRcdH1cblxuXHRcdFx0Ly8gUmVmcmVzaCB0b2tlblxuXHRcdFx0aWYgKHNlc3Npb24gJiYgKCdleHBpcmVzJyBpbiBzZXNzaW9uKSAmJiBzZXNzaW9uLmV4cGlyZXMgPCBDVVJSRU5UX1RJTUUpIHtcblxuXHRcdFx0XHQvLyBJZiBhdXRvIHJlZnJlc2ggaXMgcG9zc2libGVcblx0XHRcdFx0Ly8gRWl0aGVyIHRoZSBicm93c2VyIHN1cHBvcnRzXG5cdFx0XHRcdHZhciByZWZyZXNoID0gcHJvdmlkZXIucmVmcmVzaCB8fCBzZXNzaW9uLnJlZnJlc2hfdG9rZW47XG5cblx0XHRcdFx0Ly8gSGFzIHRoZSByZWZyZXNoIGJlZW4gcnVuIHJlY2VudGx5P1xuXHRcdFx0XHRpZiAocmVmcmVzaCAmJiAoIShuYW1lIGluIGV4cGlyZWQpIHx8IGV4cGlyZWRbbmFtZV0gPCBDVVJSRU5UX1RJTUUpKSB7XG5cdFx0XHRcdFx0Ly8gVHJ5IHRvIHJlc2lnbmluXG5cdFx0XHRcdFx0aGVsbG8uZW1pdCgnbm90aWNlJywgbmFtZSArICcgaGFzIGV4cGlyZWQgdHJ5aW5nIHRvIHJlc2lnbmluJyk7XG5cdFx0XHRcdFx0aGVsbG8ubG9naW4obmFtZSwge2Rpc3BsYXk6ICdub25lJywgZm9yY2U6IGZhbHNlfSk7XG5cblx0XHRcdFx0XHQvLyBVcGRhdGUgZXhwaXJlZCwgZXZlcnkgMTAgbWludXRlc1xuXHRcdFx0XHRcdGV4cGlyZWRbbmFtZV0gPSBDVVJSRU5UX1RJTUUgKyA2MDA7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBEb2VzIHRoaXMgcHJvdmlkZXIgbm90IHN1cHBvcnQgcmVmcmVzaFxuXHRcdFx0XHRlbHNlIGlmICghcmVmcmVzaCAmJiAhKG5hbWUgaW4gZXhwaXJlZCkpIHtcblx0XHRcdFx0XHQvLyBMYWJlbCB0aGUgZXZlbnRcblx0XHRcdFx0XHRlbWl0KCdleHBpcmVkJyk7XG5cdFx0XHRcdFx0ZXhwaXJlZFtuYW1lXSA9IHRydWU7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBJZiBzZXNzaW9uIGhhcyBleHBpcmVkIHRoZW4gd2UgZG9udCB3YW50IHRvIHN0b3JlIGl0cyB2YWx1ZSB1bnRpbCBpdCBjYW4gYmUgZXN0YWJsaXNoZWQgdGhhdCBpdHMgYmVlbiB1cGRhdGVkXG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBIYXMgc2Vzc2lvbiBjaGFuZ2VkP1xuXHRcdFx0ZWxzZSBpZiAob2xkU2Vzcy5hY2Nlc3NfdG9rZW4gPT09IHNlc3Npb24uYWNjZXNzX3Rva2VuICYmXG5cdFx0XHRvbGRTZXNzLmV4cGlyZXMgPT09IHNlc3Npb24uZXhwaXJlcykge1xuXHRcdFx0XHRjb250aW51ZTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gQWNjZXNzX3Rva2VuIGhhcyBiZWVuIHJlbW92ZWRcblx0XHRcdGVsc2UgaWYgKCFzZXNzaW9uLmFjY2Vzc190b2tlbiAmJiBvbGRTZXNzLmFjY2Vzc190b2tlbikge1xuXHRcdFx0XHRlbWl0KCdsb2dvdXQnKTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gQWNjZXNzX3Rva2VuIGhhcyBiZWVuIGNyZWF0ZWRcblx0XHRcdGVsc2UgaWYgKHNlc3Npb24uYWNjZXNzX3Rva2VuICYmICFvbGRTZXNzLmFjY2Vzc190b2tlbikge1xuXHRcdFx0XHRlbWl0KCdsb2dpbicpO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBBY2Nlc3NfdG9rZW4gaGFzIGJlZW4gdXBkYXRlZFxuXHRcdFx0ZWxzZSBpZiAoc2Vzc2lvbi5leHBpcmVzICE9PSBvbGRTZXNzLmV4cGlyZXMpIHtcblx0XHRcdFx0ZW1pdCgndXBkYXRlJyk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIFVwZGF0ZWQgc3RvcmVkIHNlc3Npb25cblx0XHRcdG9sZFNlc3Npb25zW25hbWVdID0gc2Vzc2lvbjtcblxuXHRcdFx0Ly8gUmVtb3ZlIHRoZSBleHBpcmVkIGZsYWdzXG5cdFx0XHRpZiAobmFtZSBpbiBleHBpcmVkKSB7XG5cdFx0XHRcdGRlbGV0ZSBleHBpcmVkW25hbWVdO1xuXHRcdFx0fVxuXHRcdH19XG5cblx0XHQvLyBDaGVjayBlcnJvciBldmVudHNcblx0XHRzZXRUaW1lb3V0KHNlbGYsIDEwMDApO1xuXHR9KSgpO1xuXG59KShoZWxsbyk7XG5cbi8vIEVPRiBDT1JFIGxpYlxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gQVBJXG4vLyBAcGFyYW0gcGF0aCAgICBzdHJpbmdcbi8vIEBwYXJhbSBxdWVyeSAgIG9iamVjdCAob3B0aW9uYWwpXG4vLyBAcGFyYW0gbWV0aG9kICBzdHJpbmcgKG9wdGlvbmFsKVxuLy8gQHBhcmFtIGRhdGEgICAgb2JqZWN0IChvcHRpb25hbClcbi8vIEBwYXJhbSB0aW1lb3V0IGludGVnZXIgKG9wdGlvbmFsKVxuLy8gQHBhcmFtIGNhbGxiYWNrICBmdW5jdGlvbiAob3B0aW9uYWwpXG5cbmhlbGxvLmFwaSA9IGZ1bmN0aW9uKCkge1xuXG5cdC8vIFNob3J0aGFuZFxuXHR2YXIgX3RoaXMgPSB0aGlzO1xuXHR2YXIgdXRpbHMgPSBfdGhpcy51dGlscztcblx0dmFyIGVycm9yID0gdXRpbHMuZXJyb3I7XG5cblx0Ly8gQ29uc3RydWN0IGEgbmV3IFByb21pc2Ugb2JqZWN0XG5cdHZhciBwcm9taXNlID0gdXRpbHMuUHJvbWlzZSgpO1xuXG5cdC8vIEFyZ3VtZW50c1xuXHR2YXIgcCA9IHV0aWxzLmFyZ3Moe3BhdGg6ICdzIScsIHF1ZXJ5OiAnbycsIG1ldGhvZDogJ3MnLCBkYXRhOiAnbycsIHRpbWVvdXQ6ICdpJywgY2FsbGJhY2s6ICdmJ30sIGFyZ3VtZW50cyk7XG5cblx0Ly8gTWV0aG9kXG5cdHAubWV0aG9kID0gKHAubWV0aG9kIHx8ICdnZXQnKS50b0xvd2VyQ2FzZSgpO1xuXG5cdC8vIEhlYWRlcnNcblx0cC5oZWFkZXJzID0gcC5oZWFkZXJzIHx8IHt9O1xuXG5cdC8vIFF1ZXJ5XG5cdHAucXVlcnkgPSBwLnF1ZXJ5IHx8IHt9O1xuXG5cdC8vIElmIGdldCwgcHV0IGFsbCBwYXJhbWV0ZXJzIGludG8gcXVlcnlcblx0aWYgKHAubWV0aG9kID09PSAnZ2V0JyB8fCBwLm1ldGhvZCA9PT0gJ2RlbGV0ZScpIHtcblx0XHR1dGlscy5leHRlbmQocC5xdWVyeSwgcC5kYXRhKTtcblx0XHRwLmRhdGEgPSB7fTtcblx0fVxuXG5cdHZhciBkYXRhID0gcC5kYXRhID0gcC5kYXRhIHx8IHt9O1xuXG5cdC8vIENvbXBsZXRlZCBldmVudCBjYWxsYmFja1xuXHRwcm9taXNlLnRoZW4ocC5jYWxsYmFjaywgcC5jYWxsYmFjayk7XG5cblx0Ly8gUmVtb3ZlIHRoZSBuZXR3b3JrIGZyb20gcGF0aCwgZS5nLiBmYWNlYm9vazovbWUvZnJpZW5kc1xuXHQvLyBSZXN1bHRzIGluIHsgbmV0d29yayA6IGZhY2Vib29rLCBwYXRoIDogbWUvZnJpZW5kcyB9XG5cdGlmICghcC5wYXRoKSB7XG5cdFx0cmV0dXJuIHByb21pc2UucmVqZWN0KGVycm9yKCdpbnZhbGlkX3BhdGgnLCAnTWlzc2luZyB0aGUgcGF0aCBwYXJhbWV0ZXIgZnJvbSB0aGUgcmVxdWVzdCcpKTtcblx0fVxuXG5cdHAucGF0aCA9IHAucGF0aC5yZXBsYWNlKC9eXFwvKy8sICcnKTtcblx0dmFyIGEgPSAocC5wYXRoLnNwbGl0KC9bXFwvXFw6XS8sIDIpIHx8IFtdKVswXS50b0xvd2VyQ2FzZSgpO1xuXG5cdGlmIChhIGluIF90aGlzLnNlcnZpY2VzKSB7XG5cdFx0cC5uZXR3b3JrID0gYTtcblx0XHR2YXIgcmVnID0gbmV3IFJlZ0V4cCgnXicgKyBhICsgJzo/XFwvPycpO1xuXHRcdHAucGF0aCA9IHAucGF0aC5yZXBsYWNlKHJlZywgJycpO1xuXHR9XG5cblx0Ly8gTmV0d29yayAmIFByb3ZpZGVyXG5cdC8vIERlZmluZSB0aGUgbmV0d29yayB0aGF0IHRoaXMgcmVxdWVzdCBpcyBtYWRlIGZvclxuXHRwLm5ldHdvcmsgPSBfdGhpcy5zZXR0aW5ncy5kZWZhdWx0X3NlcnZpY2UgPSBwLm5ldHdvcmsgfHwgX3RoaXMuc2V0dGluZ3MuZGVmYXVsdF9zZXJ2aWNlO1xuXHR2YXIgbyA9IF90aGlzLnNlcnZpY2VzW3AubmV0d29ya107XG5cblx0Ly8gSU5WQUxJRFxuXHQvLyBJcyB0aGVyZSBubyBzZXJ2aWNlIGJ5IHRoZSBnaXZlbiBuZXR3b3JrIG5hbWU/XG5cdGlmICghbykge1xuXHRcdHJldHVybiBwcm9taXNlLnJlamVjdChlcnJvcignaW52YWxpZF9uZXR3b3JrJywgJ0NvdWxkIG5vdCBtYXRjaCB0aGUgc2VydmljZSByZXF1ZXN0ZWQ6ICcgKyBwLm5ldHdvcmspKTtcblx0fVxuXG5cdC8vIFBBVEhcblx0Ly8gQXMgbG9uZyBhcyB0aGUgcGF0aCBpc24ndCBmbGFnZ2VkIGFzIHVuYXZhaWFibGUsIGUuZy4gcGF0aCA9PSBmYWxzZVxuXG5cdGlmICghKCEocC5tZXRob2QgaW4gbykgfHwgIShwLnBhdGggaW4gb1twLm1ldGhvZF0pIHx8IG9bcC5tZXRob2RdW3AucGF0aF0gIT09IGZhbHNlKSkge1xuXHRcdHJldHVybiBwcm9taXNlLnJlamVjdChlcnJvcignaW52YWxpZF9wYXRoJywgJ1RoZSBwcm92aWRlZCBwYXRoIGlzIG5vdCBhdmFpbGFibGUgb24gdGhlIHNlbGVjdGVkIG5ldHdvcmsnKSk7XG5cdH1cblxuXHQvLyBQUk9YWVxuXHQvLyBPQXV0aDEgY2FsbHMgYWx3YXlzIG5lZWQgYSBwcm94eVxuXG5cdGlmICghcC5vYXV0aF9wcm94eSkge1xuXHRcdHAub2F1dGhfcHJveHkgPSBfdGhpcy5zZXR0aW5ncy5vYXV0aF9wcm94eTtcblx0fVxuXG5cdGlmICghKCdwcm94eScgaW4gcCkpIHtcblx0XHRwLnByb3h5ID0gcC5vYXV0aF9wcm94eSAmJiBvLm9hdXRoICYmIHBhcnNlSW50KG8ub2F1dGgudmVyc2lvbiwgMTApID09PSAxO1xuXHR9XG5cblx0Ly8gVElNRU9VVFxuXHQvLyBBZG9wdCB0aW1lb3V0IGZyb20gZ2xvYmFsIHNldHRpbmdzIGJ5IGRlZmF1bHRcblxuXHRpZiAoISgndGltZW91dCcgaW4gcCkpIHtcblx0XHRwLnRpbWVvdXQgPSBfdGhpcy5zZXR0aW5ncy50aW1lb3V0O1xuXHR9XG5cblx0Ly8gRm9ybWF0IHJlc3BvbnNlXG5cdC8vIFdoZXRoZXIgdG8gcnVuIHRoZSByYXcgcmVzcG9uc2UgdGhyb3VnaCBwb3N0IHByb2Nlc3NpbmcuXG5cdGlmICghKCdmb3JtYXRSZXNwb25zZScgaW4gcCkpIHtcblx0XHRwLmZvcm1hdFJlc3BvbnNlID0gdHJ1ZTtcblx0fVxuXG5cdC8vIEdldCB0aGUgY3VycmVudCBzZXNzaW9uXG5cdC8vIEFwcGVuZCB0aGUgYWNjZXNzX3Rva2VuIHRvIHRoZSBxdWVyeVxuXHRwLmF1dGhSZXNwb25zZSA9IF90aGlzLmdldEF1dGhSZXNwb25zZShwLm5ldHdvcmspO1xuXHRpZiAocC5hdXRoUmVzcG9uc2UgJiYgcC5hdXRoUmVzcG9uc2UuYWNjZXNzX3Rva2VuKSB7XG5cdFx0cC5xdWVyeS5hY2Nlc3NfdG9rZW4gPSBwLmF1dGhSZXNwb25zZS5hY2Nlc3NfdG9rZW47XG5cdH1cblxuXHR2YXIgdXJsID0gcC5wYXRoO1xuXHR2YXIgbTtcblxuXHQvLyBTdG9yZSB0aGUgcXVlcnkgYXMgb3B0aW9uc1xuXHQvLyBUaGlzIGlzIHVzZWQgdG8gcG9wdWxhdGUgdGhlIHJlcXVlc3Qgb2JqZWN0IGJlZm9yZSB0aGUgZGF0YSBpcyBhdWdtZW50ZWQgYnkgdGhlIHByZXdyYXAgaGFuZGxlcnMuXG5cdHAub3B0aW9ucyA9IHV0aWxzLmNsb25lKHAucXVlcnkpO1xuXG5cdC8vIENsb25lIHRoZSBkYXRhIG9iamVjdFxuXHQvLyBQcmV2ZW50IHRoaXMgc2NyaXB0IG92ZXJ3cml0aW5nIHRoZSBkYXRhIG9mIHRoZSBpbmNvbWluZyBvYmplY3QuXG5cdC8vIEVuc3VyZSB0aGF0IGV2ZXJ5dGltZSB3ZSBydW4gYW4gaXRlcmF0aW9uIHRoZSBjYWxsYmFja3MgaGF2ZW4ndCByZW1vdmVkIHNvbWUgZGF0YVxuXHRwLmRhdGEgPSB1dGlscy5jbG9uZShkYXRhKTtcblxuXHQvLyBVUkwgTWFwcGluZ1xuXHQvLyBJcyB0aGVyZSBhIG1hcCBmb3IgdGhlIGdpdmVuIFVSTD9cblx0dmFyIGFjdGlvbnMgPSBvW3snZGVsZXRlJzogJ2RlbCd9W3AubWV0aG9kXSB8fCBwLm1ldGhvZF0gfHwge307XG5cblx0Ly8gRXh0cmFwb2xhdGUgdGhlIFF1ZXJ5U3RyaW5nXG5cdC8vIFByb3ZpZGUgYSBjbGVhbiBwYXRoXG5cdC8vIE1vdmUgdGhlIHF1ZXJ5c3RyaW5nIGludG8gdGhlIGRhdGFcblx0aWYgKHAubWV0aG9kID09PSAnZ2V0Jykge1xuXG5cdFx0dmFyIHF1ZXJ5ID0gdXJsLnNwbGl0KC9bXFw/I10vKVsxXTtcblx0XHRpZiAocXVlcnkpIHtcblx0XHRcdHV0aWxzLmV4dGVuZChwLnF1ZXJ5LCB1dGlscy5wYXJhbShxdWVyeSkpO1xuXG5cdFx0XHQvLyBSZW1vdmUgdGhlIHF1ZXJ5IHBhcnQgZnJvbSB0aGUgVVJMXG5cdFx0XHR1cmwgPSB1cmwucmVwbGFjZSgvXFw/Lio/KCN8JCkvLCAnJDEnKTtcblx0XHR9XG5cdH1cblxuXHQvLyBJcyB0aGUgaGFzaCBmcmFnbWVudCBkZWZpbmVkXG5cdGlmICgobSA9IHVybC5tYXRjaCgvIyguKykvLCAnJykpKSB7XG5cdFx0dXJsID0gdXJsLnNwbGl0KCcjJylbMF07XG5cdFx0cC5wYXRoID0gbVsxXTtcblx0fVxuXHRlbHNlIGlmICh1cmwgaW4gYWN0aW9ucykge1xuXHRcdHAucGF0aCA9IHVybDtcblx0XHR1cmwgPSBhY3Rpb25zW3VybF07XG5cdH1cblx0ZWxzZSBpZiAoJ2RlZmF1bHQnIGluIGFjdGlvbnMpIHtcblx0XHR1cmwgPSBhY3Rpb25zWydkZWZhdWx0J107XG5cdH1cblxuXHQvLyBSZWRpcmVjdCBIYW5kbGVyXG5cdC8vIFRoaXMgZGVmaW5lcyBmb3IgdGhlIEZvcm0rSWZyYW1lK0hhc2ggaGFjayB3aGVyZSB0byByZXR1cm4gdGhlIHJlc3VsdHMgdG9vLlxuXHRwLnJlZGlyZWN0X3VyaSA9IF90aGlzLnNldHRpbmdzLnJlZGlyZWN0X3VyaTtcblxuXHQvLyBEZWZpbmUgRm9ybWF0SGFuZGxlclxuXHQvLyBUaGUgcmVxdWVzdCBjYW4gYmUgcHJvY2VzZWQgaW4gYSBtdWx0aXR1ZGUgb2Ygd2F5c1xuXHQvLyBIZXJlJ3MgdGhlIG9wdGlvbnMgLSBkZXBlbmRpbmcgb24gdGhlIGJyb3dzZXIgYW5kIGVuZHBvaW50XG5cdHAueGhyID0gby54aHI7XG5cdHAuanNvbnAgPSBvLmpzb25wO1xuXHRwLmZvcm0gPSBvLmZvcm07XG5cblx0Ly8gTWFrZSByZXF1ZXN0XG5cdGlmICh0eXBlb2YgKHVybCkgPT09ICdmdW5jdGlvbicpIHtcblx0XHQvLyBEb2VzIHNlbGYgaGF2ZSBpdHMgb3duIGNhbGxiYWNrP1xuXHRcdHVybChwLCBnZXRQYXRoKTtcblx0fVxuXHRlbHNlIHtcblx0XHQvLyBFbHNlIHRoZSBVUkwgaXMgYSBzdHJpbmdcblx0XHRnZXRQYXRoKHVybCk7XG5cdH1cblxuXHRyZXR1cm4gcHJvbWlzZS5wcm94eTtcblxuXHQvLyBJZiB1cmwgbmVlZHMgYSBiYXNlXG5cdC8vIFdyYXAgZXZlcnl0aGluZyBpblxuXHRmdW5jdGlvbiBnZXRQYXRoKHVybCkge1xuXG5cdFx0Ly8gRm9ybWF0IHRoZSBzdHJpbmcgaWYgaXQgbmVlZHMgaXRcblx0XHR1cmwgPSB1cmwucmVwbGFjZSgvXFxAXFx7KFthLXpcXF9cXC1dKykoXFx8Lio/KT9cXH0vZ2ksIGZ1bmN0aW9uKG0sIGtleSwgZGVmYXVsdHMpIHtcblx0XHRcdHZhciB2YWwgPSBkZWZhdWx0cyA/IGRlZmF1bHRzLnJlcGxhY2UoL15cXHwvLCAnJykgOiAnJztcblx0XHRcdGlmIChrZXkgaW4gcC5xdWVyeSkge1xuXHRcdFx0XHR2YWwgPSBwLnF1ZXJ5W2tleV07XG5cdFx0XHRcdGRlbGV0ZSBwLnF1ZXJ5W2tleV07XG5cdFx0XHR9XG5cdFx0XHRlbHNlIGlmIChwLmRhdGEgJiYga2V5IGluIHAuZGF0YSkge1xuXHRcdFx0XHR2YWwgPSBwLmRhdGFba2V5XTtcblx0XHRcdFx0ZGVsZXRlIHAuZGF0YVtrZXldO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSBpZiAoIWRlZmF1bHRzKSB7XG5cdFx0XHRcdHByb21pc2UucmVqZWN0KGVycm9yKCdtaXNzaW5nX2F0dHJpYnV0ZScsICdUaGUgYXR0cmlidXRlICcgKyBrZXkgKyAnIGlzIG1pc3NpbmcgZnJvbSB0aGUgcmVxdWVzdCcpKTtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHZhbDtcblx0XHR9KTtcblxuXHRcdC8vIEFkZCBiYXNlXG5cdFx0aWYgKCF1cmwubWF0Y2goL15odHRwcz86XFwvXFwvLykpIHtcblx0XHRcdHVybCA9IG8uYmFzZSArIHVybDtcblx0XHR9XG5cblx0XHQvLyBEZWZpbmUgdGhlIHJlcXVlc3QgVVJMXG5cdFx0cC51cmwgPSB1cmw7XG5cblx0XHQvLyBNYWtlIHRoZSBIVFRQIHJlcXVlc3Qgd2l0aCB0aGUgY3VyYXRlZCByZXF1ZXN0IG9iamVjdFxuXHRcdC8vIENBTExCQUNLIEhBTkRMRVJcblx0XHQvLyBAIHJlc3BvbnNlIG9iamVjdFxuXHRcdC8vIEAgc3RhdHVzQ29kZSBpbnRlZ2VyIGlmIGF2YWlsYWJsZVxuXHRcdHV0aWxzLnJlcXVlc3QocCwgZnVuY3Rpb24ociwgaGVhZGVycykge1xuXG5cdFx0XHQvLyBJcyB0aGlzIGEgcmF3IHJlc3BvbnNlP1xuXHRcdFx0aWYgKCFwLmZvcm1hdFJlc3BvbnNlKSB7XG5cdFx0XHRcdC8vIEJhZCByZXF1ZXN0PyBlcnJvciBzdGF0dXNDb2RlIG9yIG90aGVyd2lzZSBjb250YWlucyBhbiBlcnJvciByZXNwb25zZSB2aXMgSlNPTlA/XG5cdFx0XHRcdGlmICh0eXBlb2YgaGVhZGVycyA9PT0gJ29iamVjdCcgPyAoaGVhZGVycy5zdGF0dXNDb2RlID49IDQwMCkgOiAodHlwZW9mIHIgPT09ICdvYmplY3QnICYmICdlcnJvcicgaW4gcikpIHtcblx0XHRcdFx0XHRwcm9taXNlLnJlamVjdChyKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRwcm9taXNlLmZ1bGZpbGwocik7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdC8vIFNob3VsZCB0aGlzIGJlIGFuIG9iamVjdFxuXHRcdFx0aWYgKHIgPT09IHRydWUpIHtcblx0XHRcdFx0ciA9IHtzdWNjZXNzOnRydWV9O1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSBpZiAoIXIpIHtcblx0XHRcdFx0ciA9IHt9O1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBUaGUgZGVsZXRlIGNhbGxiYWNrIG5lZWRzIGEgYmV0dGVyIHJlc3BvbnNlXG5cdFx0XHRpZiAocC5tZXRob2QgPT09ICdkZWxldGUnKSB7XG5cdFx0XHRcdHIgPSAoIXIgfHwgdXRpbHMuaXNFbXB0eShyKSkgPyB7c3VjY2Vzczp0cnVlfSA6IHI7XG5cdFx0XHR9XG5cblx0XHRcdC8vIEZPUk1BVCBSRVNQT05TRT9cblx0XHRcdC8vIERvZXMgc2VsZiByZXF1ZXN0IGhhdmUgYSBjb3JyZXNwb25kaW5nIGZvcm1hdHRlclxuXHRcdFx0aWYgKG8ud3JhcCAmJiAoKHAucGF0aCBpbiBvLndyYXApIHx8ICgnZGVmYXVsdCcgaW4gby53cmFwKSkpIHtcblx0XHRcdFx0dmFyIHdyYXAgPSAocC5wYXRoIGluIG8ud3JhcCA/IHAucGF0aCA6ICdkZWZhdWx0Jyk7XG5cdFx0XHRcdHZhciB0aW1lID0gKG5ldyBEYXRlKCkpLmdldFRpbWUoKTtcblxuXHRcdFx0XHQvLyBGT1JNQVQgUkVTUE9OU0Vcblx0XHRcdFx0dmFyIGIgPSBvLndyYXBbd3JhcF0ociwgaGVhZGVycywgcCk7XG5cblx0XHRcdFx0Ly8gSGFzIHRoZSByZXNwb25zZSBiZWVuIHV0dGVybHkgb3ZlcndyaXR0ZW4/XG5cdFx0XHRcdC8vIFR5cGljYWxseSBzZWxmIGF1Z21lbnRzIHRoZSBleGlzdGluZyBvYmplY3QuLiBidXQgZm9yIHRob3NlIHJhcmUgb2NjYXNzaW9uc1xuXHRcdFx0XHRpZiAoYikge1xuXHRcdFx0XHRcdHIgPSBiO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIElzIHRoZXJlIGEgbmV4dF9wYWdlIGRlZmluZWQgaW4gdGhlIHJlc3BvbnNlP1xuXHRcdFx0aWYgKHIgJiYgJ3BhZ2luZycgaW4gciAmJiByLnBhZ2luZy5uZXh0KSB7XG5cblx0XHRcdFx0Ly8gQWRkIHRoZSByZWxhdGl2ZSBwYXRoIGlmIGl0IGlzIG1pc3NpbmcgZnJvbSB0aGUgcGFnaW5nL25leHQgcGF0aFxuXHRcdFx0XHRpZiAoci5wYWdpbmcubmV4dFswXSA9PT0gJz8nKSB7XG5cdFx0XHRcdFx0ci5wYWdpbmcubmV4dCA9IHAucGF0aCArIHIucGFnaW5nLm5leHQ7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBUaGUgcmVsYXRpdmUgcGF0aCBoYXMgYmVlbiBkZWZpbmVkLCBsZXRzIG1hcmt1cCB0aGUgaGFuZGxlciBpbiB0aGUgSGFzaEZyYWdtZW50XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdHIucGFnaW5nLm5leHQgKz0gJyMnICsgcC5wYXRoO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIERpc3BhdGNoIHRvIGxpc3RlbmVyc1xuXHRcdFx0Ly8gRW1pdCBldmVudHMgd2hpY2ggcGVydGFpbiB0byB0aGUgZm9ybWF0dGVkIHJlc3BvbnNlXG5cdFx0XHRpZiAoIXIgfHwgJ2Vycm9yJyBpbiByKSB7XG5cdFx0XHRcdHByb21pc2UucmVqZWN0KHIpO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdHByb21pc2UuZnVsZmlsbChyKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxufTtcblxuLy8gQVBJIHV0aWxpdGllc1xuaGVsbG8udXRpbHMuZXh0ZW5kKGhlbGxvLnV0aWxzLCB7XG5cblx0Ly8gTWFrZSBhbiBIVFRQIHJlcXVlc3Rcblx0cmVxdWVzdDogZnVuY3Rpb24ocCwgY2FsbGJhY2spIHtcblxuXHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0dmFyIGVycm9yID0gX3RoaXMuZXJyb3I7XG5cblx0XHQvLyBUaGlzIGhhcyB0byBnbyB0aHJvdWdoIGEgUE9TVCByZXF1ZXN0XG5cdFx0aWYgKCFfdGhpcy5pc0VtcHR5KHAuZGF0YSkgJiYgISgnRmlsZUxpc3QnIGluIHdpbmRvdykgJiYgX3RoaXMuaGFzQmluYXJ5KHAuZGF0YSkpIHtcblxuXHRcdFx0Ly8gRGlzYWJsZSBYSFIgYW5kIEpTT05QXG5cdFx0XHRwLnhociA9IGZhbHNlO1xuXHRcdFx0cC5qc29ucCA9IGZhbHNlO1xuXHRcdH1cblxuXHRcdC8vIENoZWNrIGlmIHRoZSBicm93c2VyIGFuZCBzZXJ2aWNlIHN1cHBvcnQgQ09SU1xuXHRcdHZhciBjb3JzID0gdGhpcy5yZXF1ZXN0X2NvcnMoZnVuY3Rpb24oKSB7XG5cdFx0XHQvLyBJZiBpdCBkb2VzIHRoZW4gcnVuIHRoaXMuLi5cblx0XHRcdHJldHVybiAoKHAueGhyID09PSB1bmRlZmluZWQpIHx8IChwLnhociAmJiAodHlwZW9mIChwLnhocikgIT09ICdmdW5jdGlvbicgfHwgcC54aHIocCwgcC5xdWVyeSkpKSk7XG5cdFx0fSk7XG5cblx0XHRpZiAoY29ycykge1xuXG5cdFx0XHRmb3JtYXRVcmwocCwgZnVuY3Rpb24odXJsKSB7XG5cblx0XHRcdFx0dmFyIHggPSBfdGhpcy54aHIocC5tZXRob2QsIHVybCwgcC5oZWFkZXJzLCBwLmRhdGEsIGNhbGxiYWNrKTtcblx0XHRcdFx0eC5vbnByb2dyZXNzID0gcC5vbnByb2dyZXNzIHx8IG51bGw7XG5cblx0XHRcdFx0Ly8gV2luZG93cyBQaG9uZSBkb2VzIG5vdCBzdXBwb3J0IHhoci51cGxvYWQsIHNlZSAjNzRcblx0XHRcdFx0Ly8gRmVhdHVyZSBkZXRlY3Rcblx0XHRcdFx0aWYgKHgudXBsb2FkICYmIHAub251cGxvYWRwcm9ncmVzcykge1xuXHRcdFx0XHRcdHgudXBsb2FkLm9ucHJvZ3Jlc3MgPSBwLm9udXBsb2FkcHJvZ3Jlc3M7XG5cdFx0XHRcdH1cblxuXHRcdFx0fSk7XG5cblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHQvLyBDbG9uZSB0aGUgcXVlcnkgb2JqZWN0XG5cdFx0Ly8gRWFjaCByZXF1ZXN0IG1vZGlmaWVzIHRoZSBxdWVyeSBvYmplY3QgYW5kIG5lZWRzIHRvIGJlIHRhcmVkIGFmdGVyIGVhY2ggb25lLlxuXHRcdHZhciBfcXVlcnkgPSBwLnF1ZXJ5O1xuXG5cdFx0cC5xdWVyeSA9IF90aGlzLmNsb25lKHAucXVlcnkpO1xuXG5cdFx0Ly8gQXNzaWduIGEgbmV3IGNhbGxiYWNrSURcblx0XHRwLmNhbGxiYWNrSUQgPSBfdGhpcy5nbG9iYWxFdmVudCgpO1xuXG5cdFx0Ly8gSlNPTlBcblx0XHRpZiAocC5qc29ucCAhPT0gZmFsc2UpIHtcblxuXHRcdFx0Ly8gQ2xvbmUgdGhlIHF1ZXJ5IG9iamVjdFxuXHRcdFx0cC5xdWVyeS5jYWxsYmFjayA9IHAuY2FsbGJhY2tJRDtcblxuXHRcdFx0Ly8gSWYgdGhlIEpTT05QIGlzIGEgZnVuY3Rpb24gdGhlbiBydW4gaXRcblx0XHRcdGlmICh0eXBlb2YgKHAuanNvbnApID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRcdHAuanNvbnAocCwgcC5xdWVyeSk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIExldHMgdXNlIEpTT05QIGlmIHRoZSBtZXRob2QgaXMgJ2dldCdcblx0XHRcdGlmIChwLm1ldGhvZCA9PT0gJ2dldCcpIHtcblxuXHRcdFx0XHRmb3JtYXRVcmwocCwgZnVuY3Rpb24odXJsKSB7XG5cdFx0XHRcdFx0X3RoaXMuanNvbnAodXJsLCBjYWxsYmFjaywgcC5jYWxsYmFja0lELCBwLnRpbWVvdXQpO1xuXHRcdFx0XHR9KTtcblxuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0Ly8gSXQncyBub3QgY29tcGF0aWJsZSByZXNldCBxdWVyeVxuXHRcdFx0XHRwLnF1ZXJ5ID0gX3F1ZXJ5O1xuXHRcdFx0fVxuXG5cdFx0fVxuXG5cdFx0Ly8gT3RoZXJ3aXNlIHdlJ3JlIG9uIHRvIHRoZSBvbGQgc2Nob29sLCBpZnJhbWUgaGFja3MgYW5kIEpTT05QXG5cdFx0aWYgKHAuZm9ybSAhPT0gZmFsc2UpIHtcblxuXHRcdFx0Ly8gQWRkIHNvbWUgYWRkaXRpb25hbCBxdWVyeSBwYXJhbWV0ZXJzIHRvIHRoZSBVUkxcblx0XHRcdC8vIFdlJ3JlIHByZXR0eSBzdHVmZmVkIGlmIHRoZSBlbmRwb2ludCBkb2Vzbid0IGxpa2UgdGhlc2Vcblx0XHRcdHAucXVlcnkucmVkaXJlY3RfdXJpID0gcC5yZWRpcmVjdF91cmk7XG5cdFx0XHRwLnF1ZXJ5LnN0YXRlID0gSlNPTi5zdHJpbmdpZnkoe2NhbGxiYWNrOnAuY2FsbGJhY2tJRH0pO1xuXG5cdFx0XHR2YXIgb3B0cztcblxuXHRcdFx0aWYgKHR5cGVvZiAocC5mb3JtKSA9PT0gJ2Z1bmN0aW9uJykge1xuXG5cdFx0XHRcdC8vIEZvcm1hdCB0aGUgcmVxdWVzdFxuXHRcdFx0XHRvcHRzID0gcC5mb3JtKHAsIHAucXVlcnkpO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAocC5tZXRob2QgPT09ICdwb3N0JyAmJiBvcHRzICE9PSBmYWxzZSkge1xuXG5cdFx0XHRcdGZvcm1hdFVybChwLCBmdW5jdGlvbih1cmwpIHtcblx0XHRcdFx0XHRfdGhpcy5wb3N0KHVybCwgcC5kYXRhLCBvcHRzLCBjYWxsYmFjaywgcC5jYWxsYmFja0lELCBwLnRpbWVvdXQpO1xuXHRcdFx0XHR9KTtcblxuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gTm9uZSBvZiB0aGUgbWV0aG9kcyB3ZXJlIHN1Y2Nlc3NmdWwgdGhyb3cgYW4gZXJyb3Jcblx0XHRjYWxsYmFjayhlcnJvcignaW52YWxpZF9yZXF1ZXN0JywgJ1RoZXJlIHdhcyBubyBtZWNoYW5pc20gZm9yIGhhbmRsaW5nIHRoaXMgcmVxdWVzdCcpKTtcblxuXHRcdHJldHVybjtcblxuXHRcdC8vIEZvcm1hdCBVUkxcblx0XHQvLyBDb25zdHJ1Y3RzIHRoZSByZXF1ZXN0IFVSTCwgb3B0aW9uYWxseSB3cmFwcyB0aGUgVVJMIHRocm91Z2ggYSBjYWxsIHRvIGEgcHJveHkgc2VydmVyXG5cdFx0Ly8gUmV0dXJucyB0aGUgZm9ybWF0dGVkIFVSTFxuXHRcdGZ1bmN0aW9uIGZvcm1hdFVybChwLCBjYWxsYmFjaykge1xuXG5cdFx0XHQvLyBBcmUgd2Ugc2lnbmluZyB0aGUgcmVxdWVzdD9cblx0XHRcdHZhciBzaWduO1xuXG5cdFx0XHQvLyBPQXV0aDFcblx0XHRcdC8vIFJlbW92ZSB0aGUgdG9rZW4gZnJvbSB0aGUgcXVlcnkgYmVmb3JlIHNpZ25pbmdcblx0XHRcdGlmIChwLmF1dGhSZXNwb25zZSAmJiBwLmF1dGhSZXNwb25zZS5vYXV0aCAmJiBwYXJzZUludChwLmF1dGhSZXNwb25zZS5vYXV0aC52ZXJzaW9uLCAxMCkgPT09IDEpIHtcblxuXHRcdFx0XHQvLyBPQVVUSCBTSUdOSU5HIFBST1hZXG5cdFx0XHRcdHNpZ24gPSBwLnF1ZXJ5LmFjY2Vzc190b2tlbjtcblxuXHRcdFx0XHQvLyBSZW1vdmUgdGhlIGFjY2Vzc190b2tlblxuXHRcdFx0XHRkZWxldGUgcC5xdWVyeS5hY2Nlc3NfdG9rZW47XG5cblx0XHRcdFx0Ly8gRW5mb3JlIHVzZSBvZiBQcm94eVxuXHRcdFx0XHRwLnByb3h5ID0gdHJ1ZTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gUE9TVCBib2R5IHRvIHF1ZXJ5c3RyaW5nXG5cdFx0XHRpZiAocC5kYXRhICYmIChwLm1ldGhvZCA9PT0gJ2dldCcgfHwgcC5tZXRob2QgPT09ICdkZWxldGUnKSkge1xuXHRcdFx0XHQvLyBBdHRhY2ggdGhlIHAuZGF0YSB0byB0aGUgcXVlcnlzdHJpbmcuXG5cdFx0XHRcdF90aGlzLmV4dGVuZChwLnF1ZXJ5LCBwLmRhdGEpO1xuXHRcdFx0XHRwLmRhdGEgPSBudWxsO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBDb25zdHJ1Y3QgdGhlIHBhdGhcblx0XHRcdHZhciBwYXRoID0gX3RoaXMucXMocC51cmwsIHAucXVlcnkpO1xuXG5cdFx0XHQvLyBQcm94eSB0aGUgcmVxdWVzdCB0aHJvdWdoIGEgc2VydmVyXG5cdFx0XHQvLyBVc2VkIGZvciBzaWduaW5nIE9BdXRoMVxuXHRcdFx0Ly8gQW5kIGNpcmN1bXZlbnRpbmcgc2VydmljZXMgd2l0aG91dCBBY2Nlc3MtQ29udHJvbCBIZWFkZXJzXG5cdFx0XHRpZiAocC5wcm94eSkge1xuXHRcdFx0XHQvLyBVc2UgdGhlIHByb3h5IGFzIGEgcGF0aFxuXHRcdFx0XHRwYXRoID0gX3RoaXMucXMocC5vYXV0aF9wcm94eSwge1xuXHRcdFx0XHRcdHBhdGg6IHBhdGgsXG5cdFx0XHRcdFx0YWNjZXNzX3Rva2VuOiBzaWduIHx8ICcnLFxuXG5cdFx0XHRcdFx0Ly8gVGhpcyB3aWxsIHByb21wdCB0aGUgcmVxdWVzdCB0byBiZSBzaWduZWQgYXMgdGhvdWdoIGl0IGlzIE9BdXRoMVxuXHRcdFx0XHRcdHRoZW46IHAucHJveHlfcmVzcG9uc2VfdHlwZSB8fCAocC5tZXRob2QudG9Mb3dlckNhc2UoKSA9PT0gJ2dldCcgPyAncmVkaXJlY3QnIDogJ3Byb3h5JyksXG5cdFx0XHRcdFx0bWV0aG9kOiBwLm1ldGhvZC50b0xvd2VyQ2FzZSgpLFxuXHRcdFx0XHRcdHN1cHByZXNzX3Jlc3BvbnNlX2NvZGVzOiB0cnVlXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXG5cdFx0XHRjYWxsYmFjayhwYXRoKTtcblx0XHR9XG5cdH0sXG5cblx0Ly8gVGVzdCB3aGV0aGVyIHRoZSBicm93c2VyIHN1cHBvcnRzIHRoZSBDT1JTIHJlc3BvbnNlXG5cdHJlcXVlc3RfY29yczogZnVuY3Rpb24oY2FsbGJhY2spIHtcblx0XHRyZXR1cm4gJ3dpdGhDcmVkZW50aWFscycgaW4gbmV3IFhNTEh0dHBSZXF1ZXN0KCkgJiYgY2FsbGJhY2soKTtcblx0fSxcblxuXHQvLyBSZXR1cm4gdGhlIHR5cGUgb2YgRE9NIG9iamVjdFxuXHRkb21JbnN0YW5jZTogZnVuY3Rpb24odHlwZSwgZGF0YSkge1xuXHRcdHZhciB0ZXN0ID0gJ0hUTUwnICsgKHR5cGUgfHwgJycpLnJlcGxhY2UoXG5cdFx0XHQvXlthLXpdLyxcblx0XHRcdGZ1bmN0aW9uKG0pIHtcblx0XHRcdFx0cmV0dXJuIG0udG9VcHBlckNhc2UoKTtcblx0XHRcdH1cblxuXHRcdCkgKyAnRWxlbWVudCc7XG5cblx0XHRpZiAoIWRhdGEpIHtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cblx0XHRpZiAod2luZG93W3Rlc3RdKSB7XG5cdFx0XHRyZXR1cm4gZGF0YSBpbnN0YW5jZW9mIHdpbmRvd1t0ZXN0XTtcblx0XHR9XG5cdFx0ZWxzZSBpZiAod2luZG93LkVsZW1lbnQpIHtcblx0XHRcdHJldHVybiBkYXRhIGluc3RhbmNlb2Ygd2luZG93LkVsZW1lbnQgJiYgKCF0eXBlIHx8IChkYXRhLnRhZ05hbWUgJiYgZGF0YS50YWdOYW1lLnRvTG93ZXJDYXNlKCkgPT09IHR5cGUpKTtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHRyZXR1cm4gKCEoZGF0YSBpbnN0YW5jZW9mIE9iamVjdCB8fCBkYXRhIGluc3RhbmNlb2YgQXJyYXkgfHwgZGF0YSBpbnN0YW5jZW9mIFN0cmluZyB8fCBkYXRhIGluc3RhbmNlb2YgTnVtYmVyKSAmJiBkYXRhLnRhZ05hbWUgJiYgZGF0YS50YWdOYW1lLnRvTG93ZXJDYXNlKCkgPT09IHR5cGUpO1xuXHRcdH1cblx0fSxcblxuXHQvLyBDcmVhdGUgYSBjbG9uZSBvZiBhbiBvYmplY3Rcblx0Y2xvbmU6IGZ1bmN0aW9uKG9iaikge1xuXHRcdC8vIERvZXMgbm90IGNsb25lIERPTSBlbGVtZW50cywgbm9yIEJpbmFyeSBkYXRhLCBlLmcuIEJsb2JzLCBGaWxlbGlzdHNcblx0XHRpZiAob2JqID09PSBudWxsIHx8IHR5cGVvZiAob2JqKSAhPT0gJ29iamVjdCcgfHwgb2JqIGluc3RhbmNlb2YgRGF0ZSB8fCAnbm9kZU5hbWUnIGluIG9iaiB8fCB0aGlzLmlzQmluYXJ5KG9iaikgfHwgKHR5cGVvZiBGb3JtRGF0YSA9PT0gJ2Z1bmN0aW9uJyAmJiBvYmogaW5zdGFuY2VvZiBGb3JtRGF0YSkpIHtcblx0XHRcdHJldHVybiBvYmo7XG5cdFx0fVxuXG5cdFx0aWYgKEFycmF5LmlzQXJyYXkob2JqKSkge1xuXHRcdFx0Ly8gQ2xvbmUgZWFjaCBpdGVtIGluIHRoZSBhcnJheVxuXHRcdFx0cmV0dXJuIG9iai5tYXAodGhpcy5jbG9uZS5iaW5kKHRoaXMpKTtcblx0XHR9XG5cblx0XHQvLyBCdXQgZG9lcyBjbG9uZSBldmVyeXRoaW5nIGVsc2UuXG5cdFx0dmFyIGNsb25lID0ge307XG5cdFx0Zm9yICh2YXIgeCBpbiBvYmopIHtcblx0XHRcdGNsb25lW3hdID0gdGhpcy5jbG9uZShvYmpbeF0pO1xuXHRcdH1cblxuXHRcdHJldHVybiBjbG9uZTtcblx0fSxcblxuXHQvLyBYSFI6IHVzZXMgQ09SUyB0byBtYWtlIHJlcXVlc3RzXG5cdHhocjogZnVuY3Rpb24obWV0aG9kLCB1cmwsIGhlYWRlcnMsIGRhdGEsIGNhbGxiYWNrKSB7XG5cblx0XHR2YXIgciA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuXHRcdHZhciBlcnJvciA9IHRoaXMuZXJyb3I7XG5cblx0XHQvLyBCaW5hcnk/XG5cdFx0dmFyIGJpbmFyeSA9IGZhbHNlO1xuXHRcdGlmIChtZXRob2QgPT09ICdibG9iJykge1xuXHRcdFx0YmluYXJ5ID0gbWV0aG9kO1xuXHRcdFx0bWV0aG9kID0gJ0dFVCc7XG5cdFx0fVxuXG5cdFx0bWV0aG9kID0gbWV0aG9kLnRvVXBwZXJDYXNlKCk7XG5cblx0XHQvLyBYaHIucmVzcG9uc2VUeXBlICdqc29uJyBpcyBub3Qgc3VwcG9ydGVkIGluIGFueSBvZiB0aGUgdmVuZG9ycyB5ZXQuXG5cdFx0ci5vbmxvYWQgPSBmdW5jdGlvbihlKSB7XG5cdFx0XHR2YXIganNvbiA9IHIucmVzcG9uc2U7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRqc29uID0gSlNPTi5wYXJzZShyLnJlc3BvbnNlVGV4dCk7XG5cdFx0XHR9XG5cdFx0XHRjYXRjaCAoX2UpIHtcblx0XHRcdFx0aWYgKHIuc3RhdHVzID09PSA0MDEpIHtcblx0XHRcdFx0XHRqc29uID0gZXJyb3IoJ2FjY2Vzc19kZW5pZWQnLCByLnN0YXR1c1RleHQpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdHZhciBoZWFkZXJzID0gaGVhZGVyc1RvSlNPTihyLmdldEFsbFJlc3BvbnNlSGVhZGVycygpKTtcblx0XHRcdGhlYWRlcnMuc3RhdHVzQ29kZSA9IHIuc3RhdHVzO1xuXG5cdFx0XHRjYWxsYmFjayhqc29uIHx8IChtZXRob2QgPT09ICdHRVQnID8gZXJyb3IoJ2VtcHR5X3Jlc3BvbnNlJywgJ0NvdWxkIG5vdCBnZXQgcmVzb3VyY2UnKSA6IHt9KSwgaGVhZGVycyk7XG5cdFx0fTtcblxuXHRcdHIub25lcnJvciA9IGZ1bmN0aW9uKGUpIHtcblx0XHRcdHZhciBqc29uID0gci5yZXNwb25zZVRleHQ7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRqc29uID0gSlNPTi5wYXJzZShyLnJlc3BvbnNlVGV4dCk7XG5cdFx0XHR9XG5cdFx0XHRjYXRjaCAoX2UpIHt9XG5cblx0XHRcdGNhbGxiYWNrKGpzb24gfHwgZXJyb3IoJ2FjY2Vzc19kZW5pZWQnLCAnQ291bGQgbm90IGdldCByZXNvdXJjZScpKTtcblx0XHR9O1xuXG5cdFx0dmFyIHg7XG5cblx0XHQvLyBTaG91bGQgd2UgYWRkIHRoZSBxdWVyeSB0byB0aGUgVVJMP1xuXHRcdGlmIChtZXRob2QgPT09ICdHRVQnIHx8IG1ldGhvZCA9PT0gJ0RFTEVURScpIHtcblx0XHRcdGRhdGEgPSBudWxsO1xuXHRcdH1cblx0XHRlbHNlIGlmIChkYXRhICYmIHR5cGVvZiAoZGF0YSkgIT09ICdzdHJpbmcnICYmICEoZGF0YSBpbnN0YW5jZW9mIEZvcm1EYXRhKSAmJiAhKGRhdGEgaW5zdGFuY2VvZiBGaWxlKSAmJiAhKGRhdGEgaW5zdGFuY2VvZiBCbG9iKSkge1xuXHRcdFx0Ly8gTG9vcCB0aHJvdWdoIGFuZCBhZGQgZm9ybURhdGFcblx0XHRcdHZhciBmID0gbmV3IEZvcm1EYXRhKCk7XG5cdFx0XHRmb3IgKHggaW4gZGF0YSkgaWYgKGRhdGEuaGFzT3duUHJvcGVydHkoeCkpIHtcblx0XHRcdFx0aWYgKGRhdGFbeF0gaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSB7XG5cdFx0XHRcdFx0aWYgKCdmaWxlcycgaW4gZGF0YVt4XSAmJiBkYXRhW3hdLmZpbGVzLmxlbmd0aCA+IDApIHtcblx0XHRcdFx0XHRcdGYuYXBwZW5kKHgsIGRhdGFbeF0uZmlsZXNbMF0pO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRlbHNlIGlmIChkYXRhW3hdIGluc3RhbmNlb2YgQmxvYikge1xuXHRcdFx0XHRcdGYuYXBwZW5kKHgsIGRhdGFbeF0sIGRhdGEubmFtZSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Zi5hcHBlbmQoeCwgZGF0YVt4XSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0ZGF0YSA9IGY7XG5cdFx0fVxuXG5cdFx0Ly8gT3BlbiB0aGUgcGF0aCwgYXN5bmNcblx0XHRyLm9wZW4obWV0aG9kLCB1cmwsIHRydWUpO1xuXG5cdFx0aWYgKGJpbmFyeSkge1xuXHRcdFx0aWYgKCdyZXNwb25zZVR5cGUnIGluIHIpIHtcblx0XHRcdFx0ci5yZXNwb25zZVR5cGUgPSBiaW5hcnk7XG5cdFx0XHR9XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0ci5vdmVycmlkZU1pbWVUeXBlKCd0ZXh0L3BsYWluOyBjaGFyc2V0PXgtdXNlci1kZWZpbmVkJyk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gU2V0IGFueSBiZXNwb2tlIGhlYWRlcnNcblx0XHRpZiAoaGVhZGVycykge1xuXHRcdFx0Zm9yICh4IGluIGhlYWRlcnMpIHtcblx0XHRcdFx0ci5zZXRSZXF1ZXN0SGVhZGVyKHgsIGhlYWRlcnNbeF0pO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHIuc2VuZChkYXRhKTtcblxuXHRcdHJldHVybiByO1xuXG5cdFx0Ly8gSGVhZGVycyBhcmUgcmV0dXJuZWQgYXMgYSBzdHJpbmdcblx0XHRmdW5jdGlvbiBoZWFkZXJzVG9KU09OKHMpIHtcblx0XHRcdHZhciByID0ge307XG5cdFx0XHR2YXIgcmVnID0gLyhbYS16XFwtXSspOlxccz8oLiopOz8vZ2k7XG5cdFx0XHR2YXIgbTtcblx0XHRcdHdoaWxlICgobSA9IHJlZy5leGVjKHMpKSkge1xuXHRcdFx0XHRyW21bMV1dID0gbVsyXTtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHI7XG5cdFx0fVxuXHR9LFxuXG5cdC8vIEpTT05QXG5cdC8vIEluamVjdHMgYSBzY3JpcHQgdGFnIGludG8gdGhlIERPTSB0byBiZSBleGVjdXRlZCBhbmQgYXBwZW5kcyBhIGNhbGxiYWNrIGZ1bmN0aW9uIHRvIHRoZSB3aW5kb3cgb2JqZWN0XG5cdC8vIEBwYXJhbSBzdHJpbmcvZnVuY3Rpb24gcGF0aEZ1bmMgZWl0aGVyIGEgc3RyaW5nIG9mIHRoZSBVUkwgb3IgYSBjYWxsYmFjayBmdW5jdGlvbiBwYXRoRnVuYyhxdWVyeXN0cmluZ2hhc2gsIGNvbnRpbnVlRnVuYyk7XG5cdC8vIEBwYXJhbSBmdW5jdGlvbiBjYWxsYmFjayBhIGZ1bmN0aW9uIHRvIGNhbGwgb24gY29tcGxldGlvbjtcblx0anNvbnA6IGZ1bmN0aW9uKHVybCwgY2FsbGJhY2ssIGNhbGxiYWNrSUQsIHRpbWVvdXQpIHtcblxuXHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0dmFyIGVycm9yID0gX3RoaXMuZXJyb3I7XG5cblx0XHQvLyBDaGFuZ2UgdGhlIG5hbWUgb2YgdGhlIGNhbGxiYWNrXG5cdFx0dmFyIGJvb2wgPSAwO1xuXHRcdHZhciBoZWFkID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTtcblx0XHR2YXIgb3BlcmFGaXg7XG5cdFx0dmFyIHJlc3VsdCA9IGVycm9yKCdzZXJ2ZXJfZXJyb3InLCAnc2VydmVyX2Vycm9yJyk7XG5cdFx0dmFyIGNiID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRpZiAoIShib29sKyspKSB7XG5cdFx0XHRcdHdpbmRvdy5zZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRcdGNhbGxiYWNrKHJlc3VsdCk7XG5cdFx0XHRcdFx0aGVhZC5yZW1vdmVDaGlsZChzY3JpcHQpO1xuXHRcdFx0XHR9LCAwKTtcblx0XHRcdH1cblxuXHRcdH07XG5cblx0XHQvLyBBZGQgY2FsbGJhY2sgdG8gdGhlIHdpbmRvdyBvYmplY3Rcblx0XHRjYWxsYmFja0lEID0gX3RoaXMuZ2xvYmFsRXZlbnQoZnVuY3Rpb24oanNvbikge1xuXHRcdFx0cmVzdWx0ID0ganNvbjtcblx0XHRcdHJldHVybiB0cnVlO1xuXG5cdFx0XHQvLyBNYXJrIGNhbGxiYWNrIGFzIGRvbmVcblx0XHR9LCBjYWxsYmFja0lEKTtcblxuXHRcdC8vIFRoZSBVUkwgaXMgYSBmdW5jdGlvbiBmb3Igc29tZSBjYXNlcyBhbmQgYXMgc3VjaFxuXHRcdC8vIERldGVybWluZSBpdHMgdmFsdWUgd2l0aCBhIGNhbGxiYWNrIGNvbnRhaW5pbmcgdGhlIG5ldyBwYXJhbWV0ZXJzIG9mIHRoaXMgZnVuY3Rpb24uXG5cdFx0dXJsID0gdXJsLnJlcGxhY2UobmV3IFJlZ0V4cCgnPVxcXFw/KCZ8JCknKSwgJz0nICsgY2FsbGJhY2tJRCArICckMScpO1xuXG5cdFx0Ly8gQnVpbGQgc2NyaXB0IHRhZ1xuXHRcdHZhciBzY3JpcHQgPSBfdGhpcy5hcHBlbmQoJ3NjcmlwdCcsIHtcblx0XHRcdGlkOiBjYWxsYmFja0lELFxuXHRcdFx0bmFtZTogY2FsbGJhY2tJRCxcblx0XHRcdHNyYzogdXJsLFxuXHRcdFx0YXN5bmM6IHRydWUsXG5cdFx0XHRvbmxvYWQ6IGNiLFxuXHRcdFx0b25lcnJvcjogY2IsXG5cdFx0XHRvbnJlYWR5c3RhdGVjaGFuZ2U6IGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRpZiAoL2xvYWRlZHxjb21wbGV0ZS9pLnRlc3QodGhpcy5yZWFkeVN0YXRlKSkge1xuXHRcdFx0XHRcdGNiKCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblxuXHRcdC8vIE9wZXJhIGZpeCBlcnJvclxuXHRcdC8vIFByb2JsZW06IElmIGFuIGVycm9yIG9jY3VycyB3aXRoIHNjcmlwdCBsb2FkaW5nIE9wZXJhIGZhaWxzIHRvIHRyaWdnZXIgdGhlIHNjcmlwdC5vbmVycm9yIGhhbmRsZXIgd2Ugc3BlY2lmaWVkXG5cdFx0Ly9cblx0XHQvLyBGaXg6XG5cdFx0Ly8gQnkgc2V0dGluZyB0aGUgcmVxdWVzdCB0byBzeW5jaHJvbm91cyB3ZSBjYW4gdHJpZ2dlciB0aGUgZXJyb3IgaGFuZGxlciB3aGVuIGFsbCBlbHNlIGZhaWxzLlxuXHRcdC8vIFRoaXMgYWN0aW9uIHdpbGwgYmUgaWdub3JlZCBpZiB3ZSd2ZSBhbHJlYWR5IGNhbGxlZCB0aGUgY2FsbGJhY2sgaGFuZGxlciBcImNiXCIgd2l0aCBhIHN1Y2Nlc3NmdWwgb25sb2FkIGV2ZW50XG5cdFx0aWYgKHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkuaW5kZXhPZignb3BlcmEnKSA+IC0xKSB7XG5cdFx0XHRvcGVyYUZpeCA9IF90aGlzLmFwcGVuZCgnc2NyaXB0Jywge1xuXHRcdFx0XHR0ZXh0OiAnZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXFwnJyArIGNhbGxiYWNrSUQgKyAnXFwnKS5vbmVycm9yKCk7J1xuXHRcdFx0fSk7XG5cdFx0XHRzY3JpcHQuYXN5bmMgPSBmYWxzZTtcblx0XHR9XG5cblx0XHQvLyBBZGQgdGltZW91dFxuXHRcdGlmICh0aW1lb3V0KSB7XG5cdFx0XHR3aW5kb3cuc2V0VGltZW91dChmdW5jdGlvbigpIHtcblx0XHRcdFx0cmVzdWx0ID0gZXJyb3IoJ3RpbWVvdXQnLCAndGltZW91dCcpO1xuXHRcdFx0XHRjYigpO1xuXHRcdFx0fSwgdGltZW91dCk7XG5cdFx0fVxuXG5cdFx0Ly8gVE9ETzogYWRkIGZpeCBmb3IgSUUsXG5cdFx0Ly8gSG93ZXZlcjogdW5hYmxlIHJlY3JlYXRlIHRoZSBidWcgb2YgZmlyaW5nIG9mZiB0aGUgb25yZWFkeXN0YXRlY2hhbmdlIGJlZm9yZSB0aGUgc2NyaXB0IGNvbnRlbnQgaGFzIGJlZW4gZXhlY3V0ZWQgYW5kIHRoZSB2YWx1ZSBvZiBcInJlc3VsdFwiIGhhcyBiZWVuIGRlZmluZWQuXG5cdFx0Ly8gSW5qZWN0IHNjcmlwdCB0YWcgaW50byB0aGUgaGVhZCBlbGVtZW50XG5cdFx0aGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xuXG5cdFx0Ly8gQXBwZW5kIE9wZXJhIEZpeCB0byBydW4gYWZ0ZXIgb3VyIHNjcmlwdFxuXHRcdGlmIChvcGVyYUZpeCkge1xuXHRcdFx0aGVhZC5hcHBlbmRDaGlsZChvcGVyYUZpeCk7XG5cdFx0fVxuXHR9LFxuXG5cdC8vIFBvc3Rcblx0Ly8gU2VuZCBpbmZvcm1hdGlvbiB0byBhIHJlbW90ZSBsb2NhdGlvbiB1c2luZyB0aGUgcG9zdCBtZWNoYW5pc21cblx0Ly8gQHBhcmFtIHN0cmluZyB1cmkgcGF0aFxuXHQvLyBAcGFyYW0gb2JqZWN0IGRhdGEsIGtleSB2YWx1ZSBkYXRhIHRvIHNlbmRcblx0Ly8gQHBhcmFtIGZ1bmN0aW9uIGNhbGxiYWNrLCBmdW5jdGlvbiB0byBleGVjdXRlIGluIHJlc3BvbnNlXG5cdHBvc3Q6IGZ1bmN0aW9uKHVybCwgZGF0YSwgb3B0aW9ucywgY2FsbGJhY2ssIGNhbGxiYWNrSUQsIHRpbWVvdXQpIHtcblxuXHRcdHZhciBfdGhpcyA9IHRoaXM7XG5cdFx0dmFyIGVycm9yID0gX3RoaXMuZXJyb3I7XG5cdFx0dmFyIGRvYyA9IGRvY3VtZW50O1xuXG5cdFx0Ly8gVGhpcyBoYWNrIG5lZWRzIGEgZm9ybVxuXHRcdHZhciBmb3JtID0gbnVsbDtcblx0XHR2YXIgcmVlbmFibGVBZnRlclN1Ym1pdCA9IFtdO1xuXHRcdHZhciBuZXdmb3JtO1xuXHRcdHZhciBpID0gMDtcblx0XHR2YXIgeCA9IG51bGw7XG5cdFx0dmFyIGJvb2wgPSAwO1xuXHRcdHZhciBjYiA9IGZ1bmN0aW9uKHIpIHtcblx0XHRcdGlmICghKGJvb2wrKykpIHtcblx0XHRcdFx0Y2FsbGJhY2socik7XG5cdFx0XHR9XG5cdFx0fTtcblxuXHRcdC8vIFdoYXQgaXMgdGhlIG5hbWUgb2YgdGhlIGNhbGxiYWNrIHRvIGNvbnRhaW5cblx0XHQvLyBXZSdsbCBhbHNvIHVzZSB0aGlzIHRvIG5hbWUgdGhlIGlmcmFtZVxuXHRcdF90aGlzLmdsb2JhbEV2ZW50KGNiLCBjYWxsYmFja0lEKTtcblxuXHRcdC8vIEJ1aWxkIHRoZSBpZnJhbWUgd2luZG93XG5cdFx0dmFyIHdpbjtcblx0XHR0cnkge1xuXHRcdFx0Ly8gSUU3IGhhY2ssIG9ubHkgbGV0cyB1cyBkZWZpbmUgdGhlIG5hbWUgaGVyZSwgbm90IGxhdGVyLlxuXHRcdFx0d2luID0gZG9jLmNyZWF0ZUVsZW1lbnQoJzxpZnJhbWUgbmFtZT1cIicgKyBjYWxsYmFja0lEICsgJ1wiPicpO1xuXHRcdH1cblx0XHRjYXRjaCAoZSkge1xuXHRcdFx0d2luID0gZG9jLmNyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xuXHRcdH1cblxuXHRcdHdpbi5uYW1lID0gY2FsbGJhY2tJRDtcblx0XHR3aW4uaWQgPSBjYWxsYmFja0lEO1xuXHRcdHdpbi5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuXG5cdFx0Ly8gT3ZlcnJpZGUgY2FsbGJhY2sgbWVjaGFuaXNtLiBUcmlnZ2dlciBhIHJlc3BvbnNlIG9ubG9hZC9vbmVycm9yXG5cdFx0aWYgKG9wdGlvbnMgJiYgb3B0aW9ucy5jYWxsYmFja29ubG9hZCkge1xuXHRcdFx0Ly8gT25sb2FkIGlzIGJlaW5nIGZpcmVkIHR3aWNlXG5cdFx0XHR3aW4ub25sb2FkID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRcdGNiKHtcblx0XHRcdFx0XHRyZXNwb25zZTogJ3Bvc3RlZCcsXG5cdFx0XHRcdFx0bWVzc2FnZTogJ0NvbnRlbnQgd2FzIHBvc3RlZCdcblx0XHRcdFx0fSk7XG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aW1lb3V0KSB7XG5cdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRjYihlcnJvcigndGltZW91dCcsICdUaGUgcG9zdCBvcGVyYXRpb24gdGltZWQgb3V0JykpO1xuXHRcdFx0fSwgdGltZW91dCk7XG5cdFx0fVxuXG5cdFx0ZG9jLmJvZHkuYXBwZW5kQ2hpbGQod2luKTtcblxuXHRcdC8vIElmIHdlIGFyZSBqdXN0IHBvc3RpbmcgYSBzaW5nbGUgaXRlbVxuXHRcdGlmIChfdGhpcy5kb21JbnN0YW5jZSgnZm9ybScsIGRhdGEpKSB7XG5cdFx0XHQvLyBHZXQgdGhlIHBhcmVudCBmb3JtXG5cdFx0XHRmb3JtID0gZGF0YS5mb3JtO1xuXG5cdFx0XHQvLyBMb29wIHRocm91Z2ggYW5kIGRpc2FibGUgYWxsIG9mIGl0cyBzaWJsaW5nc1xuXHRcdFx0Zm9yIChpID0gMDsgaSA8IGZvcm0uZWxlbWVudHMubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0aWYgKGZvcm0uZWxlbWVudHNbaV0gIT09IGRhdGEpIHtcblx0XHRcdFx0XHRmb3JtLmVsZW1lbnRzW2ldLnNldEF0dHJpYnV0ZSgnZGlzYWJsZWQnLCB0cnVlKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBNb3ZlIHRoZSBmb2N1cyB0byB0aGUgZm9ybVxuXHRcdFx0ZGF0YSA9IGZvcm07XG5cdFx0fVxuXG5cdFx0Ly8gUG9zdGluZyBhIGZvcm1cblx0XHRpZiAoX3RoaXMuZG9tSW5zdGFuY2UoJ2Zvcm0nLCBkYXRhKSkge1xuXHRcdFx0Ly8gVGhpcyBpcyBhIGZvcm0gZWxlbWVudFxuXHRcdFx0Zm9ybSA9IGRhdGE7XG5cblx0XHRcdC8vIERvZXMgdGhpcyBmb3JtIG5lZWQgdG8gYmUgYSBtdWx0aXBhcnQgZm9ybT9cblx0XHRcdGZvciAoaSA9IDA7IGkgPCBmb3JtLmVsZW1lbnRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdGlmICghZm9ybS5lbGVtZW50c1tpXS5kaXNhYmxlZCAmJiBmb3JtLmVsZW1lbnRzW2ldLnR5cGUgPT09ICdmaWxlJykge1xuXHRcdFx0XHRcdGZvcm0uZW5jb2RpbmcgPSBmb3JtLmVuY3R5cGUgPSAnbXVsdGlwYXJ0L2Zvcm0tZGF0YSc7XG5cdFx0XHRcdFx0Zm9ybS5lbGVtZW50c1tpXS5zZXRBdHRyaWJ1dGUoJ25hbWUnLCAnZmlsZScpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0Ly8gSXRzIG5vdCBhIGZvcm0gZWxlbWVudCxcblx0XHRcdC8vIFRoZXJlZm9yZSBpdCBtdXN0IGJlIGEgSlNPTiBvYmplY3Qgb2YgS2V5PT5WYWx1ZSBvciBLZXk9PkVsZW1lbnRcblx0XHRcdC8vIElmIGFueW9uZSBvZiB0aG9zZSB2YWx1ZXMgYXJlIGEgaW5wdXQgdHlwZT1maWxlIHdlIHNoYWxsIHNoYWxsIGluc2VydCBpdHMgc2libGluZ3MgaW50byB0aGUgZm9ybSBmb3Igd2hpY2ggaXQgYmVsb25ncy5cblx0XHRcdGZvciAoeCBpbiBkYXRhKSBpZiAoZGF0YS5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0XHQvLyBJcyB0aGlzIGFuIGlucHV0IEVsZW1lbnQ/XG5cdFx0XHRcdGlmIChfdGhpcy5kb21JbnN0YW5jZSgnaW5wdXQnLCBkYXRhW3hdKSAmJiBkYXRhW3hdLnR5cGUgPT09ICdmaWxlJykge1xuXHRcdFx0XHRcdGZvcm0gPSBkYXRhW3hdLmZvcm07XG5cdFx0XHRcdFx0Zm9ybS5lbmNvZGluZyA9IGZvcm0uZW5jdHlwZSA9ICdtdWx0aXBhcnQvZm9ybS1kYXRhJztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBEbyBJZiB0aGVyZSBpcyBubyBkZWZpbmVkIGZvcm0gZWxlbWVudCwgbGV0cyBjcmVhdGUgb25lLlxuXHRcdFx0aWYgKCFmb3JtKSB7XG5cdFx0XHRcdC8vIEJ1aWxkIGZvcm1cblx0XHRcdFx0Zm9ybSA9IGRvYy5jcmVhdGVFbGVtZW50KCdmb3JtJyk7XG5cdFx0XHRcdGRvYy5ib2R5LmFwcGVuZENoaWxkKGZvcm0pO1xuXHRcdFx0XHRuZXdmb3JtID0gZm9ybTtcblx0XHRcdH1cblxuXHRcdFx0dmFyIGlucHV0O1xuXG5cdFx0XHQvLyBBZGQgZWxlbWVudHMgdG8gdGhlIGZvcm0gaWYgdGhleSBkb250IGV4aXN0XG5cdFx0XHRmb3IgKHggaW4gZGF0YSkgaWYgKGRhdGEuaGFzT3duUHJvcGVydHkoeCkpIHtcblxuXHRcdFx0XHQvLyBJcyB0aGlzIGFuIGVsZW1lbnQ/XG5cdFx0XHRcdHZhciBlbCA9IChfdGhpcy5kb21JbnN0YW5jZSgnaW5wdXQnLCBkYXRhW3hdKSB8fCBfdGhpcy5kb21JbnN0YW5jZSgndGV4dEFyZWEnLCBkYXRhW3hdKSB8fCBfdGhpcy5kb21JbnN0YW5jZSgnc2VsZWN0JywgZGF0YVt4XSkpO1xuXG5cdFx0XHRcdC8vIElzIHRoaXMgbm90IGFuIGlucHV0IGVsZW1lbnQsIG9yIG9uZSB0aGF0IGV4aXN0cyBvdXRzaWRlIHRoZSBmb3JtLlxuXHRcdFx0XHRpZiAoIWVsIHx8IGRhdGFbeF0uZm9ybSAhPT0gZm9ybSkge1xuXG5cdFx0XHRcdFx0Ly8gRG9lcyBhbiBlbGVtZW50IGhhdmUgdGhlIHNhbWUgbmFtZT9cblx0XHRcdFx0XHR2YXIgaW5wdXRzID0gZm9ybS5lbGVtZW50c1t4XTtcblx0XHRcdFx0XHRpZiAoaW5wdXQpIHtcblx0XHRcdFx0XHRcdC8vIFJlbW92ZSBpdC5cblx0XHRcdFx0XHRcdGlmICghKGlucHV0cyBpbnN0YW5jZW9mIE5vZGVMaXN0KSkge1xuXHRcdFx0XHRcdFx0XHRpbnB1dHMgPSBbaW5wdXRzXTtcblx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0Zm9yIChpID0gMDsgaSA8IGlucHV0cy5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHRcdFx0XHRpbnB1dHNbaV0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChpbnB1dHNbaV0pO1xuXHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Ly8gQ3JlYXRlIGFuIGlucHV0IGVsZW1lbnRcblx0XHRcdFx0XHRpbnB1dCA9IGRvYy5jcmVhdGVFbGVtZW50KCdpbnB1dCcpO1xuXHRcdFx0XHRcdGlucHV0LnNldEF0dHJpYnV0ZSgndHlwZScsICdoaWRkZW4nKTtcblx0XHRcdFx0XHRpbnB1dC5zZXRBdHRyaWJ1dGUoJ25hbWUnLCB4KTtcblxuXHRcdFx0XHRcdC8vIERvZXMgaXQgaGF2ZSBhIHZhbHVlIGF0dHJpYnV0ZT9cblx0XHRcdFx0XHRpZiAoZWwpIHtcblx0XHRcdFx0XHRcdGlucHV0LnZhbHVlID0gZGF0YVt4XS52YWx1ZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZWxzZSBpZiAoX3RoaXMuZG9tSW5zdGFuY2UobnVsbCwgZGF0YVt4XSkpIHtcblx0XHRcdFx0XHRcdGlucHV0LnZhbHVlID0gZGF0YVt4XS5pbm5lckhUTUwgfHwgZGF0YVt4XS5pbm5lclRleHQ7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdFx0aW5wdXQudmFsdWUgPSBkYXRhW3hdO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGZvcm0uYXBwZW5kQ2hpbGQoaW5wdXQpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gSXQgaXMgYW4gZWxlbWVudCwgd2hpY2ggZXhpc3RzIHdpdGhpbiB0aGUgZm9ybSwgYnV0IHRoZSBuYW1lIGlzIHdyb25nXG5cdFx0XHRcdGVsc2UgaWYgKGVsICYmIGRhdGFbeF0ubmFtZSAhPT0geCkge1xuXHRcdFx0XHRcdGRhdGFbeF0uc2V0QXR0cmlidXRlKCduYW1lJywgeCk7XG5cdFx0XHRcdFx0ZGF0YVt4XS5uYW1lID0geDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBEaXNhYmxlIGVsZW1lbnRzIGZyb20gd2l0aGluIHRoZSBmb3JtIGlmIHRoZXkgd2VyZW4ndCBzcGVjaWZpZWRcblx0XHRcdGZvciAoaSA9IDA7IGkgPCBmb3JtLmVsZW1lbnRzLmxlbmd0aDsgaSsrKSB7XG5cblx0XHRcdFx0aW5wdXQgPSBmb3JtLmVsZW1lbnRzW2ldO1xuXG5cdFx0XHRcdC8vIERvZXMgdGhlIHNhbWUgbmFtZSBhbmQgdmFsdWUgZXhpc3QgaW4gdGhlIHBhcmVudFxuXHRcdFx0XHRpZiAoIShpbnB1dC5uYW1lIGluIGRhdGEpICYmIGlucHV0LmdldEF0dHJpYnV0ZSgnZGlzYWJsZWQnKSAhPT0gdHJ1ZSkge1xuXHRcdFx0XHRcdC8vIERpc2FibGVcblx0XHRcdFx0XHRpbnB1dC5zZXRBdHRyaWJ1dGUoJ2Rpc2FibGVkJywgdHJ1ZSk7XG5cblx0XHRcdFx0XHQvLyBBZGQgcmUtZW5hYmxlIHRvIGNhbGxiYWNrXG5cdFx0XHRcdFx0cmVlbmFibGVBZnRlclN1Ym1pdC5wdXNoKGlucHV0KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFNldCB0aGUgdGFyZ2V0IG9mIHRoZSBmb3JtXG5cdFx0Zm9ybS5zZXRBdHRyaWJ1dGUoJ21ldGhvZCcsICdQT1NUJyk7XG5cdFx0Zm9ybS5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsIGNhbGxiYWNrSUQpO1xuXHRcdGZvcm0udGFyZ2V0ID0gY2FsbGJhY2tJRDtcblxuXHRcdC8vIFVwZGF0ZSB0aGUgZm9ybSBVUkxcblx0XHRmb3JtLnNldEF0dHJpYnV0ZSgnYWN0aW9uJywgdXJsKTtcblxuXHRcdC8vIFN1Ym1pdCB0aGUgZm9ybVxuXHRcdC8vIFNvbWUgcmVhc29uIHRoaXMgbmVlZHMgdG8gYmUgb2Zmc2V0IGZyb20gdGhlIGN1cnJlbnQgd2luZG93IGV4ZWN1dGlvblxuXHRcdHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG5cdFx0XHRmb3JtLnN1Ym1pdCgpO1xuXG5cdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdC8vIFJlbW92ZSB0aGUgaWZyYW1lIGZyb20gdGhlIHBhZ2UuXG5cdFx0XHRcdFx0Ly93aW4ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZCh3aW4pO1xuXHRcdFx0XHRcdC8vIFJlbW92ZSB0aGUgZm9ybVxuXHRcdFx0XHRcdGlmIChuZXdmb3JtKSB7XG5cdFx0XHRcdFx0XHRuZXdmb3JtLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQobmV3Zm9ybSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdGNvbnNvbGUuZXJyb3IoJ0hlbGxvSlM6IGNvdWxkIG5vdCByZW1vdmUgaWZyYW1lJyk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNhdGNoIChlZSkge31cblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJlZW5hYmxlIHRoZSBkaXNhYmxlZCBmb3JtXG5cdFx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgcmVlbmFibGVBZnRlclN1Ym1pdC5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHRcdGlmIChyZWVuYWJsZUFmdGVyU3VibWl0W2ldKSB7XG5cdFx0XHRcdFx0XHRyZWVuYWJsZUFmdGVyU3VibWl0W2ldLnNldEF0dHJpYnV0ZSgnZGlzYWJsZWQnLCBmYWxzZSk7XG5cdFx0XHRcdFx0XHRyZWVuYWJsZUFmdGVyU3VibWl0W2ldLmRpc2FibGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9LCAwKTtcblx0XHR9LCAxMDApO1xuXHR9LFxuXG5cdC8vIFNvbWUgb2YgdGhlIHByb3ZpZGVycyByZXF1aXJlIHRoYXQgb25seSBtdWx0aXBhcnQgaXMgdXNlZCB3aXRoIG5vbi1iaW5hcnkgZm9ybXMuXG5cdC8vIFRoaXMgZnVuY3Rpb24gY2hlY2tzIHdoZXRoZXIgdGhlIGZvcm0gY29udGFpbnMgYmluYXJ5IGRhdGFcblx0aGFzQmluYXJ5OiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0Zm9yICh2YXIgeCBpbiBkYXRhKSBpZiAoZGF0YS5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuXHRcdFx0aWYgKHRoaXMuaXNCaW5hcnkoZGF0YVt4XSkpIHtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdC8vIERldGVybWluZXMgaWYgYSB2YXJpYWJsZSBFaXRoZXIgSXMgb3IgbGlrZSBhIEZvcm1JbnB1dCBoYXMgdGhlIHZhbHVlIG9mIGEgQmxvYlxuXG5cdGlzQmluYXJ5OiBmdW5jdGlvbihkYXRhKSB7XG5cblx0XHRyZXR1cm4gZGF0YSBpbnN0YW5jZW9mIE9iamVjdCAmJiAoXG5cdFx0KHRoaXMuZG9tSW5zdGFuY2UoJ2lucHV0JywgZGF0YSkgJiYgZGF0YS50eXBlID09PSAnZmlsZScpIHx8XG5cdFx0KCdGaWxlTGlzdCcgaW4gd2luZG93ICYmIGRhdGEgaW5zdGFuY2VvZiB3aW5kb3cuRmlsZUxpc3QpIHx8XG5cdFx0KCdGaWxlJyBpbiB3aW5kb3cgJiYgZGF0YSBpbnN0YW5jZW9mIHdpbmRvdy5GaWxlKSB8fFxuXHRcdCgnQmxvYicgaW4gd2luZG93ICYmIGRhdGEgaW5zdGFuY2VvZiB3aW5kb3cuQmxvYikpO1xuXG5cdH0sXG5cblx0Ly8gQ29udmVydCBEYXRhLVVSSSB0byBCbG9iIHN0cmluZ1xuXHR0b0Jsb2I6IGZ1bmN0aW9uKGRhdGFVUkkpIHtcblx0XHR2YXIgcmVnID0gL15kYXRhXFw6KFteOyxdKyhcXDtjaGFyc2V0PVteOyxdKyk/KShcXDtiYXNlNjQpPywvaTtcblx0XHR2YXIgbSA9IGRhdGFVUkkubWF0Y2gocmVnKTtcblx0XHRpZiAoIW0pIHtcblx0XHRcdHJldHVybiBkYXRhVVJJO1xuXHRcdH1cblxuXHRcdHZhciBiaW5hcnkgPSBhdG9iKGRhdGFVUkkucmVwbGFjZShyZWcsICcnKSk7XG5cdFx0dmFyIGFycmF5ID0gW107XG5cdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBiaW5hcnkubGVuZ3RoOyBpKyspIHtcblx0XHRcdGFycmF5LnB1c2goYmluYXJ5LmNoYXJDb2RlQXQoaSkpO1xuXHRcdH1cblxuXHRcdHJldHVybiBuZXcgQmxvYihbbmV3IFVpbnQ4QXJyYXkoYXJyYXkpXSwge3R5cGU6IG1bMV19KTtcblx0fVxuXG59KTtcblxuLy8gRVhUUkE6IENvbnZlcnQgRm9ybUVsZW1lbnQgdG8gSlNPTiBmb3IgUE9TVGluZ1xuLy8gV3JhcHBlcnMgdG8gYWRkIGFkZGl0aW9uYWwgZnVuY3Rpb25hbGl0eSB0byBleGlzdGluZyBmdW5jdGlvbnNcbihmdW5jdGlvbihoZWxsbykge1xuXG5cdC8vIENvcHkgb3JpZ2luYWwgZnVuY3Rpb25cblx0dmFyIGFwaSA9IGhlbGxvLmFwaTtcblx0dmFyIHV0aWxzID0gaGVsbG8udXRpbHM7XG5cblx0dXRpbHMuZXh0ZW5kKHV0aWxzLCB7XG5cblx0XHQvLyBEYXRhVG9KU09OXG5cdFx0Ly8gVGhpcyB0YWtlcyBhIEZvcm1FbGVtZW50fE5vZGVMaXN0fElucHV0RWxlbWVudHxNaXhlZE9iamVjdHMgYW5kIGNvbnZlcnMgdGhlIGRhdGEgb2JqZWN0IHRvIEpTT04uXG5cdFx0ZGF0YVRvSlNPTjogZnVuY3Rpb24ocCkge1xuXG5cdFx0XHR2YXIgX3RoaXMgPSB0aGlzO1xuXHRcdFx0dmFyIHcgPSB3aW5kb3c7XG5cdFx0XHR2YXIgZGF0YSA9IHAuZGF0YTtcblxuXHRcdFx0Ly8gSXMgZGF0YSBhIGZvcm0gb2JqZWN0XG5cdFx0XHRpZiAoX3RoaXMuZG9tSW5zdGFuY2UoJ2Zvcm0nLCBkYXRhKSkge1xuXHRcdFx0XHRkYXRhID0gX3RoaXMubm9kZUxpc3RUb0pTT04oZGF0YS5lbGVtZW50cyk7XG5cdFx0XHR9XG5cdFx0XHRlbHNlIGlmICgnTm9kZUxpc3QnIGluIHcgJiYgZGF0YSBpbnN0YW5jZW9mIE5vZGVMaXN0KSB7XG5cdFx0XHRcdGRhdGEgPSBfdGhpcy5ub2RlTGlzdFRvSlNPTihkYXRhKTtcblx0XHRcdH1cblx0XHRcdGVsc2UgaWYgKF90aGlzLmRvbUluc3RhbmNlKCdpbnB1dCcsIGRhdGEpKSB7XG5cdFx0XHRcdGRhdGEgPSBfdGhpcy5ub2RlTGlzdFRvSlNPTihbZGF0YV0pO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBJcyBkYXRhIGEgYmxvYiwgRmlsZSwgRmlsZUxpc3Q/XG5cdFx0XHRpZiAoKCdGaWxlJyBpbiB3ICYmIGRhdGEgaW5zdGFuY2VvZiB3LkZpbGUpIHx8XG5cdFx0XHRcdCgnQmxvYicgaW4gdyAmJiBkYXRhIGluc3RhbmNlb2Ygdy5CbG9iKSB8fFxuXHRcdFx0XHQoJ0ZpbGVMaXN0JyBpbiB3ICYmIGRhdGEgaW5zdGFuY2VvZiB3LkZpbGVMaXN0KSkge1xuXHRcdFx0XHRkYXRhID0ge2ZpbGU6IGRhdGF9O1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBMb29wIHRocm91Z2ggZGF0YSBpZiBpdCdzIG5vdCBmb3JtIGRhdGEgaXQgbXVzdCBub3cgYmUgYSBKU09OIG9iamVjdFxuXHRcdFx0aWYgKCEoJ0Zvcm1EYXRhJyBpbiB3ICYmIGRhdGEgaW5zdGFuY2VvZiB3LkZvcm1EYXRhKSkge1xuXG5cdFx0XHRcdGZvciAodmFyIHggaW4gZGF0YSkgaWYgKGRhdGEuaGFzT3duUHJvcGVydHkoeCkpIHtcblxuXHRcdFx0XHRcdGlmICgnRmlsZUxpc3QnIGluIHcgJiYgZGF0YVt4XSBpbnN0YW5jZW9mIHcuRmlsZUxpc3QpIHtcblx0XHRcdFx0XHRcdGlmIChkYXRhW3hdLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdFx0XHRkYXRhW3hdID0gZGF0YVt4XVswXTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZWxzZSBpZiAoX3RoaXMuZG9tSW5zdGFuY2UoJ2lucHV0JywgZGF0YVt4XSkgJiYgZGF0YVt4XS50eXBlID09PSAnZmlsZScpIHtcblx0XHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRlbHNlIGlmIChfdGhpcy5kb21JbnN0YW5jZSgnaW5wdXQnLCBkYXRhW3hdKSB8fFxuXHRcdFx0XHRcdFx0X3RoaXMuZG9tSW5zdGFuY2UoJ3NlbGVjdCcsIGRhdGFbeF0pIHx8XG5cdFx0XHRcdFx0XHRfdGhpcy5kb21JbnN0YW5jZSgndGV4dEFyZWEnLCBkYXRhW3hdKSkge1xuXHRcdFx0XHRcdFx0ZGF0YVt4XSA9IGRhdGFbeF0udmFsdWU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGVsc2UgaWYgKF90aGlzLmRvbUluc3RhbmNlKG51bGwsIGRhdGFbeF0pKSB7XG5cdFx0XHRcdFx0XHRkYXRhW3hdID0gZGF0YVt4XS5pbm5lckhUTUwgfHwgZGF0YVt4XS5pbm5lclRleHQ7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdHAuZGF0YSA9IGRhdGE7XG5cdFx0XHRyZXR1cm4gZGF0YTtcblx0XHR9LFxuXG5cdFx0Ly8gTm9kZUxpc3RUb0pTT05cblx0XHQvLyBHaXZlbiBhIGxpc3Qgb2YgZWxlbWVudHMgZXh0cmFwb2xhdGUgdGhlaXIgdmFsdWVzIGFuZCByZXR1cm4gYXMgYSBqc29uIG9iamVjdFxuXHRcdG5vZGVMaXN0VG9KU09OOiBmdW5jdGlvbihub2RlbGlzdCkge1xuXG5cdFx0XHR2YXIganNvbiA9IHt9O1xuXG5cdFx0XHQvLyBDcmVhdGUgYSBkYXRhIHN0cmluZ1xuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBub2RlbGlzdC5sZW5ndGg7IGkrKykge1xuXG5cdFx0XHRcdHZhciBpbnB1dCA9IG5vZGVsaXN0W2ldO1xuXG5cdFx0XHRcdC8vIElmIHRoZSBuYW1lIG9mIHRoZSBpbnB1dCBpcyBlbXB0eSBvciBkaWFibGVkLCBkb250IGFkZCBpdC5cblx0XHRcdFx0aWYgKGlucHV0LmRpc2FibGVkIHx8ICFpbnB1dC5uYW1lKSB7XG5cdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBJcyB0aGlzIGEgZmlsZSwgZG9lcyB0aGUgYnJvd3NlciBub3Qgc3VwcG9ydCAnZmlsZXMnIGFuZCAnRm9ybURhdGEnP1xuXHRcdFx0XHRpZiAoaW5wdXQudHlwZSA9PT0gJ2ZpbGUnKSB7XG5cdFx0XHRcdFx0anNvbltpbnB1dC5uYW1lXSA9IGlucHV0O1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGpzb25baW5wdXQubmFtZV0gPSBpbnB1dC52YWx1ZSB8fCBpbnB1dC5pbm5lckhUTUw7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIGpzb247XG5cdFx0fVxuXHR9KTtcblxuXHQvLyBSZXBsYWNlIGl0XG5cdGhlbGxvLmFwaSA9IGZ1bmN0aW9uKCkge1xuXG5cdFx0Ly8gR2V0IGFyZ3VtZW50c1xuXHRcdHZhciBwID0gdXRpbHMuYXJncyh7cGF0aDogJ3MhJywgbWV0aG9kOiAncycsIGRhdGE6J28nLCB0aW1lb3V0OiAnaScsIGNhbGxiYWNrOiAnZid9LCBhcmd1bWVudHMpO1xuXG5cdFx0Ly8gQ2hhbmdlIGZvciBpbnRvIGEgZGF0YSBvYmplY3Rcblx0XHRpZiAocC5kYXRhKSB7XG5cdFx0XHR1dGlscy5kYXRhVG9KU09OKHApO1xuXHRcdH1cblxuXHRcdHJldHVybiBhcGkuY2FsbCh0aGlzLCBwKTtcblx0fTtcblxufSkoaGVsbG8pO1xuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vL1xuLy8gU2F2ZSBhbnkgYWNjZXNzIHRva2VuIHRoYXQgaXMgaW4gdGhlIGN1cnJlbnQgcGFnZSBVUkxcbi8vIEhhbmRsZSBhbnkgcmVzcG9uc2Ugc29saWNpdGVkIHRocm91Z2ggaWZyYW1lIGhhc2ggdGFnIGZvbGxvd2luZyBhbiBBUEkgcmVxdWVzdFxuLy9cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuaGVsbG8udXRpbHMucmVzcG9uc2VIYW5kbGVyKHdpbmRvdywgd2luZG93Lm9wZW5lciB8fCB3aW5kb3cucGFyZW50KTtcblxuLy8gU2NyaXB0IHRvIHN1cHBvcnQgQ2hyb21lQXBwc1xuLy8gVGhpcyBvdmVyaWRlcyB0aGUgaGVsbG8udXRpbHMucG9wdXAgbWV0aG9kIHRvIHN1cHBvcnQgY2hyb21lLmlkZW50aXR5LmxhdW5jaFdlYkF1dGhGbG93XG4vLyBTZWUgaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9hcHBzL2FwcF9pZGVudGl0eSNub25cblxuLy8gSXMgdGhpcyBhIGNocm9tZSBhcHA/XG5cbmlmICh0eXBlb2YgY2hyb21lID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgY2hyb21lLmlkZW50aXR5ID09PSAnb2JqZWN0JyAmJiBjaHJvbWUuaWRlbnRpdHkubGF1bmNoV2ViQXV0aEZsb3cpIHtcblxuXHQoZnVuY3Rpb24oKSB7XG5cblx0XHQvLyBTd2FwIHRoZSBwb3B1cCBtZXRob2Rcblx0XHRoZWxsby51dGlscy5wb3B1cCA9IGZ1bmN0aW9uKHVybCkge1xuXG5cdFx0XHRyZXR1cm4gX29wZW4odXJsLCB0cnVlKTtcblxuXHRcdH07XG5cblx0XHQvLyBTd2FwIHRoZSBoaWRkZW4gaWZyYW1lIG1ldGhvZFxuXHRcdGhlbGxvLnV0aWxzLmlmcmFtZSA9IGZ1bmN0aW9uKHVybCkge1xuXG5cdFx0XHRfb3Blbih1cmwsIGZhbHNlKTtcblxuXHRcdH07XG5cblx0XHQvLyBTd2FwIHRoZSByZXF1ZXN0X2NvcnMgbWV0aG9kXG5cdFx0aGVsbG8udXRpbHMucmVxdWVzdF9jb3JzID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcblxuXHRcdFx0Y2FsbGJhY2soKTtcblxuXHRcdFx0Ly8gQWx3YXlzIHJ1biBhcyBDT1JTXG5cblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH07XG5cblx0XHQvLyBTd2FwIHRoZSBzdG9yYWdlIG1ldGhvZFxuXHRcdHZhciBfY2FjaGUgPSB7fTtcblx0XHRjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoJ2hlbGxvJywgZnVuY3Rpb24ocikge1xuXHRcdFx0Ly8gVXBkYXRlIHRoZSBjYWNoZVxuXHRcdFx0X2NhY2hlID0gci5oZWxsbyB8fCB7fTtcblx0XHR9KTtcblxuXHRcdGhlbGxvLnV0aWxzLnN0b3JlID0gZnVuY3Rpb24obmFtZSwgdmFsdWUpIHtcblxuXHRcdFx0Ly8gR2V0IGFsbFxuXHRcdFx0aWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApIHtcblx0XHRcdFx0cmV0dXJuIF9jYWNoZTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gR2V0XG5cdFx0XHRpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRyZXR1cm4gX2NhY2hlW25hbWVdIHx8IG51bGw7XG5cdFx0XHR9XG5cblx0XHRcdC8vIFNldFxuXHRcdFx0aWYgKHZhbHVlKSB7XG5cdFx0XHRcdF9jYWNoZVtuYW1lXSA9IHZhbHVlO1xuXHRcdFx0XHRjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe2hlbGxvOiBfY2FjaGV9KTtcblx0XHRcdFx0cmV0dXJuIHZhbHVlO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBEZWxldGVcblx0XHRcdGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuXHRcdFx0XHRkZWxldGUgX2NhY2hlW25hbWVdO1xuXHRcdFx0XHRjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe2hlbGxvOiBfY2FjaGV9KTtcblx0XHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0XHR9XG5cdFx0fTtcblxuXHRcdC8vIE9wZW4gZnVuY3Rpb25cblx0XHRmdW5jdGlvbiBfb3Blbih1cmwsIGludGVyYWN0aXZlKSB7XG5cblx0XHRcdC8vIExhdW5jaFxuXHRcdFx0dmFyIHJlZiA9IHtcblx0XHRcdFx0Y2xvc2VkOiBmYWxzZVxuXHRcdFx0fTtcblxuXHRcdFx0Ly8gTGF1bmNoIHRoZSB3ZWJBdXRoRmxvd1xuXHRcdFx0Y2hyb21lLmlkZW50aXR5LmxhdW5jaFdlYkF1dGhGbG93KHtcblx0XHRcdFx0dXJsOiB1cmwsXG5cdFx0XHRcdGludGVyYWN0aXZlOiBpbnRlcmFjdGl2ZVxuXHRcdFx0fSwgZnVuY3Rpb24ocmVzcG9uc2VVcmwpIHtcblxuXHRcdFx0XHQvLyBEaWQgdGhlIHVzZXIgY2FuY2VsIHRoaXMgcHJlbWF0dXJlbHlcblx0XHRcdFx0aWYgKHJlc3BvbnNlVXJsID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRyZWYuY2xvc2VkID0gdHJ1ZTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBTcGxpdCBhcHBhcnQgdGhlIFVSTFxuXHRcdFx0XHR2YXIgYSA9IGhlbGxvLnV0aWxzLnVybChyZXNwb25zZVVybCk7XG5cblx0XHRcdFx0Ly8gVGhlIGxvY2F0aW9uIGNhbiBiZSBhdWdtZW50ZWQgaW4gdG8gYSBsb2NhdGlvbiBvYmplY3QgbGlrZSBzby4uLlxuXHRcdFx0XHQvLyBXZSBkb250IGhhdmUgd2luZG93IG9wZXJhdGlvbnMgb24gdGhlIHBvcHVwIHNvIGxldHMgY3JlYXRlIHNvbWVcblx0XHRcdFx0dmFyIF9wb3B1cCA9IHtcblx0XHRcdFx0XHRsb2NhdGlvbjoge1xuXG5cdFx0XHRcdFx0XHQvLyBDaGFuZ2UgdGhlIGxvY2F0aW9uIG9mIHRoZSBwb3B1cFxuXHRcdFx0XHRcdFx0YXNzaWduOiBmdW5jdGlvbih1cmwpIHtcblxuXHRcdFx0XHRcdFx0XHQvLyBJZiB0aGVyZSBpcyBhIHNlY29uZGFyeSByZWFzc2lnblxuXHRcdFx0XHRcdFx0XHQvLyBJbiB0aGUgY2FzZSBvZiBPQXV0aDFcblx0XHRcdFx0XHRcdFx0Ly8gVHJpZ2dlciB0aGlzIGluIG5vbi1pbnRlcmFjdGl2ZSBtb2RlLlxuXHRcdFx0XHRcdFx0XHRfb3Blbih1cmwsIGZhbHNlKTtcblx0XHRcdFx0XHRcdH0sXG5cblx0XHRcdFx0XHRcdHNlYXJjaDogYS5zZWFyY2gsXG5cdFx0XHRcdFx0XHRoYXNoOiBhLmhhc2gsXG5cdFx0XHRcdFx0XHRocmVmOiBhLmhyZWZcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGNsb3NlOiBmdW5jdGlvbigpIHt9XG5cdFx0XHRcdH07XG5cblx0XHRcdFx0Ly8gVGhlbiB0aGlzIFVSTCBjb250YWlucyBpbmZvcm1hdGlvbiB3aGljaCBIZWxsb0pTIG11c3QgcHJvY2Vzc1xuXHRcdFx0XHQvLyBVUkwgc3RyaW5nXG5cdFx0XHRcdC8vIFdpbmRvdyAtIGFueSBhY3Rpb24gc3VjaCBhcyB3aW5kb3cgcmVsb2NhdGlvbiBnb2VzIGhlcmVcblx0XHRcdFx0Ly8gT3BlbmVyIC0gdGhlIHBhcmVudCB3aW5kb3cgd2hpY2ggb3BlbmVkIHRoaXMsIGFrYSB0aGlzIHNjcmlwdFxuXG5cdFx0XHRcdGhlbGxvLnV0aWxzLnJlc3BvbnNlSGFuZGxlcihfcG9wdXAsIHdpbmRvdyk7XG5cdFx0XHR9KTtcblxuXHRcdFx0Ly8gUmV0dXJuIHRoZSByZWZlcmVuY2Vcblx0XHRcdHJldHVybiByZWY7XG5cdFx0fVxuXG5cdH0pKCk7XG59XG5cbi8vIFBob25lZ2FwIG92ZXJyaWRlIGZvciBoZWxsby5waG9uZWdhcC5qc1xuKGZ1bmN0aW9uKCkge1xuXG5cdC8vIElzIHRoaXMgYSBwaG9uZWdhcCBpbXBsZW1lbnRhdGlvbj9cblx0aWYgKCEoL15maWxlOlxcL3szfVteXFwvXS8udGVzdCh3aW5kb3cubG9jYXRpb24uaHJlZikgJiYgd2luZG93LmNvcmRvdmEpKSB7XG5cdFx0Ly8gQ29yZG92YSBpcyBub3QgaW5jbHVkZWQuXG5cdFx0cmV0dXJuO1xuXHR9XG5cblx0Ly8gQXVnbWVudCB0aGUgaGlkZGVuIGlmcmFtZSBtZXRob2Rcblx0aGVsbG8udXRpbHMuaWZyYW1lID0gZnVuY3Rpb24odXJsLCByZWRpcmVjdFVyaSkge1xuXHRcdGhlbGxvLnV0aWxzLnBvcHVwKHVybCwgcmVkaXJlY3RVcmksIHtoaWRkZW46ICd5ZXMnfSk7XG5cdH07XG5cblx0Ly8gQXVnbWVudCB0aGUgcG9wdXBcblx0dmFyIHV0aWxQb3B1cCA9IGhlbGxvLnV0aWxzLnBvcHVwO1xuXG5cdC8vIFJlcGxhY2UgcG9wdXBcblx0aGVsbG8udXRpbHMucG9wdXAgPSBmdW5jdGlvbih1cmwsIHJlZGlyZWN0VXJpLCBvcHRpb25zKSB7XG5cblx0XHQvLyBSdW4gdGhlIHN0YW5kYXJkXG5cdFx0dmFyIHBvcHVwID0gdXRpbFBvcHVwLmNhbGwodGhpcywgdXJsLCByZWRpcmVjdFVyaSwgb3B0aW9ucyk7XG5cblx0XHQvLyBDcmVhdGUgYSBmdW5jdGlvbiBmb3IgcmVvcGVuaW5nIHRoZSBwb3B1cCwgYW5kIGFzc2lnbmluZyBldmVudHMgdG8gdGhlIG5ldyBwb3B1cCBvYmplY3Rcblx0XHQvLyBQaG9uZUdhcCBzdXBwb3J0XG5cdFx0Ly8gQWRkIGFuIGV2ZW50IGxpc3RlbmVyIHRvIGxpc3RlbiB0byB0aGUgY2hhbmdlIGluIHRoZSBwb3B1cCB3aW5kb3dzIFVSTFxuXHRcdC8vIFRoaXMgbXVzdCBhcHBlYXIgYmVmb3JlIHBvcHVwLmZvY3VzKCk7XG5cdFx0dHJ5IHtcblx0XHRcdGlmIChwb3B1cCAmJiBwb3B1cC5hZGRFdmVudExpc3RlbmVyKSB7XG5cblx0XHRcdFx0Ly8gR2V0IHRoZSBvcmlnaW4gb2YgdGhlIHJlZGlyZWN0IFVSSVxuXG5cdFx0XHRcdHZhciBhID0gaGVsbG8udXRpbHMudXJsKHJlZGlyZWN0VXJpKTtcblx0XHRcdFx0dmFyIHJlZGlyZWN0VXJpT3JpZ2luID0gYS5vcmlnaW4gfHwgKGEucHJvdG9jb2wgKyAnLy8nICsgYS5ob3N0bmFtZSk7XG5cblx0XHRcdFx0Ly8gTGlzdGVuIHRvIGNoYW5nZXMgaW4gdGhlIEluQXBwQnJvd3NlciB3aW5kb3dcblxuXHRcdFx0XHRwb3B1cC5hZGRFdmVudExpc3RlbmVyKCdsb2Fkc3RhcnQnLCBmdW5jdGlvbihlKSB7XG5cblx0XHRcdFx0XHR2YXIgdXJsID0gZS51cmw7XG5cblx0XHRcdFx0XHQvLyBJcyB0aGlzIHRoZSBwYXRoLCBhcyBnaXZlbiBieSB0aGUgcmVkaXJlY3RVcmk/XG5cdFx0XHRcdFx0Ly8gQ2hlY2sgdGhlIG5ldyBVUkwgYWdhaW5zIHRoZSByZWRpcmVjdFVyaU9yaWdpbi5cblx0XHRcdFx0XHQvLyBBY2NvcmRpbmcgdG8gIzYzIGEgdXNlciBjb3VsZCBjbGljayAnY2FuY2VsJyBpbiBzb21lIGRpYWxvZyBib3hlcyAuLi4uXG5cdFx0XHRcdFx0Ly8gVGhlIHBvcHVwIHJlZGlyZWN0cyB0byBhbm90aGVyIHBhZ2Ugd2l0aCB0aGUgc2FtZSBvcmlnaW4sIHlldCB3ZSBzdGlsbCB3aXNoIGl0IHRvIGNsb3NlLlxuXG5cdFx0XHRcdFx0aWYgKHVybC5pbmRleE9mKHJlZGlyZWN0VXJpT3JpZ2luKSAhPT0gMCkge1xuXHRcdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdC8vIFNwbGl0IGFwcGFydCB0aGUgVVJMXG5cdFx0XHRcdFx0dmFyIGEgPSBoZWxsby51dGlscy51cmwodXJsKTtcblxuXHRcdFx0XHRcdC8vIFdlIGRvbnQgaGF2ZSB3aW5kb3cgb3BlcmF0aW9ucyBvbiB0aGUgcG9wdXAgc28gbGV0cyBjcmVhdGUgc29tZVxuXHRcdFx0XHRcdC8vIFRoZSBsb2NhdGlvbiBjYW4gYmUgYXVnbWVudGVkIGluIHRvIGEgbG9jYXRpb24gb2JqZWN0IGxpa2Ugc28uLi5cblxuXHRcdFx0XHRcdHZhciBfcG9wdXAgPSB7XG5cdFx0XHRcdFx0XHRsb2NhdGlvbjoge1xuXHRcdFx0XHRcdFx0XHQvLyBDaGFuZ2UgdGhlIGxvY2F0aW9uIG9mIHRoZSBwb3B1cFxuXHRcdFx0XHRcdFx0XHRhc3NpZ246IGZ1bmN0aW9uKGxvY2F0aW9uKSB7XG5cblx0XHRcdFx0XHRcdFx0XHQvLyBVbmZvdXJ0dW5hdGx5IGFuIGFwcCBpcyBtYXkgbm90IGNoYW5nZSB0aGUgbG9jYXRpb24gb2YgYSBJbkFwcEJyb3dzZXIgd2luZG93LlxuXHRcdFx0XHRcdFx0XHRcdC8vIFNvIHRvIHNoaW0gdGhpcywganVzdCBvcGVuIGEgbmV3IG9uZS5cblx0XHRcdFx0XHRcdFx0XHRwb3B1cC5leGVjdXRlU2NyaXB0KHtjb2RlOiAnd2luZG93LmxvY2F0aW9uLmhyZWYgPSBcIicgKyBsb2NhdGlvbiArICc7XCInfSk7XG5cdFx0XHRcdFx0XHRcdH0sXG5cblx0XHRcdFx0XHRcdFx0c2VhcmNoOiBhLnNlYXJjaCxcblx0XHRcdFx0XHRcdFx0aGFzaDogYS5oYXNoLFxuXHRcdFx0XHRcdFx0XHRocmVmOiBhLmhyZWZcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRjbG9zZTogZnVuY3Rpb24oKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChwb3B1cC5jbG9zZSkge1xuXHRcdFx0XHRcdFx0XHRcdHBvcHVwLmNsb3NlKCk7XG5cdFx0XHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0XHRcdHBvcHVwLmNsb3NlZCA9IHRydWU7XG5cdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdGNhdGNoIChfZSkge31cblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH07XG5cblx0XHRcdFx0XHQvLyBUaGVuIHRoaXMgVVJMIGNvbnRhaW5zIGluZm9ybWF0aW9uIHdoaWNoIEhlbGxvSlMgbXVzdCBwcm9jZXNzXG5cdFx0XHRcdFx0Ly8gVVJMIHN0cmluZ1xuXHRcdFx0XHRcdC8vIFdpbmRvdyAtIGFueSBhY3Rpb24gc3VjaCBhcyB3aW5kb3cgcmVsb2NhdGlvbiBnb2VzIGhlcmVcblx0XHRcdFx0XHQvLyBPcGVuZXIgLSB0aGUgcGFyZW50IHdpbmRvdyB3aGljaCBvcGVuZWQgdGhpcywgYWthIHRoaXMgc2NyaXB0XG5cblx0XHRcdFx0XHRoZWxsby51dGlscy5yZXNwb25zZUhhbmRsZXIoX3BvcHVwLCB3aW5kb3cpO1xuXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjYXRjaCAoZSkge31cblxuXHRcdHJldHVybiBwb3B1cDtcblx0fTtcblxufSkoKTtcblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0Ly8gT0F1dGgxXG5cdHZhciBPQXV0aDFTZXR0aW5ncyA9IHtcblx0XHR2ZXJzaW9uOiAnMS4wJyxcblx0XHRhdXRoOiAnaHR0cHM6Ly93d3cuZHJvcGJveC5jb20vMS9vYXV0aC9hdXRob3JpemUnLFxuXHRcdHJlcXVlc3Q6ICdodHRwczovL2FwaS5kcm9wYm94LmNvbS8xL29hdXRoL3JlcXVlc3RfdG9rZW4nLFxuXHRcdHRva2VuOiAnaHR0cHM6Ly9hcGkuZHJvcGJveC5jb20vMS9vYXV0aC9hY2Nlc3NfdG9rZW4nXG5cdH07XG5cblx0Ly8gT0F1dGgyIFNldHRpbmdzXG5cdHZhciBPQXV0aDJTZXR0aW5ncyA9IHtcblx0XHR2ZXJzaW9uOiAyLFxuXHRcdGF1dGg6ICdodHRwczovL3d3dy5kcm9wYm94LmNvbS8xL29hdXRoMi9hdXRob3JpemUnLFxuXHRcdGdyYW50OiAnaHR0cHM6Ly9hcGkuZHJvcGJveC5jb20vMS9vYXV0aDIvdG9rZW4nXG5cdH07XG5cblx0Ly8gSW5pdGlhdGUgdGhlIERyb3Bib3ggbW9kdWxlXG5cdGhlbGxvLmluaXQoe1xuXG5cdFx0ZHJvcGJveDoge1xuXG5cdFx0XHRuYW1lOiAnRHJvcGJveCcsXG5cblx0XHRcdG9hdXRoOiBPQXV0aDJTZXR0aW5ncyxcblxuXHRcdFx0bG9naW46IGZ1bmN0aW9uKHApIHtcblx0XHRcdFx0Ly8gT0F1dGgyIG5vbi1zdGFuZGFyZCBhZGp1c3RtZW50c1xuXHRcdFx0XHRwLnFzLnNjb3BlID0gJyc7XG5cblx0XHRcdFx0Ly8gU2hvdWxkIHRoaXMgYmUgcnVuIGFzIE9BdXRoMT9cblx0XHRcdFx0Ly8gSWYgdGhlIHJlZGlyZWN0X3VyaSBpcyBpcyBIVFRQIChub24tc2VjdXJlKSB0aGVuIGl0cyByZXF1aXJlZCB0byByZXZlcnQgdG8gdGhlIE9BdXRoMSBlbmRwb2ludHNcblx0XHRcdFx0dmFyIHJlZGlyZWN0ID0gZGVjb2RlVVJJQ29tcG9uZW50KHAucXMucmVkaXJlY3RfdXJpKTtcblx0XHRcdFx0aWYgKHJlZGlyZWN0LmluZGV4T2YoJ2h0dHA6JykgPT09IDAgJiYgcmVkaXJlY3QuaW5kZXhPZignaHR0cDovL2xvY2FsaG9zdC8nKSAhPT0gMCkge1xuXG5cdFx0XHRcdFx0Ly8gT3ZlcnJpZGUgdGhlIGRyb3Bib3ggT0F1dGggc2V0dGluZ3MuXG5cdFx0XHRcdFx0aGVsbG8uc2VydmljZXMuZHJvcGJveC5vYXV0aCA9IE9BdXRoMVNldHRpbmdzO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdC8vIE92ZXJyaWRlIHRoZSBkcm9wYm94IE9BdXRoIHNldHRpbmdzLlxuXHRcdFx0XHRcdGhlbGxvLnNlcnZpY2VzLmRyb3Bib3gub2F1dGggPSBPQXV0aDJTZXR0aW5ncztcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFRoZSBkcm9wYm94IGxvZ2luIHdpbmRvdyBpcyBhIGRpZmZlcmVudCBzaXplXG5cdFx0XHRcdHAub3B0aW9ucy5wb3B1cC53aWR0aCA9IDEwMDA7XG5cdFx0XHRcdHAub3B0aW9ucy5wb3B1cC5oZWlnaHQgPSAxMDAwO1xuXHRcdFx0fSxcblxuXHRcdFx0Lypcblx0XHRcdFx0RHJvcGJveCBkb2VzIG5vdCBhbGxvdyBpbnNlY3VyZSBIVFRQIFVSSSdzIGluIHRoZSByZWRpcmVjdF91cmkgZmllbGRcblx0XHRcdFx0Li4ub3RoZXJ3aXNlIEknZCBsb3ZlIHRvIHVzZSBPQXV0aDJcblxuXHRcdFx0XHRGb2xsb3cgcmVxdWVzdCBodHRwczovL2ZvcnVtcy5kcm9wYm94LmNvbS90b3BpYy5waHA/aWQ9MTA2NTA1XG5cblx0XHRcdFx0cC5xcy5yZXNwb25zZV90eXBlID0gJ2NvZGUnO1xuXHRcdFx0XHRvYXV0aDoge1xuXHRcdFx0XHRcdHZlcnNpb246IDIsXG5cdFx0XHRcdFx0YXV0aDogJ2h0dHBzOi8vd3d3LmRyb3Bib3guY29tLzEvb2F1dGgyL2F1dGhvcml6ZScsXG5cdFx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL2FwaS5kcm9wYm94LmNvbS8xL29hdXRoMi90b2tlbidcblx0XHRcdFx0fVxuXHRcdFx0Ki9cblxuXHRcdFx0Ly8gQVBJIEJhc2UgVVJMXG5cdFx0XHRiYXNlOiAnaHR0cHM6Ly9hcGkuZHJvcGJveC5jb20vMS8nLFxuXG5cdFx0XHQvLyBCZXNwb2tlIHNldHRpbmc6IHRoaXMgaXMgc3RhdGVzIHdoZXRoZXIgdG8gdXNlIHRoZSBjdXN0b20gZW52aXJvbm1lbnQgb2YgRHJvcGJveCBvciB0byB1c2UgdGhlaXIgb3duIGVudmlyb25tZW50XG5cdFx0XHQvLyBCZWNhdXNlIGl0J3Mgbm90b3Jpb3VzbHkgZGlmZmljdWx0IGZvciBEcm9wYm94IHRvbyBwcm92aWRlIGFjY2VzcyBmcm9tIG90aGVyIHdlYnNlcnZpY2VzLCB0aGlzIGRlZmF1bHRzIHRvIFNhbmRib3hcblx0XHRcdHJvb3Q6ICdzYW5kYm94JyxcblxuXHRcdFx0Ly8gTWFwIEdFVCByZXF1ZXN0c1xuXHRcdFx0Z2V0OiB7XG5cdFx0XHRcdG1lOiAnYWNjb3VudC9pbmZvJyxcblxuXHRcdFx0XHQvLyBIdHRwczovL3d3dy5kcm9wYm94LmNvbS9kZXZlbG9wZXJzL2NvcmUvZG9jcyNtZXRhZGF0YVxuXHRcdFx0XHQnbWUvZmlsZXMnOiByZXEoJ21ldGFkYXRhL2F1dG8vQHtwYXJlbnR8fScpLFxuXHRcdFx0XHQnbWUvZm9sZGVyJzogcmVxKCdtZXRhZGF0YS9hdXRvL0B7aWR9JyksXG5cdFx0XHRcdCdtZS9mb2xkZXJzJzogcmVxKCdtZXRhZGF0YS9hdXRvLycpLFxuXG5cdFx0XHRcdCdkZWZhdWx0JzogZnVuY3Rpb24ocCwgY2FsbGJhY2spIHtcblx0XHRcdFx0XHRpZiAocC5wYXRoLm1hdGNoKCdodHRwczovL2FwaS1jb250ZW50LmRyb3Bib3guY29tLzEvZmlsZXMvJykpIHtcblx0XHRcdFx0XHRcdC8vIFRoaXMgaXMgYSBmaWxlLCByZXR1cm4gYmluYXJ5IGRhdGFcblx0XHRcdFx0XHRcdHAubWV0aG9kID0gJ2Jsb2InO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGNhbGxiYWNrKHAucGF0aCk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdHBvc3Q6IHtcblx0XHRcdFx0J21lL2ZpbGVzJzogZnVuY3Rpb24ocCwgY2FsbGJhY2spIHtcblxuXHRcdFx0XHRcdHZhciBwYXRoID0gcC5kYXRhLnBhcmVudDtcblx0XHRcdFx0XHR2YXIgZmlsZU5hbWUgPSBwLmRhdGEubmFtZTtcblxuXHRcdFx0XHRcdHAuZGF0YSA9IHtcblx0XHRcdFx0XHRcdGZpbGU6IHAuZGF0YS5maWxlXG5cdFx0XHRcdFx0fTtcblxuXHRcdFx0XHRcdC8vIERvZXMgdGhpcyBoYXZlIGEgZGF0YS11cmkgdG8gdXBsb2FkIGFzIGEgZmlsZT9cblx0XHRcdFx0XHRpZiAodHlwZW9mIChwLmRhdGEuZmlsZSkgPT09ICdzdHJpbmcnKSB7XG5cdFx0XHRcdFx0XHRwLmRhdGEuZmlsZSA9IGhlbGxvLnV0aWxzLnRvQmxvYihwLmRhdGEuZmlsZSk7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Y2FsbGJhY2soJ2h0dHBzOi8vYXBpLWNvbnRlbnQuZHJvcGJveC5jb20vMS9maWxlc19wdXQvYXV0by8nICsgcGF0aCArICcvJyArIGZpbGVOYW1lKTtcblx0XHRcdFx0fSxcblxuXHRcdFx0XHQnbWUvZm9sZGVycyc6IGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cblx0XHRcdFx0XHR2YXIgbmFtZSA9IHAuZGF0YS5uYW1lO1xuXHRcdFx0XHRcdHAuZGF0YSA9IHt9O1xuXG5cdFx0XHRcdFx0Y2FsbGJhY2soJ2ZpbGVvcHMvY3JlYXRlX2ZvbGRlcj9yb290PUB7cm9vdHxzYW5kYm94fSYnICsgaGVsbG8udXRpbHMucGFyYW0oe1xuXHRcdFx0XHRcdFx0cGF0aDogbmFtZVxuXHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0Ly8gTWFwIERFTEVURSByZXF1ZXN0c1xuXHRcdFx0ZGVsOiB7XG5cdFx0XHRcdCdtZS9maWxlcyc6ICdmaWxlb3BzL2RlbGV0ZT9yb290PUB7cm9vdHxzYW5kYm94fSZwYXRoPUB7aWR9Jyxcblx0XHRcdFx0J21lL2ZvbGRlcic6ICdmaWxlb3BzL2RlbGV0ZT9yb290PUB7cm9vdHxzYW5kYm94fSZwYXRoPUB7aWR9J1xuXHRcdFx0fSxcblxuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZnVuY3Rpb24obykge1xuXHRcdFx0XHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdFx0XHRcdGlmICghby51aWQpIHtcblx0XHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdG8ubmFtZSA9IG8uZGlzcGxheV9uYW1lO1xuXHRcdFx0XHRcdHZhciBtID0gby5uYW1lLnNwbGl0KCcgJyk7XG5cdFx0XHRcdFx0by5maXJzdF9uYW1lID0gbS5zaGlmdCgpO1xuXHRcdFx0XHRcdG8ubGFzdF9uYW1lID0gbS5qb2luKCcgJyk7XG5cdFx0XHRcdFx0by5pZCA9IG8udWlkO1xuXHRcdFx0XHRcdGRlbGV0ZSBvLnVpZDtcblx0XHRcdFx0XHRkZWxldGUgby5kaXNwbGF5X25hbWU7XG5cdFx0XHRcdFx0cmV0dXJuIG87XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0J2RlZmF1bHQnOiBmdW5jdGlvbihvLCBoZWFkZXJzLCByZXEpIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRpZiAoby5pc19kaXIgJiYgby5jb250ZW50cykge1xuXHRcdFx0XHRcdFx0by5kYXRhID0gby5jb250ZW50cztcblx0XHRcdFx0XHRcdGRlbGV0ZSBvLmNvbnRlbnRzO1xuXG5cdFx0XHRcdFx0XHRvLmRhdGEuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XG5cdFx0XHRcdFx0XHRcdGl0ZW0ucm9vdCA9IG8ucm9vdDtcblx0XHRcdFx0XHRcdFx0Zm9ybWF0RmlsZShpdGVtLCBoZWFkZXJzLCByZXEpO1xuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Zm9ybWF0RmlsZShvLCBoZWFkZXJzLCByZXEpO1xuXG5cdFx0XHRcdFx0aWYgKG8uaXNfZGVsZXRlZCkge1xuXHRcdFx0XHRcdFx0by5zdWNjZXNzID0gdHJ1ZTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0Ly8gRG9lc24ndCByZXR1cm4gdGhlIENPUlMgaGVhZGVyc1xuXHRcdFx0eGhyOiBmdW5jdGlvbihwKSB7XG5cblx0XHRcdFx0Ly8gVGhlIHByb3h5IHN1cHBvcnRzIGFsbG93LWNyb3NzLW9yaWdpbi1yZXNvdXJjZVxuXHRcdFx0XHQvLyBBbGFzIHRoYXQncyB0aGUgb25seSB0aGluZyB3ZSdyZSB1c2luZy5cblx0XHRcdFx0aWYgKHAuZGF0YSAmJiBwLmRhdGEuZmlsZSkge1xuXHRcdFx0XHRcdHZhciBmaWxlID0gcC5kYXRhLmZpbGU7XG5cdFx0XHRcdFx0aWYgKGZpbGUpIHtcblx0XHRcdFx0XHRcdGlmIChmaWxlLmZpbGVzKSB7XG5cdFx0XHRcdFx0XHRcdHAuZGF0YSA9IGZpbGUuZmlsZXNbMF07XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRcdFx0cC5kYXRhID0gZmlsZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAocC5tZXRob2QgPT09ICdkZWxldGUnKSB7XG5cdFx0XHRcdFx0cC5tZXRob2QgPSAncG9zdCc7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdH0sXG5cblx0XHRcdGZvcm06IGZ1bmN0aW9uKHAsIHFzKSB7XG5cdFx0XHRcdGRlbGV0ZSBxcy5zdGF0ZTtcblx0XHRcdFx0ZGVsZXRlIHFzLnJlZGlyZWN0X3VyaTtcblx0XHRcdH1cblx0XHR9XG5cdH0pO1xuXG5cdGZ1bmN0aW9uIGZvcm1hdEVycm9yKG8pIHtcblx0XHRpZiAobyAmJiAnZXJyb3InIGluIG8pIHtcblx0XHRcdG8uZXJyb3IgPSB7XG5cdFx0XHRcdGNvZGU6ICdzZXJ2ZXJfZXJyb3InLFxuXHRcdFx0XHRtZXNzYWdlOiBvLmVycm9yLm1lc3NhZ2UgfHwgby5lcnJvclxuXHRcdFx0fTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRGaWxlKG8sIGhlYWRlcnMsIHJlcSkge1xuXG5cdFx0aWYgKHR5cGVvZiBvICE9PSAnb2JqZWN0JyB8fFxuXHRcdFx0KHR5cGVvZiBCbG9iICE9PSAndW5kZWZpbmVkJyAmJiBvIGluc3RhbmNlb2YgQmxvYikgfHxcblx0XHRcdCh0eXBlb2YgQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnICYmIG8gaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikpIHtcblx0XHRcdC8vIFRoaXMgaXMgYSBmaWxlLCBsZXQgaXQgdGhyb3VnaCB1bmZvcm1hdHRlZFxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGlmICgnZXJyb3InIGluIG8pIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR2YXIgcGF0aCA9IChvLnJvb3QgIT09ICdhcHBfZm9sZGVyJyA/IG8ucm9vdCA6ICcnKSArIG8ucGF0aC5yZXBsYWNlKC9cXCYvZywgJyUyNicpO1xuXHRcdHBhdGggPSBwYXRoLnJlcGxhY2UoL15cXC8vLCAnJyk7XG5cdFx0aWYgKG8udGh1bWJfZXhpc3RzKSB7XG5cdFx0XHRvLnRodW1ibmFpbCA9IHJlcS5vYXV0aF9wcm94eSArICc/cGF0aD0nICtcblx0XHRcdGVuY29kZVVSSUNvbXBvbmVudCgnaHR0cHM6Ly9hcGktY29udGVudC5kcm9wYm94LmNvbS8xL3RodW1ibmFpbHMvYXV0by8nICsgcGF0aCArICc/Zm9ybWF0PWpwZWcmc2l6ZT1tJykgKyAnJmFjY2Vzc190b2tlbj0nICsgcmVxLm9wdGlvbnMuYWNjZXNzX3Rva2VuO1xuXHRcdH1cblxuXHRcdG8udHlwZSA9IChvLmlzX2RpciA/ICdmb2xkZXInIDogby5taW1lX3R5cGUpO1xuXHRcdG8ubmFtZSA9IG8ucGF0aC5yZXBsYWNlKC8uKlxcLy9nLCAnJyk7XG5cdFx0aWYgKG8uaXNfZGlyKSB7XG5cdFx0XHRvLmZpbGVzID0gcGF0aC5yZXBsYWNlKC9eXFwvLywgJycpO1xuXHRcdH1cblx0XHRlbHNlIHtcblx0XHRcdG8uZG93bmxvYWRMaW5rID0gaGVsbG8uc2V0dGluZ3Mub2F1dGhfcHJveHkgKyAnP3BhdGg9JyArXG5cdFx0XHRlbmNvZGVVUklDb21wb25lbnQoJ2h0dHBzOi8vYXBpLWNvbnRlbnQuZHJvcGJveC5jb20vMS9maWxlcy9hdXRvLycgKyBwYXRoKSArICcmYWNjZXNzX3Rva2VuPScgKyByZXEub3B0aW9ucy5hY2Nlc3NfdG9rZW47XG5cdFx0XHRvLmZpbGUgPSAnaHR0cHM6Ly9hcGktY29udGVudC5kcm9wYm94LmNvbS8xL2ZpbGVzL2F1dG8vJyArIHBhdGg7XG5cdFx0fVxuXG5cdFx0aWYgKCFvLmlkKSB7XG5cdFx0XHRvLmlkID0gby5wYXRoLnJlcGxhY2UoL15cXC8vLCAnJyk7XG5cdFx0fVxuXG5cdFx0Ly8gTy5tZWRpYSA9ICdodHRwczovL2FwaS1jb250ZW50LmRyb3Bib3guY29tLzEvZmlsZXMvJyArIHBhdGg7XG5cdH1cblxuXHRmdW5jdGlvbiByZXEoc3RyKSB7XG5cdFx0cmV0dXJuIGZ1bmN0aW9uKHAsIGNiKSB7XG5cdFx0XHRkZWxldGUgcC5xdWVyeS5saW1pdDtcblx0XHRcdGNiKHN0cik7XG5cdFx0fTtcblx0fVxuXG59KShoZWxsbyk7XG5cbihmdW5jdGlvbihoZWxsbykge1xuXHQvLyBGb3IgQVBJcywgb25jZSBhIHZlcnNpb24gaXMgbm8gbG9uZ2VyIHVzYWJsZSwgYW55IGNhbGxzIG1hZGUgdG8gaXQgd2lsbCBiZSBkZWZhdWx0ZWQgdG8gdGhlIG5leHQgb2xkZXN0IHVzYWJsZSB2ZXJzaW9uLlxuXHQvLyBTbyB3ZSBleHBsaWNpdGx5IHN0YXRlIGl0LlxuXHR2YXIgdmVyc2lvbiA9ICd2Mi45JztcblxuXHRoZWxsby5pbml0KHtcblxuXHRcdGZhY2Vib29rOiB7XG5cblx0XHRcdG5hbWU6ICdGYWNlYm9vaycsXG5cblx0XHRcdC8vIFNFRSBodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvZmFjZWJvb2stbG9naW4vbWFudWFsbHktYnVpbGQtYS1sb2dpbi1mbG93XG5cdFx0XHRvYXV0aDoge1xuXHRcdFx0XHR2ZXJzaW9uOiAyLFxuXHRcdFx0XHRhdXRoOiAnaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tLycgKyB2ZXJzaW9uICsgJy9kaWFsb2cvb2F1dGgvJyxcblx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL2dyYXBoLmZhY2Vib29rLmNvbS9vYXV0aC9hY2Nlc3NfdG9rZW4nXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBBdXRob3JpemF0aW9uIHNjb3Blc1xuXHRcdFx0c2NvcGU6IHtcblx0XHRcdFx0YmFzaWM6ICdwdWJsaWNfcHJvZmlsZScsXG5cdFx0XHRcdGVtYWlsOiAnZW1haWwnLFxuXHRcdFx0XHRzaGFyZTogJ3VzZXJfcG9zdHMnLFxuXHRcdFx0XHRiaXJ0aGRheTogJ3VzZXJfYmlydGhkYXknLFxuXHRcdFx0XHRldmVudHM6ICd1c2VyX2V2ZW50cycsXG5cdFx0XHRcdHBob3RvczogJ3VzZXJfcGhvdG9zJyxcblx0XHRcdFx0dmlkZW9zOiAndXNlcl92aWRlb3MnLFxuXHRcdFx0XHRmcmllbmRzOiAndXNlcl9mcmllbmRzJyxcblx0XHRcdFx0ZmlsZXM6ICd1c2VyX3Bob3Rvcyx1c2VyX3ZpZGVvcycsXG5cdFx0XHRcdHB1Ymxpc2hfZmlsZXM6ICd1c2VyX3Bob3Rvcyx1c2VyX3ZpZGVvcyxwdWJsaXNoX2FjdGlvbnMnLFxuXHRcdFx0XHRwdWJsaXNoOiAncHVibGlzaF9hY3Rpb25zJyxcblxuXHRcdFx0XHQvLyBEZXByZWNhdGVkIGluIHYyLjBcblx0XHRcdFx0Ly8gQ3JlYXRlX2V2ZW50XHQ6ICdjcmVhdGVfZXZlbnQnLFxuXG5cdFx0XHRcdG9mZmxpbmVfYWNjZXNzOiAnJ1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gUmVmcmVzaCB0aGUgYWNjZXNzX3Rva2VuXG5cdFx0XHRyZWZyZXNoOiBmYWxzZSxcblxuXHRcdFx0bG9naW46IGZ1bmN0aW9uKHApIHtcblxuXHRcdFx0XHQvLyBSZWF1dGhlbnRpY2F0ZVxuXHRcdFx0XHQvLyBodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvZmFjZWJvb2stbG9naW4vcmVhdXRoZW50aWNhdGlvblxuXHRcdFx0XHRpZiAocC5vcHRpb25zLmZvcmNlKSB7XG5cdFx0XHRcdFx0cC5xcy5hdXRoX3R5cGUgPSAncmVhdXRoZW50aWNhdGUnO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gU2V0IHRoZSBkaXNwbGF5IHZhbHVlXG5cdFx0XHRcdHAucXMuZGlzcGxheSA9IHAub3B0aW9ucy5kaXNwbGF5IHx8ICdwb3B1cCc7XG5cdFx0XHR9LFxuXG5cdFx0XHRsb2dvdXQ6IGZ1bmN0aW9uKGNhbGxiYWNrLCBvcHRpb25zKSB7XG5cdFx0XHRcdC8vIEFzc2lnbiBjYWxsYmFjayB0byBhIGdsb2JhbCBoYW5kbGVyXG5cdFx0XHRcdHZhciBjYWxsYmFja0lEID0gaGVsbG8udXRpbHMuZ2xvYmFsRXZlbnQoY2FsbGJhY2spO1xuXHRcdFx0XHR2YXIgcmVkaXJlY3QgPSBlbmNvZGVVUklDb21wb25lbnQoaGVsbG8uc2V0dGluZ3MucmVkaXJlY3RfdXJpICsgJz8nICsgaGVsbG8udXRpbHMucGFyYW0oe2NhbGxiYWNrOmNhbGxiYWNrSUQsIHJlc3VsdDogSlNPTi5zdHJpbmdpZnkoe2ZvcmNlOnRydWV9KSwgc3RhdGU6ICd7fSd9KSk7XG5cdFx0XHRcdHZhciB0b2tlbiA9IChvcHRpb25zLmF1dGhSZXNwb25zZSB8fCB7fSkuYWNjZXNzX3Rva2VuO1xuXHRcdFx0XHRoZWxsby51dGlscy5pZnJhbWUoJ2h0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS9sb2dvdXQucGhwP25leHQ9JyArIHJlZGlyZWN0ICsgJyZhY2Nlc3NfdG9rZW49JyArIHRva2VuKTtcblxuXHRcdFx0XHQvLyBQb3NzaWJsZSByZXNwb25zZXM6XG5cdFx0XHRcdC8vIFN0cmluZyBVUkxcdC0gaGVsbG8ubG9nb3V0IHNob3VsZCBoYW5kbGUgdGhlIGxvZ291dFxuXHRcdFx0XHQvLyBVbmRlZmluZWRcdC0gdGhpcyBmdW5jdGlvbiB3aWxsIGhhbmRsZSB0aGUgY2FsbGJhY2tcblx0XHRcdFx0Ly8gVHJ1ZSAtIHRocm93IGEgc3VjY2VzcywgdGhpcyBjYWxsYmFjayBpc24ndCBoYW5kbGluZyB0aGUgY2FsbGJhY2tcblx0XHRcdFx0Ly8gRmFsc2UgLSB0aHJvdyBhIGVycm9yXG5cdFx0XHRcdGlmICghdG9rZW4pIHtcblx0XHRcdFx0XHQvLyBJZiB0aGVyZSBpc24ndCBhIHRva2VuLCB0aGUgYWJvdmUgd29udCByZXR1cm4gYSByZXNwb25zZSwgc28gbGV0cyB0cmlnZ2VyIGEgcmVzcG9uc2Vcblx0XHRcdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdC8vIEFQSSBCYXNlIFVSTFxuXHRcdFx0YmFzZTogJ2h0dHBzOi8vZ3JhcGguZmFjZWJvb2suY29tLycgKyB2ZXJzaW9uICsgJy8nLFxuXG5cdFx0XHQvLyBNYXAgR0VUIHJlcXVlc3RzXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6ICdtZT9maWVsZHM9ZW1haWwsZmlyc3RfbmFtZSxsYXN0X25hbWUsbmFtZSx0aW1lem9uZSx2ZXJpZmllZCcsXG5cdFx0XHRcdCdtZS9mcmllbmRzJzogJ21lL2ZyaWVuZHMnLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogJ21lL2ZyaWVuZHMnLFxuXHRcdFx0XHQnbWUvZm9sbG93ZXJzJzogJ21lL2ZyaWVuZHMnLFxuXHRcdFx0XHQnbWUvc2hhcmUnOiAnbWUvZmVlZCcsXG5cdFx0XHRcdCdtZS9saWtlJzogJ21lL2xpa2VzJyxcblx0XHRcdFx0J21lL2ZpbGVzJzogJ21lL2FsYnVtcycsXG5cdFx0XHRcdCdtZS9hbGJ1bXMnOiAnbWUvYWxidW1zP2ZpZWxkcz1jb3Zlcl9waG90byxuYW1lJyxcblx0XHRcdFx0J21lL2FsYnVtJzogJ0B7aWR9L3Bob3Rvcz9maWVsZHM9cGljdHVyZScsXG5cdFx0XHRcdCdtZS9waG90b3MnOiAnbWUvcGhvdG9zJyxcblx0XHRcdFx0J21lL3Bob3RvJzogJ0B7aWR9Jyxcblx0XHRcdFx0J2ZyaWVuZC9hbGJ1bXMnOiAnQHtpZH0vYWxidW1zJyxcblx0XHRcdFx0J2ZyaWVuZC9waG90b3MnOiAnQHtpZH0vcGhvdG9zJ1xuXG5cdFx0XHRcdC8vIFBhZ2luYXRpb25cblx0XHRcdFx0Ly8gSHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS9kb2NzL3JlZmVyZW5jZS9hcGkvcGFnaW5hdGlvbi9cblx0XHRcdH0sXG5cblx0XHRcdC8vIE1hcCBQT1NUIHJlcXVlc3RzXG5cdFx0XHRwb3N0OiB7XG5cdFx0XHRcdCdtZS9zaGFyZSc6ICdtZS9mZWVkJyxcblx0XHRcdFx0J21lL3Bob3RvJzogJ0B7aWR9J1xuXG5cdFx0XHRcdC8vIEh0dHBzOi8vZGV2ZWxvcGVycy5mYWNlYm9vay5jb20vZG9jcy9ncmFwaC1hcGkvcmVmZXJlbmNlL3YyLjIvb2JqZWN0L2xpa2VzL1xuXHRcdFx0fSxcblxuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZm9ybWF0VXNlcixcblx0XHRcdFx0J21lL2ZyaWVuZHMnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogZm9ybWF0RnJpZW5kcyxcblx0XHRcdFx0J21lL2ZvbGxvd2Vycyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9hbGJ1bXMnOiBmb3JtYXQsXG5cdFx0XHRcdCdtZS9waG90b3MnOiBmb3JtYXQsXG5cdFx0XHRcdCdtZS9maWxlcyc6IGZvcm1hdCxcblx0XHRcdFx0J2RlZmF1bHQnOiBmb3JtYXRcblx0XHRcdH0sXG5cblx0XHRcdC8vIFNwZWNpYWwgcmVxdWlyZW1lbnRzIGZvciBoYW5kbGluZyBYSFJcblx0XHRcdHhocjogZnVuY3Rpb24ocCwgcXMpIHtcblx0XHRcdFx0aWYgKHAubWV0aG9kID09PSAnZ2V0JyB8fCBwLm1ldGhvZCA9PT0gJ3Bvc3QnKSB7XG5cdFx0XHRcdFx0cXMuc3VwcHJlc3NfcmVzcG9uc2VfY29kZXMgPSB0cnVlO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gSXMgdGhpcyBhIHBvc3Qgd2l0aCBhIGRhdGEtdXJpP1xuXHRcdFx0XHRpZiAocC5tZXRob2QgPT09ICdwb3N0JyAmJiBwLmRhdGEgJiYgdHlwZW9mIChwLmRhdGEuZmlsZSkgPT09ICdzdHJpbmcnKSB7XG5cdFx0XHRcdFx0Ly8gQ29udmVydCB0aGUgRGF0YS1VUkkgdG8gYSBCbG9iXG5cdFx0XHRcdFx0cC5kYXRhLmZpbGUgPSBoZWxsby51dGlscy50b0Jsb2IocC5kYXRhLmZpbGUpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBTcGVjaWFsIHJlcXVpcmVtZW50cyBmb3IgaGFuZGxpbmcgSlNPTlAgZmFsbGJhY2tcblx0XHRcdGpzb25wOiBmdW5jdGlvbihwLCBxcykge1xuXHRcdFx0XHR2YXIgbSA9IHAubWV0aG9kO1xuXHRcdFx0XHRpZiAobSAhPT0gJ2dldCcgJiYgIWhlbGxvLnV0aWxzLmhhc0JpbmFyeShwLmRhdGEpKSB7XG5cdFx0XHRcdFx0cC5kYXRhLm1ldGhvZCA9IG07XG5cdFx0XHRcdFx0cC5tZXRob2QgPSAnZ2V0Jztcblx0XHRcdFx0fVxuXHRcdFx0XHRlbHNlIGlmIChwLm1ldGhvZCA9PT0gJ2RlbGV0ZScpIHtcblx0XHRcdFx0XHRxcy5tZXRob2QgPSAnZGVsZXRlJztcblx0XHRcdFx0XHRwLm1ldGhvZCA9ICdwb3N0Jztcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0Ly8gU3BlY2lhbCByZXF1aXJlbWVudHMgZm9yIGlmcmFtZSBmb3JtIGhhY2tcblx0XHRcdGZvcm06IGZ1bmN0aW9uKHApIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHQvLyBGaXJlIHRoZSBjYWxsYmFjayBvbmxvYWRcblx0XHRcdFx0XHRjYWxsYmFja29ubG9hZDogdHJ1ZVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH1cblx0fSk7XG5cblx0dmFyIGJhc2UgPSAnaHR0cHM6Ly9ncmFwaC5mYWNlYm9vay5jb20vJztcblxuXHRmdW5jdGlvbiBmb3JtYXRVc2VyKG8pIHtcblx0XHRpZiAoby5pZCkge1xuXHRcdFx0by50aHVtYm5haWwgPSBvLnBpY3R1cmUgPSAnaHR0cHM6Ly9ncmFwaC5mYWNlYm9vay5jb20vJyArIG8uaWQgKyAnL3BpY3R1cmUnO1xuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0RnJpZW5kcyhvKSB7XG5cdFx0aWYgKCdkYXRhJyBpbiBvKSB7XG5cdFx0XHRvLmRhdGEuZm9yRWFjaChmb3JtYXRVc2VyKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdChvLCBoZWFkZXJzLCByZXEpIHtcblx0XHRpZiAodHlwZW9mIG8gPT09ICdib29sZWFuJykge1xuXHRcdFx0byA9IHtzdWNjZXNzOiBvfTtcblx0XHR9XG5cblx0XHRpZiAobyAmJiAnZGF0YScgaW4gbykge1xuXHRcdFx0dmFyIHRva2VuID0gcmVxLnF1ZXJ5LmFjY2Vzc190b2tlbjtcblxuXHRcdFx0aWYgKCEoby5kYXRhIGluc3RhbmNlb2YgQXJyYXkpKSB7XG5cdFx0XHRcdHZhciBkYXRhID0gby5kYXRhO1xuXHRcdFx0XHRkZWxldGUgby5kYXRhO1xuXHRcdFx0XHRvLmRhdGEgPSBbZGF0YV07XG5cdFx0XHR9XG5cblx0XHRcdG8uZGF0YS5mb3JFYWNoKGZ1bmN0aW9uKGQpIHtcblxuXHRcdFx0XHRpZiAoZC5waWN0dXJlKSB7XG5cdFx0XHRcdFx0ZC50aHVtYm5haWwgPSBkLnBpY3R1cmU7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRkLnBpY3R1cmVzID0gKGQuaW1hZ2VzIHx8IFtdKVxuXHRcdFx0XHRcdC5zb3J0KGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdFx0XHRcdHJldHVybiBhLndpZHRoIC0gYi53aWR0aDtcblx0XHRcdFx0XHR9KTtcblxuXHRcdFx0XHRpZiAoZC5jb3Zlcl9waG90byAmJiBkLmNvdmVyX3Bob3RvLmlkKSB7XG5cdFx0XHRcdFx0ZC50aHVtYm5haWwgPSBiYXNlICsgZC5jb3Zlcl9waG90by5pZCArICcvcGljdHVyZT9hY2Nlc3NfdG9rZW49JyArIHRva2VuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKGQudHlwZSA9PT0gJ2FsYnVtJykge1xuXHRcdFx0XHRcdGQuZmlsZXMgPSBkLnBob3RvcyA9IGJhc2UgKyBkLmlkICsgJy9waG90b3MnO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKGQuY2FuX3VwbG9hZCkge1xuXHRcdFx0XHRcdGQudXBsb2FkX2xvY2F0aW9uID0gYmFzZSArIGQuaWQgKyAnL3Bob3Rvcyc7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cbn0pKGhlbGxvKTtcblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0aGVsbG8uaW5pdCh7XG5cblx0XHRmbGlja3I6IHtcblxuXHRcdFx0bmFtZTogJ0ZsaWNrcicsXG5cblx0XHRcdC8vIEVuc3VyZSB0aGF0IHlvdSBkZWZpbmUgYW4gb2F1dGhfcHJveHlcblx0XHRcdG9hdXRoOiB7XG5cdFx0XHRcdHZlcnNpb246ICcxLjBhJyxcblx0XHRcdFx0YXV0aDogJ2h0dHBzOi8vd3d3LmZsaWNrci5jb20vc2VydmljZXMvb2F1dGgvYXV0aG9yaXplP3Blcm1zPXJlYWQnLFxuXHRcdFx0XHRyZXF1ZXN0OiAnaHR0cHM6Ly93d3cuZmxpY2tyLmNvbS9zZXJ2aWNlcy9vYXV0aC9yZXF1ZXN0X3Rva2VuJyxcblx0XHRcdFx0dG9rZW46ICdodHRwczovL3d3dy5mbGlja3IuY29tL3NlcnZpY2VzL29hdXRoL2FjY2Vzc190b2tlbidcblx0XHRcdH0sXG5cblx0XHRcdC8vIEFQSSBiYXNlIFVSTFxuXHRcdFx0YmFzZTogJ2h0dHBzOi8vYXBpLmZsaWNrci5jb20vc2VydmljZXMvcmVzdCcsXG5cblx0XHRcdC8vIE1hcCBHRVQgcmVzcXVlc3RzXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6IHNpZ24oJ2ZsaWNrci5wZW9wbGUuZ2V0SW5mbycpLFxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6IHNpZ24oJ2ZsaWNrci5jb250YWN0cy5nZXRMaXN0Jywge3Blcl9wYWdlOidAe2xpbWl0fDUwfSd9KSxcblx0XHRcdFx0J21lL2ZvbGxvd2luZyc6IHNpZ24oJ2ZsaWNrci5jb250YWN0cy5nZXRMaXN0Jywge3Blcl9wYWdlOidAe2xpbWl0fDUwfSd9KSxcblx0XHRcdFx0J21lL2ZvbGxvd2Vycyc6IHNpZ24oJ2ZsaWNrci5jb250YWN0cy5nZXRMaXN0Jywge3Blcl9wYWdlOidAe2xpbWl0fDUwfSd9KSxcblx0XHRcdFx0J21lL2FsYnVtcyc6IHNpZ24oJ2ZsaWNrci5waG90b3NldHMuZ2V0TGlzdCcsIHtwZXJfcGFnZTonQHtsaW1pdHw1MH0nfSksXG5cdFx0XHRcdCdtZS9hbGJ1bSc6IHNpZ24oJ2ZsaWNrci5waG90b3NldHMuZ2V0UGhvdG9zJywge3Bob3Rvc2V0X2lkOiAnQHtpZH0nfSksXG5cdFx0XHRcdCdtZS9waG90b3MnOiBzaWduKCdmbGlja3IucGVvcGxlLmdldFBob3RvcycsIHtwZXJfcGFnZTonQHtsaW1pdHw1MH0nfSlcblx0XHRcdH0sXG5cblx0XHRcdHdyYXA6IHtcblx0XHRcdFx0bWU6IGZ1bmN0aW9uKG8pIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRvID0gY2hlY2tSZXNwb25zZShvLCAncGVyc29uJyk7XG5cdFx0XHRcdFx0aWYgKG8uaWQpIHtcblx0XHRcdFx0XHRcdGlmIChvLnJlYWxuYW1lKSB7XG5cdFx0XHRcdFx0XHRcdG8ubmFtZSA9IG8ucmVhbG5hbWUuX2NvbnRlbnQ7XG5cdFx0XHRcdFx0XHRcdHZhciBtID0gby5uYW1lLnNwbGl0KCcgJyk7XG5cdFx0XHRcdFx0XHRcdG8uZmlyc3RfbmFtZSA9IG0uc2hpZnQoKTtcblx0XHRcdFx0XHRcdFx0by5sYXN0X25hbWUgPSBtLmpvaW4oJyAnKTtcblx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0by50aHVtYm5haWwgPSBnZXRCdWRkeUljb24obywgJ2wnKTtcblx0XHRcdFx0XHRcdG8ucGljdHVyZSA9IGdldEJ1ZGR5SWNvbihvLCAnbCcpO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZS9mcmllbmRzJzogZm9ybWF0RnJpZW5kcyxcblx0XHRcdFx0J21lL2ZvbGxvd2Vycyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9mb2xsb3dpbmcnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvYWxidW1zJzogZnVuY3Rpb24obykge1xuXHRcdFx0XHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdFx0XHRcdG8gPSBjaGVja1Jlc3BvbnNlKG8sICdwaG90b3NldHMnKTtcblx0XHRcdFx0XHRwYWdpbmcobyk7XG5cdFx0XHRcdFx0aWYgKG8ucGhvdG9zZXQpIHtcblx0XHRcdFx0XHRcdG8uZGF0YSA9IG8ucGhvdG9zZXQ7XG5cdFx0XHRcdFx0XHRvLmRhdGEuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XG5cdFx0XHRcdFx0XHRcdGl0ZW0ubmFtZSA9IGl0ZW0udGl0bGUuX2NvbnRlbnQ7XG5cdFx0XHRcdFx0XHRcdGl0ZW0ucGhvdG9zID0gJ2h0dHBzOi8vYXBpLmZsaWNrci5jb20vc2VydmljZXMvcmVzdCcgKyBnZXRBcGlVcmwoJ2ZsaWNrci5waG90b3NldHMuZ2V0UGhvdG9zJywge3Bob3Rvc2V0X2lkOiBpdGVtLmlkfSwgdHJ1ZSk7XG5cdFx0XHRcdFx0XHR9KTtcblxuXHRcdFx0XHRcdFx0ZGVsZXRlIG8ucGhvdG9zZXQ7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cmV0dXJuIG87XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0J21lL3Bob3Rvcyc6IGZ1bmN0aW9uKG8pIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRyZXR1cm4gZm9ybWF0UGhvdG9zKG8pO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdkZWZhdWx0JzogZnVuY3Rpb24obykge1xuXHRcdFx0XHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdFx0XHRcdHJldHVybiBmb3JtYXRQaG90b3Mobyk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdHhocjogZmFsc2UsXG5cblx0XHRcdGpzb25wOiBmdW5jdGlvbihwLCBxcykge1xuXHRcdFx0XHRpZiAocC5tZXRob2QgPT0gJ2dldCcpIHtcblx0XHRcdFx0XHRkZWxldGUgcXMuY2FsbGJhY2s7XG5cdFx0XHRcdFx0cXMuanNvbmNhbGxiYWNrID0gcC5jYWxsYmFja0lEO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9KTtcblxuXHRmdW5jdGlvbiBnZXRBcGlVcmwobWV0aG9kLCBleHRyYVBhcmFtcywgc2tpcE5ldHdvcmspIHtcblx0XHR2YXIgdXJsID0gKChza2lwTmV0d29yaykgPyAnJyA6ICdmbGlja3I6JykgK1xuXHRcdFx0Jz9tZXRob2Q9JyArIG1ldGhvZCArXG5cdFx0XHQnJmFwaV9rZXk9JyArIGhlbGxvLnNlcnZpY2VzLmZsaWNrci5pZCArXG5cdFx0XHQnJmZvcm1hdD1qc29uJztcblx0XHRmb3IgKHZhciBwYXJhbSBpbiBleHRyYVBhcmFtcykge1xuXHRcdFx0aWYgKGV4dHJhUGFyYW1zLmhhc093blByb3BlcnR5KHBhcmFtKSkge1xuXHRcdFx0XHR1cmwgKz0gJyYnICsgcGFyYW0gKyAnPScgKyBleHRyYVBhcmFtc1twYXJhbV07XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHVybDtcblx0fVxuXG5cdC8vIFRoaXMgaXMgbm90IGV4YWN0bHkgbmVhdCBidXQgYXZvaWQgdG8gY2FsbFxuXHQvLyBUaGUgbWV0aG9kICdmbGlja3IudGVzdC5sb2dpbicgZm9yIGVhY2ggYXBpIGNhbGxcblxuXHRmdW5jdGlvbiB3aXRoVXNlcihjYikge1xuXHRcdHZhciBhdXRoID0gaGVsbG8uZ2V0QXV0aFJlc3BvbnNlKCdmbGlja3InKTtcblx0XHRjYihhdXRoICYmIGF1dGgudXNlcl9uc2lkID8gYXV0aC51c2VyX25zaWQgOiBudWxsKTtcblx0fVxuXG5cdGZ1bmN0aW9uIHNpZ24odXJsLCBwYXJhbXMpIHtcblx0XHRpZiAoIXBhcmFtcykge1xuXHRcdFx0cGFyYW1zID0ge307XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cdFx0XHR3aXRoVXNlcihmdW5jdGlvbih1c2VySWQpIHtcblx0XHRcdFx0cGFyYW1zLnVzZXJfaWQgPSB1c2VySWQ7XG5cdFx0XHRcdGNhbGxiYWNrKGdldEFwaVVybCh1cmwsIHBhcmFtcywgdHJ1ZSkpO1xuXHRcdFx0fSk7XG5cdFx0fTtcblx0fVxuXG5cdGZ1bmN0aW9uIGdldEJ1ZGR5SWNvbihwcm9maWxlLCBzaXplKSB7XG5cdFx0dmFyIHVybCA9ICdodHRwczovL3d3dy5mbGlja3IuY29tL2ltYWdlcy9idWRkeWljb24uZ2lmJztcblx0XHRpZiAocHJvZmlsZS5uc2lkICYmIHByb2ZpbGUuaWNvbnNlcnZlciAmJiBwcm9maWxlLmljb25mYXJtKSB7XG5cdFx0XHR1cmwgPSAnaHR0cHM6Ly9mYXJtJyArIHByb2ZpbGUuaWNvbmZhcm0gKyAnLnN0YXRpY2ZsaWNrci5jb20vJyArXG5cdFx0XHRcdHByb2ZpbGUuaWNvbnNlcnZlciArICcvJyArXG5cdFx0XHRcdCdidWRkeWljb25zLycgKyBwcm9maWxlLm5zaWQgK1xuXHRcdFx0XHQoKHNpemUpID8gJ18nICsgc2l6ZSA6ICcnKSArICcuanBnJztcblx0XHR9XG5cblx0XHRyZXR1cm4gdXJsO1xuXHR9XG5cblx0Ly8gU2VlOiBodHRwczovL3d3dy5mbGlja3IuY29tL3NlcnZpY2VzL2FwaS9taXNjLnVybHMuaHRtbFxuXHRmdW5jdGlvbiBjcmVhdGVQaG90b1VybChpZCwgZmFybSwgc2VydmVyLCBzZWNyZXQsIHNpemUpIHtcblx0XHRzaXplID0gKHNpemUpID8gJ18nICsgc2l6ZSA6ICcnO1xuXHRcdHJldHVybiAnaHR0cHM6Ly9mYXJtJyArIGZhcm0gKyAnLnN0YXRpY2ZsaWNrci5jb20vJyArIHNlcnZlciArICcvJyArIGlkICsgJ18nICsgc2VjcmV0ICsgc2l6ZSArICcuanBnJztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFVzZXIobykge1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0RXJyb3Iobykge1xuXHRcdGlmIChvICYmIG8uc3RhdCAmJiBvLnN0YXQudG9Mb3dlckNhc2UoKSAhPSAnb2snKSB7XG5cdFx0XHRvLmVycm9yID0ge1xuXHRcdFx0XHRjb2RlOiAnaW52YWxpZF9yZXF1ZXN0Jyxcblx0XHRcdFx0bWVzc2FnZTogby5tZXNzYWdlXG5cdFx0XHR9O1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFBob3RvcyhvKSB7XG5cdFx0aWYgKG8ucGhvdG9zZXQgfHwgby5waG90b3MpIHtcblx0XHRcdHZhciBzZXQgPSAoJ3Bob3Rvc2V0JyBpbiBvKSA/ICdwaG90b3NldCcgOiAncGhvdG9zJztcblx0XHRcdG8gPSBjaGVja1Jlc3BvbnNlKG8sIHNldCk7XG5cdFx0XHRwYWdpbmcobyk7XG5cdFx0XHRvLmRhdGEgPSBvLnBob3RvO1xuXHRcdFx0ZGVsZXRlIG8ucGhvdG87XG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IG8uZGF0YS5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHR2YXIgcGhvdG8gPSBvLmRhdGFbaV07XG5cdFx0XHRcdHBob3RvLm5hbWUgPSBwaG90by50aXRsZTtcblx0XHRcdFx0cGhvdG8ucGljdHVyZSA9IGNyZWF0ZVBob3RvVXJsKHBob3RvLmlkLCBwaG90by5mYXJtLCBwaG90by5zZXJ2ZXIsIHBob3RvLnNlY3JldCwgJycpO1xuXHRcdFx0XHRwaG90by5waWN0dXJlcyA9IGNyZWF0ZVBpY3R1cmVzKHBob3RvLmlkLCBwaG90by5mYXJtLCBwaG90by5zZXJ2ZXIsIHBob3RvLnNlY3JldCk7XG5cdFx0XHRcdHBob3RvLnNvdXJjZSA9IGNyZWF0ZVBob3RvVXJsKHBob3RvLmlkLCBwaG90by5mYXJtLCBwaG90by5zZXJ2ZXIsIHBob3RvLnNlY3JldCwgJ2InKTtcblx0XHRcdFx0cGhvdG8udGh1bWJuYWlsID0gY3JlYXRlUGhvdG9VcmwocGhvdG8uaWQsIHBob3RvLmZhcm0sIHBob3RvLnNlcnZlciwgcGhvdG8uc2VjcmV0LCAnbScpO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0Ly8gU2VlOiBodHRwczovL3d3dy5mbGlja3IuY29tL3NlcnZpY2VzL2FwaS9taXNjLnVybHMuaHRtbFxuXHRmdW5jdGlvbiBjcmVhdGVQaWN0dXJlcyhpZCwgZmFybSwgc2VydmVyLCBzZWNyZXQpIHtcblxuXHRcdHZhciBOT19MSU1JVCA9IDIwNDg7XG5cdFx0dmFyIHNpemVzID0gW1xuXHRcdFx0e2lkOiAndCcsIG1heDogMTAwfSxcblx0XHRcdHtpZDogJ20nLCBtYXg6IDI0MH0sXG5cdFx0XHR7aWQ6ICduJywgbWF4OiAzMjB9LFxuXHRcdFx0e2lkOiAnJywgbWF4OiA1MDB9LFxuXHRcdFx0e2lkOiAneicsIG1heDogNjQwfSxcblx0XHRcdHtpZDogJ2MnLCBtYXg6IDgwMH0sXG5cdFx0XHR7aWQ6ICdiJywgbWF4OiAxMDI0fSxcblx0XHRcdHtpZDogJ2gnLCBtYXg6IDE2MDB9LFxuXHRcdFx0e2lkOiAnaycsIG1heDogMjA0OH0sXG5cdFx0XHR7aWQ6ICdvJywgbWF4OiBOT19MSU1JVH1cblx0XHRdO1xuXG5cdFx0cmV0dXJuIHNpemVzLm1hcChmdW5jdGlvbihzaXplKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRzb3VyY2U6IGNyZWF0ZVBob3RvVXJsKGlkLCBmYXJtLCBzZXJ2ZXIsIHNlY3JldCwgc2l6ZS5pZCksXG5cblx0XHRcdFx0Ly8gTm90ZTogdGhpcyBpcyBhIGd1ZXNzIHRoYXQncyBhbG1vc3QgY2VydGFpbiB0byBiZSB3cm9uZyAodW5sZXNzIHNxdWFyZSBzb3VyY2UpXG5cdFx0XHRcdHdpZHRoOiBzaXplLm1heCxcblx0XHRcdFx0aGVpZ2h0OiBzaXplLm1heFxuXHRcdFx0fTtcblx0XHR9KTtcblx0fVxuXG5cdGZ1bmN0aW9uIGNoZWNrUmVzcG9uc2Uobywga2V5KSB7XG5cblx0XHRpZiAoa2V5IGluIG8pIHtcblx0XHRcdG8gPSBvW2tleV07XG5cdFx0fVxuXHRcdGVsc2UgaWYgKCEoJ2Vycm9yJyBpbiBvKSkge1xuXHRcdFx0by5lcnJvciA9IHtcblx0XHRcdFx0Y29kZTogJ2ludmFsaWRfcmVxdWVzdCcsXG5cdFx0XHRcdG1lc3NhZ2U6IG8ubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGdldCBkYXRhIGZyb20gRmxpY2tyJ1xuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEZyaWVuZHMobykge1xuXHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdGlmIChvLmNvbnRhY3RzKSB7XG5cdFx0XHRvID0gY2hlY2tSZXNwb25zZShvLCAnY29udGFjdHMnKTtcblx0XHRcdHBhZ2luZyhvKTtcblx0XHRcdG8uZGF0YSA9IG8uY29udGFjdDtcblx0XHRcdGRlbGV0ZSBvLmNvbnRhY3Q7XG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IG8uZGF0YS5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHR2YXIgaXRlbSA9IG8uZGF0YVtpXTtcblx0XHRcdFx0aXRlbS5pZCA9IGl0ZW0ubnNpZDtcblx0XHRcdFx0aXRlbS5uYW1lID0gaXRlbS5yZWFsbmFtZSB8fCBpdGVtLnVzZXJuYW1lO1xuXHRcdFx0XHRpdGVtLnRodW1ibmFpbCA9IGdldEJ1ZGR5SWNvbihpdGVtLCAnbScpO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gcGFnaW5nKHJlcykge1xuXHRcdGlmIChyZXMucGFnZSAmJiByZXMucGFnZXMgJiYgcmVzLnBhZ2UgIT09IHJlcy5wYWdlcykge1xuXHRcdFx0cmVzLnBhZ2luZyA9IHtcblx0XHRcdFx0bmV4dDogJz9wYWdlPScgKyAoKytyZXMucGFnZSlcblx0XHRcdH07XG5cdFx0fVxuXHR9XG5cbn0pKGhlbGxvKTtcblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0aGVsbG8uaW5pdCh7XG5cblx0XHRmb3Vyc3F1YXJlOiB7XG5cblx0XHRcdG5hbWU6ICdGb3Vyc3F1YXJlJyxcblxuXHRcdFx0b2F1dGg6IHtcblx0XHRcdFx0Ly8gU2VlOiBodHRwczovL2RldmVsb3Blci5mb3Vyc3F1YXJlLmNvbS9vdmVydmlldy9hdXRoXG5cdFx0XHRcdHZlcnNpb246IDIsXG5cdFx0XHRcdGF1dGg6ICdodHRwczovL2ZvdXJzcXVhcmUuY29tL29hdXRoMi9hdXRoZW50aWNhdGUnLFxuXHRcdFx0XHRncmFudDogJ2h0dHBzOi8vZm91cnNxdWFyZS5jb20vb2F1dGgyL2FjY2Vzc190b2tlbidcblx0XHRcdH0sXG5cblx0XHRcdC8vIFJlZnJlc2ggdGhlIGFjY2Vzc190b2tlbiBvbmNlIGV4cGlyZWRcblx0XHRcdHJlZnJlc2g6IHRydWUsXG5cblx0XHRcdGJhc2U6ICdodHRwczovL2FwaS5mb3Vyc3F1YXJlLmNvbS92Mi8nLFxuXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6ICd1c2Vycy9zZWxmJyxcblx0XHRcdFx0J21lL2ZyaWVuZHMnOiAndXNlcnMvc2VsZi9mcmllbmRzJyxcblx0XHRcdFx0J21lL2ZvbGxvd2Vycyc6ICd1c2Vycy9zZWxmL2ZyaWVuZHMnLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogJ3VzZXJzL3NlbGYvZnJpZW5kcydcblx0XHRcdH0sXG5cblx0XHRcdHdyYXA6IHtcblx0XHRcdFx0bWU6IGZ1bmN0aW9uKG8pIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRpZiAobyAmJiBvLnJlc3BvbnNlKSB7XG5cdFx0XHRcdFx0XHRvID0gby5yZXNwb25zZS51c2VyO1xuXHRcdFx0XHRcdFx0Zm9ybWF0VXNlcihvKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fSxcblxuXHRcdFx0XHQnZGVmYXVsdCc6IGZ1bmN0aW9uKG8pIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblxuXHRcdFx0XHRcdC8vIEZvcm1hdCBmcmllbmRzXG5cdFx0XHRcdFx0aWYgKG8gJiYgJ3Jlc3BvbnNlJyBpbiBvICYmICdmcmllbmRzJyBpbiBvLnJlc3BvbnNlICYmICdpdGVtcycgaW4gby5yZXNwb25zZS5mcmllbmRzKSB7XG5cdFx0XHRcdFx0XHRvLmRhdGEgPSBvLnJlc3BvbnNlLmZyaWVuZHMuaXRlbXM7XG5cdFx0XHRcdFx0XHRvLmRhdGEuZm9yRWFjaChmb3JtYXRVc2VyKTtcblx0XHRcdFx0XHRcdGRlbGV0ZSBvLnJlc3BvbnNlO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXG5cdFx0XHR4aHI6IGZvcm1hdFJlcXVlc3QsXG5cdFx0XHRqc29ucDogZm9ybWF0UmVxdWVzdFxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gZm9ybWF0RXJyb3Iobykge1xuXHRcdGlmIChvLm1ldGEgJiYgKG8ubWV0YS5jb2RlID09PSA0MDAgfHwgby5tZXRhLmNvZGUgPT09IDQwMSkpIHtcblx0XHRcdG8uZXJyb3IgPSB7XG5cdFx0XHRcdGNvZGU6ICdhY2Nlc3NfZGVuaWVkJyxcblx0XHRcdFx0bWVzc2FnZTogby5tZXRhLmVycm9yRGV0YWlsXG5cdFx0XHR9O1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFVzZXIobykge1xuXHRcdGlmIChvICYmIG8uaWQpIHtcblx0XHRcdG8udGh1bWJuYWlsID0gby5waG90by5wcmVmaXggKyAnMTAweDEwMCcgKyBvLnBob3RvLnN1ZmZpeDtcblx0XHRcdG8ubmFtZSA9IG8uZmlyc3ROYW1lICsgJyAnICsgby5sYXN0TmFtZTtcblx0XHRcdG8uZmlyc3RfbmFtZSA9IG8uZmlyc3ROYW1lO1xuXHRcdFx0by5sYXN0X25hbWUgPSBvLmxhc3ROYW1lO1xuXHRcdFx0aWYgKG8uY29udGFjdCkge1xuXHRcdFx0XHRpZiAoby5jb250YWN0LmVtYWlsKSB7XG5cdFx0XHRcdFx0by5lbWFpbCA9IG8uY29udGFjdC5lbWFpbDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFJlcXVlc3QocCwgcXMpIHtcblx0XHR2YXIgdG9rZW4gPSBxcy5hY2Nlc3NfdG9rZW47XG5cdFx0ZGVsZXRlIHFzLmFjY2Vzc190b2tlbjtcblx0XHRxcy5vYXV0aF90b2tlbiA9IHRva2VuO1xuXHRcdHFzLnYgPSAyMDEyMTEyNTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXG59KShoZWxsbyk7XG5cbihmdW5jdGlvbihoZWxsbykge1xuXG5cdGhlbGxvLmluaXQoe1xuXG5cdFx0Z2l0aHViOiB7XG5cblx0XHRcdG5hbWU6ICdHaXRIdWInLFxuXG5cdFx0XHRvYXV0aDoge1xuXHRcdFx0XHR2ZXJzaW9uOiAyLFxuXHRcdFx0XHRhdXRoOiAnaHR0cHM6Ly9naXRodWIuY29tL2xvZ2luL29hdXRoL2F1dGhvcml6ZScsXG5cdFx0XHRcdGdyYW50OiAnaHR0cHM6Ly9naXRodWIuY29tL2xvZ2luL29hdXRoL2FjY2Vzc190b2tlbicsXG5cdFx0XHRcdHJlc3BvbnNlX3R5cGU6ICdjb2RlJ1xuXHRcdFx0fSxcblxuXHRcdFx0c2NvcGU6IHtcblx0XHRcdFx0ZW1haWw6ICd1c2VyOmVtYWlsJ1xuXHRcdFx0fSxcblxuXHRcdFx0YmFzZTogJ2h0dHBzOi8vYXBpLmdpdGh1Yi5jb20vJyxcblxuXHRcdFx0Z2V0OiB7XG5cdFx0XHRcdG1lOiAndXNlcicsXG5cdFx0XHRcdCdtZS9mcmllbmRzJzogJ3VzZXIvZm9sbG93aW5nP3Blcl9wYWdlPUB7bGltaXR8MTAwfScsXG5cdFx0XHRcdCdtZS9mb2xsb3dpbmcnOiAndXNlci9mb2xsb3dpbmc/cGVyX3BhZ2U9QHtsaW1pdHwxMDB9Jyxcblx0XHRcdFx0J21lL2ZvbGxvd2Vycyc6ICd1c2VyL2ZvbGxvd2Vycz9wZXJfcGFnZT1Ae2xpbWl0fDEwMH0nLFxuXHRcdFx0XHQnbWUvbGlrZSc6ICd1c2VyL3N0YXJyZWQ/cGVyX3BhZ2U9QHtsaW1pdHwxMDB9J1xuXHRcdFx0fSxcblxuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZnVuY3Rpb24obywgaGVhZGVycykge1xuXG5cdFx0XHRcdFx0Zm9ybWF0RXJyb3IobywgaGVhZGVycyk7XG5cdFx0XHRcdFx0Zm9ybWF0VXNlcihvKTtcblxuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdkZWZhdWx0JzogZnVuY3Rpb24obywgaGVhZGVycywgcmVxKSB7XG5cblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvLCBoZWFkZXJzKTtcblxuXHRcdFx0XHRcdGlmIChBcnJheS5pc0FycmF5KG8pKSB7XG5cdFx0XHRcdFx0XHRvID0ge2RhdGE6b307XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0aWYgKG8uZGF0YSkge1xuXHRcdFx0XHRcdFx0cGFnaW5nKG8sIGhlYWRlcnMsIHJlcSk7XG5cdFx0XHRcdFx0XHRvLmRhdGEuZm9yRWFjaChmb3JtYXRVc2VyKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0eGhyOiBmdW5jdGlvbihwKSB7XG5cblx0XHRcdFx0aWYgKHAubWV0aG9kICE9PSAnZ2V0JyAmJiBwLmRhdGEpIHtcblxuXHRcdFx0XHRcdC8vIFNlcmlhbGl6ZSBwYXlsb2FkIGFzIEpTT05cblx0XHRcdFx0XHRwLmhlYWRlcnMgPSBwLmhlYWRlcnMgfHwge307XG5cdFx0XHRcdFx0cC5oZWFkZXJzWydDb250ZW50LVR5cGUnXSA9ICdhcHBsaWNhdGlvbi9qc29uJztcblx0XHRcdFx0XHRpZiAodHlwZW9mIChwLmRhdGEpID09PSAnb2JqZWN0Jykge1xuXHRcdFx0XHRcdFx0cC5kYXRhID0gSlNPTi5zdHJpbmdpZnkocC5kYXRhKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdH1cblx0XHR9XG5cdH0pO1xuXG5cdGZ1bmN0aW9uIGZvcm1hdEVycm9yKG8sIGhlYWRlcnMpIHtcblx0XHR2YXIgY29kZSA9IGhlYWRlcnMgPyBoZWFkZXJzLnN0YXR1c0NvZGUgOiAobyAmJiAnbWV0YScgaW4gbyAmJiAnc3RhdHVzJyBpbiBvLm1ldGEgJiYgby5tZXRhLnN0YXR1cyk7XG5cdFx0aWYgKChjb2RlID09PSA0MDEgfHwgY29kZSA9PT0gNDAzKSkge1xuXHRcdFx0by5lcnJvciA9IHtcblx0XHRcdFx0Y29kZTogJ2FjY2Vzc19kZW5pZWQnLFxuXHRcdFx0XHRtZXNzYWdlOiBvLm1lc3NhZ2UgfHwgKG8uZGF0YSA/IG8uZGF0YS5tZXNzYWdlIDogJ0NvdWxkIG5vdCBnZXQgcmVzcG9uc2UnKVxuXHRcdFx0fTtcblx0XHRcdGRlbGV0ZSBvLm1lc3NhZ2U7XG5cdFx0fVxuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0VXNlcihvKSB7XG5cdFx0aWYgKG8uaWQpIHtcblx0XHRcdG8udGh1bWJuYWlsID0gby5waWN0dXJlID0gby5hdmF0YXJfdXJsO1xuXHRcdFx0by5uYW1lID0gby5sb2dpbjtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBwYWdpbmcocmVzLCBoZWFkZXJzLCByZXEpIHtcblx0XHRpZiAocmVzLmRhdGEgJiYgcmVzLmRhdGEubGVuZ3RoICYmIGhlYWRlcnMgJiYgaGVhZGVycy5MaW5rKSB7XG5cdFx0XHR2YXIgbmV4dCA9IGhlYWRlcnMuTGluay5tYXRjaCgvPCguKj8pPjtcXHMqcmVsPVxcXCJuZXh0XFxcIi8pO1xuXHRcdFx0aWYgKG5leHQpIHtcblx0XHRcdFx0cmVzLnBhZ2luZyA9IHtcblx0XHRcdFx0XHRuZXh0OiBuZXh0WzFdXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cbn0pKGhlbGxvKTtcblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0dmFyIGNvbnRhY3RzVXJsID0gJ2h0dHBzOi8vd3d3Lmdvb2dsZS5jb20vbTgvZmVlZHMvY29udGFjdHMvZGVmYXVsdC9mdWxsP3Y9My4wJmFsdD1qc29uJm1heC1yZXN1bHRzPUB7bGltaXR8MTAwMH0mc3RhcnQtaW5kZXg9QHtzdGFydHwxfSc7XG5cblx0aGVsbG8uaW5pdCh7XG5cblx0XHRnb29nbGU6IHtcblxuXHRcdFx0bmFtZTogJ0dvb2dsZSBTaWduLUluJyxcblxuXHRcdFx0Ly8gU2VlOiBodHRwOi8vY29kZS5nb29nbGUuY29tL2FwaXMvYWNjb3VudHMvZG9jcy9PQXV0aDJVc2VyQWdlbnQuaHRtbFxuXHRcdFx0b2F1dGg6IHtcblx0XHRcdFx0dmVyc2lvbjogMixcblx0XHRcdFx0YXV0aDogJ2h0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbS9vL29hdXRoMi92Mi9hdXRoJyxcblx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9vYXV0aDIvdjQvdG9rZW4nXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBBdXRob3JpemF0aW9uIHNjb3Blc1xuXHRcdFx0c2NvcGU6IHtcblx0XHRcdFx0YmFzaWM6ICdvcGVuaWQgcHJvZmlsZScsXG5cdFx0XHRcdGVtYWlsOiAnZW1haWwnLFxuXHRcdFx0XHRiaXJ0aGRheTogJycsXG5cdFx0XHRcdGV2ZW50czogJycsXG5cdFx0XHRcdHBob3RvczogJ2h0dHBzOi8vcGljYXNhd2ViLmdvb2dsZS5jb20vZGF0YS8nLFxuXHRcdFx0XHR2aWRlb3M6ICdodHRwOi8vZ2RhdGEueW91dHViZS5jb20nLFxuXHRcdFx0XHRmaWxlczogJ2h0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL2F1dGgvZHJpdmUucmVhZG9ubHknLFxuXHRcdFx0XHRwdWJsaXNoOiAnJyxcblx0XHRcdFx0cHVibGlzaF9maWxlczogJ2h0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL2F1dGgvZHJpdmUnLFxuXHRcdFx0XHRzaGFyZTogJycsXG5cdFx0XHRcdGNyZWF0ZV9ldmVudDogJycsXG5cdFx0XHRcdG9mZmxpbmVfYWNjZXNzOiAnJ1xuXHRcdFx0fSxcblxuXHRcdFx0c2NvcGVfZGVsaW06ICcgJyxcblxuXHRcdFx0bG9naW46IGZ1bmN0aW9uKHApIHtcblxuXHRcdFx0XHRpZiAocC5xcy5yZXNwb25zZV90eXBlID09PSAnY29kZScpIHtcblxuXHRcdFx0XHRcdC8vIExldCdzIHNldCB0aGlzIHRvIGFuIG9mZmxpbmUgYWNjZXNzIHRvIHJldHVybiBhIHJlZnJlc2hfdG9rZW5cblx0XHRcdFx0XHRwLnFzLmFjY2Vzc190eXBlID0gJ29mZmxpbmUnO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2UgaWYgKHAucXMucmVzcG9uc2VfdHlwZS5pbmRleE9mKCdpZF90b2tlbicpID4gLTEpIHtcblx0XHRcdFx0XHRwLnFzLm5vbmNlID0gcGFyc2VJbnQoTWF0aC5yYW5kb20oKSAqIDFlMTIsIDEwKS50b1N0cmluZygzNik7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBSZWF1dGhlbnRpY2F0ZVxuXHRcdFx0XHQvLyBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS9pZGVudGl0eS9wcm90b2NvbHMvXG5cdFx0XHRcdGlmIChwLm9wdGlvbnMuZm9yY2UpIHtcblx0XHRcdFx0XHRwLnFzLmFwcHJvdmFsX3Byb21wdCA9ICdmb3JjZSc7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdC8vIEFQSSBiYXNlIFVSSVxuXHRcdFx0YmFzZTogJ2h0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tLycsXG5cblx0XHRcdC8vIE1hcCBHRVQgcmVxdWVzdHNcblx0XHRcdGdldDoge1xuXHRcdFx0XHRtZTogJ29hdXRoMi92My91c2VyaW5mbz9hbHQ9anNvbicsXG5cblx0XHRcdFx0Ly8gRGVwcmVjYXRlZCBTZXB0IDEsIDIwMTRcblx0XHRcdFx0Ly8nbWUnOiAnb2F1dGgyL3YxL3VzZXJpbmZvP2FsdD1qc29uJyxcblxuXHRcdFx0XHQvLyBTZWU6IGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tLysvYXBpL2xhdGVzdC9wZW9wbGUvbGlzdFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogY29udGFjdHNVcmwsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiBjb250YWN0c1VybCxcblx0XHRcdFx0J21lL2NvbnRhY3RzJzogY29udGFjdHNVcmwsXG5cdFx0XHRcdCdtZS9hbGJ1bXMnOiAnaHR0cHM6Ly9waWNhc2F3ZWIuZ29vZ2xlLmNvbS9kYXRhL2ZlZWQvYXBpL3VzZXIvZGVmYXVsdD9hbHQ9anNvbiZtYXgtcmVzdWx0cz1Ae2xpbWl0fDEwMH0mc3RhcnQtaW5kZXg9QHtzdGFydHwxfScsXG5cdFx0XHRcdCdtZS9hbGJ1bSc6IGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cdFx0XHRcdFx0dmFyIGtleSA9IHAucXVlcnkuaWQ7XG5cdFx0XHRcdFx0ZGVsZXRlIHAucXVlcnkuaWQ7XG5cdFx0XHRcdFx0Y2FsbGJhY2soa2V5LnJlcGxhY2UoJy9lbnRyeS8nLCAnL2ZlZWQvJykpO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZS9waG90b3MnOiAnaHR0cHM6Ly9waWNhc2F3ZWIuZ29vZ2xlLmNvbS9kYXRhL2ZlZWQvYXBpL3VzZXIvZGVmYXVsdD9hbHQ9anNvbiZraW5kPXBob3RvJm1heC1yZXN1bHRzPUB7bGltaXR8MTAwfSZzdGFydC1pbmRleD1Ae3N0YXJ0fDF9JyxcblxuXHRcdFx0XHQvLyBTZWU6IGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL2RyaXZlL3YyL3JlZmVyZW5jZS9maWxlcy9saXN0XG5cdFx0XHRcdCdtZS9maWxlJzogJ2RyaXZlL3YyL2ZpbGVzL0B7aWR9Jyxcblx0XHRcdFx0J21lL2ZpbGVzJzogJ2RyaXZlL3YyL2ZpbGVzP3E9JTIyQHtwYXJlbnR8cm9vdH0lMjIraW4rcGFyZW50cythbmQrdHJhc2hlZD1mYWxzZSZtYXhSZXN1bHRzPUB7bGltaXR8MTAwfScsXG5cblx0XHRcdFx0Ly8gU2VlOiBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS9kcml2ZS92Mi9yZWZlcmVuY2UvZmlsZXMvbGlzdFxuXHRcdFx0XHQnbWUvZm9sZGVycyc6ICdkcml2ZS92Mi9maWxlcz9xPSUyMkB7aWR8cm9vdH0lMjIraW4rcGFyZW50cythbmQrbWltZVR5cGUrPSslMjJhcHBsaWNhdGlvbi92bmQuZ29vZ2xlLWFwcHMuZm9sZGVyJTIyK2FuZCt0cmFzaGVkPWZhbHNlJm1heFJlc3VsdHM9QHtsaW1pdHwxMDB9JyxcblxuXHRcdFx0XHQvLyBTZWU6IGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL2RyaXZlL3YyL3JlZmVyZW5jZS9maWxlcy9saXN0XG5cdFx0XHRcdCdtZS9mb2xkZXInOiAnZHJpdmUvdjIvZmlsZXM/cT0lMjJAe2lkfHJvb3R9JTIyK2luK3BhcmVudHMrYW5kK3RyYXNoZWQ9ZmFsc2UmbWF4UmVzdWx0cz1Ae2xpbWl0fDEwMH0nXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBNYXAgUE9TVCByZXF1ZXN0c1xuXHRcdFx0cG9zdDoge1xuXG5cdFx0XHRcdC8vIEdvb2dsZSBEcml2ZVxuXHRcdFx0XHQnbWUvZmlsZXMnOiB1cGxvYWREcml2ZSxcblx0XHRcdFx0J21lL2ZvbGRlcnMnOiBmdW5jdGlvbihwLCBjYWxsYmFjaykge1xuXHRcdFx0XHRcdHAuZGF0YSA9IHtcblx0XHRcdFx0XHRcdHRpdGxlOiBwLmRhdGEubmFtZSxcblx0XHRcdFx0XHRcdHBhcmVudHM6IFt7aWQ6IHAuZGF0YS5wYXJlbnQgfHwgJ3Jvb3QnfV0sXG5cdFx0XHRcdFx0XHRtaW1lVHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5nb29nbGUtYXBwcy5mb2xkZXInXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRjYWxsYmFjaygnZHJpdmUvdjIvZmlsZXMnKTtcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0Ly8gTWFwIFBVVCByZXF1ZXN0c1xuXHRcdFx0cHV0OiB7XG5cdFx0XHRcdCdtZS9maWxlcyc6IHVwbG9hZERyaXZlXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBNYXAgREVMRVRFIHJlcXVlc3RzXG5cdFx0XHRkZWw6IHtcblx0XHRcdFx0J21lL2ZpbGVzJzogJ2RyaXZlL3YyL2ZpbGVzL0B7aWR9Jyxcblx0XHRcdFx0J21lL2ZvbGRlcic6ICdkcml2ZS92Mi9maWxlcy9Ae2lkfSdcblx0XHRcdH0sXG5cblx0XHRcdC8vIE1hcCBQQVRDSCByZXF1ZXN0c1xuXHRcdFx0cGF0Y2g6IHtcblx0XHRcdFx0J21lL2ZpbGUnOiAnZHJpdmUvdjIvZmlsZXMvQHtpZH0nXG5cdFx0XHR9LFxuXG5cdFx0XHR3cmFwOiB7XG5cdFx0XHRcdG1lOiBmdW5jdGlvbihvKSB7XG5cdFx0XHRcdFx0aWYgKG8uc3ViKSB7XG5cdFx0XHRcdFx0XHRvLmlkID0gby5zdWI7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0aWYgKG8uaWQpIHtcblx0XHRcdFx0XHRcdG8ubGFzdF9uYW1lID0gby5mYW1pbHlfbmFtZSB8fCAoby5uYW1lID8gby5uYW1lLmZhbWlseU5hbWUgOiBudWxsKTtcblx0XHRcdFx0XHRcdG8uZmlyc3RfbmFtZSA9IG8uZ2l2ZW5fbmFtZSB8fCAoby5uYW1lID8gby5uYW1lLmdpdmVuTmFtZSA6IG51bGwpO1xuXG5cdFx0XHRcdFx0XHRpZiAoby5lbWFpbHMgJiYgby5lbWFpbHMubGVuZ3RoKSB7XG5cdFx0XHRcdFx0XHRcdG8uZW1haWwgPSBvLmVtYWlsc1swXS52YWx1ZTtcblx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0Zm9ybWF0UGVyc29uKG8pO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZS9mcmllbmRzJzogZnVuY3Rpb24obykge1xuXHRcdFx0XHRcdGlmIChvLml0ZW1zKSB7XG5cdFx0XHRcdFx0XHRwYWdpbmcobyk7XG5cdFx0XHRcdFx0XHRvLmRhdGEgPSBvLml0ZW1zO1xuXHRcdFx0XHRcdFx0by5kYXRhLmZvckVhY2goZm9ybWF0UGVyc29uKTtcblx0XHRcdFx0XHRcdGRlbGV0ZSBvLml0ZW1zO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZS9jb250YWN0cyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogZm9ybWF0RnJpZW5kcyxcblx0XHRcdFx0J21lL3NoYXJlJzogZm9ybWF0RmVlZCxcblx0XHRcdFx0J21lL2ZlZWQnOiBmb3JtYXRGZWVkLFxuXHRcdFx0XHQnbWUvYWxidW1zJzogZ0VudHJ5LFxuXHRcdFx0XHQnbWUvcGhvdG9zJzogZm9ybWF0UGhvdG9zLFxuXHRcdFx0XHQnZGVmYXVsdCc6IGdFbnRyeVxuXHRcdFx0fSxcblxuXHRcdFx0eGhyOiBmdW5jdGlvbihwKSB7XG5cblx0XHRcdFx0aWYgKHAubWV0aG9kID09PSAncG9zdCcgfHwgcC5tZXRob2QgPT09ICdwdXQnKSB7XG5cdFx0XHRcdFx0dG9KU09OKHApO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGVsc2UgaWYgKHAubWV0aG9kID09PSAncGF0Y2gnKSB7XG5cdFx0XHRcdFx0aGVsbG8udXRpbHMuZXh0ZW5kKHAucXVlcnksIHAuZGF0YSk7XG5cdFx0XHRcdFx0cC5kYXRhID0gbnVsbDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gRG9uJ3QgZXZlbiB0cnkgc3VibWl0dGluZyB2aWEgZm9ybS5cblx0XHRcdC8vIFRoaXMgbWVhbnMgbm8gUE9TVCBvcGVyYXRpb25zIGluIDw9SUU5XG5cdFx0XHRmb3JtOiBmYWxzZVxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gdG9JbnQocykge1xuXHRcdHJldHVybiBwYXJzZUludChzLCAxMCk7XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRGZWVkKG8pIHtcblx0XHRwYWdpbmcobyk7XG5cdFx0by5kYXRhID0gby5pdGVtcztcblx0XHRkZWxldGUgby5pdGVtcztcblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdC8vIEZvcm1hdDogZW5zdXJlIGVhY2ggcmVjb3JkIGNvbnRhaW5zIGEgbmFtZSwgaWQgZXRjLlxuXHRmdW5jdGlvbiBmb3JtYXRJdGVtKG8pIHtcblx0XHRpZiAoby5lcnJvcikge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGlmICghby5uYW1lKSB7XG5cdFx0XHRvLm5hbWUgPSBvLnRpdGxlIHx8IG8ubWVzc2FnZTtcblx0XHR9XG5cblx0XHRpZiAoIW8ucGljdHVyZSkge1xuXHRcdFx0by5waWN0dXJlID0gby50aHVtYm5haWxMaW5rO1xuXHRcdH1cblxuXHRcdGlmICghby50aHVtYm5haWwpIHtcblx0XHRcdG8udGh1bWJuYWlsID0gby50aHVtYm5haWxMaW5rO1xuXHRcdH1cblxuXHRcdGlmIChvLm1pbWVUeXBlID09PSAnYXBwbGljYXRpb24vdm5kLmdvb2dsZS1hcHBzLmZvbGRlcicpIHtcblx0XHRcdG8udHlwZSA9ICdmb2xkZXInO1xuXHRcdFx0by5maWxlcyA9ICdodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9kcml2ZS92Mi9maWxlcz9xPSUyMicgKyBvLmlkICsgJyUyMitpbitwYXJlbnRzJztcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEltYWdlKGltYWdlKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHNvdXJjZTogaW1hZ2UudXJsLFxuXHRcdFx0d2lkdGg6IGltYWdlLndpZHRoLFxuXHRcdFx0aGVpZ2h0OiBpbWFnZS5oZWlnaHRcblx0XHR9O1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0UGhvdG9zKG8pIHtcblx0XHRpZiAoJ2ZlZWQnIGluIG8pIHtcblx0XHRcdG8uZGF0YSA9ICdlbnRyeScgaW4gby5mZWVkID8gby5mZWVkLmVudHJ5Lm1hcChmb3JtYXRFbnRyeSkgOiBbXTtcblx0XHRcdGRlbGV0ZSBvLmZlZWQ7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG87XG5cdH1cblxuXHQvLyBHb29nbGUgaGFzIGEgaG9ycmlibGUgSlNPTiBBUElcblx0ZnVuY3Rpb24gZ0VudHJ5KG8pIHtcblx0XHRwYWdpbmcobyk7XG5cblx0XHRpZiAoJ2ZlZWQnIGluIG8gJiYgJ2VudHJ5JyBpbiBvLmZlZWQpIHtcblx0XHRcdG8uZGF0YSA9IG8uZmVlZC5lbnRyeS5tYXAoZm9ybWF0RW50cnkpO1xuXHRcdFx0ZGVsZXRlIG8uZmVlZDtcblx0XHR9XG5cblx0XHQvLyBPbGQgc3R5bGU6IFBpY2FzYSwgZXRjLlxuXHRcdGVsc2UgaWYgKCdlbnRyeScgaW4gbykge1xuXHRcdFx0cmV0dXJuIGZvcm1hdEVudHJ5KG8uZW50cnkpO1xuXHRcdH1cblxuXHRcdC8vIE5ldyBzdHlsZTogR29vZ2xlIERyaXZlXG5cdFx0ZWxzZSBpZiAoJ2l0ZW1zJyBpbiBvKSB7XG5cdFx0XHRvLmRhdGEgPSBvLml0ZW1zLm1hcChmb3JtYXRJdGVtKTtcblx0XHRcdGRlbGV0ZSBvLml0ZW1zO1xuXHRcdH1cblx0XHRlbHNlIHtcblx0XHRcdGZvcm1hdEl0ZW0obyk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG87XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRQZXJzb24obykge1xuXHRcdG8ubmFtZSA9IG8uZGlzcGxheU5hbWUgfHwgby5uYW1lO1xuXHRcdG8ucGljdHVyZSA9IG8ucGljdHVyZSB8fCAoby5pbWFnZSA/IG8uaW1hZ2UudXJsIDogbnVsbCk7XG5cdFx0by50aHVtYm5haWwgPSBvLnBpY3R1cmU7XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRGcmllbmRzKG8sIGhlYWRlcnMsIHJlcSkge1xuXHRcdHBhZ2luZyhvKTtcblx0XHR2YXIgciA9IFtdO1xuXHRcdGlmICgnZmVlZCcgaW4gbyAmJiAnZW50cnknIGluIG8uZmVlZCkge1xuXHRcdFx0dmFyIHRva2VuID0gcmVxLnF1ZXJ5LmFjY2Vzc190b2tlbjtcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgby5mZWVkLmVudHJ5Lmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdHZhciBhID0gby5mZWVkLmVudHJ5W2ldO1xuXG5cdFx0XHRcdGEuaWRcdD0gYS5pZC4kdDtcblx0XHRcdFx0YS5uYW1lXHQ9IGEudGl0bGUuJHQ7XG5cdFx0XHRcdGRlbGV0ZSBhLnRpdGxlO1xuXHRcdFx0XHRpZiAoYS5nZCRlbWFpbCkge1xuXHRcdFx0XHRcdGEuZW1haWxcdD0gKGEuZ2QkZW1haWwgJiYgYS5nZCRlbWFpbC5sZW5ndGggPiAwKSA/IGEuZ2QkZW1haWxbMF0uYWRkcmVzcyA6IG51bGw7XG5cdFx0XHRcdFx0YS5lbWFpbHMgPSBhLmdkJGVtYWlsO1xuXHRcdFx0XHRcdGRlbGV0ZSBhLmdkJGVtYWlsO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKGEudXBkYXRlZCkge1xuXHRcdFx0XHRcdGEudXBkYXRlZCA9IGEudXBkYXRlZC4kdDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChhLmxpbmspIHtcblxuXHRcdFx0XHRcdHZhciBwaWMgPSAoYS5saW5rLmxlbmd0aCA+IDApID8gYS5saW5rWzBdLmhyZWYgOiBudWxsO1xuXHRcdFx0XHRcdGlmIChwaWMgJiYgYS5saW5rWzBdLmdkJGV0YWcpIHtcblx0XHRcdFx0XHRcdHBpYyArPSAocGljLmluZGV4T2YoJz8nKSA+IC0xID8gJyYnIDogJz8nKSArICdhY2Nlc3NfdG9rZW49JyArIHRva2VuO1xuXHRcdFx0XHRcdFx0YS5waWN0dXJlID0gcGljO1xuXHRcdFx0XHRcdFx0YS50aHVtYm5haWwgPSBwaWM7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0ZGVsZXRlIGEubGluaztcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChhLmNhdGVnb3J5KSB7XG5cdFx0XHRcdFx0ZGVsZXRlIGEuY2F0ZWdvcnk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0by5kYXRhID0gby5mZWVkLmVudHJ5O1xuXHRcdFx0ZGVsZXRlIG8uZmVlZDtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEVudHJ5KGEpIHtcblxuXHRcdHZhciBncm91cCA9IGEubWVkaWEkZ3JvdXA7XG5cdFx0dmFyIHBob3RvID0gZ3JvdXAubWVkaWEkY29udGVudC5sZW5ndGggPyBncm91cC5tZWRpYSRjb250ZW50WzBdIDoge307XG5cdFx0dmFyIG1lZGlhQ29udGVudCA9IGdyb3VwLm1lZGlhJGNvbnRlbnQgfHwgW107XG5cdFx0dmFyIG1lZGlhVGh1bWJuYWlsID0gZ3JvdXAubWVkaWEkdGh1bWJuYWlsIHx8IFtdO1xuXG5cdFx0dmFyIHBpY3R1cmVzID0gbWVkaWFDb250ZW50XG5cdFx0XHQuY29uY2F0KG1lZGlhVGh1bWJuYWlsKVxuXHRcdFx0Lm1hcChmb3JtYXRJbWFnZSlcblx0XHRcdC5zb3J0KGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdFx0cmV0dXJuIGEud2lkdGggLSBiLndpZHRoO1xuXHRcdFx0fSk7XG5cblx0XHR2YXIgaSA9IDA7XG5cdFx0dmFyIF9hO1xuXHRcdHZhciBwID0ge1xuXHRcdFx0aWQ6IGEuaWQuJHQsXG5cdFx0XHRuYW1lOiBhLnRpdGxlLiR0LFxuXHRcdFx0ZGVzY3JpcHRpb246IGEuc3VtbWFyeS4kdCxcblx0XHRcdHVwZGF0ZWRfdGltZTogYS51cGRhdGVkLiR0LFxuXHRcdFx0Y3JlYXRlZF90aW1lOiBhLnB1Ymxpc2hlZC4kdCxcblx0XHRcdHBpY3R1cmU6IHBob3RvID8gcGhvdG8udXJsIDogbnVsbCxcblx0XHRcdHBpY3R1cmVzOiBwaWN0dXJlcyxcblx0XHRcdGltYWdlczogW10sXG5cdFx0XHR0aHVtYm5haWw6IHBob3RvID8gcGhvdG8udXJsIDogbnVsbCxcblx0XHRcdHdpZHRoOiBwaG90by53aWR0aCxcblx0XHRcdGhlaWdodDogcGhvdG8uaGVpZ2h0XG5cdFx0fTtcblxuXHRcdC8vIEdldCBmZWVkL2NoaWxkcmVuXG5cdFx0aWYgKCdsaW5rJyBpbiBhKSB7XG5cdFx0XHRmb3IgKGkgPSAwOyBpIDwgYS5saW5rLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdHZhciBkID0gYS5saW5rW2ldO1xuXHRcdFx0XHRpZiAoZC5yZWwubWF0Y2goL1xcI2ZlZWQkLykpIHtcblx0XHRcdFx0XHRwLnVwbG9hZF9sb2NhdGlvbiA9IHAuZmlsZXMgPSBwLnBob3RvcyA9IGQuaHJlZjtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEdldCBpbWFnZXMgb2YgZGlmZmVyZW50IHNjYWxlc1xuXHRcdGlmICgnY2F0ZWdvcnknIGluIGEgJiYgYS5jYXRlZ29yeS5sZW5ndGgpIHtcblx0XHRcdF9hID0gYS5jYXRlZ29yeTtcblx0XHRcdGZvciAoaSA9IDA7IGkgPCBfYS5sZW5ndGg7IGkrKykge1xuXHRcdFx0XHRpZiAoX2FbaV0uc2NoZW1lICYmIF9hW2ldLnNjaGVtZS5tYXRjaCgvXFwja2luZCQvKSkge1xuXHRcdFx0XHRcdHAudHlwZSA9IF9hW2ldLnRlcm0ucmVwbGFjZSgvXi4qP1xcIy8sICcnKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEdldCBpbWFnZXMgb2YgZGlmZmVyZW50IHNjYWxlc1xuXHRcdGlmICgnbWVkaWEkdGh1bWJuYWlsJyBpbiBncm91cCAmJiBncm91cC5tZWRpYSR0aHVtYm5haWwubGVuZ3RoKSB7XG5cdFx0XHRfYSA9IGdyb3VwLm1lZGlhJHRodW1ibmFpbDtcblx0XHRcdHAudGh1bWJuYWlsID0gX2FbMF0udXJsO1xuXHRcdFx0cC5pbWFnZXMgPSBfYS5tYXAoZm9ybWF0SW1hZ2UpO1xuXHRcdH1cblxuXHRcdF9hID0gZ3JvdXAubWVkaWEkY29udGVudDtcblxuXHRcdGlmIChfYSAmJiBfYS5sZW5ndGgpIHtcblx0XHRcdHAuaW1hZ2VzLnB1c2goZm9ybWF0SW1hZ2UoX2FbMF0pKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gcDtcblx0fVxuXG5cdGZ1bmN0aW9uIHBhZ2luZyhyZXMpIHtcblxuXHRcdC8vIENvbnRhY3RzIFYyXG5cdFx0aWYgKCdmZWVkJyBpbiByZXMgJiYgcmVzLmZlZWQub3BlblNlYXJjaCRpdGVtc1BlclBhZ2UpIHtcblx0XHRcdHZhciBsaW1pdCA9IHRvSW50KHJlcy5mZWVkLm9wZW5TZWFyY2gkaXRlbXNQZXJQYWdlLiR0KTtcblx0XHRcdHZhciBzdGFydCA9IHRvSW50KHJlcy5mZWVkLm9wZW5TZWFyY2gkc3RhcnRJbmRleC4kdCk7XG5cdFx0XHR2YXIgdG90YWwgPSB0b0ludChyZXMuZmVlZC5vcGVuU2VhcmNoJHRvdGFsUmVzdWx0cy4kdCk7XG5cblx0XHRcdGlmICgoc3RhcnQgKyBsaW1pdCkgPCB0b3RhbCkge1xuXHRcdFx0XHRyZXMucGFnaW5nID0ge1xuXHRcdFx0XHRcdG5leHQ6ICc/c3RhcnQ9JyArIChzdGFydCArIGxpbWl0KVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRlbHNlIGlmICgnbmV4dFBhZ2VUb2tlbicgaW4gcmVzKSB7XG5cdFx0XHRyZXMucGFnaW5nID0ge1xuXHRcdFx0XHRuZXh0OiAnP3BhZ2VUb2tlbj0nICsgcmVzLm5leHRQYWdlVG9rZW5cblx0XHRcdH07XG5cdFx0fVxuXHR9XG5cblx0Ly8gQ29uc3RydWN0IGEgbXVsdGlwYXJ0IG1lc3NhZ2Vcblx0ZnVuY3Rpb24gTXVsdGlwYXJ0KCkge1xuXG5cdFx0Ly8gSW50ZXJuYWwgYm9keVxuXHRcdHZhciBib2R5ID0gW107XG5cdFx0dmFyIGJvdW5kYXJ5ID0gKE1hdGgucmFuZG9tKCkgKiAxZTEwKS50b1N0cmluZygzMik7XG5cdFx0dmFyIGNvdW50ZXIgPSAwO1xuXHRcdHZhciBsaW5lQnJlYWsgPSAnXFxyXFxuJztcblx0XHR2YXIgZGVsaW0gPSBsaW5lQnJlYWsgKyAnLS0nICsgYm91bmRhcnk7XG5cdFx0dmFyIHJlYWR5ID0gZnVuY3Rpb24oKSB7fTtcblxuXHRcdHZhciBkYXRhVXJpID0gL15kYXRhXFw6KFteOyxdKyhcXDtjaGFyc2V0PVteOyxdKyk/KShcXDtiYXNlNjQpPywvaTtcblxuXHRcdC8vIEFkZCBmaWxlXG5cdFx0ZnVuY3Rpb24gYWRkRmlsZShpdGVtKSB7XG5cdFx0XHR2YXIgZnIgPSBuZXcgRmlsZVJlYWRlcigpO1xuXHRcdFx0ZnIub25sb2FkID0gZnVuY3Rpb24oZSkge1xuXHRcdFx0XHRhZGRDb250ZW50KGJ0b2EoZS50YXJnZXQucmVzdWx0KSwgaXRlbS50eXBlICsgbGluZUJyZWFrICsgJ0NvbnRlbnQtVHJhbnNmZXItRW5jb2Rpbmc6IGJhc2U2NCcpO1xuXHRcdFx0fTtcblxuXHRcdFx0ZnIucmVhZEFzQmluYXJ5U3RyaW5nKGl0ZW0pO1xuXHRcdH1cblxuXHRcdC8vIEFkZCBjb250ZW50XG5cdFx0ZnVuY3Rpb24gYWRkQ29udGVudChjb250ZW50LCB0eXBlKSB7XG5cdFx0XHRib2R5LnB1c2gobGluZUJyZWFrICsgJ0NvbnRlbnQtVHlwZTogJyArIHR5cGUgKyBsaW5lQnJlYWsgKyBsaW5lQnJlYWsgKyBjb250ZW50KTtcblx0XHRcdGNvdW50ZXItLTtcblx0XHRcdHJlYWR5KCk7XG5cdFx0fVxuXG5cdFx0Ly8gQWRkIG5ldyB0aGluZ3MgdG8gdGhlIG9iamVjdFxuXHRcdHRoaXMuYXBwZW5kID0gZnVuY3Rpb24oY29udGVudCwgdHlwZSkge1xuXG5cdFx0XHQvLyBEb2VzIHRoZSBjb250ZW50IGhhdmUgYW4gYXJyYXlcblx0XHRcdGlmICh0eXBlb2YgKGNvbnRlbnQpID09PSAnc3RyaW5nJyB8fCAhKCdsZW5ndGgnIGluIE9iamVjdChjb250ZW50KSkpIHtcblx0XHRcdFx0Ly8gQ29udmVydGkgdG8gbXVsdGlwbGVzXG5cdFx0XHRcdGNvbnRlbnQgPSBbY29udGVudF07XG5cdFx0XHR9XG5cblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgY29udGVudC5sZW5ndGg7IGkrKykge1xuXG5cdFx0XHRcdGNvdW50ZXIrKztcblxuXHRcdFx0XHR2YXIgaXRlbSA9IGNvbnRlbnRbaV07XG5cblx0XHRcdFx0Ly8gSXMgdGhpcyBhIGZpbGU/XG5cdFx0XHRcdC8vIEZpbGVzIGNhbiBiZSBlaXRoZXIgQmxvYnMgb3IgRmlsZSB0eXBlc1xuXHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0KHR5cGVvZiAoRmlsZSkgIT09ICd1bmRlZmluZWQnICYmIGl0ZW0gaW5zdGFuY2VvZiBGaWxlKSB8fFxuXHRcdFx0XHRcdCh0eXBlb2YgKEJsb2IpICE9PSAndW5kZWZpbmVkJyAmJiBpdGVtIGluc3RhbmNlb2YgQmxvYilcblx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0Ly8gUmVhZCB0aGUgZmlsZSBpblxuXHRcdFx0XHRcdGFkZEZpbGUoaXRlbSk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBEYXRhLVVSST9cblx0XHRcdFx0Ly8gRGF0YTpbPG1pbWUgdHlwZT5dWztjaGFyc2V0PTxjaGFyc2V0Pl1bO2Jhc2U2NF0sPGVuY29kZWQgZGF0YT5cblx0XHRcdFx0Ly8gL15kYXRhXFw6KFteOyxdKyhcXDtjaGFyc2V0PVteOyxdKyk/KShcXDtiYXNlNjQpPywvaVxuXHRcdFx0XHRlbHNlIGlmICh0eXBlb2YgKGl0ZW0pID09PSAnc3RyaW5nJyAmJiBpdGVtLm1hdGNoKGRhdGFVcmkpKSB7XG5cdFx0XHRcdFx0dmFyIG0gPSBpdGVtLm1hdGNoKGRhdGFVcmkpO1xuXHRcdFx0XHRcdGFkZENvbnRlbnQoaXRlbS5yZXBsYWNlKGRhdGFVcmksICcnKSwgbVsxXSArIGxpbmVCcmVhayArICdDb250ZW50LVRyYW5zZmVyLUVuY29kaW5nOiBiYXNlNjQnKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFJlZ3VsYXIgc3RyaW5nXG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGFkZENvbnRlbnQoaXRlbSwgdHlwZSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0dGhpcy5vbnJlYWR5ID0gZnVuY3Rpb24oZm4pIHtcblx0XHRcdHJlYWR5ID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRcdGlmIChjb3VudGVyID09PSAwKSB7XG5cdFx0XHRcdFx0Ly8gVHJpZ2dlciByZWFkeVxuXHRcdFx0XHRcdGJvZHkudW5zaGlmdCgnJyk7XG5cdFx0XHRcdFx0Ym9keS5wdXNoKCctLScpO1xuXHRcdFx0XHRcdGZuKGJvZHkuam9pbihkZWxpbSksIGJvdW5kYXJ5KTtcblx0XHRcdFx0XHRib2R5ID0gW107XG5cdFx0XHRcdH1cblx0XHRcdH07XG5cblx0XHRcdHJlYWR5KCk7XG5cdFx0fTtcblx0fVxuXG5cdC8vIFVwbG9hZCB0byBEcml2ZVxuXHQvLyBJZiB0aGlzIGlzIFBVVCB0aGVuIG9ubHkgYXVnbWVudCB0aGUgZmlsZSB1cGxvYWRlZFxuXHQvLyBQVVQgaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vZHJpdmUvdjIvcmVmZXJlbmNlL2ZpbGVzL3VwZGF0ZVxuXHQvLyBQT1NUIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL2RyaXZlL21hbmFnZS11cGxvYWRzXG5cdGZ1bmN0aW9uIHVwbG9hZERyaXZlKHAsIGNhbGxiYWNrKSB7XG5cblx0XHR2YXIgZGF0YSA9IHt9O1xuXG5cdFx0Ly8gVGVzdCBmb3IgRE9NIGVsZW1lbnRcblx0XHRpZiAocC5kYXRhICYmXG5cdFx0XHQodHlwZW9mIChIVE1MSW5wdXRFbGVtZW50KSAhPT0gJ3VuZGVmaW5lZCcgJiYgcC5kYXRhIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudClcblx0XHQpIHtcblx0XHRcdHAuZGF0YSA9IHtmaWxlOiBwLmRhdGF9O1xuXHRcdH1cblxuXHRcdGlmICghcC5kYXRhLm5hbWUgJiYgT2JqZWN0KE9iamVjdChwLmRhdGEuZmlsZSkuZmlsZXMpLmxlbmd0aCAmJiBwLm1ldGhvZCA9PT0gJ3Bvc3QnKSB7XG5cdFx0XHRwLmRhdGEubmFtZSA9IHAuZGF0YS5maWxlLmZpbGVzWzBdLm5hbWU7XG5cdFx0fVxuXG5cdFx0aWYgKHAubWV0aG9kID09PSAncG9zdCcpIHtcblx0XHRcdHAuZGF0YSA9IHtcblx0XHRcdFx0dGl0bGU6IHAuZGF0YS5uYW1lLFxuXHRcdFx0XHRwYXJlbnRzOiBbe2lkOiBwLmRhdGEucGFyZW50IHx8ICdyb290J31dLFxuXHRcdFx0XHRmaWxlOiBwLmRhdGEuZmlsZVxuXHRcdFx0fTtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cblx0XHRcdC8vIE1ha2UgYSByZWZlcmVuY2Vcblx0XHRcdGRhdGEgPSBwLmRhdGE7XG5cdFx0XHRwLmRhdGEgPSB7fTtcblxuXHRcdFx0Ly8gQWRkIHRoZSBwYXJ0cyB0byBjaGFuZ2UgYXMgcmVxdWlyZWRcblx0XHRcdGlmIChkYXRhLnBhcmVudCkge1xuXHRcdFx0XHRwLmRhdGEucGFyZW50cyA9IFt7aWQ6IHAuZGF0YS5wYXJlbnQgfHwgJ3Jvb3QnfV07XG5cdFx0XHR9XG5cblx0XHRcdGlmIChkYXRhLmZpbGUpIHtcblx0XHRcdFx0cC5kYXRhLmZpbGUgPSBkYXRhLmZpbGU7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChkYXRhLm5hbWUpIHtcblx0XHRcdFx0cC5kYXRhLnRpdGxlID0gZGF0YS5uYW1lO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEV4dHJhY3QgdGhlIGZpbGUsIGlmIGl0IGV4aXN0cyBmcm9tIHRoZSBkYXRhIG9iamVjdFxuXHRcdC8vIElmIHRoZSBGaWxlIGlzIGFuIElOUFVUIGVsZW1lbnQgbGV0cyBqdXN0IGNvbmNlcm4gb3Vyc2VsdmVzIHdpdGggdGhlIE5vZGVMaXN0XG5cdFx0dmFyIGZpbGU7XG5cdFx0aWYgKCdmaWxlJyBpbiBwLmRhdGEpIHtcblx0XHRcdGZpbGUgPSBwLmRhdGEuZmlsZTtcblx0XHRcdGRlbGV0ZSBwLmRhdGEuZmlsZTtcblxuXHRcdFx0aWYgKHR5cGVvZiAoZmlsZSkgPT09ICdvYmplY3QnICYmICdmaWxlcycgaW4gZmlsZSkge1xuXHRcdFx0XHQvLyBBc3NpZ24gdGhlIE5vZGVMaXN0XG5cdFx0XHRcdGZpbGUgPSBmaWxlLmZpbGVzO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoIWZpbGUgfHwgIWZpbGUubGVuZ3RoKSB7XG5cdFx0XHRcdGNhbGxiYWNrKHtcblx0XHRcdFx0XHRlcnJvcjoge1xuXHRcdFx0XHRcdFx0Y29kZTogJ3JlcXVlc3RfaW52YWxpZCcsXG5cdFx0XHRcdFx0XHRtZXNzYWdlOiAnVGhlcmUgd2VyZSBubyBmaWxlcyBhdHRhY2hlZCB3aXRoIHRoaXMgcmVxdWVzdCB0byB1cGxvYWQnXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFNldCB0eXBlIHAuZGF0YS5taW1lVHlwZSA9IE9iamVjdChmaWxlWzBdKS50eXBlIHx8ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xuXG5cdFx0Ly8gQ29uc3RydWN0IGEgbXVsdGlwYXJ0IG1lc3NhZ2Vcblx0XHR2YXIgcGFydHMgPSBuZXcgTXVsdGlwYXJ0KCk7XG5cdFx0cGFydHMuYXBwZW5kKEpTT04uc3RyaW5naWZ5KHAuZGF0YSksICdhcHBsaWNhdGlvbi9qc29uJyk7XG5cblx0XHQvLyBSZWFkIHRoZSBmaWxlIGludG8gYSAgYmFzZTY0IHN0cmluZy4uLiB5ZXAgYSBoYXNzbGUsIGkga25vd1xuXHRcdC8vIEZvcm1EYXRhIGRvZXNuJ3QgbGV0IHVzIGFzc2lnbiBvdXIgb3duIE11bHRpcGFydCBoZWFkZXJzIGFuZCBIVFRQIENvbnRlbnQtVHlwZVxuXHRcdC8vIEFsYXMgR29vZ2xlQXBpIG5lZWQgdGhlc2UgaW4gYSBwYXJ0aWN1bGFyIGZvcm1hdFxuXHRcdGlmIChmaWxlKSB7XG5cdFx0XHRwYXJ0cy5hcHBlbmQoZmlsZSk7XG5cdFx0fVxuXG5cdFx0cGFydHMub25yZWFkeShmdW5jdGlvbihib2R5LCBib3VuZGFyeSkge1xuXG5cdFx0XHRwLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddID0gJ211bHRpcGFydC9yZWxhdGVkOyBib3VuZGFyeT1cIicgKyBib3VuZGFyeSArICdcIic7XG5cdFx0XHRwLmRhdGEgPSBib2R5O1xuXG5cdFx0XHRjYWxsYmFjaygndXBsb2FkL2RyaXZlL3YyL2ZpbGVzJyArIChkYXRhLmlkID8gJy8nICsgZGF0YS5pZCA6ICcnKSArICc/dXBsb2FkVHlwZT1tdWx0aXBhcnQnKTtcblx0XHR9KTtcblxuXHR9XG5cblx0ZnVuY3Rpb24gdG9KU09OKHApIHtcblx0XHRpZiAodHlwZW9mIChwLmRhdGEpID09PSAnb2JqZWN0Jykge1xuXHRcdFx0Ly8gQ29udmVydCB0aGUgUE9TVCBpbnRvIGEgamF2YXNjcmlwdCBvYmplY3Rcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHAuZGF0YSA9IEpTT04uc3RyaW5naWZ5KHAuZGF0YSk7XG5cdFx0XHRcdHAuaGVhZGVyc1snY29udGVudC10eXBlJ10gPSAnYXBwbGljYXRpb24vanNvbic7XG5cdFx0XHR9XG5cdFx0XHRjYXRjaCAoZSkge31cblx0XHR9XG5cdH1cblxufSkoaGVsbG8pO1xuXG4oZnVuY3Rpb24oaGVsbG8pIHtcblxuXHRoZWxsby5pbml0KHtcblxuXHRcdGluc3RhZ3JhbToge1xuXG5cdFx0XHRuYW1lOiAnSW5zdGFncmFtJyxcblxuXHRcdFx0b2F1dGg6IHtcblx0XHRcdFx0Ly8gU2VlOiBodHRwOi8vaW5zdGFncmFtLmNvbS9kZXZlbG9wZXIvYXV0aGVudGljYXRpb24vXG5cdFx0XHRcdHZlcnNpb246IDIsXG5cdFx0XHRcdGF1dGg6ICdodHRwczovL2luc3RhZ3JhbS5jb20vb2F1dGgvYXV0aG9yaXplLycsXG5cdFx0XHRcdGdyYW50OiAnaHR0cHM6Ly9hcGkuaW5zdGFncmFtLmNvbS9vYXV0aC9hY2Nlc3NfdG9rZW4nXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBSZWZyZXNoIHRoZSBhY2Nlc3NfdG9rZW4gb25jZSBleHBpcmVkXG5cdFx0XHRyZWZyZXNoOiB0cnVlLFxuXG5cdFx0XHRzY29wZToge1xuXHRcdFx0XHRiYXNpYzogJ2Jhc2ljJyxcblx0XHRcdFx0cGhvdG9zOiAnJyxcblx0XHRcdFx0ZnJpZW5kczogJ3JlbGF0aW9uc2hpcHMnLFxuXHRcdFx0XHRwdWJsaXNoOiAnbGlrZXMgY29tbWVudHMnLFxuXHRcdFx0XHRlbWFpbDogJycsXG5cdFx0XHRcdHNoYXJlOiAnJyxcblx0XHRcdFx0cHVibGlzaF9maWxlczogJycsXG5cdFx0XHRcdGZpbGVzOiAnJyxcblx0XHRcdFx0dmlkZW9zOiAnJyxcblx0XHRcdFx0b2ZmbGluZV9hY2Nlc3M6ICcnXG5cdFx0XHR9LFxuXG5cdFx0XHRzY29wZV9kZWxpbTogJyAnLFxuXG5cdFx0XHRiYXNlOiAnaHR0cHM6Ly9hcGkuaW5zdGFncmFtLmNvbS92MS8nLFxuXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6ICd1c2Vycy9zZWxmJyxcblx0XHRcdFx0J21lL2ZlZWQnOiAndXNlcnMvc2VsZi9mZWVkP2NvdW50PUB7bGltaXR8MTAwfScsXG5cdFx0XHRcdCdtZS9waG90b3MnOiAndXNlcnMvc2VsZi9tZWRpYS9yZWNlbnQ/bWluX2lkPTAmY291bnQ9QHtsaW1pdHwxMDB9Jyxcblx0XHRcdFx0J21lL2ZyaWVuZHMnOiAndXNlcnMvc2VsZi9mb2xsb3dzP2NvdW50PUB7bGltaXR8MTAwfScsXG5cdFx0XHRcdCdtZS9mb2xsb3dpbmcnOiAndXNlcnMvc2VsZi9mb2xsb3dzP2NvdW50PUB7bGltaXR8MTAwfScsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiAndXNlcnMvc2VsZi9mb2xsb3dlZC1ieT9jb3VudD1Ae2xpbWl0fDEwMH0nLFxuXHRcdFx0XHQnZnJpZW5kL3Bob3Rvcyc6ICd1c2Vycy9Ae2lkfS9tZWRpYS9yZWNlbnQ/bWluX2lkPTAmY291bnQ9QHtsaW1pdHwxMDB9J1xuXHRcdFx0fSxcblxuXHRcdFx0cG9zdDoge1xuXHRcdFx0XHQnbWUvbGlrZSc6IGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cdFx0XHRcdFx0dmFyIGlkID0gcC5kYXRhLmlkO1xuXHRcdFx0XHRcdHAuZGF0YSA9IHt9O1xuXHRcdFx0XHRcdGNhbGxiYWNrKCdtZWRpYS8nICsgaWQgKyAnL2xpa2VzJyk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdGRlbDoge1xuXHRcdFx0XHQnbWUvbGlrZSc6ICdtZWRpYS9Ae2lkfS9saWtlcydcblx0XHRcdH0sXG5cblx0XHRcdHdyYXA6IHtcblx0XHRcdFx0bWU6IGZ1bmN0aW9uKG8pIHtcblxuXHRcdFx0XHRcdGZvcm1hdEVycm9yKG8pO1xuXG5cdFx0XHRcdFx0aWYgKCdkYXRhJyBpbiBvKSB7XG5cdFx0XHRcdFx0XHRvLmlkID0gby5kYXRhLmlkO1xuXHRcdFx0XHRcdFx0by50aHVtYm5haWwgPSBvLmRhdGEucHJvZmlsZV9waWN0dXJlO1xuXHRcdFx0XHRcdFx0by5uYW1lID0gby5kYXRhLmZ1bGxfbmFtZSB8fCBvLmRhdGEudXNlcm5hbWU7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cmV0dXJuIG87XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0J21lL2ZyaWVuZHMnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogZm9ybWF0RnJpZW5kcyxcblx0XHRcdFx0J21lL2ZvbGxvd2Vycyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9waG90b3MnOiBmdW5jdGlvbihvKSB7XG5cblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRwYWdpbmcobyk7XG5cblx0XHRcdFx0XHRpZiAoJ2RhdGEnIGluIG8pIHtcblx0XHRcdFx0XHRcdG8uZGF0YSA9IG8uZGF0YS5maWx0ZXIoZnVuY3Rpb24oZCkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gZC50eXBlID09PSAnaW1hZ2UnO1xuXHRcdFx0XHRcdFx0fSk7XG5cblx0XHRcdFx0XHRcdG8uZGF0YS5mb3JFYWNoKGZ1bmN0aW9uKGQpIHtcblx0XHRcdFx0XHRcdFx0ZC5uYW1lID0gZC5jYXB0aW9uID8gZC5jYXB0aW9uLnRleHQgOiBudWxsO1xuXHRcdFx0XHRcdFx0XHRkLnRodW1ibmFpbCA9IGQuaW1hZ2VzLnRodW1ibmFpbC51cmw7XG5cdFx0XHRcdFx0XHRcdGQucGljdHVyZSA9IGQuaW1hZ2VzLnN0YW5kYXJkX3Jlc29sdXRpb24udXJsO1xuXHRcdFx0XHRcdFx0XHRkLnBpY3R1cmVzID0gT2JqZWN0LmtleXMoZC5pbWFnZXMpXG5cdFx0XHRcdFx0XHRcdFx0Lm1hcChmdW5jdGlvbihrZXkpIHtcblx0XHRcdFx0XHRcdFx0XHRcdHZhciBpbWFnZSA9IGQuaW1hZ2VzW2tleV07XG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gZm9ybWF0SW1hZ2UoaW1hZ2UpO1xuXHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0LnNvcnQoZnVuY3Rpb24oYSwgYikge1xuXHRcdFx0XHRcdFx0XHRcdFx0cmV0dXJuIGEud2lkdGggLSBiLndpZHRoO1xuXHRcdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cmV0dXJuIG87XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0J2RlZmF1bHQnOiBmdW5jdGlvbihvKSB7XG5cdFx0XHRcdFx0byA9IGZvcm1hdEVycm9yKG8pO1xuXHRcdFx0XHRcdHBhZ2luZyhvKTtcblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0Ly8gSW5zdGFncmFtIGRvZXMgbm90IHJldHVybiBhbnkgQ09SUyBIZWFkZXJzXG5cdFx0XHQvLyBTbyBiZXNpZGVzIEpTT05QIHdlJ3JlIHN0dWNrIHdpdGggcHJveHlcblx0XHRcdHhocjogZnVuY3Rpb24ocCwgcXMpIHtcblxuXHRcdFx0XHR2YXIgbWV0aG9kID0gcC5tZXRob2Q7XG5cdFx0XHRcdHZhciBwcm94eSA9IG1ldGhvZCAhPT0gJ2dldCc7XG5cblx0XHRcdFx0aWYgKHByb3h5KSB7XG5cblx0XHRcdFx0XHRpZiAoKG1ldGhvZCA9PT0gJ3Bvc3QnIHx8IG1ldGhvZCA9PT0gJ3B1dCcpICYmIHAucXVlcnkuYWNjZXNzX3Rva2VuKSB7XG5cdFx0XHRcdFx0XHRwLmRhdGEuYWNjZXNzX3Rva2VuID0gcC5xdWVyeS5hY2Nlc3NfdG9rZW47XG5cdFx0XHRcdFx0XHRkZWxldGUgcC5xdWVyeS5hY2Nlc3NfdG9rZW47XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Ly8gTm8gYWNjZXNzIGNvbnRyb2wgaGVhZGVyc1xuXHRcdFx0XHRcdC8vIFVzZSB0aGUgcHJveHkgaW5zdGVhZFxuXHRcdFx0XHRcdHAucHJveHkgPSBwcm94eTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHJldHVybiBwcm94eTtcblx0XHRcdH0sXG5cblx0XHRcdC8vIE5vIGZvcm1cblx0XHRcdGZvcm06IGZhbHNlXG5cdFx0fVxuXHR9KTtcblxuXHRmdW5jdGlvbiBmb3JtYXRJbWFnZShpbWFnZSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRzb3VyY2U6IGltYWdlLnVybCxcblx0XHRcdHdpZHRoOiBpbWFnZS53aWR0aCxcblx0XHRcdGhlaWdodDogaW1hZ2UuaGVpZ2h0XG5cdFx0fTtcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEVycm9yKG8pIHtcblx0XHRpZiAodHlwZW9mIG8gPT09ICdzdHJpbmcnKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRlcnJvcjoge1xuXHRcdFx0XHRcdGNvZGU6ICdpbnZhbGlkX3JlcXVlc3QnLFxuXHRcdFx0XHRcdG1lc3NhZ2U6IG9cblx0XHRcdFx0fVxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAobyAmJiAnbWV0YScgaW4gbyAmJiAnZXJyb3JfdHlwZScgaW4gby5tZXRhKSB7XG5cdFx0XHRvLmVycm9yID0ge1xuXHRcdFx0XHRjb2RlOiBvLm1ldGEuZXJyb3JfdHlwZSxcblx0XHRcdFx0bWVzc2FnZTogby5tZXRhLmVycm9yX21lc3NhZ2Vcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG87XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRGcmllbmRzKG8pIHtcblx0XHRwYWdpbmcobyk7XG5cdFx0aWYgKG8gJiYgJ2RhdGEnIGluIG8pIHtcblx0XHRcdG8uZGF0YS5mb3JFYWNoKGZvcm1hdEZyaWVuZCk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG87XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRGcmllbmQobykge1xuXHRcdGlmIChvLmlkKSB7XG5cdFx0XHRvLnRodW1ibmFpbCA9IG8ucHJvZmlsZV9waWN0dXJlO1xuXHRcdFx0by5uYW1lID0gby5mdWxsX25hbWUgfHwgby51c2VybmFtZTtcblx0XHR9XG5cdH1cblxuXHQvLyBTZWU6IGh0dHA6Ly9pbnN0YWdyYW0uY29tL2RldmVsb3Blci9lbmRwb2ludHMvXG5cdGZ1bmN0aW9uIHBhZ2luZyhyZXMpIHtcblx0XHRpZiAoJ3BhZ2luYXRpb24nIGluIHJlcykge1xuXHRcdFx0cmVzLnBhZ2luZyA9IHtcblx0XHRcdFx0bmV4dDogcmVzLnBhZ2luYXRpb24ubmV4dF91cmxcblx0XHRcdH07XG5cdFx0XHRkZWxldGUgcmVzLnBhZ2luYXRpb247XG5cdFx0fVxuXHR9XG5cbn0pKGhlbGxvKTtcblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0aGVsbG8uaW5pdCh7XG5cblx0XHRqb2lubWU6IHtcblxuXHRcdFx0bmFtZTogJ2pvaW4ubWUnLFxuXG5cdFx0XHRvYXV0aDoge1xuXHRcdFx0XHR2ZXJzaW9uOiAyLFxuXHRcdFx0XHRhdXRoOiAnaHR0cHM6Ly9zZWN1cmUuam9pbi5tZS9hcGkvcHVibGljL3YxL2F1dGgvb2F1dGgyJyxcblx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL3NlY3VyZS5qb2luLm1lL2FwaS9wdWJsaWMvdjEvYXV0aC9vYXV0aDInXG5cdFx0XHR9LFxuXG5cdFx0XHRyZWZyZXNoOiBmYWxzZSxcblxuXHRcdFx0c2NvcGU6IHtcblx0XHRcdFx0YmFzaWM6ICd1c2VyX2luZm8nLFxuXHRcdFx0XHR1c2VyOiAndXNlcl9pbmZvJyxcblx0XHRcdFx0c2NoZWR1bGVyOiAnc2NoZWR1bGVyJyxcblx0XHRcdFx0c3RhcnQ6ICdzdGFydF9tZWV0aW5nJyxcblx0XHRcdFx0ZW1haWw6ICcnLFxuXHRcdFx0XHRmcmllbmRzOiAnJyxcblx0XHRcdFx0c2hhcmU6ICcnLFxuXHRcdFx0XHRwdWJsaXNoOiAnJyxcblx0XHRcdFx0cGhvdG9zOiAnJyxcblx0XHRcdFx0cHVibGlzaF9maWxlczogJycsXG5cdFx0XHRcdGZpbGVzOiAnJyxcblx0XHRcdFx0dmlkZW9zOiAnJyxcblx0XHRcdFx0b2ZmbGluZV9hY2Nlc3M6ICcnXG5cdFx0XHR9LFxuXG5cdFx0XHRzY29wZV9kZWxpbTogJyAnLFxuXG5cdFx0XHRsb2dpbjogZnVuY3Rpb24ocCkge1xuXHRcdFx0XHRwLm9wdGlvbnMucG9wdXAud2lkdGggPSA0MDA7XG5cdFx0XHRcdHAub3B0aW9ucy5wb3B1cC5oZWlnaHQgPSA3MDA7XG5cdFx0XHR9LFxuXG5cdFx0XHRiYXNlOiAnaHR0cHM6Ly9hcGkuam9pbi5tZS92MS8nLFxuXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6ICd1c2VyJyxcblx0XHRcdFx0bWVldGluZ3M6ICdtZWV0aW5ncycsXG5cdFx0XHRcdCdtZWV0aW5ncy9pbmZvJzogJ21lZXRpbmdzL0B7aWR9J1xuXHRcdFx0fSxcblxuXHRcdFx0cG9zdDoge1xuXHRcdFx0XHQnbWVldGluZ3Mvc3RhcnQvYWRob2MnOiBmdW5jdGlvbihwLCBjYWxsYmFjaykge1xuXHRcdFx0XHRcdGNhbGxiYWNrKCdtZWV0aW5ncy9zdGFydCcpO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZWV0aW5ncy9zdGFydC9zY2hlZHVsZWQnOiBmdW5jdGlvbihwLCBjYWxsYmFjaykge1xuXHRcdFx0XHRcdHZhciBtZWV0aW5nSWQgPSBwLmRhdGEubWVldGluZ0lkO1xuXHRcdFx0XHRcdHAuZGF0YSA9IHt9O1xuXHRcdFx0XHRcdGNhbGxiYWNrKCdtZWV0aW5ncy8nICsgbWVldGluZ0lkICsgJy9zdGFydCcpO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZWV0aW5ncy9zY2hlZHVsZSc6IGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cdFx0XHRcdFx0Y2FsbGJhY2soJ21lZXRpbmdzJyk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdHBhdGNoOiB7XG5cdFx0XHRcdCdtZWV0aW5ncy91cGRhdGUnOiBmdW5jdGlvbihwLCBjYWxsYmFjaykge1xuXHRcdFx0XHRcdGNhbGxiYWNrKCdtZWV0aW5ncy8nICsgcC5kYXRhLm1lZXRpbmdJZCk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdGRlbDoge1xuXHRcdFx0XHQnbWVldGluZ3MvZGVsZXRlJzogJ21lZXRpbmdzL0B7aWR9J1xuXHRcdFx0fSxcblxuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZnVuY3Rpb24obywgaGVhZGVycykge1xuXHRcdFx0XHRcdGZvcm1hdEVycm9yKG8sIGhlYWRlcnMpO1xuXG5cdFx0XHRcdFx0aWYgKCFvLmVtYWlsKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRvLm5hbWUgPSBvLmZ1bGxOYW1lO1xuXHRcdFx0XHRcdG8uZmlyc3RfbmFtZSA9IG8ubmFtZS5zcGxpdCgnICcpWzBdO1xuXHRcdFx0XHRcdG8ubGFzdF9uYW1lID0gby5uYW1lLnNwbGl0KCcgJylbMV07XG5cdFx0XHRcdFx0by5pZCA9IG8uZW1haWw7XG5cblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fSxcblxuXHRcdFx0XHQnZGVmYXVsdCc6IGZ1bmN0aW9uKG8sIGhlYWRlcnMpIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvLCBoZWFkZXJzKTtcblxuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXG5cdFx0XHR4aHI6IGZvcm1hdFJlcXVlc3RcblxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gZm9ybWF0RXJyb3IobywgaGVhZGVycykge1xuXHRcdHZhciBlcnJvckNvZGU7XG5cdFx0dmFyIG1lc3NhZ2U7XG5cdFx0dmFyIGRldGFpbHM7XG5cblx0XHRpZiAobyAmJiAoJ01lc3NhZ2UnIGluIG8pKSB7XG5cdFx0XHRtZXNzYWdlID0gby5NZXNzYWdlO1xuXHRcdFx0ZGVsZXRlIG8uTWVzc2FnZTtcblxuXHRcdFx0aWYgKCdFcnJvckNvZGUnIGluIG8pIHtcblx0XHRcdFx0ZXJyb3JDb2RlID0gby5FcnJvckNvZGU7XG5cdFx0XHRcdGRlbGV0ZSBvLkVycm9yQ29kZTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRlcnJvckNvZGUgPSBnZXRFcnJvckNvZGUoaGVhZGVycyk7XG5cdFx0XHR9XG5cblx0XHRcdG8uZXJyb3IgPSB7XG5cdFx0XHRcdGNvZGU6IGVycm9yQ29kZSxcblx0XHRcdFx0bWVzc2FnZTogbWVzc2FnZSxcblx0XHRcdFx0ZGV0YWlsczogb1xuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFJlcXVlc3QocCwgcXMpIHtcblx0XHQvLyBNb3ZlIHRoZSBhY2Nlc3MgdG9rZW4gZnJvbSB0aGUgcmVxdWVzdCBib2R5IHRvIHRoZSByZXF1ZXN0IGhlYWRlclxuXHRcdHZhciB0b2tlbiA9IHFzLmFjY2Vzc190b2tlbjtcblx0XHRkZWxldGUgcXMuYWNjZXNzX3Rva2VuO1xuXHRcdHAuaGVhZGVycy5BdXRob3JpemF0aW9uID0gJ0JlYXJlciAnICsgdG9rZW47XG5cblx0XHQvLyBGb3JtYXQgbm9uLWdldCByZXF1ZXN0cyB0byBpbmRpY2F0ZSBqc29uIGJvZHlcblx0XHRpZiAocC5tZXRob2QgIT09ICdnZXQnICYmIHAuZGF0YSkge1xuXHRcdFx0cC5oZWFkZXJzWydDb250ZW50LVR5cGUnXSA9ICdhcHBsaWNhdGlvbi9qc29uJztcblx0XHRcdGlmICh0eXBlb2YgKHAuZGF0YSkgPT09ICdvYmplY3QnKSB7XG5cdFx0XHRcdHAuZGF0YSA9IEpTT04uc3RyaW5naWZ5KHAuZGF0YSk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKHAubWV0aG9kID09PSAncHV0Jykge1xuXHRcdFx0cC5tZXRob2QgPSAncGF0Y2gnO1xuXHRcdH1cblxuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cblx0ZnVuY3Rpb24gZ2V0RXJyb3JDb2RlKGhlYWRlcnMpIHtcblx0XHRzd2l0Y2ggKGhlYWRlcnMuc3RhdHVzQ29kZSkge1xuXHRcdFx0Y2FzZSA0MDA6XG5cdFx0XHRcdHJldHVybiAnaW52YWxpZF9yZXF1ZXN0Jztcblx0XHRcdGNhc2UgNDAzOlxuXHRcdFx0XHRyZXR1cm4gJ3N0YWxlX3Rva2VuJztcblx0XHRcdGNhc2UgNDAxOlxuXHRcdFx0XHRyZXR1cm4gJ2ludmFsaWRfdG9rZW4nO1xuXHRcdFx0Y2FzZSA1MDA6XG5cdFx0XHRcdHJldHVybiAnc2VydmVyX2Vycm9yJztcblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHJldHVybiAnc2VydmVyX2Vycm9yJztcblx0XHR9XG5cdH1cblxufShoZWxsbykpO1xuXG4oZnVuY3Rpb24oaGVsbG8pIHtcblxuXHRoZWxsby5pbml0KHtcblxuXHRcdGxpbmtlZGluOiB7XG5cblx0XHRcdG9hdXRoOiB7XG5cdFx0XHRcdHZlcnNpb246IDIsXG5cdFx0XHRcdHJlc3BvbnNlX3R5cGU6ICdjb2RlJyxcblx0XHRcdFx0YXV0aDogJ2h0dHBzOi8vd3d3LmxpbmtlZGluLmNvbS91YXMvb2F1dGgyL2F1dGhvcml6YXRpb24nLFxuXHRcdFx0XHRncmFudDogJ2h0dHBzOi8vd3d3LmxpbmtlZGluLmNvbS91YXMvb2F1dGgyL2FjY2Vzc1Rva2VuJ1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gUmVmcmVzaCB0aGUgYWNjZXNzX3Rva2VuIG9uY2UgZXhwaXJlZFxuXHRcdFx0cmVmcmVzaDogdHJ1ZSxcblxuXHRcdFx0c2NvcGU6IHtcblx0XHRcdFx0YmFzaWM6ICdyX2Jhc2ljcHJvZmlsZScsXG5cdFx0XHRcdGVtYWlsOiAncl9lbWFpbGFkZHJlc3MnLFxuXHRcdFx0XHRmaWxlczogJycsXG5cdFx0XHRcdGZyaWVuZHM6ICcnLFxuXHRcdFx0XHRwaG90b3M6ICcnLFxuXHRcdFx0XHRwdWJsaXNoOiAnd19zaGFyZScsXG5cdFx0XHRcdHB1Ymxpc2hfZmlsZXM6ICd3X3NoYXJlJyxcblx0XHRcdFx0c2hhcmU6ICcnLFxuXHRcdFx0XHR2aWRlb3M6ICcnLFxuXHRcdFx0XHRvZmZsaW5lX2FjY2VzczogJydcblx0XHRcdH0sXG5cdFx0XHRzY29wZV9kZWxpbTogJyAnLFxuXG5cdFx0XHRiYXNlOiAnaHR0cHM6Ly9hcGkubGlua2VkaW4uY29tL3YxLycsXG5cblx0XHRcdGdldDoge1xuXHRcdFx0XHRtZTogJ3Blb3BsZS9+OihwaWN0dXJlLXVybCxmaXJzdC1uYW1lLGxhc3QtbmFtZSxpZCxmb3JtYXR0ZWQtbmFtZSxlbWFpbC1hZGRyZXNzKScsXG5cblx0XHRcdFx0Ly8gU2VlOiBodHRwOi8vZGV2ZWxvcGVyLmxpbmtlZGluLmNvbS9kb2N1bWVudHMvZ2V0LW5ldHdvcmstdXBkYXRlcy1hbmQtc3RhdGlzdGljcy1hcGlcblx0XHRcdFx0J21lL3NoYXJlJzogJ3Blb3BsZS9+L25ldHdvcmsvdXBkYXRlcz9jb3VudD1Ae2xpbWl0fDI1MH0nXG5cdFx0XHR9LFxuXG5cdFx0XHRwb3N0OiB7XG5cblx0XHRcdFx0Ly8gU2VlOiBodHRwczovL2RldmVsb3Blci5saW5rZWRpbi5jb20vZG9jdW1lbnRzL2FwaS1yZXF1ZXN0cy1qc29uXG5cdFx0XHRcdCdtZS9zaGFyZSc6IGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cdFx0XHRcdFx0dmFyIGRhdGEgPSB7XG5cdFx0XHRcdFx0XHR2aXNpYmlsaXR5OiB7XG5cdFx0XHRcdFx0XHRcdGNvZGU6ICdhbnlvbmUnXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fTtcblxuXHRcdFx0XHRcdGlmIChwLmRhdGEuaWQpIHtcblxuXHRcdFx0XHRcdFx0ZGF0YS5hdHRyaWJ1dGlvbiA9IHtcblx0XHRcdFx0XHRcdFx0c2hhcmU6IHtcblx0XHRcdFx0XHRcdFx0XHRpZDogcC5kYXRhLmlkXG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH07XG5cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0XHRkYXRhLmNvbW1lbnQgPSBwLmRhdGEubWVzc2FnZTtcblx0XHRcdFx0XHRcdGlmIChwLmRhdGEucGljdHVyZSAmJiBwLmRhdGEubGluaykge1xuXHRcdFx0XHRcdFx0XHRkYXRhLmNvbnRlbnQgPSB7XG5cdFx0XHRcdFx0XHRcdFx0J3N1Ym1pdHRlZC11cmwnOiBwLmRhdGEubGluayxcblx0XHRcdFx0XHRcdFx0XHQnc3VibWl0dGVkLWltYWdlLXVybCc6IHAuZGF0YS5waWN0dXJlXG5cdFx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cC5kYXRhID0gSlNPTi5zdHJpbmdpZnkoZGF0YSk7XG5cblx0XHRcdFx0XHRjYWxsYmFjaygncGVvcGxlL34vc2hhcmVzP2Zvcm1hdD1qc29uJyk7XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0J21lL2xpa2UnOiBsaWtlXG5cdFx0XHR9LFxuXG5cdFx0XHRkZWw6e1xuXHRcdFx0XHQnbWUvbGlrZSc6IGxpa2Vcblx0XHRcdH0sXG5cblx0XHRcdHdyYXA6IHtcblx0XHRcdFx0bWU6IGZ1bmN0aW9uKG8pIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRmb3JtYXRVc2VyKG8pO1xuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9LFxuXG5cdFx0XHRcdCdtZS9mcmllbmRzJzogZm9ybWF0RnJpZW5kcyxcblx0XHRcdFx0J21lL2ZvbGxvd2luZyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvc2hhcmUnOiBmdW5jdGlvbihvKSB7XG5cdFx0XHRcdFx0Zm9ybWF0RXJyb3Iobyk7XG5cdFx0XHRcdFx0cGFnaW5nKG8pO1xuXHRcdFx0XHRcdGlmIChvLnZhbHVlcykge1xuXHRcdFx0XHRcdFx0by5kYXRhID0gby52YWx1ZXMubWFwKGZvcm1hdFVzZXIpO1xuXHRcdFx0XHRcdFx0by5kYXRhLmZvckVhY2goZnVuY3Rpb24oaXRlbSkge1xuXHRcdFx0XHRcdFx0XHRpdGVtLm1lc3NhZ2UgPSBpdGVtLmhlYWRsaW5lO1xuXHRcdFx0XHRcdFx0fSk7XG5cblx0XHRcdFx0XHRcdGRlbGV0ZSBvLnZhbHVlcztcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fSxcblxuXHRcdFx0XHQnZGVmYXVsdCc6IGZ1bmN0aW9uKG8sIGhlYWRlcnMpIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihvKTtcblx0XHRcdFx0XHRlbXB0eShvLCBoZWFkZXJzKTtcblx0XHRcdFx0XHRwYWdpbmcobyk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdGpzb25wOiBmdW5jdGlvbihwLCBxcykge1xuXHRcdFx0XHRmb3JtYXRRdWVyeShxcyk7XG5cdFx0XHRcdGlmIChwLm1ldGhvZCA9PT0gJ2dldCcpIHtcblx0XHRcdFx0XHRxcy5mb3JtYXQgPSAnanNvbnAnO1xuXHRcdFx0XHRcdHFzWydlcnJvci1jYWxsYmFjayddID0gcC5jYWxsYmFja0lEO1xuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXG5cdFx0XHR4aHI6IGZ1bmN0aW9uKHAsIHFzKSB7XG5cdFx0XHRcdGlmIChwLm1ldGhvZCAhPT0gJ2dldCcpIHtcblx0XHRcdFx0XHRmb3JtYXRRdWVyeShxcyk7XG5cdFx0XHRcdFx0cC5oZWFkZXJzWydDb250ZW50LVR5cGUnXSA9ICdhcHBsaWNhdGlvbi9qc29uJztcblxuXHRcdFx0XHRcdC8vIE5vdGU6IHgtbGktZm9ybWF0IGVuc3VyZXMgZXJyb3IgcmVzcG9uc2VzIGFyZSBub3QgcmV0dXJuZWQgaW4gWE1MXG5cdFx0XHRcdFx0cC5oZWFkZXJzWyd4LWxpLWZvcm1hdCddID0gJ2pzb24nO1xuXHRcdFx0XHRcdHAucHJveHkgPSB0cnVlO1xuXHRcdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gZm9ybWF0RXJyb3Iobykge1xuXHRcdGlmIChvICYmICdlcnJvckNvZGUnIGluIG8pIHtcblx0XHRcdG8uZXJyb3IgPSB7XG5cdFx0XHRcdGNvZGU6IG8uc3RhdHVzLFxuXHRcdFx0XHRtZXNzYWdlOiBvLm1lc3NhZ2Vcblx0XHRcdH07XG5cdFx0fVxuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0VXNlcihvKSB7XG5cdFx0aWYgKG8uZXJyb3IpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRvLmZpcnN0X25hbWUgPSBvLmZpcnN0TmFtZTtcblx0XHRvLmxhc3RfbmFtZSA9IG8ubGFzdE5hbWU7XG5cdFx0by5uYW1lID0gby5mb3JtYXR0ZWROYW1lIHx8IChvLmZpcnN0X25hbWUgKyAnICcgKyBvLmxhc3RfbmFtZSk7XG5cdFx0by50aHVtYm5haWwgPSBvLnBpY3R1cmVVcmw7XG5cdFx0by5lbWFpbCA9IG8uZW1haWxBZGRyZXNzO1xuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0RnJpZW5kcyhvKSB7XG5cdFx0Zm9ybWF0RXJyb3Iobyk7XG5cdFx0cGFnaW5nKG8pO1xuXHRcdGlmIChvLnZhbHVlcykge1xuXHRcdFx0by5kYXRhID0gby52YWx1ZXMubWFwKGZvcm1hdFVzZXIpO1xuXHRcdFx0ZGVsZXRlIG8udmFsdWVzO1xuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gcGFnaW5nKHJlcykge1xuXHRcdGlmICgnX2NvdW50JyBpbiByZXMgJiYgJ19zdGFydCcgaW4gcmVzICYmIChyZXMuX2NvdW50ICsgcmVzLl9zdGFydCkgPCByZXMuX3RvdGFsKSB7XG5cdFx0XHRyZXMucGFnaW5nID0ge1xuXHRcdFx0XHRuZXh0OiAnP3N0YXJ0PScgKyAocmVzLl9zdGFydCArIHJlcy5fY291bnQpICsgJyZjb3VudD0nICsgcmVzLl9jb3VudFxuXHRcdFx0fTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBlbXB0eShvLCBoZWFkZXJzKSB7XG5cdFx0aWYgKEpTT04uc3RyaW5naWZ5KG8pID09PSAne30nICYmIGhlYWRlcnMuc3RhdHVzQ29kZSA9PT0gMjAwKSB7XG5cdFx0XHRvLnN1Y2Nlc3MgPSB0cnVlO1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFF1ZXJ5KHFzKSB7XG5cdFx0Ly8gTGlua2VkSW4gc2lnbnMgcmVxdWVzdHMgd2l0aCB0aGUgcGFyYW1ldGVyICdvYXV0aDJfYWNjZXNzX3Rva2VuJ1xuXHRcdC8vIC4uLiB5ZWFoIGFub3RoZXIgb25lIHdobyB0aGlua3MgdGhleSBzaG91bGQgYmUgZGlmZmVyZW50IVxuXHRcdGlmIChxcy5hY2Nlc3NfdG9rZW4pIHtcblx0XHRcdHFzLm9hdXRoMl9hY2Nlc3NfdG9rZW4gPSBxcy5hY2Nlc3NfdG9rZW47XG5cdFx0XHRkZWxldGUgcXMuYWNjZXNzX3Rva2VuO1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGxpa2UocCwgY2FsbGJhY2spIHtcblx0XHRwLmhlYWRlcnNbJ3gtbGktZm9ybWF0J10gPSAnanNvbic7XG5cdFx0dmFyIGlkID0gcC5kYXRhLmlkO1xuXHRcdHAuZGF0YSA9IChwLm1ldGhvZCAhPT0gJ2RlbGV0ZScpLnRvU3RyaW5nKCk7XG5cdFx0cC5tZXRob2QgPSAncHV0Jztcblx0XHRjYWxsYmFjaygncGVvcGxlL34vbmV0d29yay91cGRhdGVzL2tleT0nICsgaWQgKyAnL2lzLWxpa2VkJyk7XG5cdH1cblxufSkoaGVsbG8pO1xuXG4vLyBTZWU6IGh0dHBzOi8vZGV2ZWxvcGVycy5zb3VuZGNsb3VkLmNvbS9kb2NzL2FwaS9yZWZlcmVuY2VcbihmdW5jdGlvbihoZWxsbykge1xuXG5cdGhlbGxvLmluaXQoe1xuXG5cdFx0c291bmRjbG91ZDoge1xuXHRcdFx0bmFtZTogJ1NvdW5kQ2xvdWQnLFxuXG5cdFx0XHRvYXV0aDoge1xuXHRcdFx0XHR2ZXJzaW9uOiAyLFxuXHRcdFx0XHRhdXRoOiAnaHR0cHM6Ly9zb3VuZGNsb3VkLmNvbS9jb25uZWN0Jyxcblx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL3NvdW5kY2xvdWQuY29tL29hdXRoMi90b2tlbidcblx0XHRcdH0sXG5cblx0XHRcdC8vIFJlcXVlc3QgcGF0aCB0cmFuc2xhdGVkXG5cdFx0XHRiYXNlOiAnaHR0cHM6Ly9hcGkuc291bmRjbG91ZC5jb20vJyxcblx0XHRcdGdldDoge1xuXHRcdFx0XHRtZTogJ21lLmpzb24nLFxuXG5cdFx0XHRcdC8vIEh0dHA6Ly9kZXZlbG9wZXJzLnNvdW5kY2xvdWQuY29tL2RvY3MvYXBpL3JlZmVyZW5jZSNtZVxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6ICdtZS9mb2xsb3dpbmdzLmpzb24nLFxuXHRcdFx0XHQnbWUvZm9sbG93ZXJzJzogJ21lL2ZvbGxvd2Vycy5qc29uJyxcblx0XHRcdFx0J21lL2ZvbGxvd2luZyc6ICdtZS9mb2xsb3dpbmdzLmpzb24nLFxuXG5cdFx0XHRcdC8vIFNlZTogaHR0cDovL2RldmVsb3BlcnMuc291bmRjbG91ZC5jb20vZG9jcy9hcGkvcmVmZXJlbmNlI2FjdGl2aXRpZXNcblx0XHRcdFx0J2RlZmF1bHQnOiBmdW5jdGlvbihwLCBjYWxsYmFjaykge1xuXG5cdFx0XHRcdFx0Ly8gSW5jbHVkZSAnLmpzb24gYXQgdGhlIGVuZCBvZiBlYWNoIHJlcXVlc3QnXG5cdFx0XHRcdFx0Y2FsbGJhY2socC5wYXRoICsgJy5qc29uJyk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdC8vIFJlc3BvbnNlIGhhbmRsZXJzXG5cdFx0XHR3cmFwOiB7XG5cdFx0XHRcdG1lOiBmdW5jdGlvbihvKSB7XG5cdFx0XHRcdFx0Zm9ybWF0VXNlcihvKTtcblx0XHRcdFx0XHRyZXR1cm4gbztcblx0XHRcdFx0fSxcblxuXHRcdFx0XHQnZGVmYXVsdCc6IGZ1bmN0aW9uKG8pIHtcblx0XHRcdFx0XHRpZiAoQXJyYXkuaXNBcnJheShvKSkge1xuXHRcdFx0XHRcdFx0byA9IHtcblx0XHRcdFx0XHRcdFx0ZGF0YTogby5tYXAoZm9ybWF0VXNlcilcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0cGFnaW5nKG8pO1xuXHRcdFx0XHRcdHJldHVybiBvO1xuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXG5cdFx0XHR4aHI6IGZvcm1hdFJlcXVlc3QsXG5cdFx0XHRqc29ucDogZm9ybWF0UmVxdWVzdFxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gZm9ybWF0UmVxdWVzdChwLCBxcykge1xuXHRcdC8vIEFsdGVyIHRoZSBxdWVyeXN0cmluZ1xuXHRcdHZhciB0b2tlbiA9IHFzLmFjY2Vzc190b2tlbjtcblx0XHRkZWxldGUgcXMuYWNjZXNzX3Rva2VuO1xuXHRcdHFzLm9hdXRoX3Rva2VuID0gdG9rZW47XG5cdFx0cXNbJ19zdGF0dXNfY29kZV9tYXBbMzAyXSddID0gMjAwO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0VXNlcihvKSB7XG5cdFx0aWYgKG8uaWQpIHtcblx0XHRcdG8ucGljdHVyZSA9IG8uYXZhdGFyX3VybDtcblx0XHRcdG8udGh1bWJuYWlsID0gby5hdmF0YXJfdXJsO1xuXHRcdFx0by5uYW1lID0gby51c2VybmFtZSB8fCBvLmZ1bGxfbmFtZTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdC8vIFNlZTogaHR0cDovL2RldmVsb3BlcnMuc291bmRjbG91ZC5jb20vZG9jcy9hcGkvcmVmZXJlbmNlI2FjdGl2aXRpZXNcblx0ZnVuY3Rpb24gcGFnaW5nKHJlcykge1xuXHRcdGlmICgnbmV4dF9ocmVmJyBpbiByZXMpIHtcblx0XHRcdHJlcy5wYWdpbmcgPSB7XG5cdFx0XHRcdG5leHQ6IHJlcy5uZXh0X2hyZWZcblx0XHRcdH07XG5cdFx0fVxuXHR9XG5cbn0pKGhlbGxvKTtcblxuLy8gU2VlOiBodHRwczovL2RldmVsb3Blci5zcG90aWZ5LmNvbS93ZWItYXBpL1xuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0aGVsbG8uaW5pdCh7XG5cblx0XHRzcG90aWZ5OiB7XG5cdFx0XHRuYW1lOiAnU3BvdGlmeScsXG5cblx0XHRcdG9hdXRoOiB7XG5cdFx0XHRcdHZlcnNpb246IDIsXG5cdFx0XHRcdGF1dGg6ICdodHRwczovL2FjY291bnRzLnNwb3RpZnkuY29tL2F1dGhvcml6ZScsXG5cdFx0XHRcdGdyYW50OiAnaHR0cHM6Ly9hY2NvdW50cy5zcG90aWZ5LmNvbS9hcGkvdG9rZW4nXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBTZWU6IGh0dHBzOi8vZGV2ZWxvcGVyLnNwb3RpZnkuY29tL3dlYi1hcGkvdXNpbmctc2NvcGVzL1xuXHRcdFx0c2NvcGVfZGVsaW06ICcgJyxcblx0XHRcdHNjb3BlOiB7XG5cdFx0XHRcdGJhc2ljOiAnJyxcblx0XHRcdFx0cGhvdG9zOiAnJyxcblx0XHRcdFx0ZnJpZW5kczogJ3VzZXItZm9sbG93LXJlYWQnLFxuXHRcdFx0XHRwdWJsaXNoOiAndXNlci1saWJyYXJ5LXJlYWQnLFxuXHRcdFx0XHRlbWFpbDogJ3VzZXItcmVhZC1lbWFpbCcsXG5cdFx0XHRcdHNoYXJlOiAnJyxcblx0XHRcdFx0cHVibGlzaF9maWxlczogJycsXG5cdFx0XHRcdGZpbGVzOiAnJyxcblx0XHRcdFx0dmlkZW9zOiAnJyxcblx0XHRcdFx0b2ZmbGluZV9hY2Nlc3M6ICcnXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBSZXF1ZXN0IHBhdGggdHJhbnNsYXRlZFxuXHRcdFx0YmFzZTogJ2h0dHBzOi8vYXBpLnNwb3RpZnkuY29tJyxcblxuXHRcdFx0Ly8gU2VlOiBodHRwczovL2RldmVsb3Blci5zcG90aWZ5LmNvbS93ZWItYXBpL2VuZHBvaW50LXJlZmVyZW5jZS9cblx0XHRcdGdldDoge1xuXHRcdFx0XHRtZTogJy92MS9tZScsXG5cdFx0XHRcdCdtZS9mb2xsb3dpbmcnOiAnL3YxL21lL2ZvbGxvd2luZz90eXBlPWFydGlzdCcsIC8vIE9ubHkgJ2FydGlzdCcgaXMgc3VwcG9ydGVkXG5cblx0XHRcdFx0Ly8gQmVjYXVzZSB0cmFja3MsIGFsYnVtcyBhbmQgcGxheWxpc3QgZXhpc3Qgb24gc3BvdGlmeSwgdGhlIHRyYWNrcyBhcmUgY29uc2lkZXJlZFxuXHRcdFx0XHQvLyB0aGUgcmVzb3VyY2UgZm9yIHRoZSAnbWUvbGlrZXMnIGVuZHBvaW50XG5cdFx0XHRcdCdtZS9saWtlJzogJy92MS9tZS90cmFja3MnXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBSZXNwb25zZSBoYW5kbGVyc1xuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZm9ybWF0VXNlcixcblx0XHRcdFx0J21lL2ZvbGxvd2luZyc6IGZvcm1hdEZvbGxvd2Vlcyxcblx0XHRcdFx0J21lL2xpa2UnOiBmb3JtYXRUcmFja3Ncblx0XHRcdH0sXG5cblx0XHRcdHhocjogZm9ybWF0UmVxdWVzdCxcblx0XHRcdGpzb25wOiBmYWxzZVxuXHRcdH1cblx0fSk7XG5cblx0Ly8gTW92ZSB0aGUgYWNjZXNzIHRva2VuIGZyb20gdGhlIHJlcXVlc3QgYm9keSB0byB0aGUgcmVxdWVzdCBoZWFkZXJcblx0ZnVuY3Rpb24gZm9ybWF0UmVxdWVzdChwLCBxcykge1xuXHRcdHZhciB0b2tlbiA9IHFzLmFjY2Vzc190b2tlbjtcblx0XHRkZWxldGUgcXMuYWNjZXNzX3Rva2VuO1xuXHRcdHAuaGVhZGVycy5BdXRob3JpemF0aW9uID0gJ0JlYXJlciAnICsgdG9rZW47XG5cblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFVzZXIobykge1xuXHRcdGlmIChvLmlkKSB7XG5cdFx0XHRvLm5hbWUgPSBvLmRpc3BsYXlfbmFtZTtcblx0XHRcdG8udGh1bWJuYWlsID0gby5pbWFnZXMubGVuZ3RoID8gby5pbWFnZXNbMF0udXJsIDogbnVsbDtcblx0XHRcdG8ucGljdHVyZSA9IG8udGh1bWJuYWlsO1xuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0Rm9sbG93ZWVzKG8pIHtcblx0XHRwYWdpbmcobyk7XG5cdFx0aWYgKG8gJiYgJ2FydGlzdHMnIGluIG8pIHtcblx0XHRcdG8uZGF0YSA9IG8uYXJ0aXN0cy5pdGVtcy5mb3JFYWNoKGZvcm1hdFVzZXIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0VHJhY2tzKG8pIHtcblx0XHRwYWdpbmcobyk7XG5cdFx0by5kYXRhID0gby5pdGVtcztcblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gcGFnaW5nKHJlcykge1xuXHRcdGlmIChyZXMgJiYgJ25leHQnIGluIHJlcykge1xuXHRcdFx0cmVzLnBhZ2luZyA9IHtcblx0XHRcdFx0bmV4dDogcmVzLm5leHRcblx0XHRcdH07XG5cdFx0XHRkZWxldGUgcmVzLm5leHQ7XG5cdFx0fVxuXHR9XG5cbn0pKGhlbGxvKTtcblxuKGZ1bmN0aW9uKGhlbGxvKSB7XG5cblx0dmFyIGJhc2UgPSAnaHR0cHM6Ly9hcGkudHdpdHRlci5jb20vJztcblxuXHRoZWxsby5pbml0KHtcblxuXHRcdHR3aXR0ZXI6IHtcblxuXHRcdFx0Ly8gRW5zdXJlIHRoYXQgeW91IGRlZmluZSBhbiBvYXV0aF9wcm94eVxuXHRcdFx0b2F1dGg6IHtcblx0XHRcdFx0dmVyc2lvbjogJzEuMGEnLFxuXHRcdFx0XHRhdXRoOiBiYXNlICsgJ29hdXRoL2F1dGhlbnRpY2F0ZScsXG5cdFx0XHRcdHJlcXVlc3Q6IGJhc2UgKyAnb2F1dGgvcmVxdWVzdF90b2tlbicsXG5cdFx0XHRcdHRva2VuOiBiYXNlICsgJ29hdXRoL2FjY2Vzc190b2tlbidcblx0XHRcdH0sXG5cblx0XHRcdGxvZ2luOiBmdW5jdGlvbihwKSB7XG5cdFx0XHRcdC8vIFJlYXV0aGVudGljYXRlXG5cdFx0XHRcdC8vIGh0dHBzOi8vZGV2LnR3aXR0ZXIuY29tL29hdXRoL3JlZmVyZW5jZS9nZXQvb2F1dGgvYXV0aGVudGljYXRlXG5cdFx0XHRcdHZhciBwcmVmaXggPSAnP2ZvcmNlX2xvZ2luPXRydWUnO1xuXHRcdFx0XHR0aGlzLm9hdXRoLmF1dGggPSB0aGlzLm9hdXRoLmF1dGgucmVwbGFjZShwcmVmaXgsICcnKSArIChwLm9wdGlvbnMuZm9yY2UgPyBwcmVmaXggOiAnJyk7XG5cdFx0XHR9LFxuXG5cdFx0XHRiYXNlOiBiYXNlICsgJzEuMS8nLFxuXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6ICdhY2NvdW50L3ZlcmlmeV9jcmVkZW50aWFscy5qc29uJyxcblx0XHRcdFx0J21lL2ZyaWVuZHMnOiAnZnJpZW5kcy9saXN0Lmpzb24/Y291bnQ9QHtsaW1pdHwyMDB9Jyxcblx0XHRcdFx0J21lL2ZvbGxvd2luZyc6ICdmcmllbmRzL2xpc3QuanNvbj9jb3VudD1Ae2xpbWl0fDIwMH0nLFxuXHRcdFx0XHQnbWUvZm9sbG93ZXJzJzogJ2ZvbGxvd2Vycy9saXN0Lmpzb24/Y291bnQ9QHtsaW1pdHwyMDB9JyxcblxuXHRcdFx0XHQvLyBIdHRwczovL2Rldi50d2l0dGVyLmNvbS9kb2NzL2FwaS8xLjEvZ2V0L3N0YXR1c2VzL3VzZXJfdGltZWxpbmVcblx0XHRcdFx0J21lL3NoYXJlJzogJ3N0YXR1c2VzL3VzZXJfdGltZWxpbmUuanNvbj9jb3VudD1Ae2xpbWl0fDIwMH0nLFxuXG5cdFx0XHRcdC8vIEh0dHBzOi8vZGV2LnR3aXR0ZXIuY29tL3Jlc3QvcmVmZXJlbmNlL2dldC9mYXZvcml0ZXMvbGlzdFxuXHRcdFx0XHQnbWUvbGlrZSc6ICdmYXZvcml0ZXMvbGlzdC5qc29uP2NvdW50PUB7bGltaXR8MjAwfSdcblx0XHRcdH0sXG5cblx0XHRcdHBvc3Q6IHtcblx0XHRcdFx0J21lL3NoYXJlJzogZnVuY3Rpb24ocCwgY2FsbGJhY2spIHtcblxuXHRcdFx0XHRcdHZhciBkYXRhID0gcC5kYXRhO1xuXHRcdFx0XHRcdHAuZGF0YSA9IG51bGw7XG5cblx0XHRcdFx0XHR2YXIgc3RhdHVzID0gW107XG5cblx0XHRcdFx0XHQvLyBDaGFuZ2UgbWVzc2FnZSB0byBzdGF0dXNcblx0XHRcdFx0XHRpZiAoZGF0YS5tZXNzYWdlKSB7XG5cdFx0XHRcdFx0XHRzdGF0dXMucHVzaChkYXRhLm1lc3NhZ2UpO1xuXHRcdFx0XHRcdFx0ZGVsZXRlIGRhdGEubWVzc2FnZTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBJZiBsaW5rIGlzIGdpdmVuXG5cdFx0XHRcdFx0aWYgKGRhdGEubGluaykge1xuXHRcdFx0XHRcdFx0c3RhdHVzLnB1c2goZGF0YS5saW5rKTtcblx0XHRcdFx0XHRcdGRlbGV0ZSBkYXRhLmxpbms7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0aWYgKGRhdGEucGljdHVyZSkge1xuXHRcdFx0XHRcdFx0c3RhdHVzLnB1c2goZGF0YS5waWN0dXJlKTtcblx0XHRcdFx0XHRcdGRlbGV0ZSBkYXRhLnBpY3R1cmU7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Ly8gQ29tcG91bmQgYWxsIHRoZSBjb21wb25lbnRzXG5cdFx0XHRcdFx0aWYgKHN0YXR1cy5sZW5ndGgpIHtcblx0XHRcdFx0XHRcdGRhdGEuc3RhdHVzID0gc3RhdHVzLmpvaW4oJyAnKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBUd2VldCBtZWRpYVxuXHRcdFx0XHRcdGlmIChkYXRhLmZpbGUpIHtcblx0XHRcdFx0XHRcdGRhdGFbJ21lZGlhW10nXSA9IGRhdGEuZmlsZTtcblx0XHRcdFx0XHRcdGRlbGV0ZSBkYXRhLmZpbGU7XG5cdFx0XHRcdFx0XHRwLmRhdGEgPSBkYXRhO1xuXHRcdFx0XHRcdFx0Y2FsbGJhY2soJ3N0YXR1c2VzL3VwZGF0ZV93aXRoX21lZGlhLmpzb24nKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBSZXR3ZWV0P1xuXHRcdFx0XHRcdGVsc2UgaWYgKCdpZCcgaW4gZGF0YSkge1xuXHRcdFx0XHRcdFx0Y2FsbGJhY2soJ3N0YXR1c2VzL3JldHdlZXQvJyArIGRhdGEuaWQgKyAnLmpzb24nKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBUd2VldFxuXHRcdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdFx0Ly8gQXNzaWduIHRoZSBwb3N0IGJvZHkgdG8gdGhlIHF1ZXJ5IHBhcmFtZXRlcnNcblx0XHRcdFx0XHRcdGhlbGxvLnV0aWxzLmV4dGVuZChwLnF1ZXJ5LCBkYXRhKTtcblx0XHRcdFx0XHRcdGNhbGxiYWNrKCdzdGF0dXNlcy91cGRhdGUuanNvbj9pbmNsdWRlX2VudGl0aWVzPTEnKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0Ly8gU2VlOiBodHRwczovL2Rldi50d2l0dGVyLmNvbS9yZXN0L3JlZmVyZW5jZS9wb3N0L2Zhdm9yaXRlcy9jcmVhdGVcblx0XHRcdFx0J21lL2xpa2UnOiBmdW5jdGlvbihwLCBjYWxsYmFjaykge1xuXHRcdFx0XHRcdHZhciBpZCA9IHAuZGF0YS5pZDtcblx0XHRcdFx0XHRwLmRhdGEgPSBudWxsO1xuXHRcdFx0XHRcdGNhbGxiYWNrKCdmYXZvcml0ZXMvY3JlYXRlLmpzb24/aWQ9JyArIGlkKTtcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0ZGVsOiB7XG5cblx0XHRcdFx0Ly8gU2VlOiBodHRwczovL2Rldi50d2l0dGVyLmNvbS9yZXN0L3JlZmVyZW5jZS9wb3N0L2Zhdm9yaXRlcy9kZXN0cm95XG5cdFx0XHRcdCdtZS9saWtlJzogZnVuY3Rpb24oKSB7XG5cdFx0XHRcdFx0cC5tZXRob2QgPSAncG9zdCc7XG5cdFx0XHRcdFx0dmFyIGlkID0gcC5kYXRhLmlkO1xuXHRcdFx0XHRcdHAuZGF0YSA9IG51bGw7XG5cdFx0XHRcdFx0Y2FsbGJhY2soJ2Zhdm9yaXRlcy9kZXN0cm95Lmpzb24/aWQ9JyArIGlkKTtcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZnVuY3Rpb24ocmVzKSB7XG5cdFx0XHRcdFx0Zm9ybWF0RXJyb3IocmVzKTtcblx0XHRcdFx0XHRmb3JtYXRVc2VyKHJlcyk7XG5cdFx0XHRcdFx0cmV0dXJuIHJlcztcblx0XHRcdFx0fSxcblxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogZm9ybWF0RnJpZW5kcyxcblxuXHRcdFx0XHQnbWUvc2hhcmUnOiBmdW5jdGlvbihyZXMpIHtcblx0XHRcdFx0XHRmb3JtYXRFcnJvcihyZXMpO1xuXHRcdFx0XHRcdHBhZ2luZyhyZXMpO1xuXHRcdFx0XHRcdGlmICghcmVzLmVycm9yICYmICdsZW5ndGgnIGluIHJlcykge1xuXHRcdFx0XHRcdFx0cmV0dXJuIHtkYXRhOiByZXN9O1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiByZXM7XG5cdFx0XHRcdH0sXG5cblx0XHRcdFx0J2RlZmF1bHQnOiBmdW5jdGlvbihyZXMpIHtcblx0XHRcdFx0XHRyZXMgPSBhcnJheVRvRGF0YVJlc3BvbnNlKHJlcyk7XG5cdFx0XHRcdFx0cGFnaW5nKHJlcyk7XG5cdFx0XHRcdFx0cmV0dXJuIHJlcztcblx0XHRcdFx0fVxuXHRcdFx0fSxcblx0XHRcdHhocjogZnVuY3Rpb24ocCkge1xuXG5cdFx0XHRcdC8vIFJlbHkgb24gdGhlIHByb3h5IGZvciBub24tR0VUIHJlcXVlc3RzLlxuXHRcdFx0XHRyZXR1cm4gKHAubWV0aG9kICE9PSAnZ2V0Jyk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9KTtcblxuXHRmdW5jdGlvbiBmb3JtYXRVc2VyKG8pIHtcblx0XHRpZiAoby5pZCkge1xuXHRcdFx0aWYgKG8ubmFtZSkge1xuXHRcdFx0XHR2YXIgbSA9IG8ubmFtZS5zcGxpdCgnICcpO1xuXHRcdFx0XHRvLmZpcnN0X25hbWUgPSBtLnNoaWZ0KCk7XG5cdFx0XHRcdG8ubGFzdF9uYW1lID0gbS5qb2luKCcgJyk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIFNlZTogaHR0cHM6Ly9kZXYudHdpdHRlci5jb20vb3ZlcnZpZXcvZ2VuZXJhbC91c2VyLXByb2ZpbGUtaW1hZ2VzLWFuZC1iYW5uZXJzXG5cdFx0XHRvLnRodW1ibmFpbCA9IG8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMgfHwgby5wcm9maWxlX2ltYWdlX3VybDtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEZyaWVuZHMobykge1xuXHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdHBhZ2luZyhvKTtcblx0XHRpZiAoby51c2Vycykge1xuXHRcdFx0by5kYXRhID0gby51c2Vycy5tYXAoZm9ybWF0VXNlcik7XG5cdFx0XHRkZWxldGUgby51c2Vycztcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEVycm9yKG8pIHtcblx0XHRpZiAoby5lcnJvcnMpIHtcblx0XHRcdHZhciBlID0gby5lcnJvcnNbMF07XG5cdFx0XHRvLmVycm9yID0ge1xuXHRcdFx0XHRjb2RlOiAncmVxdWVzdF9mYWlsZWQnLFxuXHRcdFx0XHRtZXNzYWdlOiBlLm1lc3NhZ2Vcblx0XHRcdH07XG5cdFx0fVxuXHR9XG5cblx0Ly8gVGFrZSBhIGN1cnNvciBhbmQgYWRkIGl0IHRvIHRoZSBwYXRoXG5cdGZ1bmN0aW9uIHBhZ2luZyhyZXMpIHtcblx0XHQvLyBEb2VzIHRoZSByZXNwb25zZSBpbmNsdWRlIGEgJ25leHRfY3Vyc29yX3N0cmluZydcblx0XHRpZiAoJ25leHRfY3Vyc29yX3N0cicgaW4gcmVzKSB7XG5cdFx0XHQvLyBTZWU6IGh0dHBzOi8vZGV2LnR3aXR0ZXIuY29tL2RvY3MvbWlzYy9jdXJzb3Jpbmdcblx0XHRcdHJlcy5wYWdpbmcgPSB7XG5cdFx0XHRcdG5leHQ6ICc/Y3Vyc29yPScgKyByZXMubmV4dF9jdXJzb3Jfc3RyXG5cdFx0XHR9O1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGFycmF5VG9EYXRhUmVzcG9uc2UocmVzKSB7XG5cdFx0cmV0dXJuIEFycmF5LmlzQXJyYXkocmVzKSA/IHtkYXRhOiByZXN9IDogcmVzO1xuXHR9XG5cblx0LyoqXG5cdC8vIFRoZSBkb2N1bWVudGF0aW9uIHNheXMgdG8gZGVmaW5lIHVzZXIgaW4gdGhlIHJlcXVlc3Rcblx0Ly8gQWx0aG91Z2ggaXRzIG5vdCBhY3R1YWxseSByZXF1aXJlZC5cblxuXHR2YXIgdXNlcl9pZDtcblxuXHRmdW5jdGlvbiB3aXRoVXNlcklkKGNhbGxiYWNrKXtcblx0XHRpZih1c2VyX2lkKXtcblx0XHRcdGNhbGxiYWNrKHVzZXJfaWQpO1xuXHRcdH1cblx0XHRlbHNle1xuXHRcdFx0aGVsbG8uYXBpKCd0d2l0dGVyOi9tZScsIGZ1bmN0aW9uKG8pe1xuXHRcdFx0XHR1c2VyX2lkID0gby5pZDtcblx0XHRcdFx0Y2FsbGJhY2soby5pZCk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBzaWduKHVybCl7XG5cdFx0cmV0dXJuIGZ1bmN0aW9uKHAsIGNhbGxiYWNrKXtcblx0XHRcdHdpdGhVc2VySWQoZnVuY3Rpb24odXNlcl9pZCl7XG5cdFx0XHRcdGNhbGxiYWNrKHVybCsnP3VzZXJfaWQ9Jyt1c2VyX2lkKTtcblx0XHRcdH0pO1xuXHRcdH07XG5cdH1cblx0Ki9cblxufSkoaGVsbG8pO1xuXG4vLyBWa29udGFrdGUgKHZrLmNvbSlcbihmdW5jdGlvbihoZWxsbykge1xuXG5cdGhlbGxvLmluaXQoe1xuXG5cdFx0dms6IHtcblx0XHRcdG5hbWU6ICdWaycsXG5cblx0XHRcdC8vIFNlZSBodHRwczovL3ZrLmNvbS9kZXYvb2F1dGhfZGlhbG9nXG5cdFx0XHRvYXV0aDoge1xuXHRcdFx0XHR2ZXJzaW9uOiAyLFxuXHRcdFx0XHRhdXRoOiAnaHR0cHM6Ly9vYXV0aC52ay5jb20vYXV0aG9yaXplJyxcblx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL29hdXRoLnZrLmNvbS9hY2Nlc3NfdG9rZW4nXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBBdXRob3JpemF0aW9uIHNjb3Blc1xuXHRcdFx0Ly8gU2VlIGh0dHBzOi8vdmsuY29tL2Rldi9wZXJtaXNzaW9uc1xuXHRcdFx0c2NvcGU6IHtcblx0XHRcdFx0ZW1haWw6ICdlbWFpbCcsXG5cdFx0XHRcdGZyaWVuZHM6ICdmcmllbmRzJyxcblx0XHRcdFx0cGhvdG9zOiAncGhvdG9zJyxcblx0XHRcdFx0dmlkZW9zOiAndmlkZW8nLFxuXHRcdFx0XHRzaGFyZTogJ3NoYXJlJyxcblx0XHRcdFx0b2ZmbGluZV9hY2Nlc3M6ICdvZmZsaW5lJ1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gUmVmcmVzaCB0aGUgYWNjZXNzX3Rva2VuXG5cdFx0XHRyZWZyZXNoOiB0cnVlLFxuXG5cdFx0XHRsb2dpbjogZnVuY3Rpb24ocCkge1xuXHRcdFx0XHRwLnFzLmRpc3BsYXkgPSB3aW5kb3cubmF2aWdhdG9yICYmXG5cdFx0XHRcdFx0d2luZG93Lm5hdmlnYXRvci51c2VyQWdlbnQgJiZcblx0XHRcdFx0XHQvaXBhZHxwaG9uZXxwaG9uZXxhbmRyb2lkLy50ZXN0KHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkpID8gJ21vYmlsZScgOiAncG9wdXAnO1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gQVBJIEJhc2UgVVJMXG5cdFx0XHRiYXNlOiAnaHR0cHM6Ly9hcGkudmsuY29tL21ldGhvZC8nLFxuXG5cdFx0XHQvLyBNYXAgR0VUIHJlcXVlc3RzXG5cdFx0XHRnZXQ6IHtcblx0XHRcdFx0bWU6IGZ1bmN0aW9uKHAsIGNhbGxiYWNrKSB7XG5cdFx0XHRcdFx0cC5xdWVyeS5maWVsZHMgPSAnaWQsZmlyc3RfbmFtZSxsYXN0X25hbWUscGhvdG9fbWF4Jztcblx0XHRcdFx0XHRjYWxsYmFjaygndXNlcnMuZ2V0Jyk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdHdyYXA6IHtcblx0XHRcdFx0bWU6IGZ1bmN0aW9uKHJlcywgaGVhZGVycywgcmVxKSB7XG5cdFx0XHRcdFx0Zm9ybWF0RXJyb3IocmVzKTtcblx0XHRcdFx0XHRyZXR1cm4gZm9ybWF0VXNlcihyZXMsIHJlcSk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cblx0XHRcdC8vIE5vIFhIUlxuXHRcdFx0eGhyOiBmYWxzZSxcblxuXHRcdFx0Ly8gQWxsIHJlcXVlc3RzIHNob3VsZCBiZSBKU09OUCBhcyBvZiBtaXNzaW5nIENPUlMgaGVhZGVycyBpbiBodHRwczovL2FwaS52ay5jb20vbWV0aG9kLypcblx0XHRcdGpzb25wOiB0cnVlLFxuXG5cdFx0XHQvLyBObyBmb3JtXG5cdFx0XHRmb3JtOiBmYWxzZVxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gZm9ybWF0VXNlcihvLCByZXEpIHtcblxuXHRcdGlmIChvICE9PSBudWxsICYmICdyZXNwb25zZScgaW4gbyAmJiBvLnJlc3BvbnNlICE9PSBudWxsICYmIG8ucmVzcG9uc2UubGVuZ3RoKSB7XG5cdFx0XHRvID0gby5yZXNwb25zZVswXTtcblx0XHRcdG8uaWQgPSBvLnVpZDtcblx0XHRcdG8udGh1bWJuYWlsID0gby5waWN0dXJlID0gby5waG90b19tYXg7XG5cdFx0XHRvLm5hbWUgPSBvLmZpcnN0X25hbWUgKyAnICcgKyBvLmxhc3RfbmFtZTtcblxuXHRcdFx0aWYgKHJlcS5hdXRoUmVzcG9uc2UgJiYgcmVxLmF1dGhSZXNwb25zZS5lbWFpbCAhPT0gbnVsbClcblx0XHRcdFx0by5lbWFpbCA9IHJlcS5hdXRoUmVzcG9uc2UuZW1haWw7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG87XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRFcnJvcihvKSB7XG5cblx0XHRpZiAoby5lcnJvcikge1xuXHRcdFx0dmFyIGUgPSBvLmVycm9yO1xuXHRcdFx0by5lcnJvciA9IHtcblx0XHRcdFx0Y29kZTogZS5lcnJvcl9jb2RlLFxuXHRcdFx0XHRtZXNzYWdlOiBlLmVycm9yX21zZ1xuXHRcdFx0fTtcblx0XHR9XG5cdH1cblxufSkoaGVsbG8pO1xuXG4oZnVuY3Rpb24oaGVsbG8pIHtcblxuXHRoZWxsby5pbml0KHtcblx0XHR3aW5kb3dzOiB7XG5cdFx0XHRuYW1lOiAnV2luZG93cyBsaXZlJyxcblxuXHRcdFx0Ly8gUkVGOiBodHRwOi8vbXNkbi5taWNyb3NvZnQuY29tL2VuLXVzL2xpYnJhcnkvaGgyNDM2NDEuYXNweFxuXHRcdFx0b2F1dGg6IHtcblx0XHRcdFx0dmVyc2lvbjogMixcblx0XHRcdFx0YXV0aDogJ2h0dHBzOi8vbG9naW4ubGl2ZS5jb20vb2F1dGgyMF9hdXRob3JpemUuc3JmJyxcblx0XHRcdFx0Z3JhbnQ6ICdodHRwczovL2xvZ2luLmxpdmUuY29tL29hdXRoMjBfdG9rZW4uc3JmJ1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gUmVmcmVzaCB0aGUgYWNjZXNzX3Rva2VuIG9uY2UgZXhwaXJlZFxuXHRcdFx0cmVmcmVzaDogdHJ1ZSxcblxuXHRcdFx0bG9nb3V0OiBmdW5jdGlvbigpIHtcblx0XHRcdFx0cmV0dXJuICdodHRwOi8vbG9naW4ubGl2ZS5jb20vb2F1dGgyMF9sb2dvdXQuc3JmP3RzPScgKyAobmV3IERhdGUoKSkuZ2V0VGltZSgpO1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gQXV0aG9yaXphdGlvbiBzY29wZXNcblx0XHRcdHNjb3BlOiB7XG5cdFx0XHRcdGJhc2ljOiAnd2wuc2lnbmluLHdsLmJhc2ljJyxcblx0XHRcdFx0ZW1haWw6ICd3bC5lbWFpbHMnLFxuXHRcdFx0XHRiaXJ0aGRheTogJ3dsLmJpcnRoZGF5Jyxcblx0XHRcdFx0ZXZlbnRzOiAnd2wuY2FsZW5kYXJzJyxcblx0XHRcdFx0cGhvdG9zOiAnd2wucGhvdG9zJyxcblx0XHRcdFx0dmlkZW9zOiAnd2wucGhvdG9zJyxcblx0XHRcdFx0ZnJpZW5kczogJ3dsLmNvbnRhY3RzX2VtYWlscycsXG5cdFx0XHRcdGZpbGVzOiAnd2wuc2t5ZHJpdmUnLFxuXHRcdFx0XHRwdWJsaXNoOiAnd2wuc2hhcmUnLFxuXHRcdFx0XHRwdWJsaXNoX2ZpbGVzOiAnd2wuc2t5ZHJpdmVfdXBkYXRlJyxcblx0XHRcdFx0c2hhcmU6ICd3bC5zaGFyZScsXG5cdFx0XHRcdGNyZWF0ZV9ldmVudDogJ3dsLmNhbGVuZGFyc191cGRhdGUsd2wuZXZlbnRzX2NyZWF0ZScsXG5cdFx0XHRcdG9mZmxpbmVfYWNjZXNzOiAnd2wub2ZmbGluZV9hY2Nlc3MnXG5cdFx0XHR9LFxuXG5cdFx0XHQvLyBBUEkgYmFzZSBVUkxcblx0XHRcdGJhc2U6ICdodHRwczovL2FwaXMubGl2ZS5uZXQvdjUuMC8nLFxuXG5cdFx0XHQvLyBNYXAgR0VUIHJlcXVlc3RzXG5cdFx0XHRnZXQ6IHtcblxuXHRcdFx0XHQvLyBGcmllbmRzXG5cdFx0XHRcdG1lOiAnbWUnLFxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6ICdtZS9mcmllbmRzJyxcblx0XHRcdFx0J21lL2ZvbGxvd2luZyc6ICdtZS9jb250YWN0cycsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiAnbWUvZnJpZW5kcycsXG5cdFx0XHRcdCdtZS9jb250YWN0cyc6ICdtZS9jb250YWN0cycsXG5cblx0XHRcdFx0J21lL2FsYnVtcyc6ICdtZS9hbGJ1bXMnLFxuXG5cdFx0XHRcdC8vIEluY2x1ZGUgdGhlIGRhdGFbaWRdIGluIHRoZSBwYXRoXG5cdFx0XHRcdCdtZS9hbGJ1bSc6ICdAe2lkfS9maWxlcycsXG5cdFx0XHRcdCdtZS9waG90byc6ICdAe2lkfScsXG5cblx0XHRcdFx0Ly8gRmlsZXNcblx0XHRcdFx0J21lL2ZpbGVzJzogJ0B7cGFyZW50fG1lL3NreWRyaXZlfS9maWxlcycsXG5cdFx0XHRcdCdtZS9mb2xkZXJzJzogJ0B7aWR8bWUvc2t5ZHJpdmV9L2ZpbGVzJyxcblx0XHRcdFx0J21lL2ZvbGRlcic6ICdAe2lkfG1lL3NreWRyaXZlfS9maWxlcydcblx0XHRcdH0sXG5cblx0XHRcdC8vIE1hcCBQT1NUIHJlcXVlc3RzXG5cdFx0XHRwb3N0OiB7XG5cdFx0XHRcdCdtZS9hbGJ1bXMnOiAnbWUvYWxidW1zJyxcblx0XHRcdFx0J21lL2FsYnVtJzogJ0B7aWR9L2ZpbGVzLycsXG5cblx0XHRcdFx0J21lL2ZvbGRlcnMnOiAnQHtpZHxtZS9za3lkcml2ZS99Jyxcblx0XHRcdFx0J21lL2ZpbGVzJzogJ0B7cGFyZW50fG1lL3NreWRyaXZlfS9maWxlcydcblx0XHRcdH0sXG5cblx0XHRcdC8vIE1hcCBERUxFVEUgcmVxdWVzdHNcblx0XHRcdGRlbDoge1xuXHRcdFx0XHQvLyBJbmNsdWRlIHRoZSBkYXRhW2lkXSBpbiB0aGUgcGF0aFxuXHRcdFx0XHQnbWUvYWxidW0nOiAnQHtpZH0nLFxuXHRcdFx0XHQnbWUvcGhvdG8nOiAnQHtpZH0nLFxuXHRcdFx0XHQnbWUvZm9sZGVyJzogJ0B7aWR9Jyxcblx0XHRcdFx0J21lL2ZpbGVzJzogJ0B7aWR9J1xuXHRcdFx0fSxcblxuXHRcdFx0d3JhcDoge1xuXHRcdFx0XHRtZTogZm9ybWF0VXNlcixcblxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9jb250YWN0cyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9mb2xsb3dlcnMnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogZm9ybWF0RnJpZW5kcyxcblx0XHRcdFx0J21lL2FsYnVtcyc6IGZvcm1hdEFsYnVtcyxcblx0XHRcdFx0J21lL3Bob3Rvcyc6IGZvcm1hdERlZmF1bHQsXG5cdFx0XHRcdCdkZWZhdWx0JzogZm9ybWF0RGVmYXVsdFxuXHRcdFx0fSxcblxuXHRcdFx0eGhyOiBmdW5jdGlvbihwKSB7XG5cdFx0XHRcdGlmIChwLm1ldGhvZCAhPT0gJ2dldCcgJiYgcC5tZXRob2QgIT09ICdkZWxldGUnICYmICFoZWxsby51dGlscy5oYXNCaW5hcnkocC5kYXRhKSkge1xuXG5cdFx0XHRcdFx0Ly8gRG9lcyB0aGlzIGhhdmUgYSBkYXRhLXVyaSB0byB1cGxvYWQgYXMgYSBmaWxlP1xuXHRcdFx0XHRcdGlmICh0eXBlb2YgKHAuZGF0YS5maWxlKSA9PT0gJ3N0cmluZycpIHtcblx0XHRcdFx0XHRcdHAuZGF0YS5maWxlID0gaGVsbG8udXRpbHMudG9CbG9iKHAuZGF0YS5maWxlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0XHRwLmRhdGEgPSBKU09OLnN0cmluZ2lmeShwLmRhdGEpO1xuXHRcdFx0XHRcdFx0cC5oZWFkZXJzID0ge1xuXHRcdFx0XHRcdFx0XHQnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0fSxcblxuXHRcdFx0anNvbnA6IGZ1bmN0aW9uKHApIHtcblx0XHRcdFx0aWYgKHAubWV0aG9kICE9PSAnZ2V0JyAmJiAhaGVsbG8udXRpbHMuaGFzQmluYXJ5KHAuZGF0YSkpIHtcblx0XHRcdFx0XHRwLmRhdGEubWV0aG9kID0gcC5tZXRob2Q7XG5cdFx0XHRcdFx0cC5tZXRob2QgPSAnZ2V0Jztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gZm9ybWF0RGVmYXVsdChvKSB7XG5cdFx0aWYgKCdkYXRhJyBpbiBvKSB7XG5cdFx0XHRvLmRhdGEuZm9yRWFjaChmdW5jdGlvbihkKSB7XG5cdFx0XHRcdGlmIChkLnBpY3R1cmUpIHtcblx0XHRcdFx0XHRkLnRodW1ibmFpbCA9IGQucGljdHVyZTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChkLmltYWdlcykge1xuXHRcdFx0XHRcdGQucGljdHVyZXMgPSBkLmltYWdlc1xuXHRcdFx0XHRcdFx0Lm1hcChmb3JtYXRJbWFnZSlcblx0XHRcdFx0XHRcdC5zb3J0KGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIGEud2lkdGggLSBiLndpZHRoO1xuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0SW1hZ2UoaW1hZ2UpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0d2lkdGg6IGltYWdlLndpZHRoLFxuXHRcdFx0aGVpZ2h0OiBpbWFnZS5oZWlnaHQsXG5cdFx0XHRzb3VyY2U6IGltYWdlLnNvdXJjZVxuXHRcdH07XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRBbGJ1bXMobykge1xuXHRcdGlmICgnZGF0YScgaW4gbykge1xuXHRcdFx0by5kYXRhLmZvckVhY2goZnVuY3Rpb24oZCkge1xuXHRcdFx0XHRkLnBob3RvcyA9IGQuZmlsZXMgPSAnaHR0cHM6Ly9hcGlzLmxpdmUubmV0L3Y1LjAvJyArIGQuaWQgKyAnL3Bob3Rvcyc7XG5cdFx0XHR9KTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdFVzZXIobywgaGVhZGVycywgcmVxKSB7XG5cdFx0aWYgKG8uaWQpIHtcblx0XHRcdHZhciB0b2tlbiA9IHJlcS5xdWVyeS5hY2Nlc3NfdG9rZW47XG5cdFx0XHRpZiAoby5lbWFpbHMpIHtcblx0XHRcdFx0by5lbWFpbCA9IG8uZW1haWxzLnByZWZlcnJlZDtcblx0XHRcdH1cblxuXHRcdFx0Ly8gSWYgdGhpcyBpcyBub3QgYW4gbm9uLW5ldHdvcmsgZnJpZW5kXG5cdFx0XHRpZiAoby5pc19mcmllbmQgIT09IGZhbHNlKSB7XG5cdFx0XHRcdC8vIFVzZSB0aGUgaWQgb2YgdGhlIHVzZXJfaWQgaWYgYXZhaWxhYmxlXG5cdFx0XHRcdHZhciBpZCA9IChvLnVzZXJfaWQgfHwgby5pZCk7XG5cdFx0XHRcdG8udGh1bWJuYWlsID0gby5waWN0dXJlID0gJ2h0dHBzOi8vYXBpcy5saXZlLm5ldC92NS4wLycgKyBpZCArICcvcGljdHVyZT9hY2Nlc3NfdG9rZW49JyArIHRva2VuO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiBvO1xuXHR9XG5cblx0ZnVuY3Rpb24gZm9ybWF0RnJpZW5kcyhvLCBoZWFkZXJzLCByZXEpIHtcblx0XHRpZiAoJ2RhdGEnIGluIG8pIHtcblx0XHRcdG8uZGF0YS5mb3JFYWNoKGZ1bmN0aW9uKGQpIHtcblx0XHRcdFx0Zm9ybWF0VXNlcihkLCBoZWFkZXJzLCByZXEpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG87XG5cdH1cblxufSkoaGVsbG8pO1xuXG4oZnVuY3Rpb24oaGVsbG8pIHtcblxuXHRoZWxsby5pbml0KHtcblxuXHRcdHlhaG9vOiB7XG5cblx0XHRcdC8vIEVuc3VyZSB0aGF0IHlvdSBkZWZpbmUgYW4gb2F1dGhfcHJveHlcblx0XHRcdG9hdXRoOiB7XG5cdFx0XHRcdHZlcnNpb246ICcxLjBhJyxcblx0XHRcdFx0YXV0aDogJ2h0dHBzOi8vYXBpLmxvZ2luLnlhaG9vLmNvbS9vYXV0aC92Mi9yZXF1ZXN0X2F1dGgnLFxuXHRcdFx0XHRyZXF1ZXN0OiAnaHR0cHM6Ly9hcGkubG9naW4ueWFob28uY29tL29hdXRoL3YyL2dldF9yZXF1ZXN0X3Rva2VuJyxcblx0XHRcdFx0dG9rZW46ICdodHRwczovL2FwaS5sb2dpbi55YWhvby5jb20vb2F1dGgvdjIvZ2V0X3Rva2VuJ1xuXHRcdFx0fSxcblxuXHRcdFx0Ly8gTG9naW4gaGFuZGxlclxuXHRcdFx0bG9naW46IGZ1bmN0aW9uKHApIHtcblx0XHRcdFx0Ly8gQ2hhbmdlIHRoZSBkZWZhdWx0IHBvcHVwIHdpbmRvdyB0byBiZSBhdCBsZWFzdCA1NjBcblx0XHRcdFx0Ly8gWWFob28gZG9lcyBkeW5hbWljYWxseSBjaGFuZ2UgaXQgb24gdGhlIGZseSBmb3IgdGhlIHNpZ25pbiBzY3JlZW4gKG9ubHksIHdoYXQgaWYgeW91ciBhbHJlYWR5IHNpZ25lZCBpbilcblx0XHRcdFx0cC5vcHRpb25zLnBvcHVwLndpZHRoID0gNTYwO1xuXG5cdFx0XHRcdC8vIFlhaG9vIHRocm93cyBhbiBwYXJhbWV0ZXIgZXJyb3IgaWYgZm9yIHdoYXRldmVyIHJlYXNvbiB0aGUgc3RhdGUuc2NvcGUgY29udGFpbnMgYSBjb21tYSwgc28gbGV0cyByZW1vdmUgc2NvcGVcblx0XHRcdFx0dHJ5IHtkZWxldGUgcC5xcy5zdGF0ZS5zY29wZTt9XG5cdFx0XHRcdGNhdGNoIChlKSB7fVxuXHRcdFx0fSxcblxuXHRcdFx0YmFzZTogJ2h0dHBzOi8vc29jaWFsLnlhaG9vYXBpcy5jb20vdjEvJyxcblxuXHRcdFx0Z2V0OiB7XG5cdFx0XHRcdG1lOiB5cWwoJ3NlbGVjdCAqIGZyb20gc29jaWFsLnByb2ZpbGUoMCkgd2hlcmUgZ3VpZD1tZScpLFxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6IHlxbCgnc2VsZWN0ICogZnJvbSBzb2NpYWwuY29udGFjdHMoMCkgd2hlcmUgZ3VpZD1tZScpLFxuXHRcdFx0XHQnbWUvZm9sbG93aW5nJzogeXFsKCdzZWxlY3QgKiBmcm9tIHNvY2lhbC5jb250YWN0cygwKSB3aGVyZSBndWlkPW1lJylcblx0XHRcdH0sXG5cdFx0XHR3cmFwOiB7XG5cdFx0XHRcdG1lOiBmb3JtYXRVc2VyLFxuXG5cdFx0XHRcdC8vIENhbid0IGdldCBJRHNcblx0XHRcdFx0Ly8gSXQgbWlnaHQgYmUgYmV0dGVyIHRvIGxvb3AgdGhyb3VnaCB0aGUgc29jaWFsLnJlbGF0aW9uc2hpcCB0YWJsZSB3aXRoIGhhcyB1bmlxdWUgSURzIG9mIHVzZXJzLlxuXHRcdFx0XHQnbWUvZnJpZW5kcyc6IGZvcm1hdEZyaWVuZHMsXG5cdFx0XHRcdCdtZS9mb2xsb3dpbmcnOiBmb3JtYXRGcmllbmRzLFxuXHRcdFx0XHQnZGVmYXVsdCc6IHBhZ2luZ1xuXHRcdFx0fVxuXHRcdH1cblx0fSk7XG5cblx0Lypcblx0XHQvLyBBdXRvLXJlZnJlc2ggZml4OiBidWcgaW4gWWFob28gY2FuJ3QgZ2V0IHRoaXMgdG8gd29yayB3aXRoIG5vZGUtb2F1dGgtc2hpbVxuXHRcdGxvZ2luIDogZnVuY3Rpb24obyl7XG5cdFx0XHQvLyBJcyB0aGUgdXNlciBhbHJlYWR5IGxvZ2dlZCBpblxuXHRcdFx0dmFyIGF1dGggPSBoZWxsbygneWFob28nKS5nZXRBdXRoUmVzcG9uc2UoKTtcblxuXHRcdFx0Ly8gSXMgdGhpcyBhIHJlZnJlc2ggdG9rZW4/XG5cdFx0XHRpZihvLm9wdGlvbnMuZGlzcGxheT09PSdub25lJyYmYXV0aCYmYXV0aC5hY2Nlc3NfdG9rZW4mJmF1dGgucmVmcmVzaF90b2tlbil7XG5cdFx0XHRcdC8vIEFkZCB0aGUgb2xkIHRva2VuIGFuZCB0aGUgcmVmcmVzaCB0b2tlbiwgaW5jbHVkaW5nIHBhdGggdG8gdGhlIHF1ZXJ5XG5cdFx0XHRcdC8vIFNlZSBodHRwOi8vZGV2ZWxvcGVyLnlhaG9vLmNvbS9vYXV0aC9ndWlkZS9vYXV0aC1yZWZyZXNoYWNjZXNzdG9rZW4uaHRtbFxuXHRcdFx0XHRvLnFzLmFjY2Vzc190b2tlbiA9IGF1dGguYWNjZXNzX3Rva2VuO1xuXHRcdFx0XHRvLnFzLnJlZnJlc2hfdG9rZW4gPSBhdXRoLnJlZnJlc2hfdG9rZW47XG5cdFx0XHRcdG8ucXMudG9rZW5fdXJsID0gJ2h0dHBzOi8vYXBpLmxvZ2luLnlhaG9vLmNvbS9vYXV0aC92Mi9nZXRfdG9rZW4nO1xuXHRcdFx0fVxuXHRcdH0sXG5cdCovXG5cblx0ZnVuY3Rpb24gZm9ybWF0RXJyb3Iobykge1xuXHRcdGlmIChvICYmICdtZXRhJyBpbiBvICYmICdlcnJvcl90eXBlJyBpbiBvLm1ldGEpIHtcblx0XHRcdG8uZXJyb3IgPSB7XG5cdFx0XHRcdGNvZGU6IG8ubWV0YS5lcnJvcl90eXBlLFxuXHRcdFx0XHRtZXNzYWdlOiBvLm1ldGEuZXJyb3JfbWVzc2FnZVxuXHRcdFx0fTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBmb3JtYXRVc2VyKG8pIHtcblxuXHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdGlmIChvLnF1ZXJ5ICYmIG8ucXVlcnkucmVzdWx0cyAmJiBvLnF1ZXJ5LnJlc3VsdHMucHJvZmlsZSkge1xuXHRcdFx0byA9IG8ucXVlcnkucmVzdWx0cy5wcm9maWxlO1xuXHRcdFx0by5pZCA9IG8uZ3VpZDtcblx0XHRcdG8ubGFzdF9uYW1lID0gby5mYW1pbHlOYW1lO1xuXHRcdFx0by5maXJzdF9uYW1lID0gby5naXZlbk5hbWUgfHwgby5uaWNrbmFtZTtcblx0XHRcdHZhciBhID0gW107XG5cdFx0XHRpZiAoby5maXJzdF9uYW1lKSB7XG5cdFx0XHRcdGEucHVzaChvLmZpcnN0X25hbWUpO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoby5sYXN0X25hbWUpIHtcblx0XHRcdFx0YS5wdXNoKG8ubGFzdF9uYW1lKTtcblx0XHRcdH1cblxuXHRcdFx0by5uYW1lID0gYS5qb2luKCcgJyk7XG5cdFx0XHRvLmVtYWlsID0gKG8uZW1haWxzICYmIG8uZW1haWxzWzBdKSA/IG8uZW1haWxzWzBdLmhhbmRsZSA6IG51bGw7XG5cdFx0XHRvLnRodW1ibmFpbCA9IG8uaW1hZ2UgPyBvLmltYWdlLmltYWdlVXJsIDogbnVsbDtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEZyaWVuZHMobywgaGVhZGVycywgcmVxdWVzdCkge1xuXHRcdGZvcm1hdEVycm9yKG8pO1xuXHRcdHBhZ2luZyhvLCBoZWFkZXJzLCByZXF1ZXN0KTtcblx0XHR2YXIgY29udGFjdDtcblx0XHR2YXIgZmllbGQ7XG5cdFx0aWYgKG8ucXVlcnkgJiYgby5xdWVyeS5yZXN1bHRzICYmIG8ucXVlcnkucmVzdWx0cy5jb250YWN0KSB7XG5cdFx0XHRvLmRhdGEgPSBvLnF1ZXJ5LnJlc3VsdHMuY29udGFjdDtcblx0XHRcdGRlbGV0ZSBvLnF1ZXJ5O1xuXG5cdFx0XHRpZiAoIUFycmF5LmlzQXJyYXkoby5kYXRhKSkge1xuXHRcdFx0XHRvLmRhdGEgPSBbby5kYXRhXTtcblx0XHRcdH1cblxuXHRcdFx0by5kYXRhLmZvckVhY2goZm9ybWF0RnJpZW5kKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gbztcblx0fVxuXG5cdGZ1bmN0aW9uIGZvcm1hdEZyaWVuZChjb250YWN0KSB7XG5cdFx0Y29udGFjdC5pZCA9IG51bGw7XG5cblx0XHQvLyAjMzYyOiBSZXBvcnRzIG9mIHJlc3BvbnNlcyByZXR1cm5pbmcgYSBzaW5nbGUgaXRlbSwgcmF0aGVyIHRoYW4gYW4gQXJyYXkgb2YgaXRlbXMuXG5cdFx0Ly8gRm9ybWF0IHRoZSBjb250YWN0LmZpZWxkcyB0byBiZSBhbiBhcnJheS5cblx0XHRpZiAoY29udGFjdC5maWVsZHMgJiYgIShjb250YWN0LmZpZWxkcyBpbnN0YW5jZW9mIEFycmF5KSkge1xuXHRcdFx0Y29udGFjdC5maWVsZHMgPSBbY29udGFjdC5maWVsZHNdO1xuXHRcdH1cblxuXHRcdChjb250YWN0LmZpZWxkcyB8fCBbXSkuZm9yRWFjaChmdW5jdGlvbihmaWVsZCkge1xuXHRcdFx0aWYgKGZpZWxkLnR5cGUgPT09ICdlbWFpbCcpIHtcblx0XHRcdFx0Y29udGFjdC5lbWFpbCA9IGZpZWxkLnZhbHVlO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoZmllbGQudHlwZSA9PT0gJ25hbWUnKSB7XG5cdFx0XHRcdGNvbnRhY3QuZmlyc3RfbmFtZSA9IGZpZWxkLnZhbHVlLmdpdmVuTmFtZTtcblx0XHRcdFx0Y29udGFjdC5sYXN0X25hbWUgPSBmaWVsZC52YWx1ZS5mYW1pbHlOYW1lO1xuXHRcdFx0XHRjb250YWN0Lm5hbWUgPSBmaWVsZC52YWx1ZS5naXZlbk5hbWUgKyAnICcgKyBmaWVsZC52YWx1ZS5mYW1pbHlOYW1lO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoZmllbGQudHlwZSA9PT0gJ3lhaG9vaWQnKSB7XG5cdFx0XHRcdGNvbnRhY3QuaWQgPSBmaWVsZC52YWx1ZTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdGZ1bmN0aW9uIHBhZ2luZyhyZXMsIGhlYWRlcnMsIHJlcXVlc3QpIHtcblxuXHRcdC8vIFNlZTogaHR0cDovL2RldmVsb3Blci55YWhvby5jb20veXFsL2d1aWRlL3BhZ2luZy5odG1sI2xvY2FsX2xpbWl0c1xuXHRcdGlmIChyZXMucXVlcnkgJiYgcmVzLnF1ZXJ5LmNvdW50ICYmIHJlcXVlc3Qub3B0aW9ucykge1xuXHRcdFx0cmVzLnBhZ2luZyA9IHtcblx0XHRcdFx0bmV4dDogJz9zdGFydD0nICsgKHJlcy5xdWVyeS5jb3VudCArICgrcmVxdWVzdC5vcHRpb25zLnN0YXJ0IHx8IDEpKVxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRyZXR1cm4gcmVzO1xuXHR9XG5cblx0ZnVuY3Rpb24geXFsKHEpIHtcblx0XHRyZXR1cm4gJ2h0dHBzOi8vcXVlcnkueWFob29hcGlzLmNvbS92MS95cWw/cT0nICsgKHEgKyAnIGxpbWl0IEB7bGltaXR8MTAwfSBvZmZzZXQgQHtzdGFydHwwfScpLnJlcGxhY2UoL1xccy9nLCAnJTIwJykgKyAnJmZvcm1hdD1qc29uJztcblx0fVxuXG59KShoZWxsbyk7XG5cbi8vIFJlZ2lzdGVyIGFzIGFub255bW91cyBBTUQgbW9kdWxlXG5pZiAodHlwZW9mIGRlZmluZSA9PT0gJ2Z1bmN0aW9uJyAmJiBkZWZpbmUuYW1kKSB7XG5cdGRlZmluZShmdW5jdGlvbigpIHtcblx0XHRyZXR1cm4gaGVsbG87XG5cdH0pO1xufVxuXG4vLyBDb21tb25KUyBtb2R1bGUgZm9yIGJyb3dzZXJpZnlcbmlmICh0eXBlb2YgbW9kdWxlID09PSAnb2JqZWN0JyAmJiBtb2R1bGUuZXhwb3J0cykge1xuXHRtb2R1bGUuZXhwb3J0cyA9IGhlbGxvO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xudmFyIHRva2VuID0gJyVbYS1mMC05XXsyfSc7XG52YXIgc2luZ2xlTWF0Y2hlciA9IG5ldyBSZWdFeHAodG9rZW4sICdnaScpO1xudmFyIG11bHRpTWF0Y2hlciA9IG5ldyBSZWdFeHAoJygnICsgdG9rZW4gKyAnKSsnLCAnZ2knKTtcblxuZnVuY3Rpb24gZGVjb2RlQ29tcG9uZW50cyhjb21wb25lbnRzLCBzcGxpdCkge1xuXHR0cnkge1xuXHRcdC8vIFRyeSB0byBkZWNvZGUgdGhlIGVudGlyZSBzdHJpbmcgZmlyc3Rcblx0XHRyZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KGNvbXBvbmVudHMuam9pbignJykpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHQvLyBEbyBub3RoaW5nXG5cdH1cblxuXHRpZiAoY29tcG9uZW50cy5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4gY29tcG9uZW50cztcblx0fVxuXG5cdHNwbGl0ID0gc3BsaXQgfHwgMTtcblxuXHQvLyBTcGxpdCB0aGUgYXJyYXkgaW4gMiBwYXJ0c1xuXHR2YXIgbGVmdCA9IGNvbXBvbmVudHMuc2xpY2UoMCwgc3BsaXQpO1xuXHR2YXIgcmlnaHQgPSBjb21wb25lbnRzLnNsaWNlKHNwbGl0KTtcblxuXHRyZXR1cm4gQXJyYXkucHJvdG90eXBlLmNvbmNhdC5jYWxsKFtdLCBkZWNvZGVDb21wb25lbnRzKGxlZnQpLCBkZWNvZGVDb21wb25lbnRzKHJpZ2h0KSk7XG59XG5cbmZ1bmN0aW9uIGRlY29kZShpbnB1dCkge1xuXHR0cnkge1xuXHRcdHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoaW5wdXQpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHR2YXIgdG9rZW5zID0gaW5wdXQubWF0Y2goc2luZ2xlTWF0Y2hlcik7XG5cblx0XHRmb3IgKHZhciBpID0gMTsgaSA8IHRva2Vucy5sZW5ndGg7IGkrKykge1xuXHRcdFx0aW5wdXQgPSBkZWNvZGVDb21wb25lbnRzKHRva2VucywgaSkuam9pbignJyk7XG5cblx0XHRcdHRva2VucyA9IGlucHV0Lm1hdGNoKHNpbmdsZU1hdGNoZXIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBpbnB1dDtcblx0fVxufVxuXG5mdW5jdGlvbiBjdXN0b21EZWNvZGVVUklDb21wb25lbnQoaW5wdXQpIHtcblx0Ly8gS2VlcCB0cmFjayBvZiBhbGwgdGhlIHJlcGxhY2VtZW50cyBhbmQgcHJlZmlsbCB0aGUgbWFwIHdpdGggdGhlIGBCT01gXG5cdHZhciByZXBsYWNlTWFwID0ge1xuXHRcdCclRkUlRkYnOiAnXFx1RkZGRFxcdUZGRkQnLFxuXHRcdCclRkYlRkUnOiAnXFx1RkZGRFxcdUZGRkQnXG5cdH07XG5cblx0dmFyIG1hdGNoID0gbXVsdGlNYXRjaGVyLmV4ZWMoaW5wdXQpO1xuXHR3aGlsZSAobWF0Y2gpIHtcblx0XHR0cnkge1xuXHRcdFx0Ly8gRGVjb2RlIGFzIGJpZyBjaHVua3MgYXMgcG9zc2libGVcblx0XHRcdHJlcGxhY2VNYXBbbWF0Y2hbMF1dID0gZGVjb2RlVVJJQ29tcG9uZW50KG1hdGNoWzBdKTtcblx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdHZhciByZXN1bHQgPSBkZWNvZGUobWF0Y2hbMF0pO1xuXG5cdFx0XHRpZiAocmVzdWx0ICE9PSBtYXRjaFswXSkge1xuXHRcdFx0XHRyZXBsYWNlTWFwW21hdGNoWzBdXSA9IHJlc3VsdDtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRtYXRjaCA9IG11bHRpTWF0Y2hlci5leGVjKGlucHV0KTtcblx0fVxuXG5cdC8vIEFkZCBgJUMyYCBhdCB0aGUgZW5kIG9mIHRoZSBtYXAgdG8gbWFrZSBzdXJlIGl0IGRvZXMgbm90IHJlcGxhY2UgdGhlIGNvbWJpbmF0b3IgYmVmb3JlIGV2ZXJ5dGhpbmcgZWxzZVxuXHRyZXBsYWNlTWFwWyclQzInXSA9ICdcXHVGRkZEJztcblxuXHR2YXIgZW50cmllcyA9IE9iamVjdC5rZXlzKHJlcGxhY2VNYXApO1xuXG5cdGZvciAodmFyIGkgPSAwOyBpIDwgZW50cmllcy5sZW5ndGg7IGkrKykge1xuXHRcdC8vIFJlcGxhY2UgYWxsIGRlY29kZWQgY29tcG9uZW50c1xuXHRcdHZhciBrZXkgPSBlbnRyaWVzW2ldO1xuXHRcdGlucHV0ID0gaW5wdXQucmVwbGFjZShuZXcgUmVnRXhwKGtleSwgJ2cnKSwgcmVwbGFjZU1hcFtrZXldKTtcblx0fVxuXG5cdHJldHVybiBpbnB1dDtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAoZW5jb2RlZFVSSSkge1xuXHRpZiAodHlwZW9mIGVuY29kZWRVUkkgIT09ICdzdHJpbmcnKSB7XG5cdFx0dGhyb3cgbmV3IFR5cGVFcnJvcignRXhwZWN0ZWQgYGVuY29kZWRVUklgIHRvIGJlIG9mIHR5cGUgYHN0cmluZ2AsIGdvdCBgJyArIHR5cGVvZiBlbmNvZGVkVVJJICsgJ2AnKTtcblx0fVxuXG5cdHRyeSB7XG5cdFx0ZW5jb2RlZFVSSSA9IGVuY29kZWRVUkkucmVwbGFjZSgvXFwrL2csICcgJyk7XG5cblx0XHQvLyBUcnkgdGhlIGJ1aWx0IGluIGRlY29kZXIgZmlyc3Rcblx0XHRyZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KGVuY29kZWRVUkkpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHQvLyBGYWxsYmFjayB0byBhIG1vcmUgYWR2YW5jZWQgZGVjb2RlclxuXHRcdHJldHVybiBjdXN0b21EZWNvZGVVUklDb21wb25lbnQoZW5jb2RlZFVSSSk7XG5cdH1cbn07XG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUocmVzdWx0LnZhbHVlKTsgfSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xudmFyIF9faW1wb3J0RGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19pbXBvcnREZWZhdWx0KSB8fCBmdW5jdGlvbiAobW9kKSB7XG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgaGVsbG9qc18xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCJoZWxsb2pzXCIpKTtcbmxldCBjb25maWcgPSB7XG4gICAgc2NvcGU6ICd1c2VyLnJlYWQgZ3JvdXAucmVhZC5hbGwnLFxuICAgIG1zZnQ6IHtcbiAgICAgICAgaWQ6ICd5b3VyLWFwcC1pZCcsXG4gICAgICAgIG9hdXRoOiB7XG4gICAgICAgICAgICB2ZXJzaW9uOiAyLFxuICAgICAgICAgICAgYXV0aDogJ2h0dHBzOi8vbG9naW4ubWljcm9zb2Z0b25saW5lLmNvbS9jb21tb24vb2F1dGgyL3YyLjAvYXV0aG9yaXplJ1xuICAgICAgICB9LFxuICAgICAgICBzY29wZV9kZWxpbTogJyAnLFxuICAgICAgICBmb3JtOiBmYWxzZVxuICAgIH1cbn07XG5sZXQgaGVsbG9PYmogPSBudWxsO1xuZnVuY3Rpb24gc2V0SGVsbG8oaGVsbG8pIHtcbiAgICBoZWxsb09iaiA9IGhlbGxvO1xuICAgIGhlbGxvT2JqLmluaXQoe1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIG1zZnQ6IGNvbmZpZy5tc2Z0XG4gICAgfSwge1xuICAgICAgICByZWRpcmVjdF91cmk6IHdpbmRvdy5sb2NhdGlvbi5ocmVmXG4gICAgfSk7XG59XG5mdW5jdGlvbiBpbml0aWFsaXplKHBhcmFtcykge1xuICAgIGNvbmZpZy5zY29wZSA9IHBhcmFtcy5zY29wZSB8fCAndXNlci5yZWFkJztcbiAgICBpZiAoIXBhcmFtcy5hcHBJRCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2FwcElEIG11c3QgYmUgcGFzc2VkIGludG8gaW5pdGlhbGl6ZScpO1xuICAgIH1cbiAgICBjb25maWcubXNmdC5pZCA9IHBhcmFtcy5hcHBJRDtcbiAgICBzZXRIZWxsbyhoZWxsb2pzXzEuZGVmYXVsdCk7XG59XG5leHBvcnRzLmluaXRpYWxpemUgPSBpbml0aWFsaXplO1xuZnVuY3Rpb24gbG9nb3V0KCkge1xuICAgIGlmIChoZWxsb09iaikge1xuICAgICAgICByZXR1cm4gaGVsbG9PYmooJ21zZnQnKS5sb2dvdXQoeyBmb3JjZTogdHJ1ZSB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignYGluaXRpYWxpemVgIHdhcyBuZXZlciBjYWxsZWQnKTtcbiAgICB9XG59XG5leHBvcnRzLmxvZ291dCA9IGxvZ291dDtcbmZ1bmN0aW9uIGxvZ2luKCkge1xuICAgIGlmIChoZWxsb09iaikge1xuICAgICAgICByZXR1cm4gaGVsbG9PYmooJ21zZnQnKS5sb2dpbih7IHNjb3BlOiBjb25maWcuc2NvcGUgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2Bpbml0aWFsaXplYCB3YXMgbmV2ZXIgY2FsbGVkJyk7XG4gICAgfVxufVxuZXhwb3J0cy5sb2dpbiA9IGxvZ2luO1xuZnVuY3Rpb24gYWNjZXNzVG9rZW4oKSB7XG4gICAgaWYgKCFoZWxsb09iaikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0hhcyBpbml0aWFsaXplZCBiZWVuIGNhbGxlZD8gSGVsbG8gaXMgbnVsbC4nKTtcbiAgICB9XG4gICAgY29uc3QgbXNmdCA9IGhlbGxvT2JqKCdtc2Z0Jyk7XG4gICAgaWYgKCFtc2Z0KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignQ291bGQgbm90IGZpbmQgbXNmdCBvYmplY3QgaW4gaGVsbG8uICBIYXMgaGVsbG8gYmVlbiBpbml0aWFsaXplZD8nKTtcbiAgICB9XG4gICAgY29uc3QgYXV0aFJlc3BvbnNlID0gbXNmdC5nZXRBdXRoUmVzcG9uc2UoKTtcbiAgICBpZiAoIWF1dGhSZXNwb25zZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGF1dGggcmVzcG9uc2UgZm91bmQuICBIYXMgdXNlciBiZWVuIGF1dGhlbnRpY2F0ZWQ/Jyk7XG4gICAgfVxuICAgIGNvbnN0IHRva2VuID0gYXV0aFJlc3BvbnNlLmFjY2Vzc190b2tlbjtcbiAgICBpZiAoIXRva2VuKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignQWNjZXNzIHRva2VuIG5vdCBmb3VuZCBmb3IgbXNmdC4gIEhhcyB1c2VyIGJlZW4gYXV0aGVudGljYXRlZD8nKTtcbiAgICB9XG4gICAgcmV0dXJuIHRva2VuO1xufVxuZXhwb3J0cy5hY2Nlc3NUb2tlbiA9IGFjY2Vzc1Rva2VuO1xuZnVuY3Rpb24gbWFrZVJlcXVlc3QodXJsLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdSZXF1ZXN0aW5nJywgdXJsKTtcbiAgICAgICAgY29uc3QgeyByZXNwb25zZVR5cGUgPSAnanNvbicsIG1ldGhvZCA9ICdHRVQnLCBqc29uQm9keSA9IG51bGwgfSA9IG9wdGlvbnMgfHwge307XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRva2VuID0gYWNjZXNzVG9rZW4oKTtcbiAgICAgICAgICAgICAgICBjb25zdCByZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgICAgICAgICAgcmVxdWVzdC5vcGVuKG1ldGhvZCwgdXJsLCB0cnVlKTtcbiAgICAgICAgICAgICAgICByZXF1ZXN0LnJlc3BvbnNlVHlwZSA9IHJlc3BvbnNlVHlwZTtcbiAgICAgICAgICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoJ0F1dGhvcml6YXRpb24nLCBgQmVhcmVyICR7dG9rZW59YCk7XG4gICAgICAgICAgICAgICAgaWYgKGpzb25Cb2R5KSB7XG4gICAgICAgICAgICAgICAgICAgIHJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcignQ29udGVudC1UeXBlJywgJ2FwcGxpY2F0aW9uL2pzb24nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmVxdWVzdC5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0LnN0YXR1cyA+PSA0MDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChgRXJyb3IgJHtyZXF1ZXN0LnN0YXR1c31gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAocmVxdWVzdC5yZWFkeVN0YXRlID09IFhNTEh0dHBSZXF1ZXN0LkRPTkUgJiYgcmVxdWVzdC5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlcXVlc3QucmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBsZXQgYm9keSA9IG51bGw7XG4gICAgICAgICAgICAgICAgaWYgKGpzb25Cb2R5KSB7XG4gICAgICAgICAgICAgICAgICAgIGJvZHkgPSBKU09OLnN0cmluZ2lmeShqc29uQm9keSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJlcXVlc3Quc2VuZChib2R5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbmV4cG9ydHMubWFrZVJlcXVlc3QgPSBtYWtlUmVxdWVzdDtcbmZ1bmN0aW9uIGlzQXV0aGVudGljYXRlZCgpIHtcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAoIWhlbGxvT2JqKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ2hlbHBlcnMgaGFzIG5vdCBiZSBpbml0aWFsaXplZCcpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1zZnQgPSBoZWxsb09iaignbXNmdCcpO1xuICAgICAgICBpZiAoIW1zZnQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuaW5mbygnQ291bGQgbm90IGZpbmQgbXNmdCBvYmplY3QgaW4gaGVsbG8uICBIYXMgaGVsbG8gYmVlbiBpbml0aWFsaXplZD8nKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBhdXRoUmVzcG9uc2UgPSBtc2Z0LmdldEF1dGhSZXNwb25zZSgpO1xuICAgICAgICBpZiAoIWF1dGhSZXNwb25zZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRva2VuID0gYXV0aFJlc3BvbnNlLmFjY2Vzc190b2tlbjtcbiAgICAgICAgaWYgKCF0b2tlbikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBwcm9maWxlID0geWllbGQgbWFrZVJlcXVlc3QoJ2h0dHBzOi8vZ3JhcGgubWljcm9zb2Z0LmNvbS92MS4wL21lLycpO1xuICAgICAgICAgICAgcmV0dXJuICEhcHJvZmlsZVsnZGlzcGxheU5hbWUnXTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLy8gY29uc29sZS5lcnJvcignRXJyb3IgY2hlY2tpbmcgcHJvZmlsZSB0byBzZWUgaWYgbG9nZ2VkIGluLicsIGUpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbmV4cG9ydHMuaXNBdXRoZW50aWNhdGVkID0gaXNBdXRoZW50aWNhdGVkO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgVGhvdWdodFNlcnZpY2VTdHViXzEgPSByZXF1aXJlKFwiLi9UaG91Z2h0U2VydmljZVN0dWJcIik7XG5leHBvcnRzLlRob3VnaHRTZXJ2aWNlU3R1YiA9IFRob3VnaHRTZXJ2aWNlU3R1Yl8xLmRlZmF1bHQ7XG52YXIgU3BlZWNoU2VydmljZVN0dWJfMSA9IHJlcXVpcmUoXCIuL1NwZWVjaFNlcnZpY2VTdHViXCIpO1xuZXhwb3J0cy5TcGVlY2hTZXJ2aWNlU3R1YiA9IFNwZWVjaFNlcnZpY2VTdHViXzEuZGVmYXVsdDtcbnZhciBJbWFnZVNlcnZpY2VTdHViXzEgPSByZXF1aXJlKFwiLi9JbWFnZVNlcnZpY2VTdHViXCIpO1xuZXhwb3J0cy5JbWFnZVNlcnZpY2VTdHViID0gSW1hZ2VTZXJ2aWNlU3R1Yl8xLmRlZmF1bHQ7XG52YXIgU3lzdGVtU2VydmljZXNTdHViXzEgPSByZXF1aXJlKFwiLi9TeXN0ZW1TZXJ2aWNlc1N0dWJcIik7XG5leHBvcnRzLlN5c3RlbVNlcnZpY2VTdHViID0gU3lzdGVtU2VydmljZXNTdHViXzEuZGVmYXVsdDtcbnZhciBHcmFwaFNlcnZpY2VTdHViXzEgPSByZXF1aXJlKFwiLi9HcmFwaFNlcnZpY2VTdHViXCIpO1xuZXhwb3J0cy5HcmFwaFNlcnZpY2VTdHViID0gR3JhcGhTZXJ2aWNlU3R1Yl8xLmRlZmF1bHQ7XG52YXIgS2V5VmFsdWVTZXJ2aWNlU3R1Yl8xID0gcmVxdWlyZShcIi4vS2V5VmFsdWVTZXJ2aWNlU3R1YlwiKTtcbmV4cG9ydHMuS2V5VmFsdWVTZXJ2aWNlU3R1YiA9IEtleVZhbHVlU2VydmljZVN0dWJfMS5kZWZhdWx0O1xudmFyIEJ1dHRvblNlcnZpY2VTdHViXzEgPSByZXF1aXJlKFwiLi9CdXR0b25TZXJ2aWNlU3R1YlwiKTtcbmV4cG9ydHMuQnV0dG9uU2VydmljZVN0dWIgPSBCdXR0b25TZXJ2aWNlU3R1Yl8xLmRlZmF1bHQ7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNsYXNzIFRob3VnaHRTZXJ2aWNlU3R1YiB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMudGhvdWdodHMgPSBbeyBfaWQ6ICctMScsIHN1YmplY3Q6ICdCdXkgc29tZSBtaWxrJyB9LCB7IF9pZDogJy0yJywgc3ViamVjdDogJ0NyZWF0ZSBzbGlkZSBkZWNrJyB9XTtcbiAgICB9XG4gICAgc2V0QnVja2V0KGJ1Y2tldCkgeyB9XG4gICAgY3JlYXRlKHRob3VnaHQpIHtcbiAgICAgICAgdGhpcy50aG91Z2h0cy5wdXNoKHsgX2lkOiBgJHtuZXcgRGF0ZSgpfWAsIHN1YmplY3Q6IHRob3VnaHQuc3ViamVjdCB9KTtcbiAgICAgICAgaWYgKHRoaXMudGhvdWdodHNVcGRhdGVkQ2FsbGJhY2spIHtcbiAgICAgICAgICAgIHRoaXMudGhvdWdodHNVcGRhdGVkQ2FsbGJhY2sodGhpcy50aG91Z2h0cywgbnVsbCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0VXBkYXRlZENhbGxiYWNrKGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMudGhvdWdodHNVcGRhdGVkQ2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICAgICAgdGhpcy50aG91Z2h0c1VwZGF0ZWRDYWxsYmFjayh0aGlzLnRob3VnaHRzLCBudWxsKTtcbiAgICB9XG4gICAgZGVsZXRlKGlkKSB7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy50aG91Z2h0cy5maW5kSW5kZXgoKHRob3VnaHQpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0aG91Z2h0Ll9pZCA9PSBpZDtcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICAgICAgICB0aGlzLnRob3VnaHRzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5leHBvcnRzLmRlZmF1bHQgPSBUaG91Z2h0U2VydmljZVN0dWI7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNsYXNzIFN5c3RlbVNlcnZpY2VTdHViIHtcbiAgICBwZXJmb3JtSGFwdGljKHR5cGUpIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdQZXJmb3JtIGhhcHRpYzonLCB0eXBlKTtcbiAgICB9XG4gICAgdGFrZVNuYXBzaG90KCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIG9uU2hvd1N5c3RlbU1lbnUoY2FsbGJhY2spIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdTZXQgb25TaG93U3lzdGVtTWVudSBjYWxsYmFjaycpO1xuICAgIH1cbiAgICBwZXJmb3JtTmF2aWdhdGlvbihhcmdzKSB7IH1cbiAgICBzZXRXaW5kb3dTZXR0aW5ncyhhcmdzKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgZ2V0V2luZG93U2V0dGluZ3MoYXJncykge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHt9KTtcbiAgICB9XG4gICAgc2V0VGl0bGUoYXJncykge1xuICAgICAgICBpZiAoYXJncy50aXRsZSkge1xuICAgICAgICAgICAgZG9jdW1lbnQudGl0bGUgPSBhcmdzLnRpdGxlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgZ2V0TG9jYXRpb24oYXJncykge1xuICAgICAgICBpZiAoIW5hdmlnYXRvci5nZW9sb2NhdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KCdCcm93c2VyIGRvZXMgbm90IHN1cHBvcnQgbG9jYXRpb24nKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgbmF2aWdhdG9yLmdlb2xvY2F0aW9uLmdldEN1cnJlbnRQb3NpdGlvbigobG9jYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWxvY2F0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdCgnQ291bGQgbm90IGdldCBsb2NhdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb29yZGluYXRlOiB7IGxhdGl0dWRlOiBsb2NhdGlvbi5jb29yZHMubGF0aXR1ZGUsIGxvbmdpdHVkZTogbG9jYXRpb24uY29vcmRzLmxvbmdpdHVkZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBsb2NhdGlvbi50aW1lc3RhbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICBob3Jpem9udGFsQWNjdXJhY3k6IGxvY2F0aW9uLmNvb3Jkcy5hY2N1cmFjeSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNwZWVkOiBsb2NhdGlvbi5jb29yZHMuc3BlZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2U6IGxvY2F0aW9uLmNvb3Jkcy5oZWFkaW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWx0aXR1ZGU6IGxvY2F0aW9uLmNvb3Jkcy5hbHRpdHVkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZlcnRpY2FsQWNjdXJhY3k6IGxvY2F0aW9uLmNvb3Jkcy5hbHRpdHVkZUFjY3VyYWN5LFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0cy5kZWZhdWx0ID0gU3lzdGVtU2VydmljZVN0dWI7XG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUocmVzdWx0LnZhbHVlKTsgfSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgaGVscGVyc18xID0gcmVxdWlyZShcIi4uL2hlbHBlcnNcIik7XG5jbGFzcyBTcGVlY2hTZXJ2aWNlU3R1YiB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuaW5wdXRMZXZlbENhbGxiYWNrcyA9IG5ldyBNYXAoKTtcbiAgICAgICAgdGhpcy5zcGVlY2hSdW5uaW5nID0gZmFsc2U7XG4gICAgfVxuICAgIGlzUnVubmluZygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3BlZWNoUnVubmluZztcbiAgICB9XG4gICAgdG9nZ2xlUnVubmluZyhjYWxsYmFjaykge1xuICAgICAgICB0aGlzLnNwZWVjaENhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICAgIHRoaXMuc3BlZWNoUnVubmluZyA9ICF0aGlzLnNwZWVjaFJ1bm5pbmc7XG4gICAgICAgIGlmICh0aGlzLnNwZWVjaElzUnVubmluZ0NhbGxiYWNrKSB7XG4gICAgICAgICAgICB0aGlzLnNwZWVjaElzUnVubmluZ0NhbGxiYWNrKHRoaXMuc3BlZWNoUnVubmluZyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc3BlZWNoUnVubmluZykge1xuICAgICAgICAgICAgdGhpcy5mZXRjaFRleHQoKTtcbiAgICAgICAgICAgIHRoaXMuc3RhcnRUaW1lcigpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zdG9wVGltZXIoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIHNldElzUnVubmluZ0NhbGxiYWNrKGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMuc3BlZWNoSXNSdW5uaW5nQ2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICB9XG4gICAgc2V0T25SZXN1bHRzQ2FsbGJhY2soY2FsbGJhY2spIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdzZXRPblJlc3VsdHNDYWxsYmFjayBpcyBjdXJyZW50bHkgc3R1YmJlZCcpO1xuICAgICAgICByZXR1cm4gaGVscGVyc18xLmdlbmVyYXRlVVVJRCgpO1xuICAgIH1cbiAgICByZW1vdmVPblJlc3VsdHNDYWxsYmFjayh0b2tlbikge1xuICAgICAgICBjb25zb2xlLmluZm8oJ3JlbW92ZU9uUmVzdWx0c0NhbGxiYWNrIGlzIGN1cnJlbnRseSBzdHViYmVkJyk7XG4gICAgfVxuICAgIGZldGNoVGV4dCgpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5zcGVlY2hSdW5uaW5nKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBmZXRjaCgnaHR0cHM6Ly93d3cucmFuZG9tdGV4dC5tZS9hcGkvZ2liYmVyaXNoL3AtMS8zLTE3Jyk7XG4gICAgICAgICAgICAgICAgY29uc3QganNvbiA9IHlpZWxkIHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgICAgICAgICBjb25zdCB0ZXh0V2l0aFAgPSBqc29uLnRleHRfb3V0O1xuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUuaW5mbygnVGV4dCBSZXNwb25zZTonLCBqc29uLCB0ZXh0V2l0aFApXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuc3BlZWNoQ2FsbGJhY2sgJiYgdGV4dFdpdGhQKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNsZWFuVGV4dCA9IHRleHRXaXRoUFxuICAgICAgICAgICAgICAgICAgICAgICAgLnRyaW0oKVxuICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoJzxwPicsICcnKVxuICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoJzwvcD4nLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3BlZWNoQ2FsbGJhY2soY2xlYW5UZXh0LCBudWxsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5zcGVlY2hDYWxsYmFjaykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNwZWVjaENhbGxiYWNrKG51bGwsIGVycm9yKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBzZXRJbnB1dExldmVsQ2FsbGJhY2soY2FsbGJhY2spIHtcbiAgICAgICAgY29uc3QgdXVpZCA9IGhlbHBlcnNfMS5nZW5lcmF0ZVVVSUQoKTtcbiAgICAgICAgdGhpcy5pbnB1dExldmVsQ2FsbGJhY2tzLnNldCh1dWlkLCBjYWxsYmFjayk7XG4gICAgICAgIGNvbnNvbGUuaW5mbygnQWRkZWQgaW5wdXRMZXZlbCBjYWxsYmFjay4gVG9rZW46JywgdXVpZCk7XG4gICAgICAgIHJldHVybiB1dWlkO1xuICAgIH1cbiAgICByZW1vdmVJbnB1dExldmVsQ2FsYmFjayh0b2tlbikge1xuICAgICAgICBjb25zb2xlLmluZm8oJ1JlbW92ZWQgaW5wdXRMZXZlbCBjYWxsYmFjay4gVG9rZW46JywgdG9rZW4pO1xuICAgICAgICB0aGlzLmlucHV0TGV2ZWxDYWxsYmFja3MuZGVsZXRlKHRva2VuKTtcbiAgICB9XG4gICAgc3RhcnRUaW1lcigpIHtcbiAgICAgICAgaWYgKHRoaXMuaW50ZXJ2YWxUb2tlbikge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaW50ZXJ2YWxUb2tlbiA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgICAgIGxldCBwZXJjZW50ID0gTWF0aC5yYW5kb20oKTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMZXZlbENhbGxiYWNrcy5mb3JFYWNoKChjYWxsYmFjaykgPT4ge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKHBlcmNlbnQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sIDEwMCk7XG4gICAgfVxuICAgIHN0b3BUaW1lcigpIHtcbiAgICAgICAgaWYgKCF0aGlzLmludGVydmFsVG9rZW4pIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWxUb2tlbik7XG4gICAgICAgIHRoaXMuaW50ZXJ2YWxUb2tlbiA9IHVuZGVmaW5lZDtcbiAgICB9XG59XG5leHBvcnRzLmRlZmF1bHQgPSBTcGVlY2hTZXJ2aWNlU3R1YjtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgaGVscGVyc18xID0gcmVxdWlyZShcIi4uL2hlbHBlcnNcIik7XG5jbGFzcyBLZXlWYWx1ZVNlcnZpY2VTdHViIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5faXNDb25uZWN0ZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tZXNzYWdlQ2FsbGJhY2tzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmlzQ29ubmVjdGVkQ2FsbGJhY2tzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmRlZmVycmVkUHJvbWlzZXMgPSBuZXcgTWFwKCk7XG4gICAgfVxuICAgIGlzQ29ubmVjdGVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5faXNDb25uZWN0ZWQ7XG4gICAgfVxuICAgIHNldE9uTWVzc2FnZUNhbGxiYWNrKGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMuc2V0dXBTb2NrZXQoKTtcbiAgICAgICAgY29uc3QgdXVpZCA9IGhlbHBlcnNfMS5nZW5lcmF0ZVVVSUQoKTtcbiAgICAgICAgdGhpcy5tZXNzYWdlQ2FsbGJhY2tzLnNldCh1dWlkLCBjYWxsYmFjayk7XG4gICAgICAgIGNvbnNvbGUuaW5mbygnQWRkZWQgS2V5VmFsdWUgY2FsbGJhY2suIFRva2VuOicsIHV1aWQpO1xuICAgICAgICByZXR1cm4gdXVpZDtcbiAgICB9XG4gICAgcmVtb3ZlT25NZXNzYWdlQ2FsbGJhY2sodG9rZW4pIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdSZW1vdmVkIE9uIE1lc3NhZ2UgQ2FsbGJhY2suICBUb2tlbjonLCB0b2tlbik7XG4gICAgICAgIHRoaXMubWVzc2FnZUNhbGxiYWNrcy5kZWxldGUodG9rZW4pO1xuICAgIH1cbiAgICBzZXRJc0Nvbm5lY3RlZENoYW5nZWRDYWxsYmFjayhjYWxsYmFjaykge1xuICAgICAgICBjb25zdCB1dWlkID0gaGVscGVyc18xLmdlbmVyYXRlVVVJRCgpO1xuICAgICAgICB0aGlzLmlzQ29ubmVjdGVkQ2FsbGJhY2tzLnNldCh1dWlkLCBjYWxsYmFjayk7XG4gICAgICAgIGNvbnNvbGUuaW5mbygnQWRkZWQgaXNDb25uZWN0ZWQgY2FsbGJhY2suIFRva2VuOicsIHV1aWQpO1xuICAgICAgICByZXR1cm4gdXVpZDtcbiAgICB9XG4gICAgcmVtb3ZlSXNDb25uZWN0ZWRDaGFuZ2VkQ2FsbGJhY2sodG9rZW4pIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdSZW1vdmVkIGlzQ29ubmVjdGVkIGNhbGxiYWNrLiBUb2tlbjonLCB0b2tlbik7XG4gICAgICAgIHRoaXMuaXNDb25uZWN0ZWRDYWxsYmFja3MuZGVsZXRlKHRva2VuKTtcbiAgICB9XG4gICAgc2V0S2V5KGtleSwgdmFsdWUpIHtcbiAgICAgICAgY29uc29sZS5pbmZvKCdzZXQga2V5Jywga2V5LCB2YWx1ZSk7XG4gICAgICAgIGNvbnN0IG1zZyA9IHsgXCJ0eXBlXCI6IFwic2V0S2V5XCIsIHZhbHVlOiB7IGtleSwgdmFsdWUgfSB9O1xuICAgICAgICBjb25zdCBzdHIgPSBKU09OLnN0cmluZ2lmeShtc2cpO1xuICAgICAgICBpZiAodGhpcy5zb2NrZXQpIHtcbiAgICAgICAgICAgIHRoaXMuc29ja2V0LnNlbmQoc3RyKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBkZWxldGVLZXkoa2V5KSB7XG4gICAgICAgIGNvbnN0IG1zZyA9IHsgXCJ0eXBlXCI6IFwiZGVsZXRlS2V5XCIsIHZhbHVlOiBrZXkgfTtcbiAgICAgICAgY29uc3Qgc3RyID0gSlNPTi5zdHJpbmdpZnkobXNnKTtcbiAgICAgICAgaWYgKHRoaXMuc29ja2V0KSB7XG4gICAgICAgICAgICB0aGlzLnNvY2tldC5zZW5kKHN0cik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmVxdWVzdEtleShrZXkpIHtcbiAgICAgICAgdGhpcy5zZXR1cFNvY2tldCgpO1xuICAgICAgICAvKlxuICAgICAgICBcInR5cGVcIjogXCJyZXF1ZXN0S2V5XCIsXG4gICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBrZXksXG4gICAgICAgICAgICAgICAgXCJyZXF1ZXN0SURcIjogcmVxdWVzdElEXG4gICAgICAgICAgICAgICAgKi9cbiAgICAgICAgY29uc3QgdXVpZCA9IGhlbHBlcnNfMS5nZW5lcmF0ZVVVSUQoKTtcbiAgICAgICAgY29uc3QgbXNnID0ge1xuICAgICAgICAgICAgXCJ0eXBlXCI6IFwicmVxdWVzdEtleVwiLFxuICAgICAgICAgICAgXCJ2YWx1ZVwiOiBrZXksXG4gICAgICAgICAgICBcInJlcXVlc3RJRFwiOiB1dWlkXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHN0ciA9IEpTT04uc3RyaW5naWZ5KG1zZyk7XG4gICAgICAgIGNvbnN0IGRlZmVycmVkID0gbmV3IERlZmVycmVkKCk7XG4gICAgICAgIHRoaXMuZGVmZXJyZWRQcm9taXNlcy5zZXQodXVpZCwgZGVmZXJyZWQpO1xuICAgICAgICBpZiAodGhpcy5zb2NrZXQpIHtcbiAgICAgICAgICAgIHRoaXMuc29ja2V0LnNlbmQoc3RyKTtcbiAgICAgICAgICAgIHJldHVybiBkZWZlcnJlZC5wcm9taXNlO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KCdTb2NrZXQgbm90IHNldCB1cCcpO1xuICAgICAgICB9XG4gICAgfVxuICAgIG9uTWVzc2FnZShldikge1xuICAgICAgICAvLyBjb25zb2xlLmluZm8oJ0V2ZW50IGNvbWluZyBpbiAtJywgdHlwZW9mIGV2LmRhdGEpXG4gICAgICAgIGNvbnN0IHN0ciA9IGV2LmRhdGE7XG4gICAgICAgIGlmIChzdHIpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbXNnID0gSlNPTi5wYXJzZShldi5kYXRhKTtcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZUpTTWVzc2FnZShtc2cpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQ291bGQgbm90IHBhcnNlIHNlcnZlciBtZXNzYWdlXCIsIGV2LmRhdGEsIGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdkYXRhIHJldHVybmVkIGZyb20gbWVzc2FnZSBpcyBub3QgYSBzdHJpbmcnLCB0eXBlb2YgZXYuZGF0YSwgZXYuZGF0YSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaGFuZGxlSlNNZXNzYWdlKG1zZykge1xuICAgICAgICBpZiAobXNnLnJlcXVlc3RJRCkge1xuICAgICAgICAgICAgY29uc3QgZGVmZXJyZWQgPSB0aGlzLmRlZmVycmVkUHJvbWlzZXMuZ2V0KG1zZy5yZXF1ZXN0SUQpO1xuICAgICAgICAgICAgdGhpcy5kZWZlcnJlZFByb21pc2VzLmRlbGV0ZShtc2cucmVxdWVzdElEKTtcbiAgICAgICAgICAgIGlmIChkZWZlcnJlZCAmJiBkZWZlcnJlZC5yZXNvbHZlICYmIG1zZy52YWx1ZSkge1xuICAgICAgICAgICAgICAgIGRlZmVycmVkLnJlc29sdmUobXNnLnZhbHVlKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5tZXNzYWdlQ2FsbGJhY2tzLmZvckVhY2goY2FsbGJhY2sgPT4ge1xuICAgICAgICAgICAgY2FsbGJhY2sobXNnKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHVwZGF0ZUlzQ29ubmVjdGVkKGNvbm5lY3RlZCkge1xuICAgICAgICB0aGlzLl9pc0Nvbm5lY3RlZCA9IGNvbm5lY3RlZDtcbiAgICAgICAgdGhpcy5pc0Nvbm5lY3RlZENhbGxiYWNrcy5mb3JFYWNoKGNhbGxiYWNrID0+IHtcbiAgICAgICAgICAgIGNhbGxiYWNrKHRoaXMuX2lzQ29ubmVjdGVkKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHNldHVwU29ja2V0KCkge1xuICAgICAgICBpZiAodGhpcy5zb2NrZXQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmluZm8oJ2Nvbm5lY3RpbmcgdG8gc29ja2V0Jyk7XG4gICAgICAgIC8vIGNvbnN0IFVSTCA9IFwid3NzOi8vbG9va291dC5uZ3Jvay5pby9zb2NrZXQvc2lmdFwiXG4gICAgICAgIGNvbnN0IFVSTCA9IFwid3NzOi8vbG9va291dC1wcm90by5henVyZXdlYnNpdGVzLm5ldC9zb2NrZXQvc2lmdFwiO1xuICAgICAgICB0aGlzLnNvY2tldCA9IG5ldyBXZWJTb2NrZXQoVVJMKTtcbiAgICAgICAgdGhpcy5zb2NrZXQub25tZXNzYWdlID0gKGUpID0+IHtcbiAgICAgICAgICAgIHRoaXMub25NZXNzYWdlKGUpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNvY2tldC5vbm9wZW4gPSAoZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5pbmZvKCdjb25uZWN0aW9uIG9wZW5lZCB0bycsIFVSTCwgZSk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZUlzQ29ubmVjdGVkKHRydWUpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNvY2tldC5vbmNsb3NlID0gKGUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUuaW5mbygnY29ubmVjdGlvbiBjbG9zZWQnLCBlKTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlSXNDb25uZWN0ZWQoZmFsc2UpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNvY2tldC5vbmVycm9yID0gKGUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ2Nvbm5lY3Rpb24gZXJyb3InLCBlKTtcbiAgICAgICAgfTtcbiAgICB9XG59XG5leHBvcnRzLmRlZmF1bHQgPSBLZXlWYWx1ZVNlcnZpY2VTdHViO1xuY2xhc3MgRGVmZXJyZWQge1xuICAgIGNvbnN0cnVjdG9yKGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHRoaXMucmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgICAgICAgICB0aGlzLnJlamVjdCA9IHJlamVjdDtcbiAgICAgICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY2xhc3MgSW1hZ2VTZXJ2aWNlU3R1YiB7XG4gICAgY2FwdHVyZShhcmdzKSB7XG4gICAgICAgIHJldHVybiBpbWFnZVRvRGF0YVVSTCgnaHR0cHM6Ly9waWNzdW0ucGhvdG9zLzIwMC8zMDAvP3JhbmRvbScpO1xuICAgIH1cbn1cbmV4cG9ydHMuZGVmYXVsdCA9IEltYWdlU2VydmljZVN0dWI7XG4vLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMjAyODUwNTMvMzk2NVxuZnVuY3Rpb24gaW1hZ2VUb0RhdGFVUkwodXJsKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgY29uc3QgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHhoci5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgICAgICAgICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHJlYWRlci5yZXN1bHQpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKHhoci5yZXNwb25zZSk7XG4gICAgICAgIH07XG4gICAgICAgIHhoci5vbmVycm9yID0gKGV2KSA9PiB7XG4gICAgICAgICAgICByZWplY3QoYFRoZXJlIHdhcyBhbiBlcnJvciBnZXR0aW5nIHRoZSBibG9iICR7ZXZ9YCk7XG4gICAgICAgIH07XG4gICAgICAgIHhoci5vcGVuKCdHRVQnLCB1cmwpO1xuICAgICAgICB4aHIucmVzcG9uc2VUeXBlID0gJ2Jsb2InO1xuICAgICAgICB4aHIuc2VuZCgpO1xuICAgIH0pO1xufVxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jbGFzcyBHcmFwaFNlcnZpY2VTdHViIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5sb2dnZWRJbiA9IGZhbHNlO1xuICAgIH1cbiAgICBpc0xvZ2dlZEluKCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMubG9nZ2VkSW4pO1xuICAgIH1cbiAgICB1cGRhdGVTY29wZShzY29wZSkgeyB9XG4gICAgbG9naW4oKSB7XG4gICAgICAgIHRoaXMubG9nZ2VkSW4gPSB0cnVlO1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIGxvZ291dCgpIHtcbiAgICAgICAgdGhpcy5sb2dnZWRJbiA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIGdldCh1cmwpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgICBcIkBvZGF0YS5jb250ZXh0XCI6IFwiaHR0cHM6Ly9ncmFwaC5taWNyb3NvZnQuY29tL3YxLjAvJG1ldGFkYXRhI3VzZXJzLyRlbnRpdHlcIixcbiAgICAgICAgICAgIFwiYnVzaW5lc3NQaG9uZXNcIjogW1xuICAgICAgICAgICAgICAgIFwiKzEgNDEyIDU1NSAwMTA5XCJcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBcImRpc3BsYXlOYW1lXCI6IFwiTWVnYW4gQm93ZW5cIixcbiAgICAgICAgICAgIFwiZ2l2ZW5OYW1lXCI6IFwiTWVnYW5cIixcbiAgICAgICAgICAgIFwiam9iVGl0bGVcIjogXCJBdWRpdG9yXCIsXG4gICAgICAgICAgICBcIm1haWxcIjogXCJNZWdhbkJATTM2NXgyMTQzNTUub25taWNyb3NvZnQuY29tXCIsXG4gICAgICAgICAgICBcIm1vYmlsZVBob25lXCI6IG51bGwsXG4gICAgICAgICAgICBcIm9mZmljZUxvY2F0aW9uXCI6IFwiMTIvMTExMFwiLFxuICAgICAgICAgICAgXCJwcmVmZXJyZWRMYW5ndWFnZVwiOiBcImVuLVVTXCIsXG4gICAgICAgICAgICBcInN1cm5hbWVcIjogXCJCb3dlblwiLFxuICAgICAgICAgICAgXCJ1c2VyUHJpbmNpcGFsTmFtZVwiOiBcIk1lZ2FuQkBNMzY1eDIxNDM1NS5vbm1pY3Jvc29mdC5jb21cIixcbiAgICAgICAgICAgIFwiaWRcIjogXCI0OGQzMTg4Ny01ZmFkLTRkNzMtYTlmNS0zYzM1NmU2OGEwMzhcIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgZ2V0QWNjZXNzVG9rZW4oKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoeyBhY2Nlc3NUb2tlbjogJ3RoaXMgaXMgZmFrZScgfSk7XG4gICAgfVxufVxuZXhwb3J0cy5kZWZhdWx0ID0gR3JhcGhTZXJ2aWNlU3R1YjtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY2xhc3MgQnV0dG9uU2VydmljZVN0dWIge1xuICAgIGFkZChhcmdzKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgbG9hZChhcmdzKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgbW92ZShhcmdzKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgcmVtb3ZlKGFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbn1cbmV4cG9ydHMuZGVmYXVsdCA9IEJ1dHRvblNlcnZpY2VTdHViO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX2ltcG9ydERlZmF1bHQgPSAodGhpcyAmJiB0aGlzLl9faW1wb3J0RGVmYXVsdCkgfHwgZnVuY3Rpb24gKG1vZCkge1xuICAgIHJldHVybiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSA/IG1vZCA6IHsgXCJkZWZhdWx0XCI6IG1vZCB9O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vIGRldGVybWluZSBpZiB3aW5kb3cuRkwgZXhpc3RzXG4vLyBpZiBpdCBkb2VzIHVzZSB0aGUgZ3JhcGggQVBJIG9uIGl0XG4vLyBpZiBpdCBkb2Vzbid0LCB1c2UgdGhlIGhlbGxvLmpzIGxpYlxuLy9cbi8vIGNyZWF0ZSBnZXQgZm9yIHRoZSBmZWVkXG4vLyBjcmVhdGUgZ2V0IGZvciBhbiBpbWFnZSBiYXNlIDY0XG5jb25zdCBxdWVyeV9zdHJpbmdfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwicXVlcnktc3RyaW5nXCIpKTtcbmNvbnN0IGhlbHBlcnNfMSA9IHJlcXVpcmUoXCIuL2hlbHBlcnNcIik7XG5jb25zdCBoZWxwZXIgPSAhIXdpbmRvd1snRkwnXSA/IG5ldyBoZWxwZXJzXzEuRkxHcmFwaCgpIDogbmV3IGhlbHBlcnNfMS5XZWJHcmFwaCgpO1xuY29uc3QgQkFTRV9VUkwgPSAnaHR0cHM6Ly9sb29rb3V0LXByb3RvLmF6dXJld2Vic2l0ZXMubmV0Jztcbi8vIGNvbnN0IEJBU0VfVVJMID0gJ2h0dHBzOi8vbG9va291dC5uZ3Jvay5pbydcbmZ1bmN0aW9uIGluaXRpYWxpemUoKSB7XG4gICAgcmV0dXJuIGhlbHBlci5pbml0aWFsaXplKCk7XG59XG5leHBvcnRzLmluaXRpYWxpemUgPSBpbml0aWFsaXplO1xuZnVuY3Rpb24gaXNMb2dnZWRJbigpIHtcbiAgICByZXR1cm4gaGVscGVyLmlzTG9nZ2VkSW4oKTtcbn1cbmV4cG9ydHMuaXNMb2dnZWRJbiA9IGlzTG9nZ2VkSW47XG5mdW5jdGlvbiBsb2dJbigpIHtcbiAgICByZXR1cm4gaGVscGVyLmxvZ0luKCk7XG59XG5leHBvcnRzLmxvZ0luID0gbG9nSW47XG5mdW5jdGlvbiBsb2dPdXQoKSB7XG4gICAgcmV0dXJuIGhlbHBlci5sb2dPdXQoKTtcbn1cbmV4cG9ydHMubG9nT3V0ID0gbG9nT3V0O1xuZnVuY3Rpb24gYWNjZXNzVG9rZW4oKSB7XG4gICAgcmV0dXJuIGhlbHBlci5hY2Nlc3NUb2tlbigpO1xufVxuZXhwb3J0cy5hY2Nlc3NUb2tlbiA9IGFjY2Vzc1Rva2VuO1xuZnVuY3Rpb24ganNvbkFjY2VwdEhlYWRlcigpIHtcbiAgICByZXR1cm4geyBuYW1lOiAnQWNjZXB0JywgdmFsdWU6ICdhcHBsaWNhdGlvbi9qc29uJyB9O1xufVxuZnVuY3Rpb24gZmVlZChhcmdzKSB7XG4gICAgY29uc3QgcGF0aCA9ICcvdXNlcnMvbWUvZmVlZCc7XG4gICAgbGV0IGJhc2VVUkwgPSBCQVNFX1VSTDtcbiAgICBhcmdzID0gYXJncyB8fCB7fTtcbiAgICBpZiAoYXJncy5iYXNlVVJMKSB7XG4gICAgICAgIGJhc2VVUkwgPSBhcmdzLmJhc2VVUkw7XG4gICAgICAgIGRlbGV0ZSBhcmdzLmJhc2VVUkw7XG4gICAgfVxuICAgIGNvbnN0IHRpbWVab25lT2Zmc2V0ID0gbmV3IERhdGUoKS5nZXRUaW1lem9uZU9mZnNldCgpIC8gLTYwO1xuICAgIGlmICghYXJncy50aW1lWm9uZU9mZnNldCkge1xuICAgICAgICBhcmdzLnRpbWVab25lT2Zmc2V0ID0gdGltZVpvbmVPZmZzZXQ7XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IGJhc2VVUkwgKyBwYXRoO1xuICAgIHJldHVybiBtYWtlUmVxdWVzdCh1cmwsIHsgcXM6IGFyZ3MsIGhlYWRlcnM6IFtqc29uQWNjZXB0SGVhZGVyKCldIH0pO1xufVxuZXhwb3J0cy5mZWVkID0gZmVlZDtcbmZ1bmN0aW9uIHByaW9yaXR5Q29udGFjdHMoYXJncykge1xuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSAnL3VzZXJzL21lL3ByaW9yaXR5Q29udGFjdHMnO1xuICAgICAgICBsZXQgYmFzZVVSTCA9IEJBU0VfVVJMO1xuICAgICAgICBpZiAoYXJncyAmJiBhcmdzLmJhc2VVUkwpIHtcbiAgICAgICAgICAgIGJhc2VVUkwgPSBhcmdzLmJhc2VVUkw7XG4gICAgICAgICAgICBkZWxldGUgYXJncy5iYXNlVVJMO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVybCA9IGJhc2VVUkwgKyBwYXRoO1xuICAgICAgICByZXR1cm4gbWFrZVJlcXVlc3QodXJsLCB7IGhlYWRlcnM6IFtqc29uQWNjZXB0SGVhZGVyKCldIH0pO1xuICAgIH0pO1xufVxuZXhwb3J0cy5wcmlvcml0eUNvbnRhY3RzID0gcHJpb3JpdHlDb250YWN0cztcbmZ1bmN0aW9uIGNyZWF0ZVByaW9yaXR5Q29udGFjdChhcmdzKSB7XG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgY29uc3QgcGF0aCA9ICcvdXNlcnMvbWUvcHJpb3JpdHlDb250YWN0cyc7XG4gICAgICAgIGxldCBiYXNlVVJMID0gQkFTRV9VUkw7XG4gICAgICAgIGFyZ3MgPSBhcmdzIHx8IHt9O1xuICAgICAgICBpZiAoYXJncy5iYXNlVVJMKSB7XG4gICAgICAgICAgICBiYXNlVVJMID0gYXJncy5iYXNlVVJMO1xuICAgICAgICAgICAgZGVsZXRlIGFyZ3MuYmFzZVVSTDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYXlsb2FkID0geyBlbWFpbDogYXJncy5lbWFpbCB9O1xuICAgICAgICBjb25zdCB1cmwgPSBiYXNlVVJMICsgcGF0aDtcbiAgICAgICAgcmV0dXJuIG1ha2VSZXF1ZXN0KHVybCwgeyBtZXRob2Q6ICdQT1NUJywganNvbkJvZHk6IHBheWxvYWQsIGhlYWRlcnM6IFtqc29uQWNjZXB0SGVhZGVyKCldIH0pO1xuICAgIH0pO1xufVxuZXhwb3J0cy5jcmVhdGVQcmlvcml0eUNvbnRhY3QgPSBjcmVhdGVQcmlvcml0eUNvbnRhY3Q7XG5mdW5jdGlvbiBkZWxldGVQcmlvcml0eUNvbnRhY3QoYXJncykge1xuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGxldCBiYXNlVVJMID0gQkFTRV9VUkw7XG4gICAgICAgIGFyZ3MgPSBhcmdzIHx8IHt9O1xuICAgICAgICBpZiAoIWFyZ3MuZW1haWwpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignZW1haWwgaXMgcmVxdWlyZWQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYXRoID0gYC91c2Vycy9tZS9wcmlvcml0eUNvbnRhY3RzLyR7YXJncy5lbWFpbH1gO1xuICAgICAgICBpZiAoYXJncy5iYXNlVVJMKSB7XG4gICAgICAgICAgICBiYXNlVVJMID0gYXJncy5iYXNlVVJMO1xuICAgICAgICAgICAgZGVsZXRlIGFyZ3MuYmFzZVVSTDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cmwgPSBiYXNlVVJMICsgcGF0aDtcbiAgICAgICAgcmV0dXJuIG1ha2VSZXF1ZXN0KHVybCwgeyBtZXRob2Q6ICdERUxFVEUnLCBoZWFkZXJzOiBbanNvbkFjY2VwdEhlYWRlcigpXSB9KTtcbiAgICB9KTtcbn1cbmV4cG9ydHMuZGVsZXRlUHJpb3JpdHlDb250YWN0ID0gZGVsZXRlUHJpb3JpdHlDb250YWN0O1xuZnVuY3Rpb24gZmV0Y2hHcmFwaEltYWdlKHVybCkge1xuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHlpZWxkIG1ha2VSZXF1ZXN0KHVybCwgeyByZXNwb25zZVR5cGU6ICdibG9iJyB9KTtcbiAgICAgICAgLy8gY29uc29sZS5pbmZvKCdHb3QgcmVzdWx0JywgcmVzdWx0KVxuICAgICAgICBjb25zdCB3VVJMID0gd2luZG93LlVSTDtcbiAgICAgICAgY29uc3QgYmxvYlVybCA9IHdVUkwuY3JlYXRlT2JqZWN0VVJMKHJlc3VsdCk7XG4gICAgICAgIHJldHVybiBibG9iVXJsO1xuICAgIH0pO1xufVxuZXhwb3J0cy5mZXRjaEdyYXBoSW1hZ2UgPSBmZXRjaEdyYXBoSW1hZ2U7XG5mdW5jdGlvbiBtYWtlUmVxdWVzdCh1cmwsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBjb25zb2xlLmluZm8oJ1JlcXVlc3RpbmcnLCB1cmwpO1xuICAgICAgICBjb25zdCB7IHJlc3BvbnNlVHlwZSA9ICdqc29uJywgbWV0aG9kID0gJ0dFVCcsIGpzb25Cb2R5ID0gbnVsbCwgcXMgPSB7fSwgaGVhZGVycyA9IFtdIH0gPSBvcHRpb25zIHx8IHt9O1xuICAgICAgICBjb25zdCB0b2tlbiA9IHlpZWxkIGFjY2Vzc1Rva2VuKCk7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChxcykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IHF1ZXJ5X3N0cmluZ18xLmRlZmF1bHQuc3RyaW5naWZ5KHFzKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSB1cmwgKyAnPycgKyB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgcmVxdWVzdCA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICAgICAgICAgIHJlcXVlc3Qub3BlbihtZXRob2QsIHVybCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgcmVxdWVzdC5yZXNwb25zZVR5cGUgPSByZXNwb25zZVR5cGU7XG4gICAgICAgICAgICAgICAgcmVxdWVzdC5zZXRSZXF1ZXN0SGVhZGVyKCdBdXRob3JpemF0aW9uJywgYEJlYXJlciAke3Rva2VufWApO1xuICAgICAgICAgICAgICAgIGlmIChqc29uQm9keSkge1xuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9qc29uJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGhlYWRlcnMuZm9yRWFjaCgoaGVhZGVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcihoZWFkZXIubmFtZSwgaGVhZGVyLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5pbmZvKCdTb21ldGhpbmcgaGFwcGVuZWQnLCB1cmwsIHJlcXVlc3QucmVzcG9uc2UpXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0LnN0YXR1cyA+PSA0MDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChgRXJyb3IgJHtyZXF1ZXN0LnN0YXR1c31gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAocmVxdWVzdC5yZWFkeVN0YXRlID09IFhNTEh0dHBSZXF1ZXN0LkRPTkUgJiYgcmVxdWVzdC5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlcXVlc3QucmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBsZXQgYm9keSA9IG51bGw7XG4gICAgICAgICAgICAgICAgaWYgKGpzb25Cb2R5KSB7XG4gICAgICAgICAgICAgICAgICAgIGJvZHkgPSBKU09OLnN0cmluZ2lmeShqc29uQm9keSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJlcXVlc3Quc2VuZChib2R5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbmV4cG9ydHMubWFrZVJlcXVlc3QgPSBtYWtlUmVxdWVzdDtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZShyZXN1bHQudmFsdWUpOyB9KS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcbiAgICB9KTtcbn07XG52YXIgX19pbXBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2ltcG9ydFN0YXIpIHx8IGZ1bmN0aW9uIChtb2QpIHtcbiAgICBpZiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSByZXR1cm4gbW9kO1xuICAgIHZhciByZXN1bHQgPSB7fTtcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xuICAgIHJlc3VsdFtcImRlZmF1bHRcIl0gPSBtb2Q7XG4gICAgcmV0dXJuIHJlc3VsdDtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCBpbmRleF8xID0gcmVxdWlyZShcIi4uL2luZGV4XCIpO1xuY29uc3QgZ3JhcGhIZWxwZXIgPSBfX2ltcG9ydFN0YXIocmVxdWlyZShcIkBvcGVuLXN0dWRpby9zaW5nbGUtcGFnZS1tc2Z0LWdyYXBoLWhlbHBlclwiKSk7XG5jb25zdCBTQ09QRSA9ICdVc2VyLlJlYWQgTWFpbC5SZWFkIENhbGVuZGFycy5SZWFkIEdyb3VwLlJlYWQuQWxsIFRhc2tzLlJlYWQgVXNlci5SZWFkQmFzaWMuQWxsJztcbmNsYXNzIEZMR3JhcGgge1xuICAgIGluaXRpYWxpemUoKSB7XG4gICAgICAgIHJldHVybiBpbmRleF8xLkZMLmdyYXBoLnVwZGF0ZVNjb3BlKFNDT1BFLnNwbGl0KCcgJykpO1xuICAgIH1cbiAgICBpc0xvZ2dlZEluKCkge1xuICAgICAgICByZXR1cm4gaW5kZXhfMS5GTC5ncmFwaC5pc0xvZ2dlZEluKCk7XG4gICAgfVxuICAgIGxvZ0luKCkge1xuICAgICAgICByZXR1cm4gaW5kZXhfMS5GTC5ncmFwaC5sb2dpbigpO1xuICAgIH1cbiAgICBsb2dPdXQoKSB7XG4gICAgICAgIHJldHVybiBpbmRleF8xLkZMLmdyYXBoLmxvZ291dCgpO1xuICAgIH1cbiAgICBhY2Nlc3NUb2tlbigpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIGNvbnN0IHRva2VuID0geWllbGQgaW5kZXhfMS5GTC5ncmFwaC5nZXRBY2Nlc3NUb2tlbigpO1xuICAgICAgICAgICAgaWYgKHRva2VuLmFjY2Vzc1Rva2VuKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuLmFjY2Vzc1Rva2VuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBhY2Nlc3MgdG9rZW4nKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0cy5GTEdyYXBoID0gRkxHcmFwaDtcbmNsYXNzIFdlYkdyYXBoIHtcbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICBncmFwaEhlbHBlci5pbml0aWFsaXplKHtcbiAgICAgICAgICAgIGFwcElEOiAnZDUzOWE4ZGEtMzFmYS00ZTRhLTkxYjgtZmVmMTQ4OTcyNTA3JyxcbiAgICAgICAgICAgIHNjb3BlOiBTQ09QRSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlzTG9nZ2VkSW4oKSB7XG4gICAgICAgIHJldHVybiBncmFwaEhlbHBlci5pc0F1dGhlbnRpY2F0ZWQoKTtcbiAgICB9XG4gICAgbG9nSW4oKSB7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICBjb25zb2xlLmluZm8oJ2NhbGxpbmcgbG9naW4nLCBncmFwaEhlbHBlcik7XG4gICAgICAgICAgICB5aWVsZCBncmFwaEhlbHBlci5sb2dpbigpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgbG9nT3V0KCkge1xuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgcmV0dXJuIGdyYXBoSGVscGVyLmxvZ291dCgpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgYWNjZXNzVG9rZW4oKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGdyYXBoSGVscGVyLmFjY2Vzc1Rva2VuKCkpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5leHBvcnRzLldlYkdyYXBoID0gV2ViR3JhcGg7XG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2ltcG9ydFN0YXIgPSAodGhpcyAmJiB0aGlzLl9faW1wb3J0U3RhcikgfHwgZnVuY3Rpb24gKG1vZCkge1xuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XG4gICAgdmFyIHJlc3VsdCA9IHt9O1xuICAgIGlmIChtb2QgIT0gbnVsbCkgZm9yICh2YXIgayBpbiBtb2QpIGlmIChPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtb2QsIGspKSByZXN1bHRba10gPSBtb2Rba107XG4gICAgcmVzdWx0W1wiZGVmYXVsdFwiXSA9IG1vZDtcbiAgICByZXR1cm4gcmVzdWx0O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IFNpZnRMaWIgPSBfX2ltcG9ydFN0YXIocmVxdWlyZShcIi4vc2lmdFwiKSk7XG5jb25zdCBzdHVic18xID0gcmVxdWlyZShcIi4vc3R1YnNcIik7XG5jbGFzcyBGTFN0dWIge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnRob3VnaHRzID0gbmV3IHN0dWJzXzEuVGhvdWdodFNlcnZpY2VTdHViKCk7XG4gICAgICAgIHRoaXMuc3BlZWNoID0gbmV3IHN0dWJzXzEuU3BlZWNoU2VydmljZVN0dWIoKTtcbiAgICAgICAgdGhpcy5pbWFnZSA9IG5ldyBzdHVic18xLkltYWdlU2VydmljZVN0dWIoKTtcbiAgICAgICAgdGhpcy5zeXN0ZW0gPSBuZXcgc3R1YnNfMS5TeXN0ZW1TZXJ2aWNlU3R1YigpO1xuICAgICAgICB0aGlzLmdyYXBoID0gbmV3IHN0dWJzXzEuR3JhcGhTZXJ2aWNlU3R1YigpO1xuICAgICAgICB0aGlzLmtleVZhbHVlID0gbmV3IHN0dWJzXzEuS2V5VmFsdWVTZXJ2aWNlU3R1YigpO1xuICAgICAgICB0aGlzLmJ1dHRvbiA9IG5ldyBzdHVic18xLkJ1dHRvblNlcnZpY2VTdHViKCk7XG4gICAgfVxufVxuZXhwb3J0cy5GTCA9ICh3aW5kb3dbJ0ZMJ10gfHwgbmV3IEZMU3R1YigpKTtcbmV4cG9ydHMuU2lmdCA9IFNpZnRMaWI7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmZ1bmN0aW9uIGdlbmVyYXRlVVVJRCgpIHtcbiAgICB2YXIgZCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgIHZhciB1dWlkID0gJ3h4eHh4eHh4LXh4eHgtNHh4eC15eHh4LXh4eHh4eHh4eHh4eCcucmVwbGFjZSgvW3h5XS9nLCBmdW5jdGlvbiAoYykge1xuICAgICAgICB2YXIgciA9IChkICsgTWF0aC5yYW5kb20oKSAqIDE2KSAlIDE2IHwgMDtcbiAgICAgICAgZCA9IE1hdGguZmxvb3IoZCAvIDE2KTtcbiAgICAgICAgcmV0dXJuIChjID09ICd4JyA/IHIgOiAociAmIDB4MyB8IDB4OCkpLnRvU3RyaW5nKDE2KTtcbiAgICB9KTtcbiAgICByZXR1cm4gdXVpZDtcbn1cbmV4cG9ydHMuZ2VuZXJhdGVVVUlEID0gZ2VuZXJhdGVVVUlEO1xuIiwiLy8gc2hpbSBmb3IgdXNpbmcgcHJvY2VzcyBpbiBicm93c2VyXG52YXIgcHJvY2VzcyA9IG1vZHVsZS5leHBvcnRzID0ge307XG5cbi8vIGNhY2hlZCBmcm9tIHdoYXRldmVyIGdsb2JhbCBpcyBwcmVzZW50IHNvIHRoYXQgdGVzdCBydW5uZXJzIHRoYXQgc3R1YiBpdFxuLy8gZG9uJ3QgYnJlYWsgdGhpbmdzLiAgQnV0IHdlIG5lZWQgdG8gd3JhcCBpdCBpbiBhIHRyeSBjYXRjaCBpbiBjYXNlIGl0IGlzXG4vLyB3cmFwcGVkIGluIHN0cmljdCBtb2RlIGNvZGUgd2hpY2ggZG9lc24ndCBkZWZpbmUgYW55IGdsb2JhbHMuICBJdCdzIGluc2lkZSBhXG4vLyBmdW5jdGlvbiBiZWNhdXNlIHRyeS9jYXRjaGVzIGRlb3B0aW1pemUgaW4gY2VydGFpbiBlbmdpbmVzLlxuXG52YXIgY2FjaGVkU2V0VGltZW91dDtcbnZhciBjYWNoZWRDbGVhclRpbWVvdXQ7XG5cbmZ1bmN0aW9uIGRlZmF1bHRTZXRUaW1vdXQoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdzZXRUaW1lb3V0IGhhcyBub3QgYmVlbiBkZWZpbmVkJyk7XG59XG5mdW5jdGlvbiBkZWZhdWx0Q2xlYXJUaW1lb3V0ICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ2NsZWFyVGltZW91dCBoYXMgbm90IGJlZW4gZGVmaW5lZCcpO1xufVxuKGZ1bmN0aW9uICgpIHtcbiAgICB0cnkge1xuICAgICAgICBpZiAodHlwZW9mIHNldFRpbWVvdXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNhY2hlZFNldFRpbWVvdXQgPSBzZXRUaW1lb3V0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2FjaGVkU2V0VGltZW91dCA9IGRlZmF1bHRTZXRUaW1vdXQ7XG4gICAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNhY2hlZFNldFRpbWVvdXQgPSBkZWZhdWx0U2V0VGltb3V0O1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICBpZiAodHlwZW9mIGNsZWFyVGltZW91dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgY2FjaGVkQ2xlYXJUaW1lb3V0ID0gY2xlYXJUaW1lb3V0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2FjaGVkQ2xlYXJUaW1lb3V0ID0gZGVmYXVsdENsZWFyVGltZW91dDtcbiAgICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY2FjaGVkQ2xlYXJUaW1lb3V0ID0gZGVmYXVsdENsZWFyVGltZW91dDtcbiAgICB9XG59ICgpKVxuZnVuY3Rpb24gcnVuVGltZW91dChmdW4pIHtcbiAgICBpZiAoY2FjaGVkU2V0VGltZW91dCA9PT0gc2V0VGltZW91dCkge1xuICAgICAgICAvL25vcm1hbCBlbnZpcm9tZW50cyBpbiBzYW5lIHNpdHVhdGlvbnNcbiAgICAgICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuLCAwKTtcbiAgICB9XG4gICAgLy8gaWYgc2V0VGltZW91dCB3YXNuJ3QgYXZhaWxhYmxlIGJ1dCB3YXMgbGF0dGVyIGRlZmluZWRcbiAgICBpZiAoKGNhY2hlZFNldFRpbWVvdXQgPT09IGRlZmF1bHRTZXRUaW1vdXQgfHwgIWNhY2hlZFNldFRpbWVvdXQpICYmIHNldFRpbWVvdXQpIHtcbiAgICAgICAgY2FjaGVkU2V0VGltZW91dCA9IHNldFRpbWVvdXQ7XG4gICAgICAgIHJldHVybiBzZXRUaW1lb3V0KGZ1biwgMCk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIC8vIHdoZW4gd2hlbiBzb21lYm9keSBoYXMgc2NyZXdlZCB3aXRoIHNldFRpbWVvdXQgYnV0IG5vIEkuRS4gbWFkZG5lc3NcbiAgICAgICAgcmV0dXJuIGNhY2hlZFNldFRpbWVvdXQoZnVuLCAwKTtcbiAgICB9IGNhdGNoKGUpe1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gV2hlbiB3ZSBhcmUgaW4gSS5FLiBidXQgdGhlIHNjcmlwdCBoYXMgYmVlbiBldmFsZWQgc28gSS5FLiBkb2Vzbid0IHRydXN0IHRoZSBnbG9iYWwgb2JqZWN0IHdoZW4gY2FsbGVkIG5vcm1hbGx5XG4gICAgICAgICAgICByZXR1cm4gY2FjaGVkU2V0VGltZW91dC5jYWxsKG51bGwsIGZ1biwgMCk7XG4gICAgICAgIH0gY2F0Y2goZSl7XG4gICAgICAgICAgICAvLyBzYW1lIGFzIGFib3ZlIGJ1dCB3aGVuIGl0J3MgYSB2ZXJzaW9uIG9mIEkuRS4gdGhhdCBtdXN0IGhhdmUgdGhlIGdsb2JhbCBvYmplY3QgZm9yICd0aGlzJywgaG9wZnVsbHkgb3VyIGNvbnRleHQgY29ycmVjdCBvdGhlcndpc2UgaXQgd2lsbCB0aHJvdyBhIGdsb2JhbCBlcnJvclxuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZFNldFRpbWVvdXQuY2FsbCh0aGlzLCBmdW4sIDApO1xuICAgICAgICB9XG4gICAgfVxuXG5cbn1cbmZ1bmN0aW9uIHJ1bkNsZWFyVGltZW91dChtYXJrZXIpIHtcbiAgICBpZiAoY2FjaGVkQ2xlYXJUaW1lb3V0ID09PSBjbGVhclRpbWVvdXQpIHtcbiAgICAgICAgLy9ub3JtYWwgZW52aXJvbWVudHMgaW4gc2FuZSBzaXR1YXRpb25zXG4gICAgICAgIHJldHVybiBjbGVhclRpbWVvdXQobWFya2VyKTtcbiAgICB9XG4gICAgLy8gaWYgY2xlYXJUaW1lb3V0IHdhc24ndCBhdmFpbGFibGUgYnV0IHdhcyBsYXR0ZXIgZGVmaW5lZFxuICAgIGlmICgoY2FjaGVkQ2xlYXJUaW1lb3V0ID09PSBkZWZhdWx0Q2xlYXJUaW1lb3V0IHx8ICFjYWNoZWRDbGVhclRpbWVvdXQpICYmIGNsZWFyVGltZW91dCkge1xuICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBjbGVhclRpbWVvdXQ7XG4gICAgICAgIHJldHVybiBjbGVhclRpbWVvdXQobWFya2VyKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gd2hlbiB3aGVuIHNvbWVib2R5IGhhcyBzY3Jld2VkIHdpdGggc2V0VGltZW91dCBidXQgbm8gSS5FLiBtYWRkbmVzc1xuICAgICAgICByZXR1cm4gY2FjaGVkQ2xlYXJUaW1lb3V0KG1hcmtlcik7XG4gICAgfSBjYXRjaCAoZSl7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBXaGVuIHdlIGFyZSBpbiBJLkUuIGJ1dCB0aGUgc2NyaXB0IGhhcyBiZWVuIGV2YWxlZCBzbyBJLkUuIGRvZXNuJ3QgIHRydXN0IHRoZSBnbG9iYWwgb2JqZWN0IHdoZW4gY2FsbGVkIG5vcm1hbGx5XG4gICAgICAgICAgICByZXR1cm4gY2FjaGVkQ2xlYXJUaW1lb3V0LmNhbGwobnVsbCwgbWFya2VyKTtcbiAgICAgICAgfSBjYXRjaCAoZSl7XG4gICAgICAgICAgICAvLyBzYW1lIGFzIGFib3ZlIGJ1dCB3aGVuIGl0J3MgYSB2ZXJzaW9uIG9mIEkuRS4gdGhhdCBtdXN0IGhhdmUgdGhlIGdsb2JhbCBvYmplY3QgZm9yICd0aGlzJywgaG9wZnVsbHkgb3VyIGNvbnRleHQgY29ycmVjdCBvdGhlcndpc2UgaXQgd2lsbCB0aHJvdyBhIGdsb2JhbCBlcnJvci5cbiAgICAgICAgICAgIC8vIFNvbWUgdmVyc2lvbnMgb2YgSS5FLiBoYXZlIGRpZmZlcmVudCBydWxlcyBmb3IgY2xlYXJUaW1lb3V0IHZzIHNldFRpbWVvdXRcbiAgICAgICAgICAgIHJldHVybiBjYWNoZWRDbGVhclRpbWVvdXQuY2FsbCh0aGlzLCBtYXJrZXIpO1xuICAgICAgICB9XG4gICAgfVxuXG5cblxufVxudmFyIHF1ZXVlID0gW107XG52YXIgZHJhaW5pbmcgPSBmYWxzZTtcbnZhciBjdXJyZW50UXVldWU7XG52YXIgcXVldWVJbmRleCA9IC0xO1xuXG5mdW5jdGlvbiBjbGVhblVwTmV4dFRpY2soKSB7XG4gICAgaWYgKCFkcmFpbmluZyB8fCAhY3VycmVudFF1ZXVlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZHJhaW5pbmcgPSBmYWxzZTtcbiAgICBpZiAoY3VycmVudFF1ZXVlLmxlbmd0aCkge1xuICAgICAgICBxdWV1ZSA9IGN1cnJlbnRRdWV1ZS5jb25jYXQocXVldWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHF1ZXVlSW5kZXggPSAtMTtcbiAgICB9XG4gICAgaWYgKHF1ZXVlLmxlbmd0aCkge1xuICAgICAgICBkcmFpblF1ZXVlKCk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBkcmFpblF1ZXVlKCkge1xuICAgIGlmIChkcmFpbmluZykge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIHZhciB0aW1lb3V0ID0gcnVuVGltZW91dChjbGVhblVwTmV4dFRpY2spO1xuICAgIGRyYWluaW5nID0gdHJ1ZTtcblxuICAgIHZhciBsZW4gPSBxdWV1ZS5sZW5ndGg7XG4gICAgd2hpbGUobGVuKSB7XG4gICAgICAgIGN1cnJlbnRRdWV1ZSA9IHF1ZXVlO1xuICAgICAgICBxdWV1ZSA9IFtdO1xuICAgICAgICB3aGlsZSAoKytxdWV1ZUluZGV4IDwgbGVuKSB7XG4gICAgICAgICAgICBpZiAoY3VycmVudFF1ZXVlKSB7XG4gICAgICAgICAgICAgICAgY3VycmVudFF1ZXVlW3F1ZXVlSW5kZXhdLnJ1bigpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHF1ZXVlSW5kZXggPSAtMTtcbiAgICAgICAgbGVuID0gcXVldWUubGVuZ3RoO1xuICAgIH1cbiAgICBjdXJyZW50UXVldWUgPSBudWxsO1xuICAgIGRyYWluaW5nID0gZmFsc2U7XG4gICAgcnVuQ2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xufVxuXG5wcm9jZXNzLm5leHRUaWNrID0gZnVuY3Rpb24gKGZ1bikge1xuICAgIHZhciBhcmdzID0gbmV3IEFycmF5KGFyZ3VtZW50cy5sZW5ndGggLSAxKTtcbiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGFyZ3NbaSAtIDFdID0gYXJndW1lbnRzW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIHF1ZXVlLnB1c2gobmV3IEl0ZW0oZnVuLCBhcmdzKSk7XG4gICAgaWYgKHF1ZXVlLmxlbmd0aCA9PT0gMSAmJiAhZHJhaW5pbmcpIHtcbiAgICAgICAgcnVuVGltZW91dChkcmFpblF1ZXVlKTtcbiAgICB9XG59O1xuXG4vLyB2OCBsaWtlcyBwcmVkaWN0aWJsZSBvYmplY3RzXG5mdW5jdGlvbiBJdGVtKGZ1biwgYXJyYXkpIHtcbiAgICB0aGlzLmZ1biA9IGZ1bjtcbiAgICB0aGlzLmFycmF5ID0gYXJyYXk7XG59XG5JdGVtLnByb3RvdHlwZS5ydW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgdGhpcy5mdW4uYXBwbHkobnVsbCwgdGhpcy5hcnJheSk7XG59O1xucHJvY2Vzcy50aXRsZSA9ICdicm93c2VyJztcbnByb2Nlc3MuYnJvd3NlciA9IHRydWU7XG5wcm9jZXNzLmVudiA9IHt9O1xucHJvY2Vzcy5hcmd2ID0gW107XG5wcm9jZXNzLnZlcnNpb24gPSAnJzsgLy8gZW1wdHkgc3RyaW5nIHRvIGF2b2lkIHJlZ2V4cCBpc3N1ZXNcbnByb2Nlc3MudmVyc2lvbnMgPSB7fTtcblxuZnVuY3Rpb24gbm9vcCgpIHt9XG5cbnByb2Nlc3Mub24gPSBub29wO1xucHJvY2Vzcy5hZGRMaXN0ZW5lciA9IG5vb3A7XG5wcm9jZXNzLm9uY2UgPSBub29wO1xucHJvY2Vzcy5vZmYgPSBub29wO1xucHJvY2Vzcy5yZW1vdmVMaXN0ZW5lciA9IG5vb3A7XG5wcm9jZXNzLnJlbW92ZUFsbExpc3RlbmVycyA9IG5vb3A7XG5wcm9jZXNzLmVtaXQgPSBub29wO1xuXG5wcm9jZXNzLmJpbmRpbmcgPSBmdW5jdGlvbiAobmFtZSkge1xuICAgIHRocm93IG5ldyBFcnJvcigncHJvY2Vzcy5iaW5kaW5nIGlzIG5vdCBzdXBwb3J0ZWQnKTtcbn07XG5cbnByb2Nlc3MuY3dkID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gJy8nIH07XG5wcm9jZXNzLmNoZGlyID0gZnVuY3Rpb24gKGRpcikge1xuICAgIHRocm93IG5ldyBFcnJvcigncHJvY2Vzcy5jaGRpciBpcyBub3Qgc3VwcG9ydGVkJyk7XG59O1xucHJvY2Vzcy51bWFzayA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gMDsgfTtcbiIsIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBcUJBQTtBREFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRHBMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QURaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUR4QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUQ1RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QURuS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRGpCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FEekNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRDNCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QURoSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRGxHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FEbERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRDNCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRGhCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBRHBKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUQ5RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUR2ekxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUR0UkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUR0QkE7QUFDQTtBQUNBOztBREZBLElBQUEsRUFBQTtFQUFBOzs7O0FBQUEsRUFBQSxHQUFLLE9BQUEsQ0FBUSxLQUFSLENBQWMsQ0FBQzs7QUFFZCxPQUFPLENBQUM7OztFQUNiLFFBQUMsQ0FBQSxZQUFELEdBQWdCOztFQUNoQixRQUFDLENBQUEsVUFBRCxHQUFjOztFQUNkLFFBQUMsQ0FBQSxhQUFELEdBQWlCOztFQUVKLGtCQUFDLE9BQUQ7O01BQUMsVUFBVTs7Ozs7Ozs7SUFDdkIsT0FBTyxDQUFDLE9BQVIsR0FBa0I7SUFDbEIsMENBQU0sT0FBTjtJQUNBLEVBQUUsQ0FBQyxRQUFRLENBQUMsb0JBQVosQ0FBaUMsSUFBQyxDQUFBLFdBQWxDO0lBQ0EsRUFBRSxDQUFDLFFBQVEsQ0FBQyw2QkFBWixDQUEwQyxJQUFDLENBQUEsbUJBQTNDO0VBSlk7O3FCQU1iLFdBQUEsR0FBYSxTQUFDLEdBQUQ7SUFDWixJQUFHLEdBQUcsQ0FBQyxJQUFKLEtBQVksUUFBZjthQUNDLElBQUMsQ0FBQSxhQUFELENBQWUsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUF6QixFQUE4QixHQUFHLENBQUMsS0FBSyxDQUFDLEtBQXhDLEVBREQ7O0VBRFk7O3FCQUliLG1CQUFBLEdBQXFCLFNBQUMsU0FBRDtJQUNwQixRQUFRLENBQUMsV0FBVCxHQUF1QjtJQUN2QixJQUFHLFNBQUg7YUFDQyxJQUFDLENBQUEsSUFBRCxDQUFNLFFBQVEsQ0FBQyxVQUFmLEVBREQ7S0FBQSxNQUFBO2FBR0MsSUFBQyxDQUFBLElBQUQsQ0FBTSxRQUFRLENBQUMsYUFBZixFQUhEOztFQUZvQjs7cUJBT3JCLGFBQUEsR0FBZSxTQUFDLEdBQUQsRUFBTSxLQUFOO0lBRWQsSUFBQyxDQUFBLElBQUQsQ0FBTSxhQUFBLEdBQWdCLEdBQXRCLEVBQTJCLEtBQTNCO1dBQ0EsSUFBQyxDQUFBLElBQUQsQ0FBTSxjQUFBLEdBQWlCLEdBQXZCLEVBQTRCLEtBQTVCO0VBSGM7O3FCQUtmLFdBQUEsR0FBYSxTQUFDLElBQUQ7QUFDWixRQUFBO0FBQUE7U0FBQSxzQ0FBQTs7bUJBQ0MsVUFBQSxDQUFXLENBQVg7QUFERDs7RUFEWTs7cUJBSWIsVUFBQSxHQUFZLFNBQUMsR0FBRDtJQUNYLElBQU8sUUFBUSxDQUFDLFdBQVQsS0FBd0IsS0FBL0I7YUFDQyxFQUFFLENBQUMsUUFBUSxDQUFDLFVBQVosQ0FBdUIsR0FBdkIsQ0FDQSxDQUFDLElBREQsQ0FDTSxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUMsTUFBRDtpQkFDTCxLQUFDLENBQUEsYUFBRCxDQUFlLEdBQWYsRUFBb0IsTUFBTSxDQUFDLEtBQTNCO1FBREs7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRE4sQ0FHQSxFQUFDLEtBQUQsRUFIQSxDQUdPLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxLQUFEO2lCQUNOLEtBQUEsQ0FBTSxLQUFOO1FBRE07TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBSFAsRUFERDs7RUFEVzs7cUJBUVosTUFBQSxHQUFRLFNBQUMsR0FBRCxFQUFNLEtBQU47V0FDUCxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQVosQ0FBbUIsR0FBbkIsRUFBd0IsS0FBeEI7RUFETzs7RUFHUixRQUFDLENBQUEsTUFBRCxDQUFRLGFBQVIsRUFDQztJQUFBLEdBQUEsRUFBSyxTQUFBO2FBQUcsUUFBUSxDQUFDO0lBQVosQ0FBTDtHQUREOzs7O0dBMUM4Qjs7OztBREYvQixJQUFBOztBQUFBLE1BQWUsT0FBQSxDQUFRLDhCQUFSLENBQWYsRUFBRSxXQUFGLEVBQU07O0FBQ04sT0FBTyxDQUFDLElBQVIsR0FBZTs7QUFDZixPQUFPLENBQUMsRUFBUixHQUFhIn0=
