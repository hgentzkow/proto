require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"TouchIndicator":[function(require,module,exports){
exports.TouchIndicator = (function() {
  function TouchIndicator() {}

  TouchIndicator.fillColor = "#FF0000";

  TouchIndicator.enable = function() {
    if (Utils.isPhone()) {
      this.scaleFactor = window.devicePixelRatio;
    } else {
      this.scaleFactor = 1;
    }
    this.createIndicator();
    Events.wrap(window.document).on(Events.TouchStart, this.onTouchStart);
    Events.wrap(window.document).on(Events.TouchMove, this.onTouchMove);
    return Events.wrap(window.document).on(Events.TouchEnd, this.onTouchEnd);
  };

  TouchIndicator.disable = function() {
    var ref;
    Events.wrap(window.document).off(Events.TouchStart, this.onTouchStart);
    Events.wrap(window.document).off(Events.TouchMove, this.onTouchMove);
    Events.wrap(window.document).off(Events.TouchEnd, this.onTouchEnd);
    return (ref = this.indicator) != null ? ref.destroy() : void 0;
  };

  TouchIndicator.onTouchStart = function(e) {
    TouchIndicator.indicator.visible = true;
    TouchIndicator.indicator.animate("down");
    TouchIndicator.fill.animate("down");
    TouchIndicator.indicator.bringToFront();
    TouchIndicator.indicator.midX = e.layerX / TouchIndicator.scaleFactor;
    return TouchIndicator.indicator.midY = e.layerY / TouchIndicator.scaleFactor;
  };

  TouchIndicator.onTouchMove = function(e) {
    TouchIndicator.indicator.midX = e.layerX / TouchIndicator.scaleFactor;
    return TouchIndicator.indicator.midY = e.layerY / TouchIndicator.scaleFactor;
  };

  TouchIndicator.onTouchEnd = function(e) {
    TouchIndicator.indicator.animate("up");
    TouchIndicator.fill.animate("up");
    return Utils.delay(0.05, function() {
      return TouchIndicator.indicator.visible = false;
    });
  };

  TouchIndicator.setFillColor = function(c) {
    return this.fillColor = c;
  };

  TouchIndicator.createIndicator = function() {
    this.indicator = new Layer({
      parent: null,
      width: 44,
      height: 44,
      borderRadius: 30,
      visible: false,
      ignoreEvents: true,
      backgroundColor: null,
      borderWidth: 2,
      borderColor: this.fillColor,
      scale: 1.5
    });
    this.fill = new Layer({
      parent: this.indicator,
      width: this.indicator.width,
      height: this.indicator.height,
      borderRadius: this.indicator.width / 2,
      borderWidth: 2,
      borderColor: this.fillColor,
      opacity: 0.5
    });
    this.fill.states = {
      "down": {
        borderWidth: 15,
        options: {
          time: 0.2
        }
      },
      "up": {
        borderWidth: 2,
        options: {
          time: 0.2
        }
      }
    };
    return this.indicator.states = {
      "down": {
        scale: 1,
        options: {
          time: 0.05
        }
      },
      "up": {
        scale: 1.2,
        options: {
          time: 0.05
        }
      }
    };
  };

  return TouchIndicator;

})();


},{}],"myModule":[function(require,module,exports){
exports.myVar = "myVariable";

exports.myFunction = function() {
  return print("myFunction is running");
};

exports.myArray = [1, 2, 3];


},{}]},{},[])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnJhbWVyLm1vZHVsZXMuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL1RvdWNoSW5kaWNhdG9yLmZyYW1lci9tb2R1bGVzL215TW9kdWxlLmNvZmZlZSIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL1RvdWNoSW5kaWNhdG9yLmZyYW1lci9tb2R1bGVzL1RvdWNoSW5kaWNhdG9yLmNvZmZlZSIsIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiIyBBZGQgdGhlIGZvbGxvd2luZyBsaW5lIHRvIHlvdXIgcHJvamVjdCBpbiBGcmFtZXIgU3R1ZGlvLiBcbiMgbXlNb2R1bGUgPSByZXF1aXJlIFwibXlNb2R1bGVcIlxuIyBSZWZlcmVuY2UgdGhlIGNvbnRlbnRzIGJ5IG5hbWUsIGxpa2UgbXlNb2R1bGUubXlGdW5jdGlvbigpIG9yIG15TW9kdWxlLm15VmFyXG5cbmV4cG9ydHMubXlWYXIgPSBcIm15VmFyaWFibGVcIlxuXG5leHBvcnRzLm15RnVuY3Rpb24gPSAtPlxuXHRwcmludCBcIm15RnVuY3Rpb24gaXMgcnVubmluZ1wiXG5cbmV4cG9ydHMubXlBcnJheSA9IFsxLCAyLCAzXSIsImNsYXNzIGV4cG9ydHMuVG91Y2hJbmRpY2F0b3IgXG5cblx0dGhpcy5maWxsQ29sb3IgPSBcIiNGRjAwMDBcIlxuXG5cdEBlbmFibGU6ICgpIC0+XG5cdFx0aWYgVXRpbHMuaXNQaG9uZSgpXG5cdFx0XHRAc2NhbGVGYWN0b3IgPSB3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpb1xuXHRcdGVsc2Vcblx0XHRcdEBzY2FsZUZhY3RvciA9IDFcblxuXHRcdEBjcmVhdGVJbmRpY2F0b3IoKVxuXG5cdFx0RXZlbnRzLndyYXAod2luZG93LmRvY3VtZW50KS5vbiBFdmVudHMuVG91Y2hTdGFydCwgQG9uVG91Y2hTdGFydFxuXHRcdEV2ZW50cy53cmFwKHdpbmRvdy5kb2N1bWVudCkub24gRXZlbnRzLlRvdWNoTW92ZSwgQG9uVG91Y2hNb3ZlXG5cdFx0RXZlbnRzLndyYXAod2luZG93LmRvY3VtZW50KS5vbiBFdmVudHMuVG91Y2hFbmQsIEBvblRvdWNoRW5kXG5cblxuXHRAZGlzYWJsZTogKCkgLT5cblx0XHRFdmVudHMud3JhcCh3aW5kb3cuZG9jdW1lbnQpLm9mZiBFdmVudHMuVG91Y2hTdGFydCwgQG9uVG91Y2hTdGFydFxuXHRcdEV2ZW50cy53cmFwKHdpbmRvdy5kb2N1bWVudCkub2ZmIEV2ZW50cy5Ub3VjaE1vdmUsIEBvblRvdWNoTW92ZVxuXHRcdEV2ZW50cy53cmFwKHdpbmRvdy5kb2N1bWVudCkub2ZmIEV2ZW50cy5Ub3VjaEVuZCwgQG9uVG91Y2hFbmRcblxuXHRcdEBpbmRpY2F0b3I/LmRlc3Ryb3koKVxuXG5cdEBvblRvdWNoU3RhcnQ6IChlKSA9PlxuXHRcdEBpbmRpY2F0b3IudmlzaWJsZSA9IHRydWVcblx0XHRAaW5kaWNhdG9yLmFuaW1hdGUgXCJkb3duXCJcblx0XHRAZmlsbC5hbmltYXRlIFwiZG93blwiXG5cdFx0QGluZGljYXRvci5icmluZ1RvRnJvbnQoKVxuXG5cdFx0QGluZGljYXRvci5taWRYID0gZS5sYXllclggLyBAc2NhbGVGYWN0b3Jcblx0XHRAaW5kaWNhdG9yLm1pZFkgPSBlLmxheWVyWSAvIEBzY2FsZUZhY3RvclxuXG5cdEBvblRvdWNoTW92ZTogKGUpID0+XG5cdFx0QGluZGljYXRvci5taWRYID0gZS5sYXllclggLyBAc2NhbGVGYWN0b3Jcblx0XHRAaW5kaWNhdG9yLm1pZFkgPSBlLmxheWVyWSAvIEBzY2FsZUZhY3RvclxuXG5cdEBvblRvdWNoRW5kOiAoZSkgPT5cblx0XHRAaW5kaWNhdG9yLmFuaW1hdGUgXCJ1cFwiXG5cdFx0QGZpbGwuYW5pbWF0ZSBcInVwXCJcblx0XHRVdGlscy5kZWxheSAwLjA1LCA9PlxuXHRcdFx0QGluZGljYXRvci52aXNpYmxlID0gZmFsc2Vcblx0XG5cdEBzZXRGaWxsQ29sb3I6IChjKSAtPlxuXHRcdHRoaXMuZmlsbENvbG9yID0gY1xuXG5cbiMgVEhJUyBJUyBXSEVSRSBUSEUgRE9UIEdFVFMgQ1JFQVRFRFxuIyBBREpVU1QgVEhFIFZJU1VBTCBQUk9QRVJUSUVTICYgU1RBVEVTIEhFUkVcbiMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRAY3JlYXRlSW5kaWNhdG9yOiAoKSAtPlxuXHRcdEBpbmRpY2F0b3IgPSBuZXcgTGF5ZXJcblx0XHRcdHBhcmVudDogbnVsbFxuXHRcdFx0d2lkdGg6IDQ0XG5cdFx0XHRoZWlnaHQ6IDQ0XG5cdFx0XHRib3JkZXJSYWRpdXM6IDMwXG5cdFx0XHR2aXNpYmxlOiAgZmFsc2Vcblx0XHRcdGlnbm9yZUV2ZW50czogdHJ1ZVxuXHRcdFx0YmFja2dyb3VuZENvbG9yOiBudWxsXG5cdFx0XHRib3JkZXJXaWR0aDogMlxuXHRcdFx0Ym9yZGVyQ29sb3I6IHRoaXMuZmlsbENvbG9yXG5cdFx0XHRzY2FsZTogMS41XG5cdFx0XHRcblx0XHRAZmlsbCA9IG5ldyBMYXllclxuXHRcdFx0cGFyZW50OiBAaW5kaWNhdG9yXG5cdFx0XHR3aWR0aDogQGluZGljYXRvci53aWR0aFxuXHRcdFx0aGVpZ2h0OiBAaW5kaWNhdG9yLmhlaWdodFxuXHRcdFx0Ym9yZGVyUmFkaXVzOiBAaW5kaWNhdG9yLndpZHRoIC8gMlxuXHRcdFx0Ym9yZGVyV2lkdGg6IDJcblx0XHRcdGJvcmRlckNvbG9yOiB0aGlzLmZpbGxDb2xvclxuXHRcdFx0b3BhY2l0eTogMC41XG5cblx0XHRAZmlsbC5zdGF0ZXMgPSBcblx0XHRcdFwiZG93blwiOiBcblx0XHRcdFx0Ym9yZGVyV2lkdGg6IDE1XG5cdFx0XHRcdG9wdGlvbnM6IFxuXHRcdFx0XHRcdHRpbWU6IDAuMlxuXG5cdFx0XHRcInVwXCI6XG5cdFx0XHRcdGJvcmRlcldpZHRoOiAyXG5cdFx0XHRcdG9wdGlvbnM6IFxuXHRcdFx0XHRcdHRpbWU6IDAuMlxuXHRcblx0XHRAaW5kaWNhdG9yLnN0YXRlcyA9IFxuXHRcdFx0XCJkb3duXCI6XG5cdFx0XHRcdHNjYWxlOiAxXG5cdFx0XHRcdG9wdGlvbnM6XG5cdFx0XHRcdFx0dGltZTogMC4wNVxuXHRcdFx0XCJ1cFwiOlxuXHRcdFx0XHRzY2FsZTogMS4yXG5cdFx0XHRcdG9wdGlvbnM6XG5cdFx0XHRcdFx0dGltZTogMC4wNVxuXG5cbiIsIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBRUFBO0FEQU0sT0FBTyxDQUFDOzs7RUFFYixjQUFJLENBQUMsU0FBTCxHQUFpQjs7RUFFakIsY0FBQyxDQUFBLE1BQUQsR0FBUyxTQUFBO0lBQ1IsSUFBRyxLQUFLLENBQUMsT0FBTixDQUFBLENBQUg7TUFDQyxJQUFDLENBQUEsV0FBRCxHQUFlLE1BQU0sQ0FBQyxpQkFEdkI7S0FBQSxNQUFBO01BR0MsSUFBQyxDQUFBLFdBQUQsR0FBZSxFQUhoQjs7SUFLQSxJQUFDLENBQUEsZUFBRCxDQUFBO0lBRUEsTUFBTSxDQUFDLElBQVAsQ0FBWSxNQUFNLENBQUMsUUFBbkIsQ0FBNEIsQ0FBQyxFQUE3QixDQUFnQyxNQUFNLENBQUMsVUFBdkMsRUFBbUQsSUFBQyxDQUFBLFlBQXBEO0lBQ0EsTUFBTSxDQUFDLElBQVAsQ0FBWSxNQUFNLENBQUMsUUFBbkIsQ0FBNEIsQ0FBQyxFQUE3QixDQUFnQyxNQUFNLENBQUMsU0FBdkMsRUFBa0QsSUFBQyxDQUFBLFdBQW5EO1dBQ0EsTUFBTSxDQUFDLElBQVAsQ0FBWSxNQUFNLENBQUMsUUFBbkIsQ0FBNEIsQ0FBQyxFQUE3QixDQUFnQyxNQUFNLENBQUMsUUFBdkMsRUFBaUQsSUFBQyxDQUFBLFVBQWxEO0VBVlE7O0VBYVQsY0FBQyxDQUFBLE9BQUQsR0FBVSxTQUFBO0FBQ1QsUUFBQTtJQUFBLE1BQU0sQ0FBQyxJQUFQLENBQVksTUFBTSxDQUFDLFFBQW5CLENBQTRCLENBQUMsR0FBN0IsQ0FBaUMsTUFBTSxDQUFDLFVBQXhDLEVBQW9ELElBQUMsQ0FBQSxZQUFyRDtJQUNBLE1BQU0sQ0FBQyxJQUFQLENBQVksTUFBTSxDQUFDLFFBQW5CLENBQTRCLENBQUMsR0FBN0IsQ0FBaUMsTUFBTSxDQUFDLFNBQXhDLEVBQW1ELElBQUMsQ0FBQSxXQUFwRDtJQUNBLE1BQU0sQ0FBQyxJQUFQLENBQVksTUFBTSxDQUFDLFFBQW5CLENBQTRCLENBQUMsR0FBN0IsQ0FBaUMsTUFBTSxDQUFDLFFBQXhDLEVBQWtELElBQUMsQ0FBQSxVQUFuRDsrQ0FFVSxDQUFFLE9BQVosQ0FBQTtFQUxTOztFQU9WLGNBQUMsQ0FBQSxZQUFELEdBQWUsU0FBQyxDQUFEO0lBQ2QsY0FBQyxDQUFBLFNBQVMsQ0FBQyxPQUFYLEdBQXFCO0lBQ3JCLGNBQUMsQ0FBQSxTQUFTLENBQUMsT0FBWCxDQUFtQixNQUFuQjtJQUNBLGNBQUMsQ0FBQSxJQUFJLENBQUMsT0FBTixDQUFjLE1BQWQ7SUFDQSxjQUFDLENBQUEsU0FBUyxDQUFDLFlBQVgsQ0FBQTtJQUVBLGNBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxHQUFrQixDQUFDLENBQUMsTUFBRixHQUFXLGNBQUMsQ0FBQTtXQUM5QixjQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsR0FBa0IsQ0FBQyxDQUFDLE1BQUYsR0FBVyxjQUFDLENBQUE7RUFQaEI7O0VBU2YsY0FBQyxDQUFBLFdBQUQsR0FBYyxTQUFDLENBQUQ7SUFDYixjQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsR0FBa0IsQ0FBQyxDQUFDLE1BQUYsR0FBVyxjQUFDLENBQUE7V0FDOUIsY0FBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLEdBQWtCLENBQUMsQ0FBQyxNQUFGLEdBQVcsY0FBQyxDQUFBO0VBRmpCOztFQUlkLGNBQUMsQ0FBQSxVQUFELEdBQWEsU0FBQyxDQUFEO0lBQ1osY0FBQyxDQUFBLFNBQVMsQ0FBQyxPQUFYLENBQW1CLElBQW5CO0lBQ0EsY0FBQyxDQUFBLElBQUksQ0FBQyxPQUFOLENBQWMsSUFBZDtXQUNBLEtBQUssQ0FBQyxLQUFOLENBQVksSUFBWixFQUFrQixTQUFBO2FBQ2pCLGNBQUMsQ0FBQSxTQUFTLENBQUMsT0FBWCxHQUFxQjtJQURKLENBQWxCO0VBSFk7O0VBTWIsY0FBQyxDQUFBLFlBQUQsR0FBZSxTQUFDLENBQUQ7V0FDZCxJQUFJLENBQUMsU0FBTCxHQUFpQjtFQURIOztFQU9mLGNBQUMsQ0FBQSxlQUFELEdBQWtCLFNBQUE7SUFDakIsSUFBQyxDQUFBLFNBQUQsR0FBaUIsSUFBQSxLQUFBLENBQ2hCO01BQUEsTUFBQSxFQUFRLElBQVI7TUFDQSxLQUFBLEVBQU8sRUFEUDtNQUVBLE1BQUEsRUFBUSxFQUZSO01BR0EsWUFBQSxFQUFjLEVBSGQ7TUFJQSxPQUFBLEVBQVUsS0FKVjtNQUtBLFlBQUEsRUFBYyxJQUxkO01BTUEsZUFBQSxFQUFpQixJQU5qQjtNQU9BLFdBQUEsRUFBYSxDQVBiO01BUUEsV0FBQSxFQUFhLElBQUksQ0FBQyxTQVJsQjtNQVNBLEtBQUEsRUFBTyxHQVRQO0tBRGdCO0lBWWpCLElBQUMsQ0FBQSxJQUFELEdBQVksSUFBQSxLQUFBLENBQ1g7TUFBQSxNQUFBLEVBQVEsSUFBQyxDQUFBLFNBQVQ7TUFDQSxLQUFBLEVBQU8sSUFBQyxDQUFBLFNBQVMsQ0FBQyxLQURsQjtNQUVBLE1BQUEsRUFBUSxJQUFDLENBQUEsU0FBUyxDQUFDLE1BRm5CO01BR0EsWUFBQSxFQUFjLElBQUMsQ0FBQSxTQUFTLENBQUMsS0FBWCxHQUFtQixDQUhqQztNQUlBLFdBQUEsRUFBYSxDQUpiO01BS0EsV0FBQSxFQUFhLElBQUksQ0FBQyxTQUxsQjtNQU1BLE9BQUEsRUFBUyxHQU5UO0tBRFc7SUFTWixJQUFDLENBQUEsSUFBSSxDQUFDLE1BQU4sR0FDQztNQUFBLE1BQUEsRUFDQztRQUFBLFdBQUEsRUFBYSxFQUFiO1FBQ0EsT0FBQSxFQUNDO1VBQUEsSUFBQSxFQUFNLEdBQU47U0FGRDtPQUREO01BS0EsSUFBQSxFQUNDO1FBQUEsV0FBQSxFQUFhLENBQWI7UUFDQSxPQUFBLEVBQ0M7VUFBQSxJQUFBLEVBQU0sR0FBTjtTQUZEO09BTkQ7O1dBVUQsSUFBQyxDQUFBLFNBQVMsQ0FBQyxNQUFYLEdBQ0M7TUFBQSxNQUFBLEVBQ0M7UUFBQSxLQUFBLEVBQU8sQ0FBUDtRQUNBLE9BQUEsRUFDQztVQUFBLElBQUEsRUFBTSxJQUFOO1NBRkQ7T0FERDtNQUlBLElBQUEsRUFDQztRQUFBLEtBQUEsRUFBTyxHQUFQO1FBQ0EsT0FBQSxFQUNDO1VBQUEsSUFBQSxFQUFNLElBQU47U0FGRDtPQUxEOztFQWxDZ0I7Ozs7Ozs7O0FEOUNuQixPQUFPLENBQUMsS0FBUixHQUFnQjs7QUFFaEIsT0FBTyxDQUFDLFVBQVIsR0FBcUIsU0FBQTtTQUNwQixLQUFBLENBQU0sdUJBQU47QUFEb0I7O0FBR3JCLE9BQU8sQ0FBQyxPQUFSLEdBQWtCLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQIn0=
