require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"Sift/Button":[function(require,module,exports){
var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

exports.Button = (function(superClass) {
  extend(Button, superClass);

  function Button(options) {
    var color, fontSize, ref, ref1;
    if (options == null) {
      options = {};
    }
    this.onMouseUp = bind(this.onMouseUp, this);
    this.onMouseDown = bind(this.onMouseDown, this);
    if (options.backgroundColor == null) {
      options.backgroundColor = "white";
    }
    if (options.height == null) {
      options.height = 40;
    }
    if (options.width == null) {
      options.width = 100;
    }
    if (options.borderRadius == null) {
      options.borderRadius = options.height / 2;
    }
    if (options.borderWidth == null) {
      options.borderWidth = 2;
    }
    Button.__super__.constructor.call(this, options);
    this.opacity = 0.7;
    color = (ref = options.color) != null ? ref : "black";
    this.borderColor = color;
    fontSize = (ref1 = options.fontSize) != null ? ref1 : 17;
    this.textLabel = new TextLayer({
      parent: this,
      fontSize: fontSize,
      fontWeight: 600,
      text: options.title,
      textAlign: Align.center,
      height: fontSize + 6,
      midY: this.height / 2,
      autoSize: true,
      color: color
    });
    this.width = this.textLabel.width + 36;
    this.textLabel.width = this.width;
    this.on(Events.MouseDown, this.onMouseDown);
    this.on(Events.MouseUp, this.onMouseUp);
  }

  Button.prototype.onMouseDown = function(e) {
    return this.animate({
      opacity: 1,
      options: {
        time: 0.1
      }
    });
  };

  Button.prototype.onMouseUp = function(e) {
    return this.animate({
      opacity: 0.7,
      options: {
        time: 0.1
      }
    });
  };

  return Button;

})(Layer);


},{}],"Sift/Switch":[function(require,module,exports){
var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

exports.Switch = (function(superClass) {
  extend(Switch, superClass);

  function Switch(options) {
    var ref, ref1;
    if (options == null) {
      options = {};
    }
    this.toggle = bind(this.toggle, this);
    this.enable = bind(this.enable, this);
    Switch.__super__.constructor.call(this, options);
    this.backgroundColor = null;
    this.enabled = (ref = options.enabled) != null ? ref : true;
    this.fillColor = (ref1 = options.fillColor) != null ? ref1 : "#0078D4";
    this.height = 31;
    this.width = 51;
    this.bg = new Layer({
      parent: this,
      width: this.width,
      height: this.height,
      backgroundColor: this.fillColor,
      borderColor: this.fillColor,
      borderWidth: 2,
      borderRadius: this.height / 2
    });
    this.thumb = new Layer({
      parent: this,
      width: this.height - 4,
      height: this.height - 4,
      backgroundColor: "#FFF",
      borderRadius: this.height / 2,
      shadowY: 2,
      shadowBlur: 4,
      shadowColor: "rgba(0,0,0,0.35)",
      x: 2,
      y: 2
    });
    this.enable(this.enabled);
    this.on(Events.Tap, this.toggle);
  }

  Switch.prototype.enable = function(isOn) {
    if (isOn == null) {
      isOn = true;
    }
    this.enabled = isOn;
    if (this.enabled) {
      this.thumb.animate({
        maxX: this.bg.width - 2,
        options: {
          time: 0.1
        }
      });
      return this.bg.animate({
        backgroundColor: this.fillColor,
        borderColor: this.fillColor,
        options: {
          time: 0.1
        }
      });
    } else {
      this.thumb.animate({
        x: 2,
        options: {
          time: 0.1
        }
      });
      return this.bg.animate({
        backgroundColor: "#FFF",
        borderColor: "#E5E5EA",
        options: {
          time: 0.1
        }
      });
    }
  };

  Switch.prototype.toggle = function() {
    return this.enable(!this.enabled);
  };

  return Switch;

})(Layer);


},{}],"Sift/TweakerPanel":[function(require,module,exports){

/* Tweaker Panel
	 * 2019.02.04 Microsoft Open Studio
	 * Cadin Batrack (cadin.batrack@microsoft.com)

	

	 * USING TWEAKERPANEL

	{TweakerPanel} = require "Sift/TweakerPanel"
	tweakerPanel = new TweakerPanel


	 * INFO
	TweakerPanel can create controls for you (`createSwitch`, `createSlider`, `createButton`),
	or you can create controls and add them to the panel with `addItem`.

	* Items are automatically laid out vertically in the order they are created or added. * 

	The create methods will return the control that was created. You can use that or not:
		closeButton = tweaker.createButton("Close", closeHandler)
			or
		tweaker.createButton("Close", closeHandler)


	USE ESC KEY TO TOGGLE PANEL

	
	 * DEPENDENCIES
	- Sift/Button
	- Sift/Switch


	 * METHODS

	  method 			arguments
	  ----------------------------------------
	  open 				---
	  close 			---
	  toggle 			---

	  createSwitch		label: String, value: Boolean, clickHandler: Function
	  createSlider		label: String, minValue:Number, maxValue: Number, currentValue: Number, changeHandler: Function
	  createButton		label: String, clickHandler: Function

	  addItem			item: Layer
 */
var Button, Switch, TweakerSlider,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

Button = require("Sift/Button").Button;

Switch = require("Sift/Switch").Switch;

exports.TweakerPanel = (function(superClass) {
  extend(TweakerPanel, superClass);

  TweakerPanel.DidClose = "didClose";

  function TweakerPanel(options) {
    if (options == null) {
      options = {};
    }
    if (options.width == null) {
      options.width = Screen.width;
    }
    if (options.backgroundColor == null) {
      options.backgroundColor = "rgba(255, 255, 255, 1)";
    }
    if (options.borderColor == null) {
      options.borderColor = "rgba(0, 0, 0, 0.4)";
    }
    if (options.borderWidth == null) {
      options.borderWidth = {
        bottom: 1
      };
    }
    TweakerPanel.__super__.constructor.call(this, options);
    this.height = 300;
    this.sliders = [];
    this.yPos = 50;
    this.padding = 10;
    this.isOpen = false;
    Screen.on(Events.EdgeSwipeLeft, (function(_this) {
      return function(e) {};
    })(this));
    window.addEventListener("keydown", (function(_this) {
      return function(e) {
        if (e.keyCode === 17 || e.keyCode === 27) {
          return _this.toggle();
        }
      };
    })(this));
  }

  TweakerPanel.prototype.addItem = function(item) {
    item.parent = this;
    item.y = this.yPos;
    this.yPos += item.height;
    this.height = this.yPos;
    if (!this.isOpen) {
      this.y = -this.height;
    }
    return item;
  };

  TweakerPanel.prototype.createSlider = function(label, minValue, maxValue, currentValue, changeHandler) {
    var tweakerSlider;
    tweakerSlider = new TweakerSlider({
      parent: this,
      labelText: label,
      minValue: minValue,
      maxValue: maxValue,
      currentValue: currentValue
    });
    this.addSlider(tweakerSlider);
    if (changeHandler != null) {
      tweakerSlider.slider.on(Events.SliderValueChange, changeHandler);
    }
    return tweakerSlider;
  };

  TweakerPanel.prototype.addSlider = function(slider) {
    this.sliders.push(slider);
    slider.y = this.yPos;
    return this.addItem(slider);
  };

  TweakerPanel.prototype.createButton = function(title, clickHandler) {
    var button;
    button = new Button({
      title: title
    });
    button.on(Events.Tap, clickHandler);
    return this.addItem(button);
  };

  TweakerPanel.prototype.createSwitch = function(title, value, clickHandler) {
    var container, divider, textLabel, toggle;
    container = new Layer({
      backgroundColor: null,
      height: 44,
      width: Screen.width - 16,
      x: 16
    });
    toggle = new Switch({
      parent: container,
      enabled: value,
      x: container.width - 67,
      y: 6
    });
    textLabel = new TextLayer({
      parent: container,
      text: title,
      fontSize: 17,
      fontWeight: 500,
      color: "black",
      textAlign: Align.left,
      width: container.width - 83,
      lineHeight: 1,
      y: Align.center
    });
    divider = new Layer({
      parent: container,
      backgroundColor: "#C8C7CC",
      height: 1,
      width: Screen.width,
      x: 0,
      y: container.height - 1
    });
    toggle.on(Events.Tap, clickHandler);
    this.addItem(container);
    return toggle;
  };

  TweakerPanel.prototype.open = function() {
    this.animate({
      y: 0,
      options: {
        time: 0.2,
        curve: Bezier.ease
      }
    });
    return this.isOpen = true;
  };

  TweakerPanel.prototype.close = function() {
    this.isOpen = false;
    this.animate({
      y: -this.height,
      options: {
        curve: Bezier.ease,
        time: 0.35
      }
    });
    return this.emit(TweakerPanel.DidClose);
  };

  TweakerPanel.prototype.toggle = function() {
    if (this.isOpen) {
      return this.close();
    } else {
      return this.open();
    }
  };

  return TweakerPanel;

})(Layer);

TweakerSlider = (function(superClass) {
  extend(TweakerSlider, superClass);

  function TweakerSlider(options) {
    if (options == null) {
      options = {};
    }
    this.onSliderChanged = bind(this.onSliderChanged, this);
    if (options.backgroundColor == null) {
      options.backgroundColor = null;
    }
    TweakerSlider.__super__.constructor.call(this, options);
    this.decimals = 0;
    this.container = new Layer({
      parent: this,
      backgroundColor: null
    });
    this.label = new TextLayer({
      parent: this.container,
      backgroundColor: null,
      text: options.labelText,
      fontSize: 12,
      fontWeight: 700,
      color: "black",
      textAlign: Align.right,
      width: 100,
      lineHeight: 1
    });
    this.slider = new SliderComponent({
      parent: this.container,
      x: 120,
      y: 1,
      width: 200,
      min: options.minValue,
      max: options.maxValue,
      value: options.currentValue
    });
    this.slider.knob.draggable.momentum = false;
    this.slider.fill.backgroundColor = "#0078D4";
    this.slider.on(Events.SliderValueChange, this.onSliderChanged);
    if (options.changeHandler != null) {
      this.slider.on(Events.SliderValueChange, options.changeHandler);
    }
    this.height = this.slider.height;
    this.valueText = new TextLayer({
      parent: this.container,
      backgroundColor: null,
      text: this.slider.value,
      fontSize: 12,
      fontWeight: 700,
      color: "black",
      textAlign: Align.right,
      width: 50,
      lineHeight: 1,
      x: 310
    });
  }

  TweakerSlider.prototype.onSliderChanged = function(e) {
    this.valueText.text = this.getCurrentValue();
    if (this.trackingObject != null) {
      return this.trackingObject[this.trackingProperty] = this.getCurrentValue();
    }
  };

  TweakerSlider.prototype.setFillColor = function(color) {
    return this.slider.fill.backgroundColor = color;
  };

  TweakerSlider.prototype.setTrackColor = function(color) {
    return this.slider.backgroundColor = color;
  };

  TweakerSlider.prototype.setCurrentValue = function(value, animated) {
    if (animated == null) {
      animated = true;
    }
    if (animated === true) {
      return this.slider.animateToValue(value);
    } else {
      return this.slider.value = value;
    }
  };

  TweakerSlider.prototype.getCurrentValue = function() {
    return Utils.round(this.slider.value, this.decimals);
  };

  TweakerSlider.prototype.setDecimalPlaces = function(decimals) {
    return this.decimals = decimals;
  };

  TweakerSlider.prototype.bindToPropertyOfObject = function(property, object) {
    this.trackingObject = object;
    return this.trackingProperty = property;
  };

  return TweakerSlider;

})(Layer);


},{"Sift/Button":"Sift/Button","Sift/Switch":"Sift/Switch"}],"myModule":[function(require,module,exports){
exports.myVar = "myVariable";

exports.myFunction = function() {
  return print("myFunction is running");
};

exports.myArray = [1, 2, 3];


},{}]},{},[])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnJhbWVyLm1vZHVsZXMuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL1R3ZWFrZXJQYW5lbC5mcmFtZXIvbW9kdWxlcy9teU1vZHVsZS5jb2ZmZWUiLCIuLi8uLi8uLi8uLi8uLi9Vc2Vycy9oYWdlbnQvRGVza3RvcC9WQVVMVC9ERVNJR04vUFJPVE8vX0FTU0VUUy9Ud2Vha2VyUGFuZWwuZnJhbWVyL21vZHVsZXMvU2lmdC9Ud2Vha2VyUGFuZWwuY29mZmVlIiwiLi4vLi4vLi4vLi4vLi4vVXNlcnMvaGFnZW50L0Rlc2t0b3AvVkFVTFQvREVTSUdOL1BST1RPL19BU1NFVFMvVHdlYWtlclBhbmVsLmZyYW1lci9tb2R1bGVzL1NpZnQvU3dpdGNoLmNvZmZlZSIsIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2hhZ2VudC9EZXNrdG9wL1ZBVUxUL0RFU0lHTi9QUk9UTy9fQVNTRVRTL1R3ZWFrZXJQYW5lbC5mcmFtZXIvbW9kdWxlcy9TaWZ0L0J1dHRvbi5jb2ZmZWUiLCJub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIiMgQWRkIHRoZSBmb2xsb3dpbmcgbGluZSB0byB5b3VyIHByb2plY3QgaW4gRnJhbWVyIFN0dWRpby4gXG4jIG15TW9kdWxlID0gcmVxdWlyZSBcIm15TW9kdWxlXCJcbiMgUmVmZXJlbmNlIHRoZSBjb250ZW50cyBieSBuYW1lLCBsaWtlIG15TW9kdWxlLm15RnVuY3Rpb24oKSBvciBteU1vZHVsZS5teVZhclxuXG5leHBvcnRzLm15VmFyID0gXCJteVZhcmlhYmxlXCJcblxuZXhwb3J0cy5teUZ1bmN0aW9uID0gLT5cblx0cHJpbnQgXCJteUZ1bmN0aW9uIGlzIHJ1bm5pbmdcIlxuXG5leHBvcnRzLm15QXJyYXkgPSBbMSwgMiwgM10iLCIjIyMgVHdlYWtlciBQYW5lbFxuXHQjIDIwMTkuMDIuMDQgTWljcm9zb2Z0IE9wZW4gU3R1ZGlvXG5cdCMgQ2FkaW4gQmF0cmFjayAoY2FkaW4uYmF0cmFja0BtaWNyb3NvZnQuY29tKVxuXG5cdFxuXG5cdCMgVVNJTkcgVFdFQUtFUlBBTkVMXG5cblx0e1R3ZWFrZXJQYW5lbH0gPSByZXF1aXJlIFwiU2lmdC9Ud2Vha2VyUGFuZWxcIlxuXHR0d2Vha2VyUGFuZWwgPSBuZXcgVHdlYWtlclBhbmVsXG5cblxuXHQjIElORk9cblx0VHdlYWtlclBhbmVsIGNhbiBjcmVhdGUgY29udHJvbHMgZm9yIHlvdSAoYGNyZWF0ZVN3aXRjaGAsIGBjcmVhdGVTbGlkZXJgLCBgY3JlYXRlQnV0dG9uYCksXG5cdG9yIHlvdSBjYW4gY3JlYXRlIGNvbnRyb2xzIGFuZCBhZGQgdGhlbSB0byB0aGUgcGFuZWwgd2l0aCBgYWRkSXRlbWAuXG5cblx0KiBJdGVtcyBhcmUgYXV0b21hdGljYWxseSBsYWlkIG91dCB2ZXJ0aWNhbGx5IGluIHRoZSBvcmRlciB0aGV5IGFyZSBjcmVhdGVkIG9yIGFkZGVkLiAqIFxuXG5cdFRoZSBjcmVhdGUgbWV0aG9kcyB3aWxsIHJldHVybiB0aGUgY29udHJvbCB0aGF0IHdhcyBjcmVhdGVkLiBZb3UgY2FuIHVzZSB0aGF0IG9yIG5vdDpcblx0XHRjbG9zZUJ1dHRvbiA9IHR3ZWFrZXIuY3JlYXRlQnV0dG9uKFwiQ2xvc2VcIiwgY2xvc2VIYW5kbGVyKVxuXHRcdFx0b3Jcblx0XHR0d2Vha2VyLmNyZWF0ZUJ1dHRvbihcIkNsb3NlXCIsIGNsb3NlSGFuZGxlcilcblxuXG5cdFVTRSBFU0MgS0VZIFRPIFRPR0dMRSBQQU5FTFxuXG5cdFxuXHQjIERFUEVOREVOQ0lFU1xuXHQtIFNpZnQvQnV0dG9uXG5cdC0gU2lmdC9Td2l0Y2hcblxuXG5cdCMgTUVUSE9EU1xuXG5cdCAgbWV0aG9kIFx0XHRcdGFyZ3VtZW50c1xuXHQgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0ICBvcGVuIFx0XHRcdFx0LS0tXG5cdCAgY2xvc2UgXHRcdFx0LS0tXG5cdCAgdG9nZ2xlIFx0XHRcdC0tLVxuXG5cdCAgY3JlYXRlU3dpdGNoXHRcdGxhYmVsOiBTdHJpbmcsIHZhbHVlOiBCb29sZWFuLCBjbGlja0hhbmRsZXI6IEZ1bmN0aW9uXG5cdCAgY3JlYXRlU2xpZGVyXHRcdGxhYmVsOiBTdHJpbmcsIG1pblZhbHVlOk51bWJlciwgbWF4VmFsdWU6IE51bWJlciwgY3VycmVudFZhbHVlOiBOdW1iZXIsIGNoYW5nZUhhbmRsZXI6IEZ1bmN0aW9uXG5cdCAgY3JlYXRlQnV0dG9uXHRcdGxhYmVsOiBTdHJpbmcsIGNsaWNrSGFuZGxlcjogRnVuY3Rpb25cblxuXHQgIGFkZEl0ZW1cdFx0XHRpdGVtOiBMYXllclxuXG5cbiMjI1xuXG5cbntCdXR0b259ID0gcmVxdWlyZSBcIlNpZnQvQnV0dG9uXCJcbntTd2l0Y2h9ID0gcmVxdWlyZSBcIlNpZnQvU3dpdGNoXCJcblxuY2xhc3MgZXhwb3J0cy5Ud2Vha2VyUGFuZWwgZXh0ZW5kcyBMYXllclxuXG5cdEBEaWRDbG9zZSA9IFwiZGlkQ2xvc2VcIlxuXG5cdGNvbnN0cnVjdG9yOiAob3B0aW9ucyA9IHt9KSAtPlxuXG5cdFx0b3B0aW9ucy53aWR0aCA/PSBTY3JlZW4ud2lkdGhcblx0XHRvcHRpb25zLmJhY2tncm91bmRDb2xvciA/PSBcInJnYmEoMjU1LCAyNTUsIDI1NSwgMSlcIiAjXCJyZ2JhKDI0MCwgMjQwLCAyNDAsIDEpXCJcblx0XHRvcHRpb25zLmJvcmRlckNvbG9yID89IFwicmdiYSgwLCAwLCAwLCAwLjQpXCJcblx0XHRvcHRpb25zLmJvcmRlcldpZHRoID89IFxuXHRcdFx0Ym90dG9tOiAxXG5cblx0XHRzdXBlcihvcHRpb25zKVxuXHRcdEBoZWlnaHQgPSAzMDBcblx0XHRAc2xpZGVycyA9IFtdXG5cdFx0QHlQb3MgPSA1MFxuXHRcdEBwYWRkaW5nID0gMTBcblx0XHRAaXNPcGVuID0gZmFsc2VcblxuXHRcdFNjcmVlbi5vbiBFdmVudHMuRWRnZVN3aXBlTGVmdCwgKGUpID0+XG5cdFx0XHQjIEBvcGVuKClcblxuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyIFwia2V5ZG93blwiLCAoZSkgPT5cblx0XHRcdCMgY29udHJvbCBvciBlc2Mga2V5IHRvIHRvZ2dsZSBtZW51XG5cdFx0XHRpZiBlLmtleUNvZGUgaXMgMTcgb3IgZS5rZXlDb2RlIGlzIDI3IFxuXHRcdFx0XHRAdG9nZ2xlKClcblxuXG5cdGFkZEl0ZW06IChpdGVtKSAtPlxuXHRcdGl0ZW0ucGFyZW50ID0gQFxuXHRcdGl0ZW0ueSA9IEB5UG9zXG5cdFx0QHlQb3MgKz0gaXRlbS5oZWlnaHQgIysgQHBhZGRpbmdcblx0XHRAaGVpZ2h0ID0gQHlQb3Ncblx0XHR1bmxlc3MgQGlzT3BlblxuXHRcdFx0QHkgPSAtIEBoZWlnaHQgXG5cdFx0aXRlbVxuXG5cdGNyZWF0ZVNsaWRlcjogKGxhYmVsLCBtaW5WYWx1ZSwgbWF4VmFsdWUsIGN1cnJlbnRWYWx1ZSwgY2hhbmdlSGFuZGxlcikgLT5cblx0XHR0d2Vha2VyU2xpZGVyID0gbmV3IFR3ZWFrZXJTbGlkZXJcblx0XHRcdHBhcmVudDogQFxuXHRcdFx0bGFiZWxUZXh0OiBsYWJlbFxuXHRcdFx0bWluVmFsdWU6IG1pblZhbHVlXG5cdFx0XHRtYXhWYWx1ZTogbWF4VmFsdWVcblx0XHRcdGN1cnJlbnRWYWx1ZTogY3VycmVudFZhbHVlXG5cblx0XHRAYWRkU2xpZGVyIHR3ZWFrZXJTbGlkZXJcblxuXHRcdGlmIGNoYW5nZUhhbmRsZXI/XG5cdFx0XHR0d2Vha2VyU2xpZGVyLnNsaWRlci5vbiBFdmVudHMuU2xpZGVyVmFsdWVDaGFuZ2UsIGNoYW5nZUhhbmRsZXJcblx0XHRcblxuXHRcdHJldHVybiB0d2Vha2VyU2xpZGVyXG5cblx0YWRkU2xpZGVyOiAoc2xpZGVyKSAtPlxuXHRcdEBzbGlkZXJzLnB1c2ggc2xpZGVyXG5cdFx0c2xpZGVyLnkgPSBAeVBvc1xuXHRcdEBhZGRJdGVtKHNsaWRlcilcblxuXHRjcmVhdGVCdXR0b246ICh0aXRsZSwgY2xpY2tIYW5kbGVyKSAtPlxuXHRcdGJ1dHRvbiA9IG5ldyBCdXR0b25cblx0XHRcdHRpdGxlOiB0aXRsZVxuXHRcdGJ1dHRvbi5vbiBFdmVudHMuVGFwLCBjbGlja0hhbmRsZXJcblxuXHRcdEBhZGRJdGVtKGJ1dHRvbilcblxuXHRjcmVhdGVTd2l0Y2g6ICh0aXRsZSwgdmFsdWUsIGNsaWNrSGFuZGxlcikgLT5cblx0XHRjb250YWluZXIgPSBuZXcgTGF5ZXIgXG5cdFx0XHRiYWNrZ3JvdW5kQ29sb3I6IG51bGxcblx0XHRcdGhlaWdodDogNDRcblx0XHRcdHdpZHRoOiBTY3JlZW4ud2lkdGggLSAxNlxuXHRcdFx0eDogMTZcblxuXHRcdHRvZ2dsZSA9IG5ldyBTd2l0Y2hcblx0XHRcdHBhcmVudDogY29udGFpbmVyXG5cdFx0XHRlbmFibGVkOiB2YWx1ZVxuXHRcdFx0eDogY29udGFpbmVyLndpZHRoIC0gNjdcblx0XHRcdHk6IDZcblxuXHRcdHRleHRMYWJlbCA9IG5ldyBUZXh0TGF5ZXJcblx0XHRcdHBhcmVudDogY29udGFpbmVyXG5cdFx0XHR0ZXh0OiB0aXRsZVxuXHRcdFx0Zm9udFNpemU6IDE3XG5cdFx0XHRmb250V2VpZ2h0OiA1MDBcblx0XHRcdGNvbG9yOiBcImJsYWNrXCJcblx0XHRcdHRleHRBbGlnbjogQWxpZ24ubGVmdFxuXHRcdFx0d2lkdGg6IGNvbnRhaW5lci53aWR0aCAtIDgzXG5cdFx0XHRsaW5lSGVpZ2h0OiAxXG5cdFx0XHR5OiBBbGlnbi5jZW50ZXJcblx0XHRcblx0XHRkaXZpZGVyID0gbmV3IExheWVyIFxuXHRcdFx0cGFyZW50OiBjb250YWluZXJcblx0XHRcdGJhY2tncm91bmRDb2xvcjogXCIjQzhDN0NDXCJcblx0XHRcdGhlaWdodDogMVxuXHRcdFx0d2lkdGg6IFNjcmVlbi53aWR0aFxuXHRcdFx0eDogMFxuXHRcdFx0eTogY29udGFpbmVyLmhlaWdodCAtIDFcblxuXHRcdHRvZ2dsZS5vbiBFdmVudHMuVGFwLCBjbGlja0hhbmRsZXJcblxuXHRcdEBhZGRJdGVtIGNvbnRhaW5lclxuXHRcdHRvZ2dsZVxuXG5cdG9wZW46ICgpIC0+XG5cdFx0QGFuaW1hdGVcblx0XHRcdHk6IDBcblx0XHRcdG9wdGlvbnM6XG5cdFx0XHRcdHRpbWU6IDAuMlxuXHRcdFx0XHRjdXJ2ZTogQmV6aWVyLmVhc2Vcblx0XHRAaXNPcGVuID0gdHJ1ZVxuXG5cdGNsb3NlOiAoKSAtPlxuXHRcdEBpc09wZW4gPSBmYWxzZVxuXHRcdEBhbmltYXRlXG5cdFx0XHR5OiAtQGhlaWdodFxuXHRcdFx0b3B0aW9uczpcblx0XHRcdFx0Y3VydmU6IEJlemllci5lYXNlXG5cdFx0XHRcdHRpbWU6IDAuMzVcblx0XHRAZW1pdCBUd2Vha2VyUGFuZWwuRGlkQ2xvc2Vcblx0dG9nZ2xlOiAoKSAtPlxuXHRcdGlmIEBpc09wZW5cblx0XHRcdEBjbG9zZSgpXG5cdFx0ZWxzZSBcblx0XHRcdEBvcGVuKClcblxuXG5cbmNsYXNzIFR3ZWFrZXJTbGlkZXIgZXh0ZW5kcyBMYXllciBcblxuXHRjb25zdHJ1Y3RvcjogKG9wdGlvbnMgPSB7fSkgLT5cblx0XHRvcHRpb25zLmJhY2tncm91bmRDb2xvciA/PSBudWxsXG5cdFx0c3VwZXIob3B0aW9ucylcblxuXHRcdEBkZWNpbWFscyA9IDBcblxuXHRcdEBjb250YWluZXIgPSBuZXcgTGF5ZXJcblx0XHRcdHBhcmVudDogQFxuXHRcdFx0YmFja2dyb3VuZENvbG9yOiBudWxsXG5cblx0XHRAbGFiZWwgPSBuZXcgVGV4dExheWVyXG5cdFx0XHRwYXJlbnQ6IEBjb250YWluZXJcblx0XHRcdGJhY2tncm91bmRDb2xvcjogbnVsbFxuXHRcdFx0dGV4dDogb3B0aW9ucy5sYWJlbFRleHRcblx0XHRcdGZvbnRTaXplOiAxMlxuXHRcdFx0Zm9udFdlaWdodDogNzAwXG5cdFx0XHRjb2xvcjogXCJibGFja1wiXG5cdFx0XHR0ZXh0QWxpZ246IEFsaWduLnJpZ2h0XG5cdFx0XHR3aWR0aDogMTAwXG5cdFx0XHRsaW5lSGVpZ2h0OiAxXG5cblx0XHRAc2xpZGVyID0gbmV3IFNsaWRlckNvbXBvbmVudFxuXHRcdFx0cGFyZW50OiBAY29udGFpbmVyXG5cdFx0XHR4OiAxMjBcblx0XHRcdHk6IDFcblx0XHRcdHdpZHRoOiAyMDBcblx0XHRcdG1pbjogb3B0aW9ucy5taW5WYWx1ZVxuXHRcdFx0bWF4OiBvcHRpb25zLm1heFZhbHVlXG5cdFx0XHR2YWx1ZTogb3B0aW9ucy5jdXJyZW50VmFsdWVcblxuXHRcdEBzbGlkZXIua25vYi5kcmFnZ2FibGUubW9tZW50dW0gPSBmYWxzZVxuXHRcdEBzbGlkZXIuZmlsbC5iYWNrZ3JvdW5kQ29sb3IgPSBcIiMwMDc4RDRcIlxuXHRcdEBzbGlkZXIub24gRXZlbnRzLlNsaWRlclZhbHVlQ2hhbmdlLCBAb25TbGlkZXJDaGFuZ2VkXG5cblx0XHRpZiBvcHRpb25zLmNoYW5nZUhhbmRsZXI/XG5cdFx0XHRAc2xpZGVyLm9uIEV2ZW50cy5TbGlkZXJWYWx1ZUNoYW5nZSwgb3B0aW9ucy5jaGFuZ2VIYW5kbGVyXG5cblx0XHRAaGVpZ2h0ID0gQHNsaWRlci5oZWlnaHRcblxuXHRcdEB2YWx1ZVRleHQgPSBuZXcgVGV4dExheWVyXG5cdFx0XHRwYXJlbnQ6IEBjb250YWluZXJcblx0XHRcdGJhY2tncm91bmRDb2xvcjogbnVsbFxuXHRcdFx0dGV4dDogQHNsaWRlci52YWx1ZVxuXHRcdFx0Zm9udFNpemU6IDEyXG5cdFx0XHRmb250V2VpZ2h0OiA3MDBcblx0XHRcdGNvbG9yOiBcImJsYWNrXCJcblx0XHRcdHRleHRBbGlnbjogQWxpZ24ucmlnaHRcblx0XHRcdHdpZHRoOiA1MFxuXHRcdFx0bGluZUhlaWdodDogMVxuXHRcdFx0eDogMzEwXG5cblx0b25TbGlkZXJDaGFuZ2VkOiAoZSkgPT5cblx0XHRAdmFsdWVUZXh0LnRleHQgPSBAZ2V0Q3VycmVudFZhbHVlKClcblxuXHRcdGlmIEB0cmFja2luZ09iamVjdD8gXG5cdFx0XHRAdHJhY2tpbmdPYmplY3RbQHRyYWNraW5nUHJvcGVydHldID0gQGdldEN1cnJlbnRWYWx1ZSgpXG5cblx0c2V0RmlsbENvbG9yOiAoY29sb3IpIC0+XG5cdFx0QHNsaWRlci5maWxsLmJhY2tncm91bmRDb2xvciA9IGNvbG9yXG5cblx0c2V0VHJhY2tDb2xvcjogKGNvbG9yKSAtPlxuXHRcdEBzbGlkZXIuYmFja2dyb3VuZENvbG9yID0gY29sb3JcblxuXHRzZXRDdXJyZW50VmFsdWU6ICh2YWx1ZSwgYW5pbWF0ZWQgPSB0cnVlKSAtPlxuXHRcdGlmIGFuaW1hdGVkIGlzIHRydWUgXG5cdFx0XHRAc2xpZGVyLmFuaW1hdGVUb1ZhbHVlIHZhbHVlXG5cdFx0ZWxzZVxuXHRcdFx0QHNsaWRlci52YWx1ZSA9IHZhbHVlXG5cblx0Z2V0Q3VycmVudFZhbHVlOiAoKSAtPlxuXHRcdHJldHVybiBVdGlscy5yb3VuZChAc2xpZGVyLnZhbHVlLCBAZGVjaW1hbHMpXG5cblx0c2V0RGVjaW1hbFBsYWNlczogKGRlY2ltYWxzKSAtPlxuXHRcdEBkZWNpbWFscyA9IGRlY2ltYWxzXG5cblx0YmluZFRvUHJvcGVydHlPZk9iamVjdDogKHByb3BlcnR5LCBvYmplY3QpIC0+XG5cdFx0QHRyYWNraW5nT2JqZWN0ID0gb2JqZWN0XG5cdFx0QHRyYWNraW5nUHJvcGVydHkgPSBwcm9wZXJ0eVxuXG5cbiIsImNsYXNzIGV4cG9ydHMuU3dpdGNoIGV4dGVuZHMgTGF5ZXJcblx0Y29uc3RydWN0b3I6IChvcHRpb25zID0ge30pIC0+XG5cdFx0c3VwZXIob3B0aW9ucylcblx0XHRAYmFja2dyb3VuZENvbG9yID0gbnVsbFxuXHRcdEBlbmFibGVkID0gb3B0aW9ucy5lbmFibGVkID8gdHJ1ZVxuXHRcdEBmaWxsQ29sb3IgPSBvcHRpb25zLmZpbGxDb2xvciA/IFwiIzAwNzhENFwiXG5cdFx0QGhlaWdodCA9IDMxXG5cdFx0QHdpZHRoID0gNTFcblxuXHRcdEBiZyA9IG5ldyBMYXllclxuXHRcdFx0cGFyZW50OiBAXG5cdFx0XHR3aWR0aDogQHdpZHRoXG5cdFx0XHRoZWlnaHQ6IEBoZWlnaHRcblx0XHRcdGJhY2tncm91bmRDb2xvcjogQGZpbGxDb2xvclxuXHRcdFx0Ym9yZGVyQ29sb3I6IEBmaWxsQ29sb3Jcblx0XHRcdGJvcmRlcldpZHRoOiAyXG5cdFx0XHRib3JkZXJSYWRpdXM6IChAaGVpZ2h0IC8gMilcblxuXHRcdEB0aHVtYiA9IG5ldyBMYXllclxuXHRcdFx0cGFyZW50OiBAXG5cdFx0XHR3aWR0aDogQGhlaWdodCAtIDRcblx0XHRcdGhlaWdodDogQGhlaWdodCAtIDRcblx0XHRcdGJhY2tncm91bmRDb2xvcjogXCIjRkZGXCJcblx0XHRcdGJvcmRlclJhZGl1czogQGhlaWdodCAvIDJcblx0XHRcdHNoYWRvd1k6IDJcblx0XHRcdHNoYWRvd0JsdXI6IDRcblx0XHRcdHNoYWRvd0NvbG9yOiBcInJnYmEoMCwwLDAsMC4zNSlcIlx0XG5cdFx0XHR4OiAyXG5cdFx0XHR5OiAyXG5cblx0XHRAZW5hYmxlIEBlbmFibGVkXG5cblx0XHRAb24gRXZlbnRzLlRhcCwgQHRvZ2dsZVxuXG5cdGVuYWJsZTogKGlzT24gPSB0cnVlKSA9PlxuXHRcdEBlbmFibGVkID0gaXNPblxuXHRcdGlmIEBlbmFibGVkXG5cdFx0XHRAdGh1bWIuYW5pbWF0ZVxuXHRcdFx0XHRtYXhYOiBAYmcud2lkdGggLSAyXG5cdFx0XHRcdG9wdGlvbnM6IFxuXHRcdFx0XHRcdHRpbWU6IDAuMVxuXHRcdFx0QGJnLmFuaW1hdGVcblx0XHRcdFx0YmFja2dyb3VuZENvbG9yOiBAZmlsbENvbG9yXG5cdFx0XHRcdGJvcmRlckNvbG9yOiBAZmlsbENvbG9yXG5cdFx0XHRcdG9wdGlvbnM6XG5cdFx0XHRcdFx0dGltZTogMC4xXG5cdFx0ZWxzZVxuXHRcdFx0QHRodW1iLmFuaW1hdGVcblx0XHRcdFx0eDogMlxuXHRcdFx0XHRvcHRpb25zOlxuXHRcdFx0XHRcdHRpbWU6IDAuMVxuXHRcdFx0QGJnLmFuaW1hdGVcblx0XHRcdFx0YmFja2dyb3VuZENvbG9yOiBcIiNGRkZcIlxuXHRcdFx0XHRib3JkZXJDb2xvcjogXCIjRTVFNUVBXCJcblx0XHRcdFx0b3B0aW9uczpcblx0XHRcdFx0XHR0aW1lOiAwLjFcblxuXHR0b2dnbGU6ICgpID0+XG5cdFx0QGVuYWJsZSghQGVuYWJsZWQpXG5cdFx0XG5cblxuXHRcdCIsIiMgQmFzaWMgQnV0dG9uIGNsYXNzIGZvciBUd2Vha2VyUGFuZWwgc3R1ZmZcbiMgVG8gYmUgaW1wcm92ZWQuLi5cblxuY2xhc3MgZXhwb3J0cy5CdXR0b24gZXh0ZW5kcyBMYXllciBcblxuXHRjb25zdHJ1Y3RvcjogKG9wdGlvbnMgPSB7fSkgLT5cblxuXHRcdG9wdGlvbnMuYmFja2dyb3VuZENvbG9yID89IFwid2hpdGVcIiAjXCIjMDA3OEQ0XCJcblx0XHRvcHRpb25zLmhlaWdodCA/PSA0MFxuXHRcdG9wdGlvbnMud2lkdGggPz0gMTAwXG5cdFx0b3B0aW9ucy5ib3JkZXJSYWRpdXMgPz0gb3B0aW9ucy5oZWlnaHQgLyAyXG5cdFx0b3B0aW9ucy5ib3JkZXJXaWR0aCA/PSAyXG5cblx0XHRzdXBlcihvcHRpb25zKVxuXG5cdFx0QG9wYWNpdHkgPSAwLjdcblxuXHRcdGNvbG9yID0gb3B0aW9ucy5jb2xvciA/IFwiYmxhY2tcIlxuXHRcdEBib3JkZXJDb2xvciA9IGNvbG9yXG5cblx0XHRmb250U2l6ZSA9IG9wdGlvbnMuZm9udFNpemUgPyAxN1xuXG5cdFx0QHRleHRMYWJlbCA9IG5ldyBUZXh0TGF5ZXJcblx0XHRcdHBhcmVudDogQFxuXHRcdFx0Zm9udFNpemU6IGZvbnRTaXplXG5cdFx0XHRmb250V2VpZ2h0OiA2MDBcblx0XHRcdHRleHQ6IG9wdGlvbnMudGl0bGVcblx0XHRcdHRleHRBbGlnbjogQWxpZ24uY2VudGVyXG5cdFx0XHRoZWlnaHQ6IGZvbnRTaXplICsgNlxuXHRcdFx0bWlkWTogQGhlaWdodCAvIDJcblx0XHRcdGF1dG9TaXplOiB0cnVlXG5cdFx0XHRjb2xvcjogY29sb3JcblxuXHRcdEB3aWR0aCA9IEB0ZXh0TGFiZWwud2lkdGggKyAzNlxuXHRcdEB0ZXh0TGFiZWwud2lkdGggPSBAd2lkdGhcblxuXHRcdEBvbiBFdmVudHMuTW91c2VEb3duLCBAb25Nb3VzZURvd25cblx0XHRAb24gRXZlbnRzLk1vdXNlVXAsIEBvbk1vdXNlVXBcblxuXHRvbk1vdXNlRG93bjogKGUpID0+XG5cdFx0QGFuaW1hdGVcblx0XHRcdG9wYWNpdHk6IDFcblx0XHRcdG9wdGlvbnM6IFxuXHRcdFx0XHR0aW1lOiAwLjFcblxuXHRvbk1vdXNlVXA6IChlKSA9PlxuXHRcdEBhbmltYXRlIFxuXHRcdFx0b3BhY2l0eTogMC43XG5cdFx0XHRvcHRpb25zOiBcblx0XHRcdFx0dGltZTogMC4xXG5cblx0IyBAZGVmaW5lIFwidGV4dENvbG9yXCIsXG5cdCMgXHRnZXQ6IC0+IHJldHVybiBAdGV4dExhYmVsLmNvbG9yXG5cdCMgXHRzZXQ6IChjb2xvcikgLT5cblx0IyBcdFx0QHRleHRMYWJlbC5jb2xvciA9IGNvbG9yXG5cdCMgXHRcdEBib3JkZXJDb2xvciA9IGNvbG9yXG5cblx0IyBzZXRTaXplOiAoc2l6ZSlcbiIsIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBSUFBO0FER0EsSUFBQTs7OztBQUFNLE9BQU8sQ0FBQzs7O0VBRUEsZ0JBQUMsT0FBRDtBQUVaLFFBQUE7O01BRmEsVUFBVTs7Ozs7TUFFdkIsT0FBTyxDQUFDLGtCQUFtQjs7O01BQzNCLE9BQU8sQ0FBQyxTQUFVOzs7TUFDbEIsT0FBTyxDQUFDLFFBQVM7OztNQUNqQixPQUFPLENBQUMsZUFBZ0IsT0FBTyxDQUFDLE1BQVIsR0FBaUI7OztNQUN6QyxPQUFPLENBQUMsY0FBZTs7SUFFdkIsd0NBQU0sT0FBTjtJQUVBLElBQUMsQ0FBQSxPQUFELEdBQVc7SUFFWCxLQUFBLHlDQUF3QjtJQUN4QixJQUFDLENBQUEsV0FBRCxHQUFlO0lBRWYsUUFBQSw4Q0FBOEI7SUFFOUIsSUFBQyxDQUFBLFNBQUQsR0FBaUIsSUFBQSxTQUFBLENBQ2hCO01BQUEsTUFBQSxFQUFRLElBQVI7TUFDQSxRQUFBLEVBQVUsUUFEVjtNQUVBLFVBQUEsRUFBWSxHQUZaO01BR0EsSUFBQSxFQUFNLE9BQU8sQ0FBQyxLQUhkO01BSUEsU0FBQSxFQUFXLEtBQUssQ0FBQyxNQUpqQjtNQUtBLE1BQUEsRUFBUSxRQUFBLEdBQVcsQ0FMbkI7TUFNQSxJQUFBLEVBQU0sSUFBQyxDQUFBLE1BQUQsR0FBVSxDQU5oQjtNQU9BLFFBQUEsRUFBVSxJQVBWO01BUUEsS0FBQSxFQUFPLEtBUlA7S0FEZ0I7SUFXakIsSUFBQyxDQUFBLEtBQUQsR0FBUyxJQUFDLENBQUEsU0FBUyxDQUFDLEtBQVgsR0FBbUI7SUFDNUIsSUFBQyxDQUFBLFNBQVMsQ0FBQyxLQUFYLEdBQW1CLElBQUMsQ0FBQTtJQUVwQixJQUFDLENBQUEsRUFBRCxDQUFJLE1BQU0sQ0FBQyxTQUFYLEVBQXNCLElBQUMsQ0FBQSxXQUF2QjtJQUNBLElBQUMsQ0FBQSxFQUFELENBQUksTUFBTSxDQUFDLE9BQVgsRUFBb0IsSUFBQyxDQUFBLFNBQXJCO0VBaENZOzttQkFrQ2IsV0FBQSxHQUFhLFNBQUMsQ0FBRDtXQUNaLElBQUMsQ0FBQSxPQUFELENBQ0M7TUFBQSxPQUFBLEVBQVMsQ0FBVDtNQUNBLE9BQUEsRUFDQztRQUFBLElBQUEsRUFBTSxHQUFOO09BRkQ7S0FERDtFQURZOzttQkFNYixTQUFBLEdBQVcsU0FBQyxDQUFEO1dBQ1YsSUFBQyxDQUFBLE9BQUQsQ0FDQztNQUFBLE9BQUEsRUFBUyxHQUFUO01BQ0EsT0FBQSxFQUNDO1FBQUEsSUFBQSxFQUFNLEdBQU47T0FGRDtLQUREO0VBRFU7Ozs7R0ExQ2lCOzs7O0FESDdCLElBQUE7Ozs7QUFBTSxPQUFPLENBQUM7OztFQUNBLGdCQUFDLE9BQUQ7QUFDWixRQUFBOztNQURhLFVBQVU7Ozs7SUFDdkIsd0NBQU0sT0FBTjtJQUNBLElBQUMsQ0FBQSxlQUFELEdBQW1CO0lBQ25CLElBQUMsQ0FBQSxPQUFELDJDQUE2QjtJQUM3QixJQUFDLENBQUEsU0FBRCwrQ0FBaUM7SUFDakMsSUFBQyxDQUFBLE1BQUQsR0FBVTtJQUNWLElBQUMsQ0FBQSxLQUFELEdBQVM7SUFFVCxJQUFDLENBQUEsRUFBRCxHQUFVLElBQUEsS0FBQSxDQUNUO01BQUEsTUFBQSxFQUFRLElBQVI7TUFDQSxLQUFBLEVBQU8sSUFBQyxDQUFBLEtBRFI7TUFFQSxNQUFBLEVBQVEsSUFBQyxDQUFBLE1BRlQ7TUFHQSxlQUFBLEVBQWlCLElBQUMsQ0FBQSxTQUhsQjtNQUlBLFdBQUEsRUFBYSxJQUFDLENBQUEsU0FKZDtNQUtBLFdBQUEsRUFBYSxDQUxiO01BTUEsWUFBQSxFQUFlLElBQUMsQ0FBQSxNQUFELEdBQVUsQ0FOekI7S0FEUztJQVNWLElBQUMsQ0FBQSxLQUFELEdBQWEsSUFBQSxLQUFBLENBQ1o7TUFBQSxNQUFBLEVBQVEsSUFBUjtNQUNBLEtBQUEsRUFBTyxJQUFDLENBQUEsTUFBRCxHQUFVLENBRGpCO01BRUEsTUFBQSxFQUFRLElBQUMsQ0FBQSxNQUFELEdBQVUsQ0FGbEI7TUFHQSxlQUFBLEVBQWlCLE1BSGpCO01BSUEsWUFBQSxFQUFjLElBQUMsQ0FBQSxNQUFELEdBQVUsQ0FKeEI7TUFLQSxPQUFBLEVBQVMsQ0FMVDtNQU1BLFVBQUEsRUFBWSxDQU5aO01BT0EsV0FBQSxFQUFhLGtCQVBiO01BUUEsQ0FBQSxFQUFHLENBUkg7TUFTQSxDQUFBLEVBQUcsQ0FUSDtLQURZO0lBWWIsSUFBQyxDQUFBLE1BQUQsQ0FBUSxJQUFDLENBQUEsT0FBVDtJQUVBLElBQUMsQ0FBQSxFQUFELENBQUksTUFBTSxDQUFDLEdBQVgsRUFBZ0IsSUFBQyxDQUFBLE1BQWpCO0VBL0JZOzttQkFpQ2IsTUFBQSxHQUFRLFNBQUMsSUFBRDs7TUFBQyxPQUFPOztJQUNmLElBQUMsQ0FBQSxPQUFELEdBQVc7SUFDWCxJQUFHLElBQUMsQ0FBQSxPQUFKO01BQ0MsSUFBQyxDQUFBLEtBQUssQ0FBQyxPQUFQLENBQ0M7UUFBQSxJQUFBLEVBQU0sSUFBQyxDQUFBLEVBQUUsQ0FBQyxLQUFKLEdBQVksQ0FBbEI7UUFDQSxPQUFBLEVBQ0M7VUFBQSxJQUFBLEVBQU0sR0FBTjtTQUZEO09BREQ7YUFJQSxJQUFDLENBQUEsRUFBRSxDQUFDLE9BQUosQ0FDQztRQUFBLGVBQUEsRUFBaUIsSUFBQyxDQUFBLFNBQWxCO1FBQ0EsV0FBQSxFQUFhLElBQUMsQ0FBQSxTQURkO1FBRUEsT0FBQSxFQUNDO1VBQUEsSUFBQSxFQUFNLEdBQU47U0FIRDtPQURELEVBTEQ7S0FBQSxNQUFBO01BV0MsSUFBQyxDQUFBLEtBQUssQ0FBQyxPQUFQLENBQ0M7UUFBQSxDQUFBLEVBQUcsQ0FBSDtRQUNBLE9BQUEsRUFDQztVQUFBLElBQUEsRUFBTSxHQUFOO1NBRkQ7T0FERDthQUlBLElBQUMsQ0FBQSxFQUFFLENBQUMsT0FBSixDQUNDO1FBQUEsZUFBQSxFQUFpQixNQUFqQjtRQUNBLFdBQUEsRUFBYSxTQURiO1FBRUEsT0FBQSxFQUNDO1VBQUEsSUFBQSxFQUFNLEdBQU47U0FIRDtPQURELEVBZkQ7O0VBRk87O21CQXVCUixNQUFBLEdBQVEsU0FBQTtXQUNQLElBQUMsQ0FBQSxNQUFELENBQVEsQ0FBQyxJQUFDLENBQUEsT0FBVjtFQURPOzs7O0dBekRvQjs7Ozs7QURBN0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBLDZCQUFBO0VBQUE7Ozs7QUFrREMsU0FBVSxPQUFBLENBQVEsYUFBUjs7QUFDVixTQUFVLE9BQUEsQ0FBUSxhQUFSOztBQUVMLE9BQU8sQ0FBQzs7O0VBRWIsWUFBQyxDQUFBLFFBQUQsR0FBWTs7RUFFQyxzQkFBQyxPQUFEOztNQUFDLFVBQVU7OztNQUV2QixPQUFPLENBQUMsUUFBUyxNQUFNLENBQUM7OztNQUN4QixPQUFPLENBQUMsa0JBQW1COzs7TUFDM0IsT0FBTyxDQUFDLGNBQWU7OztNQUN2QixPQUFPLENBQUMsY0FDUDtRQUFBLE1BQUEsRUFBUSxDQUFSOzs7SUFFRCw4Q0FBTSxPQUFOO0lBQ0EsSUFBQyxDQUFBLE1BQUQsR0FBVTtJQUNWLElBQUMsQ0FBQSxPQUFELEdBQVc7SUFDWCxJQUFDLENBQUEsSUFBRCxHQUFRO0lBQ1IsSUFBQyxDQUFBLE9BQUQsR0FBVztJQUNYLElBQUMsQ0FBQSxNQUFELEdBQVU7SUFFVixNQUFNLENBQUMsRUFBUCxDQUFVLE1BQU0sQ0FBQyxhQUFqQixFQUFnQyxDQUFBLFNBQUEsS0FBQTthQUFBLFNBQUMsQ0FBRCxHQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFoQztJQUdBLE1BQU0sQ0FBQyxnQkFBUCxDQUF3QixTQUF4QixFQUFtQyxDQUFBLFNBQUEsS0FBQTthQUFBLFNBQUMsQ0FBRDtRQUVsQyxJQUFHLENBQUMsQ0FBQyxPQUFGLEtBQWEsRUFBYixJQUFtQixDQUFDLENBQUMsT0FBRixLQUFhLEVBQW5DO2lCQUNDLEtBQUMsQ0FBQSxNQUFELENBQUEsRUFERDs7TUFGa0M7SUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQW5DO0VBbEJZOzt5QkF3QmIsT0FBQSxHQUFTLFNBQUMsSUFBRDtJQUNSLElBQUksQ0FBQyxNQUFMLEdBQWM7SUFDZCxJQUFJLENBQUMsQ0FBTCxHQUFTLElBQUMsQ0FBQTtJQUNWLElBQUMsQ0FBQSxJQUFELElBQVMsSUFBSSxDQUFDO0lBQ2QsSUFBQyxDQUFBLE1BQUQsR0FBVSxJQUFDLENBQUE7SUFDWCxJQUFBLENBQU8sSUFBQyxDQUFBLE1BQVI7TUFDQyxJQUFDLENBQUEsQ0FBRCxHQUFLLENBQUUsSUFBQyxDQUFBLE9BRFQ7O1dBRUE7RUFQUTs7eUJBU1QsWUFBQSxHQUFjLFNBQUMsS0FBRCxFQUFRLFFBQVIsRUFBa0IsUUFBbEIsRUFBNEIsWUFBNUIsRUFBMEMsYUFBMUM7QUFDYixRQUFBO0lBQUEsYUFBQSxHQUFvQixJQUFBLGFBQUEsQ0FDbkI7TUFBQSxNQUFBLEVBQVEsSUFBUjtNQUNBLFNBQUEsRUFBVyxLQURYO01BRUEsUUFBQSxFQUFVLFFBRlY7TUFHQSxRQUFBLEVBQVUsUUFIVjtNQUlBLFlBQUEsRUFBYyxZQUpkO0tBRG1CO0lBT3BCLElBQUMsQ0FBQSxTQUFELENBQVcsYUFBWDtJQUVBLElBQUcscUJBQUg7TUFDQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQXJCLENBQXdCLE1BQU0sQ0FBQyxpQkFBL0IsRUFBa0QsYUFBbEQsRUFERDs7QUFJQSxXQUFPO0VBZE07O3lCQWdCZCxTQUFBLEdBQVcsU0FBQyxNQUFEO0lBQ1YsSUFBQyxDQUFBLE9BQU8sQ0FBQyxJQUFULENBQWMsTUFBZDtJQUNBLE1BQU0sQ0FBQyxDQUFQLEdBQVcsSUFBQyxDQUFBO1dBQ1osSUFBQyxDQUFBLE9BQUQsQ0FBUyxNQUFUO0VBSFU7O3lCQUtYLFlBQUEsR0FBYyxTQUFDLEtBQUQsRUFBUSxZQUFSO0FBQ2IsUUFBQTtJQUFBLE1BQUEsR0FBYSxJQUFBLE1BQUEsQ0FDWjtNQUFBLEtBQUEsRUFBTyxLQUFQO0tBRFk7SUFFYixNQUFNLENBQUMsRUFBUCxDQUFVLE1BQU0sQ0FBQyxHQUFqQixFQUFzQixZQUF0QjtXQUVBLElBQUMsQ0FBQSxPQUFELENBQVMsTUFBVDtFQUxhOzt5QkFPZCxZQUFBLEdBQWMsU0FBQyxLQUFELEVBQVEsS0FBUixFQUFlLFlBQWY7QUFDYixRQUFBO0lBQUEsU0FBQSxHQUFnQixJQUFBLEtBQUEsQ0FDZjtNQUFBLGVBQUEsRUFBaUIsSUFBakI7TUFDQSxNQUFBLEVBQVEsRUFEUjtNQUVBLEtBQUEsRUFBTyxNQUFNLENBQUMsS0FBUCxHQUFlLEVBRnRCO01BR0EsQ0FBQSxFQUFHLEVBSEg7S0FEZTtJQU1oQixNQUFBLEdBQWEsSUFBQSxNQUFBLENBQ1o7TUFBQSxNQUFBLEVBQVEsU0FBUjtNQUNBLE9BQUEsRUFBUyxLQURUO01BRUEsQ0FBQSxFQUFHLFNBQVMsQ0FBQyxLQUFWLEdBQWtCLEVBRnJCO01BR0EsQ0FBQSxFQUFHLENBSEg7S0FEWTtJQU1iLFNBQUEsR0FBZ0IsSUFBQSxTQUFBLENBQ2Y7TUFBQSxNQUFBLEVBQVEsU0FBUjtNQUNBLElBQUEsRUFBTSxLQUROO01BRUEsUUFBQSxFQUFVLEVBRlY7TUFHQSxVQUFBLEVBQVksR0FIWjtNQUlBLEtBQUEsRUFBTyxPQUpQO01BS0EsU0FBQSxFQUFXLEtBQUssQ0FBQyxJQUxqQjtNQU1BLEtBQUEsRUFBTyxTQUFTLENBQUMsS0FBVixHQUFrQixFQU56QjtNQU9BLFVBQUEsRUFBWSxDQVBaO01BUUEsQ0FBQSxFQUFHLEtBQUssQ0FBQyxNQVJUO0tBRGU7SUFXaEIsT0FBQSxHQUFjLElBQUEsS0FBQSxDQUNiO01BQUEsTUFBQSxFQUFRLFNBQVI7TUFDQSxlQUFBLEVBQWlCLFNBRGpCO01BRUEsTUFBQSxFQUFRLENBRlI7TUFHQSxLQUFBLEVBQU8sTUFBTSxDQUFDLEtBSGQ7TUFJQSxDQUFBLEVBQUcsQ0FKSDtNQUtBLENBQUEsRUFBRyxTQUFTLENBQUMsTUFBVixHQUFtQixDQUx0QjtLQURhO0lBUWQsTUFBTSxDQUFDLEVBQVAsQ0FBVSxNQUFNLENBQUMsR0FBakIsRUFBc0IsWUFBdEI7SUFFQSxJQUFDLENBQUEsT0FBRCxDQUFTLFNBQVQ7V0FDQTtFQW5DYTs7eUJBcUNkLElBQUEsR0FBTSxTQUFBO0lBQ0wsSUFBQyxDQUFBLE9BQUQsQ0FDQztNQUFBLENBQUEsRUFBRyxDQUFIO01BQ0EsT0FBQSxFQUNDO1FBQUEsSUFBQSxFQUFNLEdBQU47UUFDQSxLQUFBLEVBQU8sTUFBTSxDQUFDLElBRGQ7T0FGRDtLQUREO1dBS0EsSUFBQyxDQUFBLE1BQUQsR0FBVTtFQU5MOzt5QkFRTixLQUFBLEdBQU8sU0FBQTtJQUNOLElBQUMsQ0FBQSxNQUFELEdBQVU7SUFDVixJQUFDLENBQUEsT0FBRCxDQUNDO01BQUEsQ0FBQSxFQUFHLENBQUMsSUFBQyxDQUFBLE1BQUw7TUFDQSxPQUFBLEVBQ0M7UUFBQSxLQUFBLEVBQU8sTUFBTSxDQUFDLElBQWQ7UUFDQSxJQUFBLEVBQU0sSUFETjtPQUZEO0tBREQ7V0FLQSxJQUFDLENBQUEsSUFBRCxDQUFNLFlBQVksQ0FBQyxRQUFuQjtFQVBNOzt5QkFRUCxNQUFBLEdBQVEsU0FBQTtJQUNQLElBQUcsSUFBQyxDQUFBLE1BQUo7YUFDQyxJQUFDLENBQUEsS0FBRCxDQUFBLEVBREQ7S0FBQSxNQUFBO2FBR0MsSUFBQyxDQUFBLElBQUQsQ0FBQSxFQUhEOztFQURPOzs7O0dBdEgwQjs7QUE4SDdCOzs7RUFFUSx1QkFBQyxPQUFEOztNQUFDLFVBQVU7Ozs7TUFDdkIsT0FBTyxDQUFDLGtCQUFtQjs7SUFDM0IsK0NBQU0sT0FBTjtJQUVBLElBQUMsQ0FBQSxRQUFELEdBQVk7SUFFWixJQUFDLENBQUEsU0FBRCxHQUFpQixJQUFBLEtBQUEsQ0FDaEI7TUFBQSxNQUFBLEVBQVEsSUFBUjtNQUNBLGVBQUEsRUFBaUIsSUFEakI7S0FEZ0I7SUFJakIsSUFBQyxDQUFBLEtBQUQsR0FBYSxJQUFBLFNBQUEsQ0FDWjtNQUFBLE1BQUEsRUFBUSxJQUFDLENBQUEsU0FBVDtNQUNBLGVBQUEsRUFBaUIsSUFEakI7TUFFQSxJQUFBLEVBQU0sT0FBTyxDQUFDLFNBRmQ7TUFHQSxRQUFBLEVBQVUsRUFIVjtNQUlBLFVBQUEsRUFBWSxHQUpaO01BS0EsS0FBQSxFQUFPLE9BTFA7TUFNQSxTQUFBLEVBQVcsS0FBSyxDQUFDLEtBTmpCO01BT0EsS0FBQSxFQUFPLEdBUFA7TUFRQSxVQUFBLEVBQVksQ0FSWjtLQURZO0lBV2IsSUFBQyxDQUFBLE1BQUQsR0FBYyxJQUFBLGVBQUEsQ0FDYjtNQUFBLE1BQUEsRUFBUSxJQUFDLENBQUEsU0FBVDtNQUNBLENBQUEsRUFBRyxHQURIO01BRUEsQ0FBQSxFQUFHLENBRkg7TUFHQSxLQUFBLEVBQU8sR0FIUDtNQUlBLEdBQUEsRUFBSyxPQUFPLENBQUMsUUFKYjtNQUtBLEdBQUEsRUFBSyxPQUFPLENBQUMsUUFMYjtNQU1BLEtBQUEsRUFBTyxPQUFPLENBQUMsWUFOZjtLQURhO0lBU2QsSUFBQyxDQUFBLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQXZCLEdBQWtDO0lBQ2xDLElBQUMsQ0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWIsR0FBK0I7SUFDL0IsSUFBQyxDQUFBLE1BQU0sQ0FBQyxFQUFSLENBQVcsTUFBTSxDQUFDLGlCQUFsQixFQUFxQyxJQUFDLENBQUEsZUFBdEM7SUFFQSxJQUFHLDZCQUFIO01BQ0MsSUFBQyxDQUFBLE1BQU0sQ0FBQyxFQUFSLENBQVcsTUFBTSxDQUFDLGlCQUFsQixFQUFxQyxPQUFPLENBQUMsYUFBN0MsRUFERDs7SUFHQSxJQUFDLENBQUEsTUFBRCxHQUFVLElBQUMsQ0FBQSxNQUFNLENBQUM7SUFFbEIsSUFBQyxDQUFBLFNBQUQsR0FBaUIsSUFBQSxTQUFBLENBQ2hCO01BQUEsTUFBQSxFQUFRLElBQUMsQ0FBQSxTQUFUO01BQ0EsZUFBQSxFQUFpQixJQURqQjtNQUVBLElBQUEsRUFBTSxJQUFDLENBQUEsTUFBTSxDQUFDLEtBRmQ7TUFHQSxRQUFBLEVBQVUsRUFIVjtNQUlBLFVBQUEsRUFBWSxHQUpaO01BS0EsS0FBQSxFQUFPLE9BTFA7TUFNQSxTQUFBLEVBQVcsS0FBSyxDQUFDLEtBTmpCO01BT0EsS0FBQSxFQUFPLEVBUFA7TUFRQSxVQUFBLEVBQVksQ0FSWjtNQVNBLENBQUEsRUFBRyxHQVRIO0tBRGdCO0VBdkNMOzswQkFtRGIsZUFBQSxHQUFpQixTQUFDLENBQUQ7SUFDaEIsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLEdBQWtCLElBQUMsQ0FBQSxlQUFELENBQUE7SUFFbEIsSUFBRywyQkFBSDthQUNDLElBQUMsQ0FBQSxjQUFlLENBQUEsSUFBQyxDQUFBLGdCQUFELENBQWhCLEdBQXFDLElBQUMsQ0FBQSxlQUFELENBQUEsRUFEdEM7O0VBSGdCOzswQkFNakIsWUFBQSxHQUFjLFNBQUMsS0FBRDtXQUNiLElBQUMsQ0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWIsR0FBK0I7RUFEbEI7OzBCQUdkLGFBQUEsR0FBZSxTQUFDLEtBQUQ7V0FDZCxJQUFDLENBQUEsTUFBTSxDQUFDLGVBQVIsR0FBMEI7RUFEWjs7MEJBR2YsZUFBQSxHQUFpQixTQUFDLEtBQUQsRUFBUSxRQUFSOztNQUFRLFdBQVc7O0lBQ25DLElBQUcsUUFBQSxLQUFZLElBQWY7YUFDQyxJQUFDLENBQUEsTUFBTSxDQUFDLGNBQVIsQ0FBdUIsS0FBdkIsRUFERDtLQUFBLE1BQUE7YUFHQyxJQUFDLENBQUEsTUFBTSxDQUFDLEtBQVIsR0FBZ0IsTUFIakI7O0VBRGdCOzswQkFNakIsZUFBQSxHQUFpQixTQUFBO0FBQ2hCLFdBQU8sS0FBSyxDQUFDLEtBQU4sQ0FBWSxJQUFDLENBQUEsTUFBTSxDQUFDLEtBQXBCLEVBQTJCLElBQUMsQ0FBQSxRQUE1QjtFQURTOzswQkFHakIsZ0JBQUEsR0FBa0IsU0FBQyxRQUFEO1dBQ2pCLElBQUMsQ0FBQSxRQUFELEdBQVk7RUFESzs7MEJBR2xCLHNCQUFBLEdBQXdCLFNBQUMsUUFBRCxFQUFXLE1BQVg7SUFDdkIsSUFBQyxDQUFBLGNBQUQsR0FBa0I7V0FDbEIsSUFBQyxDQUFBLGdCQUFELEdBQW9CO0VBRkc7Ozs7R0E3RUc7Ozs7QUQvSzVCLE9BQU8sQ0FBQyxLQUFSLEdBQWdCOztBQUVoQixPQUFPLENBQUMsVUFBUixHQUFxQixTQUFBO1NBQ3BCLEtBQUEsQ0FBTSx1QkFBTjtBQURvQjs7QUFHckIsT0FBTyxDQUFDLE9BQVIsR0FBa0IsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAifQ==
